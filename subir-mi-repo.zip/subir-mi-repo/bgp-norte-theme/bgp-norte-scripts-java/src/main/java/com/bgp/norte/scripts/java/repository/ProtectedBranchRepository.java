package com.bgp.norte.scripts.java.repository;

import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.models.Project;
import org.springframework.stereotype.Repository;

import lombok.extern.log4j.Log4j;

@Log4j
@Repository
public class ProtectedBranchRepository {

  public void protectBranch(GitLabApi gitLabApi, Project project, String wildcardName) {

    try {

      gitLabApi.getProtectedBranchesApi().protectBranch(project.getId(), wildcardName);

      log.info("Proyecto modificado " + project.getName());

    } catch (GitLabApiException e) {
      // TODO Auto-generated catch block
      log.info("Proyecto con error:" + project.getName());
      log.error("-> " + e);
    }

  }

  public void unprotectBranch(GitLabApi gitLabApi, Project project, String wildcardName) {

    try {

      gitLabApi.getProtectedBranchesApi().unprotectBranch(project.getId(), wildcardName);

      log.info("Proyecto modificado " + project.getName());

    } catch (GitLabApiException e) {
      // TODO Auto-generated catch block
      log.info("Proyecto con error:" + project.getName());
      log.error("-> " + e);
    }
    
  }
}
