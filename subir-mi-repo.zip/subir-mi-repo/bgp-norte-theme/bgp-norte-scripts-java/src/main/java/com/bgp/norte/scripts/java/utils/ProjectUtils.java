package com.bgp.norte.scripts.java.utils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.gitlab4j.api.models.Project;

public class ProjectUtils {

  public static ArrayList<Project> filterProjectWithProjectNameList(ArrayList<Project> projects,
      ArrayList<String> projectsName) {

    Stream<Project> stream = projects.stream();
    Set<String> setProjects = new HashSet<String>(projectsName);

    return stream.filter(p -> setProjects.contains(p.getName()))
        .collect(Collectors.toCollection(ArrayList::new));
  }

}
