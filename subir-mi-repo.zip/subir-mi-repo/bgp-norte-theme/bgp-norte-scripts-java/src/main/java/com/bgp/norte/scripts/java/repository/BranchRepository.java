package com.bgp.norte.scripts.java.repository;

import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.models.Project;
import org.springframework.stereotype.Repository;

import lombok.extern.log4j.Log4j;

@Log4j
@Repository
public class BranchRepository {

  public void createBranch(GitLabApi gitLabApi, Project project, String branchName, String from) {

    try {

      gitLabApi.getRepositoryApi().createBranch(project.getId(), branchName, from);

      log.info("Proyecto modificado " + project.getName());

    } catch (GitLabApiException e) {
      // TODO Auto-generated catch block
      log.info("Proyecto con error:" + project.getName());
      log.error("-> " + e);
    }

  }
  
  public void deleteBranch(GitLabApi gitLabApi, Project project, String branchName) {

    try {

      gitLabApi.getRepositoryApi().deleteBranch(project.getId(), branchName);

      log.info("Proyecto modificado " + project.getName());

    } catch (GitLabApiException e) {
      // TODO Auto-generated catch block
      log.info("Proyecto con error:" + project.getName());
      log.error("-> " + e);
    }

  }
}
