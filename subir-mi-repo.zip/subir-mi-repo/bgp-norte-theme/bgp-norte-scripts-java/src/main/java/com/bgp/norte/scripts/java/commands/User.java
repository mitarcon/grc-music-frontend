package com.bgp.norte.scripts.java.commands;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.shell.standard.ShellComponent;
import org.springframework.shell.standard.ShellMethod;
import org.springframework.shell.standard.ShellOption;

import com.bgp.norte.scripts.java.gitlab.service.UserService;

@ShellComponent
public class User {

  @Autowired
  private UserService userService;

  @Value("${gitlab.endpoint}")
  private String url;

  @Value("${gitlab.private-token}")
  private String privateTokenProperty;

  private final static String DEFAULT_PRIVATE_TOKEN = "";
  private final static String DEFAULT_USER_NAME = "";


  @ShellMethod("Working with user")
  public void user(
      @ShellOption(defaultValue = DEFAULT_PRIVATE_TOKEN, value = "--pt") String privateToken,
      @ShellOption(defaultValue = DEFAULT_USER_NAME, value = "--u") String userName) {

    if (DEFAULT_PRIVATE_TOKEN.equals(privateToken)) {

      privateToken = privateTokenProperty;
    }

    userService.getUser(url, privateToken, userName);
  }
}
