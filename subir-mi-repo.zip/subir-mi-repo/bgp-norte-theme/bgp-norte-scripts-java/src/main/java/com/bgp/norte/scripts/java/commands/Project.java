package com.bgp.norte.scripts.java.commands;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.shell.standard.ShellComponent;
import org.springframework.shell.standard.ShellMethod;
import org.springframework.shell.standard.ShellOption;

import com.bgp.norte.scripts.java.gitlab.service.ProjectService;

@ShellComponent
public class Project {


  @Autowired
  private ProjectService projectService;

  @Value("${gitlab.endpoint}")
  private String url;

  @Value("${gitlab.private-token}")
  private String privateTokenProperty;

  private final static String DEFAULT_PRIVATE_TOKEN = "";

  @ShellMethod("Working with project")
  public void project(
      @ShellOption(defaultValue = DEFAULT_PRIVATE_TOKEN, value = "--pt") String privateToken) {

    if (DEFAULT_PRIVATE_TOKEN.equals(privateToken)) {

      privateToken = privateTokenProperty;
    }


    projectService.getProjects(url, privateToken);
  }

}
