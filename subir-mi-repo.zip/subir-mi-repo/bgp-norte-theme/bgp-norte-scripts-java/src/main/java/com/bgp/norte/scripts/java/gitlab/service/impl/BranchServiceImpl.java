package com.bgp.norte.scripts.java.gitlab.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.models.Project;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bgp.norte.scripts.java.gitlab.service.BranchService;
import com.bgp.norte.scripts.java.gitlab.service.ProjectService;
import com.bgp.norte.scripts.java.repository.BranchRepository;

@Service
public class BranchServiceImpl implements BranchService {

  @Autowired
  private ProjectService projectService;

  @Autowired
  private BranchRepository branchRepository;

  @Override
  public void create(String url, String secretToken, ArrayList<String> projectsName,
      String nameBranch, String from) {

    GitLabApi gitLabApi = new GitLabApi(url, secretToken);

    List<Project> projects = projectService.getProjectsAndFilter(gitLabApi, projectsName);

    projects.forEach(project -> {

      branchRepository.createBranch(gitLabApi, project, nameBranch, from);

    });
  }

  @Override
  public void delete(String url, String secretToken, ArrayList<String> projectsName,
      String branchName) {

    GitLabApi gitLabApi = new GitLabApi(url, secretToken);

    List<Project> projects = projectService.getProjectsAndFilter(gitLabApi, projectsName);

    projects.forEach(project -> {

      branchRepository.deleteBranch(gitLabApi, project, branchName);

    });

  }

}
