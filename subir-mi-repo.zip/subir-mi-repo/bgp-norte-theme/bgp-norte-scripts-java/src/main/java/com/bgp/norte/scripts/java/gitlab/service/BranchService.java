package com.bgp.norte.scripts.java.gitlab.service;

import java.util.ArrayList;

public interface BranchService {

  void create(String url, String secretToken, ArrayList<String> projectsName, String nameBranch,
      String from);

  void delete(String url, String secretToken, ArrayList<String> projectsName, String branchName);

}
