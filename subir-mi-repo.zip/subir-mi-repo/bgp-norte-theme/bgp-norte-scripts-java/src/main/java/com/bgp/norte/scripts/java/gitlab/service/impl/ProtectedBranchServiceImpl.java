package com.bgp.norte.scripts.java.gitlab.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.models.Project;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bgp.norte.scripts.java.gitlab.service.ProjectService;
import com.bgp.norte.scripts.java.gitlab.service.ProtectedBranchService;
import com.bgp.norte.scripts.java.repository.ProtectedBranchRepository;

@Service
public class ProtectedBranchServiceImpl implements ProtectedBranchService {

  @Autowired
  private ProjectService projectService;
  
  @Autowired
  private ProtectedBranchRepository protectedBranchRepository;

  @Override
  public void createWildcard(String url, String secretToken, ArrayList<String> projectsName,
      String wildcardName) {
    // TODO Auto-generated method stub

    GitLabApi gitLabApi = new GitLabApi(url, secretToken);

    List<Project> projects = projectService.getProjectsAndFilter(gitLabApi, projectsName);

    projects.forEach(project -> {

        protectedBranchRepository.protectBranch(gitLabApi, project, wildcardName);
        
    });
  }

  @Override
  public void deleteWildcard(String url, String secretToken, ArrayList<String> projectsName,
      String wildcardName) {
    // TODO Auto-generated method stub

    GitLabApi gitLabApi = new GitLabApi(url, secretToken);

    List<Project> projects = projectService.getProjectsAndFilter(gitLabApi, projectsName);

    projects.forEach(project -> {
      
      protectedBranchRepository.unprotectBranch(gitLabApi, project, wildcardName);

    });

  }

}
