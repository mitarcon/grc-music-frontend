package com.bgp.norte.scripts.java.gitlab.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.Pager;
import org.gitlab4j.api.models.User;
import org.springframework.stereotype.Service;

import com.bgp.norte.scripts.java.gitlab.service.UserService;

import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class UserServiceImpl implements UserService {

  @Override
  public List<User> getUser(GitLabApi gitLabApi) {
    // TODO Auto-generated method stub

    Pager<User> pager = null;
    List<User> users = new ArrayList<User>();

    try {
      pager = gitLabApi.getUserApi().getUsers(10);

      while (pager.hasNext()) {

        for (User user : pager.next()) {
          users.add(user);
        }

      }

    } catch (Exception e) {
      // TODO: handle exception
      log.error(e);
    }

    return users;

  }

  public User getUser(String url, String privateToken, String userName) {

    GitLabApi gitLabApi = new GitLabApi(url, privateToken);
    List<User> users =
        getUser(gitLabApi).stream().filter(user -> user.getUsername().equals(userName))
            .collect(Collectors.toCollection(ArrayList::new));

    if (users.size() > 0) {

      log.info("Usuario es " + users.get(0).getUsername() + " id: " + users.get(0).getId());

      return users.get(0);

    } else {

      return null;
    }

  }

}
