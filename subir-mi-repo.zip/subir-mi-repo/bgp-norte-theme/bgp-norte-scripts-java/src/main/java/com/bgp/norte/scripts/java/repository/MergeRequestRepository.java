package com.bgp.norte.scripts.java.repository;

import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.models.MergeRequest;
import org.gitlab4j.api.models.Project;
import org.springframework.stereotype.Repository;

import lombok.extern.log4j.Log4j;

@Log4j
@Repository
public class MergeRequestRepository {

  public void createMergeRequest(GitLabApi gitLabApi, Project project, String sourceBranch,
      String targetBranch, String title, String description, boolean removeSourceBranch, int assigneeId) {

    
    try {
      
      MergeRequest mergeRequest;
      mergeRequest = gitLabApi.getMergeRequestApi().createMergeRequest(project.getId(), sourceBranch,
          targetBranch, title, "", assigneeId, null, null, null, removeSourceBranch);
      
      log.info(
          "Proyecto modificado " + project.getName() + " con MR id: " + mergeRequest.getIid());
      
    } catch (GitLabApiException e) {
      // TODO Auto-generated catch block
      log.info("Proyecto con error:" + project.getName());
      log.error("-> " + e);
    }


  }
}
