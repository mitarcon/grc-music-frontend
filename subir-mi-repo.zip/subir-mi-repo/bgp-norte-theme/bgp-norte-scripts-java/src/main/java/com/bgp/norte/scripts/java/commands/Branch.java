package com.bgp.norte.scripts.java.commands;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.shell.standard.ShellComponent;
import org.springframework.shell.standard.ShellMethod;
import org.springframework.shell.standard.ShellOption;
import org.springframework.util.StringUtils;

import com.bgp.norte.scripts.java.gitlab.service.BranchService;
import com.bgp.norte.scripts.java.utils.DocumentUtils;
import com.bgp.norte.scripts.java.utils.FileUtils;

import lombok.extern.log4j.Log4j;


@ShellComponent
@Log4j
public class Branch {

  @Value("${bgp.list-projects.name}")
  private String nameFileProject;

  @Value("${gitlab.endpoint}")
  private String url;

  @Value("${gitlab.private-token}")
  private String privateTokenProperty;

  @Autowired
  private BranchService branchService;

  @ShellMethod("Working with branch")
  public void branch(@ShellOption("--a") String action, @ShellOption("--r") String route,
      @ShellOption("--n") String name,
      @ShellOption(defaultValue="", value="--f") String fromName,
      @ShellOption("--pt") String privateToken) {

    log.trace(String.format(
        "Dentro de wildcard con ['action': %s, 'route': %s, 'privateToken': %s, 'name': %s, 'fromName': %s]",
        action, route, privateToken, name, fromName));


    File file = FileUtils.validateFileRoute(route);

    if (null == file) {
      return;
    }

    switch (action) {
      case "c":
        if (StringUtils.isEmpty(fromName)) {
          log.error("el parametro '--f' (desde el branch) no puede ser vacio cuando se va a crear");
        }
        branchService.create(url, privateToken, DocumentUtils.getProjectsFromFileSh(file), name,
            fromName);
        break;

      case "d":

        branchService.delete(url, privateToken, DocumentUtils.getProjectsFromFileSh(file), name);
        break;

      default:

        log.warn("action '" + action + "' no existe");
        break;
    }

  }


}
