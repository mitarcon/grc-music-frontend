package com.bgp.norte.scripts.java.gitlab.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.models.Project;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bgp.norte.scripts.java.gitlab.service.ProjectService;
import com.bgp.norte.scripts.java.repository.ProjectRepository;

@Service
public class ProjectServiceImpl implements ProjectService {

  @Autowired
  ProjectRepository projectRepository;

  @Override
  public List<Project> getProjects(GitLabApi gitLabApi) {
    // TODO Auto-generated method stub

    return projectRepository.getProjects(gitLabApi);
  }

  @Override
  public List<Project> getProjects(String url, String privateToken) {
    // TODO Auto-generated method stub

    return projectRepository.getProjects(url, privateToken);
  }

  @Override
  public List<Project> getProjectsAndFilter(GitLabApi gitLabApi, ArrayList<String> projectsName) {
    // TODO Auto-generated method stub

    return projectRepository.getProjectsAndFilter(gitLabApi, projectsName);
  }

}
