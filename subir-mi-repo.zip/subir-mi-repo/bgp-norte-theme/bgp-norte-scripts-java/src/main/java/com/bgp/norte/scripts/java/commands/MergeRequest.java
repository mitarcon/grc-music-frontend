package com.bgp.norte.scripts.java.commands;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.shell.standard.ShellComponent;
import org.springframework.shell.standard.ShellMethod;
import org.springframework.shell.standard.ShellOption;

import com.bgp.norte.scripts.java.gitlab.service.MergeRequestService;
import com.bgp.norte.scripts.java.utils.DocumentUtils;
import com.bgp.norte.scripts.java.utils.FileUtils;

import lombok.extern.log4j.Log4j;

@ShellComponent
@Log4j
public class MergeRequest {

  @Value("${bgp.list-projects.name}")
  private String nameFileProject;

  @Value("${gitlab.endpoint}")
  private String url;

  @Value("${gitlab.private-token}")
  private String privateTokenProperty;

  @Autowired
  private MergeRequestService mergeRequestService;

  private final static String DEFAULT_PRIVATE_TOKEN = "";
  private final static String DEFAULT_ROUTE = "";
  private final static String DEFAULT_REMOVE = "t";

  @ShellMethod("Working with mergerequest")
  public void mergerequest(@ShellOption("--a") String action,
      @ShellOption(defaultValue = DEFAULT_ROUTE, value = "--r") String route,
      @ShellOption("--f") String sourceBranch, @ShellOption("--t") String targetBranch,
      @ShellOption(defaultValue = DEFAULT_PRIVATE_TOKEN, value = "--pt") String privateToken,
      @ShellOption("--ti") String title,
      @ShellOption(defaultValue = DEFAULT_REMOVE, value = "--rmb") String removeSourceBranch,
      @ShellOption("--u") Integer assigneeId) {

    log.trace(String.format(
        "Dentro de wildcard con ['action': %s, 'route': %s, 'privateToken': %s, 'sourceBranch': %s, 'title': %s, 'targetBranch': %s, 'removeSourceBranch': %s, 'assigneeId': %s]",
        action, route, privateToken, sourceBranch, targetBranch, title, removeSourceBranch,
        assigneeId));

    if (DEFAULT_PRIVATE_TOKEN.equals(privateToken)) {

      privateToken = privateTokenProperty;
    }

    boolean bRemoveSourceBranch = false;

    if ("t".equals(removeSourceBranch)) {
      bRemoveSourceBranch = true;
    } else if ("f".equals(removeSourceBranch)) {
      bRemoveSourceBranch = false;
    } else {
      log.error(
          "el parametro --rmb representa removeSourceBranch y los valores permitidos son t o f");
    }

    File file = FileUtils.validateFileRoute(route);

    if (null == file) {
      return;
    }
    
    switch (action) {
      case "c":

        mergeRequestService.create(url, privateToken, DocumentUtils.getProjectsFromFileSh(file),
            sourceBranch, targetBranch, title, bRemoveSourceBranch, assigneeId);
        break;

      default:

        log.warn("action '" + action + "' no existe");
        break;
    }
  }
}
