package com.bgp.norte.scripts.java.gitlab.service;

import java.util.ArrayList;

public interface MergeRequestService {

  void create(String url, String secretToken, ArrayList<String> projectsName, String sourceBranch,
      String targetBranch, String title, boolean removeSourceBranch, int assigneeId);
}
