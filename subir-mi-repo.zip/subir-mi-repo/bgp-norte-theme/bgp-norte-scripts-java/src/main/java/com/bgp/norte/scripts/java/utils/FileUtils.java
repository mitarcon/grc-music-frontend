package com.bgp.norte.scripts.java.utils;

import java.io.File;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;


import lombok.extern.log4j.Log4j;

@Log4j
public class FileUtils {
  
  @Value("${bgp.list-projects.name}")
  private static String nameFileProject;
  
  private final static String DEFAULT_ROUTE = "";
  
  public static File validateFileRoute (String route) {
    
    File file;

    // Sino se recibe la ruta por parametro se tomara la del archivo de
    // configuracion
    if (!DEFAULT_ROUTE.equals(route)) {

      file = new File(route);

      if (!file.exists()) {

        log.warn("El archivo no existe");
        return null;
      }

      if (file.isDirectory()) {

        log.warn("La ruta es un directorio y debe ser un archivo");
        return null;
      }

    } else {

      // Uso el archivo que se encuentra en el property
      try {

        file = new ClassPathResource(nameFileProject).getFile();

      } catch (IOException e) {
        log.error("Falla con la ruta: " + nameFileProject);
        log.error(e.toString());
        return null;
      }

    }    
    
    return file;
  }
}
