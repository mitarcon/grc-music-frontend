package com.bgp.norte.scripts.java.repository;

public class UserRepository {

}
