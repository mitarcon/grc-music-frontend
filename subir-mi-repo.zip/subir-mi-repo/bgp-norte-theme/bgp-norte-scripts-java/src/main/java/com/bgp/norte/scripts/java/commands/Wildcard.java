package com.bgp.norte.scripts.java.commands;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.shell.standard.ShellComponent;
import org.springframework.shell.standard.ShellMethod;
import org.springframework.shell.standard.ShellOption;

import com.bgp.norte.scripts.java.gitlab.service.ProtectedBranchService;
import com.bgp.norte.scripts.java.utils.DocumentUtils;
import com.bgp.norte.scripts.java.utils.FileUtils;

import lombok.extern.log4j.Log4j;

@ShellComponent
@Log4j
public class Wildcard {

  @Autowired
  private ProtectedBranchService protectedBranchService;

  @Value("${bgp.list-projects.name}")
  private String nameFileProject;

  @Value("${gitlab.endpoint}")
  private String url;

  @Value("${gitlab.private-token}")
  private String privateTokenProperty;

  private final static String DEFAULT_ROUTE_WILDCARD = "";
  private final static String DEFAULT_PRIVATE_TOKEN = "";

  @ShellMethod("Working with wildcard")
  public void wildcard(@ShellOption("--a") String action,
      @ShellOption(defaultValue = DEFAULT_ROUTE_WILDCARD, value = "--r") String route,
      @ShellOption("--n") String name,
      @ShellOption(defaultValue = DEFAULT_PRIVATE_TOKEN, value = "--pt") String privateToken) {

    log.trace(String.format(
        "Dentro de wildcard con ['action': %s, 'route': %s, 'name': %s, 'privateToken': %s]",
        action, route, name, privateToken));

    if (DEFAULT_PRIVATE_TOKEN.equals(privateToken)) {

      privateToken = privateTokenProperty;
    }

    File file = FileUtils.validateFileRoute(route);

    if (null == file) {
      return;
    }

    switch (action) {
      case "c":
        
        protectedBranchService.createWildcard(url, privateToken, DocumentUtils.getProjectsFromFileSh(file), name);
        break;

      case "d":

        protectedBranchService.deleteWildcard(url, privateToken, DocumentUtils.getProjectsFromFileSh(file), name);
        break;

      default:

        log.warn("action '" + action + "' no existe");
        break;
    }

  }

}
