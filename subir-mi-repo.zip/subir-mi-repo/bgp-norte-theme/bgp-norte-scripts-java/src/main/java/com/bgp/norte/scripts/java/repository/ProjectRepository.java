package com.bgp.norte.scripts.java.repository;

import java.util.ArrayList;
import java.util.List;

import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.Pager;
import org.gitlab4j.api.models.Project;
import org.springframework.stereotype.Repository;

import com.bgp.norte.scripts.java.utils.ProjectUtils;

import lombok.extern.log4j.Log4j;

@Log4j
@Repository
public class ProjectRepository {

  public List<Project> getProjects(GitLabApi gitLabApi) {
    // TODO Auto-generated method stub
    List<Project> output = new ArrayList<Project>();
    Pager<Project> pager = null;

    try {
      pager = gitLabApi.getProjectApi().getProjects(100);

      while (pager.hasNext()) {
        for (Project project : pager.next()) {
          output.add(project);
        }
      }


    } catch (Exception e) {
      // TODO: handle exception
      log.error(e);
    }

    return output;
  }

  public List<Project> getProjects(String url, String privateToken) {
    // TODO Auto-generated method stub

    GitLabApi gitLabApi = new GitLabApi(url, privateToken);
    return getProjects(gitLabApi);

  }

  public List<Project> getProjectsAndFilter(GitLabApi gitLabApi, ArrayList<String> projectsName) {
    // TODO Auto-generated method stub

    List<Project> projects = getProjects(gitLabApi);
    log.trace("Total de proyectos en servidor " + projects.size());

    // Limpio la lista de proyectos
    projects = ProjectUtils.filterProjectWithProjectNameList(new ArrayList<Project>(projects),
        projectsName);
    log.info("Total de proyectos luego de filtrados " + projects.size());

    return projects;
  }
  
}
