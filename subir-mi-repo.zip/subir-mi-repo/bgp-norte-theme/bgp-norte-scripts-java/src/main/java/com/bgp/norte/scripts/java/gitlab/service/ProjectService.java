package com.bgp.norte.scripts.java.gitlab.service;

import java.util.ArrayList;
import java.util.List;

import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.models.Project;

public interface ProjectService {

  List<Project> getProjects(String url, String secretToken);

  List<Project> getProjects(GitLabApi gitLabApi);

  List<Project> getProjectsAndFilter(GitLabApi gitLabApi, ArrayList<String> projectsName);

}
