package com.bgp.norte.scripts.java.gitlab.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.models.Project;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bgp.norte.scripts.java.gitlab.service.MergeRequestService;
import com.bgp.norte.scripts.java.gitlab.service.ProjectService;
import com.bgp.norte.scripts.java.repository.MergeRequestRepository;

@Service
public class MergeRequestServiceImpl implements MergeRequestService {

  @Autowired
  private ProjectService projectService;

  @Autowired
  private MergeRequestRepository mergeRequestRepository;

  @Override
  public void create(String url, String secretToken, ArrayList<String> projectsName,
      String sourceBranch, String targetBranch, String title, boolean removeSourceBranch,
      int assigneeId) {
    // TODO Auto-generated method stub

    GitLabApi gitLabApi = new GitLabApi(url, secretToken);

    List<Project> projects = projectService.getProjectsAndFilter(gitLabApi, projectsName);

    projects.forEach(project -> {

      mergeRequestRepository.createMergeRequest(gitLabApi, project, sourceBranch, targetBranch,
          title, "", removeSourceBranch, assigneeId);
    });
  }

}
