package com.bgp.norte.scripts.java.gitlab.service;

import java.util.List;

import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.models.User;

public interface UserService {

  List<User> getUser(GitLabApi gitLabApi);

  User getUser(String url, String privateToken, String userName);

}
