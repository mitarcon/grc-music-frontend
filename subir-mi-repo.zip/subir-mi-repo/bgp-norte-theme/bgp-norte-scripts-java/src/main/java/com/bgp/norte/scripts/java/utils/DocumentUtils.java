package com.bgp.norte.scripts.java.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class DocumentUtils {

  private static final Logger logger = LogManager.getLogger(DocumentUtils.class);
  public static final String raizProject = "bgp-norte-";

  public static ArrayList<String> getProjectsFromFileSh(File file) {

    ArrayList<String> projectsName = new ArrayList<String>();

    if (null != file) {

      FileReader fr = null;
      BufferedReader br = null;

      try {
        fr = new FileReader(file);
        br = new BufferedReader(fr);

        String linea;
        int start;

        while (null != (linea = br.readLine())) {
          start = linea.indexOf(raizProject);

          if (-1 < start) {

            projectsName.add(linea.substring(start, linea.indexOf("\"", start + 1)));
          }

        }

      } catch (Exception e) {
        logger.error(e.toString());
      }
    }

    return projectsName;
  }

}
