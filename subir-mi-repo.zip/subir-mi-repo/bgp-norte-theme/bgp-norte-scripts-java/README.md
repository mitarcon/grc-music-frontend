# Scripts

## Script para ejecutar acciones masivas en gitlab  
  
* Wildcard 
  
*Ej: $> wildcard --n nuevoWildcard --a c*  
   
**Parametros**  
1. --a (action) : Acción a ejecutar con las opciones ['c': crear, 'd': eliminar]  
2. --r (ruta)  : Ruta donde se encuentra la lista de proyectos con los que se va a trabajar (La estructura debe ser igual al archivo   [variables.sh](http://gitlab.bgeneral.com/dxp/bgp-norte-scripts/blob/dev/variables.sh))  
3. --n (nombre) : Nombre del wildcard a crear  
4. --pt (private token) : token generado para gitlab para permitir ejecución  

* Branch 
  
*Ej: $> branch --n nuevoBranch --f tagSelected --a c*  

**Parametros**  
1. --a (action) : Acción a ejecutar con las opciones ['c': crear]  
2. --r (ruta)  : Ruta donde se encuentra la lista de proyectos con los que se va a trabajar (La estructura debe ser igual al archivo   [varialbes.sh](http://gitlab.bgeneral.com/dxp/bgp-norte-scripts/blob/dev/variables.sh))  
3. --n (nombre) : Nombre del branch a crear  
4. --pt (private token) : token generado para gitlab para permitir ejecución  
5. --f (origen) : Branch a partir del cual vamos a crear  

* Merge Request

*Ej: $> mergerequest --a c --f sourceBranch --t targetBranch --pt privateToken --ti title --rmb t --a f --u 0 --pt XXXXXXXXXXXXXXXXXXXXXXXXXr

**Parametros**  E
1. --a (action) : Acción a ejecutar con las opciones ['c': crear]  
2. --r (ruta)  : Ruta donde se encuentra la lista de proyectos con los que se va a trabajar (La estructura debe ser igual al archivo   [varialbes.sh](http://gitlab.bgeneral.com/dxp/bgp-norte-scripts/blob/dev/variables.sh))  
3. --f (sourceBranch) : Branch de origen

4. --t (targetBranch) : Branch destino
5. --pt (private token) : token generado para gitlab para permitir ejecución  
6. --ti (title) : Titulo del MR
7. --rmb (removeSourceBranch) : Remover branch con las opciones ['t': si, 'f': n]
9. --u (assigneeId) : Usuario a asignar el branch

* User

*Ej: $> user --u jllinares --pt XXXXXXXXXXXXXXXXXXXXXXXXXr

**Parametros**  

1. --u (userName) : Username a consultar 