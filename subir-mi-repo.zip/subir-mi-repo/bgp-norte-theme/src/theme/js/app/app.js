/* globals angular, appName */

(function(win) {
  "use strict";

  //
  // Application Main File
  //

  //
  // These Modules Will be Shared Between Portlets.
  // This is the setup for all custom modules.
  //
  win.MainApp.Controllers = angular.module(appName + ".controllers", []);
  win.MainApp.Directives = angular.module(appName + ".directives", []);
  win.MainApp.Services = angular.module(appName + ".services", []);
  win.MainApp.Filters = angular.module(appName + ".filters", []);
  win.MainApp.Values = angular.module(appName + ".values", []);
  win.MainApp.Factory = angular.module(appName + ".factory", []);

  //
  // Setup Common Modules
  //
  angular
    .module(appName, [
      appName + ".controllers",
      appName + ".directives",
      appName + ".services",
      appName + ".filters",
      appName + ".values",
      appName + ".factory",
      'autoComplete',
      'ngSanitize',
      'ui.router',
      'ngMessages',
      'ui.bootstrap',
      'aa.formExtensions',
      'ngStorage',
      'ngTable',
      'nya.bootstrap.select',
      'Mac',
      'ng-currency',
      'ngAnimate',
      'ui.select',
      'ngFileUpload',
      'rzModule',
      'ngPatternRestrict',
      'btorfs.multiselect'
    ]);

  //Adding config for angular agility
  angular.module(appName).run(['formConfig', function(formConfig) {
    formConfig.init();
  }]);

  angular.module(appName).config(['nyaBsConfigProvider',
    function (nyaBsConfig) {

      var localeId = 'es-ES';

      var configObj = {
          defaultNoneSelection: 'No has seleccionado nada',
          noSearchResult: '0 resultados encontrados',
          numberItemSelected: '%d elementos seleccionados',
          selectAll: 'Selecciona todo',
          deselectAll: 'Desmarca todo'
        };

      nyaBsConfig.setLocalizedText(localeId, configObj);
      nyaBsConfig.useLocale(localeId);

    }
  ]);

  angular
    .module(appName).config(['$httpProvider', '$sessionStorageProvider',
    function($httpProvider, storage) {
      //
      // Custom Providers and Common Config goes here
      //
      //initialize get if not there
	  $httpProvider.interceptors.push(['$q', function ($q) {
        return {
          'request': function (config) {

            var token = storage.get('ngsesid');

            if (token) {
              config.headers.ngsesid = token;
            }

            return config || $q.when(config);

          },
          'response': function (response) {

            var token = response.headers().ngsesid;

            if (token) {
              storage.set('ngsesid', token);
            }

            return response;

          },
          'responseError': function (response) {

            if (response.status === 404 &&
              response.data.indexOf('<html') >= 0) {

              window.location.assign('/');

              return $q.resolve(response);
            }

            if (response.status === 417) {

              window.location.assign('/c/portal/logout');

              return $q.resolve(response);
            }

            return $q.reject(response);

          }
        };
      }]);


      if (!$httpProvider.defaults.headers.get) {
        $httpProvider.defaults.headers.get = {};
      }

      // DISABLE HTTP CACHES
      $httpProvider.defaults.headers.get['If-Modified-Since'] = 'Sat, 12 May 1979 12:00:00 GMT';
      $httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
      $httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
    // END - DISABLE HTTP CACHES
    }]).run([
    '$log',
    '$window',
    'stateKeeperService',
    'UiSelectSelectizeGroupedTemplate',
    '$transitions', function($log, $window, stateKeeperService, UiSelectSelectizeGroupedTemplate, $transitions) {

      $log.debug("[Liferay/Angular] Initializing " + appName + "...");

      // Add a new ui-select template
      UiSelectSelectizeGroupedTemplate.add();

      $transitions.onSuccess({}, function(transition) {

        if (transition.from() && transition.params().historyStateData) {
          stateKeeperService.set({
            name: transition.from().name,
            data: transition.params().historyStateData
          });
        }
      });

    }]);
}(window));
