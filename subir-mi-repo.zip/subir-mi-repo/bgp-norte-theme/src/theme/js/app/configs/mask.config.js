/* globals angular, appName */

(function () {
  "use strict";

  var app = angular.module(appName);

  var decorateDirective = function(directiveName, preLinkFn) {
    app.config(function($provide) {
      $provide.decorator(directiveName + 'Directive', function($delegate) {
        var originalLinkFn = $delegate[0].link;

        $delegate[0].compile = function(tElem, tAttr) {
          return function newLinkFn(scope, element, attrs, controller) {
            preLinkFn(scope, element, attrs, controller);
            originalLinkFn.apply($delegate[0], arguments);
          };
        };

        delete $delegate[0].link;
        return $delegate;
      });
    });
  };

  // Prevent IE bug when user press ctrl+z in masked fields
  if (/MSIE|Trident/.test(navigator.userAgent)) {

    var bindCtrlZProtections = function(scope, element) {

      // Overrides the undo shortcut behavior to clear the field
      element.on('keydown', function(e) {
        var isCtrlZ = e.which === 90 && e.ctrlKey;

        if (isCtrlZ) {
          element.val('');
          e.preventDefault();
          return false;
        }
      });

      // Keeps the maxLength if undo is performed using the menu
      element.on('input', function(e) {
        var maxlength = element.attr('maxlength');

        if (maxlength !== undefined && element.val().length > maxlength)
          element.val(element.val().slice(0, maxlength));
      });
    };

    decorateDirective('uiNumberMask', bindCtrlZProtections);
    decorateDirective('uiMoneyMask', bindCtrlZProtections);
    decorateDirective('uiPercentageMask', bindCtrlZProtections);
    decorateDirective('uiDateMask', bindCtrlZProtections);
    decorateDirective('uiTimeMask', bindCtrlZProtections);
  }

}());
