
(function() {

  Date.prototype.toJSON = function() {
    return moment(this).format("YYYY-MM-DDTHH:mm:ss");
  };

}());
