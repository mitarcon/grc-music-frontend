/* globals MainApp */
(function (win) {
  "user strict";

  function CapitalizeFilter() {
    return function (input, all) {
      return (!!input) ? input.replace(/([^\W_]+[^]*) */g, function(txt) {
        return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
      }):'';
    }
  };

  win.MainApp.Filters.filter('capitalize', CapitalizeFilter);
}(window));