(function(win) {
  "use strict";

  /*
   * ==================== reasonCatalogFilter ====================
   */
  function reasonCatalogFilter( catalogService, isEmpty ) {
    
    return function(value, project, status, stage){
      
      var reasonCat = catalogService.get(value, project);
      
      var matchReasons = [];
      
      angular.forEach(reasonCat, function(reason){
        
        if(String(reason.status.id) === String(status) &&
          (
            String(reason.stage.id) === String(stage) ||
            String(reason.stage.id) === "*"
          )
          ){
          
            if(!isEmpty(reason.quoteRecordReasonSubGroup)){
                
              angular.forEach(reason.quoteRecordReasonSubGroup,
                function(reasonGroup){
                  
                  matchReasons.push(reasonGroup);
                });
          
            }else{

              matchReasons.push(reason);
            }
          
          }
              
      });
      
      return matchReasons;
    };
  }
  reasonCatalogFilter.$inject = [ 'catalogService', 'isEmptyFilter' ];
  win.MainApp.Filters.filter('reasonCatalog', reasonCatalogFilter);
  
}(window));
