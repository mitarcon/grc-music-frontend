/* globals MainApp */

(function (win) {
  "use strict";

  function BgpUrlsFilter(bgpUrls) {
    return function (input, args) {
      if (!bgpUrls.hasOwnProperty(input))
        throw new Error('Unknown bgpUrls key: ' + input);

      return bgpUrls[input];
    };
  }

  BgpUrlsFilter.$inject = ['bgpUrls'];

  win.MainApp.Filters.filter('url', BgpUrlsFilter);

}(window));
