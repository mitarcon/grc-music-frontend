(function(win){
  'use strict';

  /*
  ====================
  contactFilter
  ====================
  */

  var contact = function(log, contactUtils){

    log.debug('[contactFilter] Initializing...');

    return function(contacts,code){
      return contactUtils.firstContactOfType(code, contacts).valor;
    };
  };
  contact.$inject = ['$log', 'contactUtils'];
  win.MainApp.Filters
    .filter('contact', contact);

  /*
  ====================
  isEmptyFilter
  ====================
  */

  var isEmpty = function(log){

    log.debug('[isEmptyFilter] Initializing...');

    return function (obj) {
      return angular.isUndefined(obj) || obj === '' || obj === null ||
      (typeof  obj === 'object' && !angular.isDate(obj) &&
      Object.keys(obj).length === 0);
    };
  };
  isEmpty.$inject = ['$log'];
  win.MainApp.Filters
    .filter('isEmpty', isEmpty);

  /*
  ====================
  cedFilter
  ====================
  */

  var ced = function (log) {

    log.debug('[cedFilter] Initializing...');

    var getIdPart = function (ced, begin, end) {
      var idPart = ced.substring(begin, end).trim();
      if (idPart === '00' || idPart === '') {
        return '';
      } else if (isNaN(parseInt(idPart))) {
        return idPart + '-';
      } else {
        return parseInt(idPart) + '-';
      }
    };
    return function (identification) {
      if(angular.isDefined(identification)) {
        var document = identification.trim();
        var province = getIdPart(document, 0, 2);
        var alpha = getIdPart(document, 2,  4);

        return province + alpha +
          parseInt(document.substring(4, 8).trim()) + '-' +
          parseInt(document.substring(8, 14).trim());
      }
      return '';
    };
  };
  ced.$inject = ['$log'];
  win.MainApp.Filters
    .filter('ced', ced);

  /*
  ====================
  accountFilter
  ====================
  */

  var account = function($log,isEmpty){ //', ['isEmptyFilter', function (isEmpty) {

    $log.debug('[accountFilter] Initializing...');

    return function (account) {
      if (!isEmpty(account)) {
        var acc = account.trim();
        return acc.substring(0,2) + '-' +
               acc.substring(2, 4) + '-' +
               acc.substring(4, 6) + '-' +
               acc.substring(6, 12) + '-' +
               acc.substring(12, 13);
      }
      return '';
    };
  };
  account.$inject = ['$log','isEmptyFilter'];
  win.MainApp.Filters
    .filter('account', account);

  /*
  ====================
  buildAccountListFilter
  ====================
  */

  var buildAccountList = function ($log,isEmpty, accountFilter) {

    $log.debug('[buildAccountListFilter] Initializing...');

      return function (account, name){
        if (!(isEmpty(account) || isEmpty(name))){
          return accountFilter(account) + ' • ' + name;
        }
        return '';
    };
  };
  buildAccountList.$inject = ['$log','isEmptyFilter', 'accountFilter'];
  win.MainApp.Filters
    .filter('buildAccountList',buildAccountList);

  /*
  ====================
  ctplFilter
  ====================
  */

  var ctpl = function (log, filter, templates) {

    log.debug('[ctplFilter] Initializing...');

    return function (name) {
      return filter('filter')(templates, function (template) {
        return template.name === name;
      })[0].url;
    };

  };
  ctpl.$inject = ['$log', '$filter', 'commonTemplates'];
  win.MainApp.Filters
    .filter('ctpl',ctpl);

  /*
  ====================
  npFilter
  ====================
  */

  var np = function ($log, namespace) {
    $log.debug('[npFilter] Initializing...');
    return function (name, index) {
      var result = namespace + name;
      if (angular.isDefined(index)) {
        result += '_' + index;
      }
      return result;
    };
  };
  np.$inject = ['$log', 'namespace'];
  win.MainApp.Filters
    .filter('np', np);


  /*
  ====================
  addEleArrayFilter
  ====================
  */

  var addEleArray = function ($log) {
    $log.debug('[addEleArray] Initializing...');
    return function (array, ele) {
      array = angular.copy(array);
      if(array.indexOf(ele) === -1){
        array.unshift(ele);
      }
      return array;
    };
  };
  np.$inject = ['$log'];
  win.MainApp.Filters
    .filter('addEleArray', addEleArray);

  /*
  ====================
  arrToStringFilter
  ====================
  */

  var arrToString = function($log, filter) {
    $log.debug('[arrToStringFilter] Initializing...');
    return function(dirtyArray, token) {
      var cleanArray = filter(dirtyArray, function(item) {
         return angular.isDefined(item);
      });
      return cleanArray.join(token);
    };
  };
  arrToString.$inject = ['$log', 'filterFilter'];
  win.MainApp.Filters
    .filter('arrToString', arrToString);

  /*
  ====================
  completedContactsFilter
  ====================
  */

  var completedContacts = function (log, filter) {

    log.debug('[completedContactsFilter] Initializing...');

    return function(contacts) {
      return filter(contacts, function (contact) {
        return contact.name !== "";
      });
    };
  };
  completedContacts.$inject = ['$log', 'filterFilter'];
  win.MainApp.Filters
    .filter('completedContacts', completedContacts);

  /*
  ====================
  sumByKeyFilter
  ====================
  */

  var sumByKey = function(log) {

    log.debug('[sumByKeyFilter] Initializing...');

    return function(data, key) {
      if (typeof(data) === 'undefined' || typeof(key) === 'undefined') {
        return 0;
      }
      var sum = 0;
      for (var i = data.length - 1; i >= 0; i--) {
        sum += parseFloat(data[i][key]);
      }
      return sum;
    };
  };
  sumByKey.$inject = ['$log'];
  win.MainApp.Filters
    .filter('sumByKey', sumByKey);

  /*
  ====================
  uniqueFilter
  ====================
  */

  var unique = function(log) {

    log.debug('[uniqueFilter] Initializing...');

    return function(collection, keyname) {
      var output = [],
      keys = [];
      angular.forEach(collection, function(item) {
        var key;
        if (angular.isDefined(item[keyname].id)){
          key = item[keyname].id;
        }else{
          key = item[keyname];
        }

        if(keys.indexOf(key) === -1) {
          keys.push(key);
          output.push(item);
        }
      });

      return output;
    };
  };
  unique.$inject = ['$log'];
  win.MainApp.Filters
    .filter('unique', unique);

    /*
    ====================
    BGTrim
    ====================
    */

  var bgTrim = function(log){

    log.debug('[bgTrim] Initializing...');

    return function (obj) {
      if(obj)
      return angular.copy(obj).replace(/ /g, '');
    };
  };
  bgTrim.$inject = ['$log'];
  win.MainApp.Filters
    .filter('bgTrim', bgTrim);

}(window));
