/* globals MainApp */

(function (win) {
  "use strict";


  var isString = angular.isString;

  function PercentFilter($window) {

    return function (value,divided) {

      var divider = isString(value) ? $window.Number(value) : value;

      if (!divided) {
        return value+"%";
      }

      return ((divider / divided) * 100) + "%";

    };

  }

  PercentFilter.$inject = ['$window'];

  win.MainApp.Filters.filter('cent', PercentFilter);

}(window));
