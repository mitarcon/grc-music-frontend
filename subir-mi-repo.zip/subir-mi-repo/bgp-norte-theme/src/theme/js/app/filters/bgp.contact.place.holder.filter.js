(function(win){
  'use strict';
  function ph(lang, translate) {

    return function (code) {
      if (angular.isDefined(code)) {
        return translate.getValue('placeholder.'+code.trim());
      }
    };
  }
  ph.$inject = ['lang','translateService'];
  win.MainApp.Filters
    .filter('ph',ph);

}(window));
