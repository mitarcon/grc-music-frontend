/* globals MainApp */

(function (win) {
  "use strict";

  function TranslateFilter($sce, translateService) {
    return function (key, args) {
      var value = translateService.getValue(key, args);
      return $sce.trustAsHtml(value);
    };
  }

  TranslateFilter.$inject = ['$sce', 'translateService'];

  win.MainApp.Filters.filter('t', TranslateFilter);
  
  /*
  ====================
  Translate Arrays Values Filter
  ====================
  */

  var translateArrayValuesFilter = function($sce, translateService){

    return function (arr) {
      var jsonVariable = {};
      angular.forEach(arr, function (value, key) {
        value = (translateService.getValue(value));
        jsonVariable[key] = $sce.valueOf($sce.trustAsHtml(value));
      });
      
      return jsonVariable;
    };
  };
  translateArrayValuesFilter.$inject = ['$sce', 'translateService'];
  win.MainApp.Filters
    .filter('TArrayValues', translateArrayValuesFilter);

}(window));
