(function(win){
  'use strict';
  /*
  =============
  bgDateFilter
  =============
  */


    function bgDate(lang, isEmpty, stringUtils) {
      return function (arrayDate, format) {
        format = angular.isDefined(format) ? format : 'YMD';

        var startDate = arrayDate[0];
        var endDate = isEmpty(arrayDate[1]) ? new Date() : new Date(arrayDate[1]);
        if(isEmpty(startDate))
          return '';

        startDate = new Date(startDate);
        startDate.setHours(0);
        endDate.setHours(0);

        if (startDate.getTime() > endDate.getTime())
          return '';

        var diff = moment.preciseDiff(startDate, endDate, true);
        format = format
          .replace('Y', stringUtils.pluralizer(diff.years, 'global.year'))
          .replace('M', stringUtils.pluralizer(diff.months, 'global.month'))
          .replace('D', stringUtils.pluralizer(diff.days, 'global.day'));
        return format;
      };

    }
    bgDate.$inject = ['lang', 'isEmptyFilter', 'stringUtils'];
    win.MainApp.Filters
      .filter('bgDate',bgDate);

    /*
    ======================
    bgEstimatedDateFIlter
    ======================
    */

    function bgEstimatedDate(log, isEmpty) {
      log.debug('[bgEstimatedDate] Initializing......');
      return function (arrayValue, formatDate) {

        formatDate = isEmpty(formatDate) ? 'DD/MM/YYYY' : formatDate ;
        var yearSubtract = isEmpty(arrayValue[0]) ? 0 : arrayValue[0];
        var monthSubtract = isEmpty(arrayValue[1]) ? 0 : arrayValue[1];
        var daysSubtract = isEmpty(arrayValue[2]) ? undefined : arrayValue[2];

        if(arrayValue[2]){
          var z = new Date().getDate();
          var p = new Date(arrayValue[2]).getDate();
          daysSubtract = Math.abs(p-z);
        }

        return moment().subtract(monthSubtract, 'months').subtract(
               yearSubtract, 'year').subtract(daysSubtract, 'days')
               .format(formatDate);
      };

    }
    bgEstimatedDate.$inject=['$log','isEmptyFilter'];
    win.MainApp.Filters
      .filter('bgEstimatedDate',bgEstimatedDate);

    /*
    ======================
    bgDecomposeDateFilter
    ======================
    */

    function bgDecomposeDate(isEmpty) {
      return function(date, format) {
        format = isEmpty(format) ? '' : format;
        return moment(date).format(format);
      };
    }
    bgDecomposeDate.$inject = ['isEmptyFilter'];
    win.MainApp.Filters
    .filter('bgDecomposeDate', bgDecomposeDate);

}(window));
