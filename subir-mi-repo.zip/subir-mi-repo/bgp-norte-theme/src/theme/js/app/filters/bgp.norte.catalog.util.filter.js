/**
 * Filters for access to catalogs data Created by fnovoa on 04/13/2016. Migrated
 * to dxp
 */
(function(win) {
  "use strict";

  /*
   * ==================== CatalogFilter ====================
   */
  function CatalogFilter( catalogService ) {
    return function(value, project){
      return catalogService.get(value, project);
    };
  }
  CatalogFilter.$inject = [ 'catalogService' ];
  win.MainApp.Filters.filter('catalog', CatalogFilter);

  /*
   * ==================== CatalogIsReadyFilter ====================
   */
  function CatalogIsReadyFilter( catalogService ) {
    var catalogIsReadyFilter = function (catalogName, project) {
      return angular.isDefined(catalogService.get(catalogName, project));
    };
    catalogIsReadyFilter.$stateful = true;
    return catalogIsReadyFilter;
  }
  CatalogIsReadyFilter.$inject = [ 'catalogService' ];
  win.MainApp.Filters.filter('catalogIsReady', CatalogIsReadyFilter);

  /*
   * ==================== catalogItemFilter ====================
   */
  var catalogItem = function(catalogService) {
    return function (value, catalogName, project, defaultValue){
      return catalogService.item(value, catalogName, project, defaultValue);
    };
  };

  catalogItem.$inject = [ 'catalogService' ];
  win.MainApp.Filters.filter('catalogItem', catalogItem);

  /*
   * ==================== describeFilter ====================
   */
  var describe = function(catalogService) {
    return function (value, catalogName, project, field){
      return catalogService.describe(value, catalogName, project, field);
    };
  };

  describe.$inject = [ 'catalogService' ];
  win.MainApp.Filters.filter('describe', describe);

}(window));
