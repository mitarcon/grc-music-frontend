(function (win) {
  "use strict";

  /*
  * Si webContextPath es vacio es una ruta de comunes
  * sino es una ruta de la aplicacion por parametro
  */
  function BgpTplRootUrlFilter(isEmpty) {
    return function (value, webContextPath) {
      if(isEmpty(webContextPath)){
        return window.baseThemeURL + value;
      }else{
        return win.baseAssetsURL + webContextPath + "/" + value;
      }
    };
  }
  BgpTplRootUrlFilter.$inject = ['isEmptyFilter'];
  win.MainApp.Filters.filter('BgpTplRootUrl', BgpTplRootUrlFilter);
}(window));
