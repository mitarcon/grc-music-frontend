(function (win) {
  "use strict";

  function uploadFileDescrip(
    translate,
    dateFilter
  ){
    return output;

    // key: Nombre de la persona
    // args: fecha
    function output(key, args) {
      var date = new Date(args);
      return translate.getValue('quote.file.upload.modal.by', [key,
        dateFilter(date,translate.getValue('save.date.format.doc.full'))
        .replace('p. m.','PM')
        .replace('a. m.','AM')
        .replace('.', '')]);
    }
  }

  uploadFileDescrip.$inject = [
    'translateService',
    'dateFilter'
  ];

  win.MainApp.Filters.filter('uploadFileDescrip', uploadFileDescrip);

}(window));

(function (win) {
  "use strict";

  function versionFileDescrip(
    translate,
    dateFilter
  ){
    return output;

    // dateI: fecha
    function output(dateI) {
      var date = new Date(dateI);
      return  dateFilter(date,translate.getValue('save.date.format.doc.full'))
        .replace('p. m.','PM')
        .replace('a. m.','AM')
        .replace('.', '');
    }
  }

  versionFileDescrip.$inject = [
    'translateService',
    'dateFilter'
  ];

  win.MainApp.Filters.filter('versionFileDescrip', versionFileDescrip);

}(window));
