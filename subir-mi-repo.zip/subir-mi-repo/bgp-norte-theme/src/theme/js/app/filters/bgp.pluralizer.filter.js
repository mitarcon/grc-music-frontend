(function(win){
  'use strict';

  function bgPluralizer(translateService, stringUtils) {
    return function(value, key){
     return stringUtils.pluralizer(value, key, true);
    };
  }

  bgPluralizer.$inject = ['translateService', 'stringUtils'];
  win.MainApp.Filters
    .filter('bgPluralizer',bgPluralizer);

}(window));
