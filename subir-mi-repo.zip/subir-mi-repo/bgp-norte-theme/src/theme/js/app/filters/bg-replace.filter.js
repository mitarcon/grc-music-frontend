(function (win) {
  "use strict";

  function bgReplaceFilter() {
    return function (str, pattern, replacement, html) {
      if (html) {
        replacement = '<' + replacement + '>';
      }
      try {
        return (str || '').replace(new RegExp(pattern, 'g'), function () {
          return replacement;
        });
      } catch (e) {
        return (str || '');
      }
    };
  }

  win.MainApp.Filters.filter('bgReplace', bgReplaceFilter);

}(window));
