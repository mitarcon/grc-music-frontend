(function(win) {
  win.MainApp.Values
    .value('bgDocumentSizes', {

      //COMUNES
      'CAR-ACEP': 'carta (8 ½ x 11)',
      'CART-APC': 'carta (8 ½ x 11)',
      'COTIZ': 'carta (8 ½ x 11)',
      'COT': 'carta (8 ½ x 11)',
      'HOJ-DAT': 'carta (8 ½ x 11)',
      'PRECA': 'carta (8 ½ x 11)',
      //fin COMUNES


      'CART-ATT': 'Membretado FWLA',
      'CART-MUN': 'Membretado FWLA',
      'CART-PROM': 'Membretado Banco General y  carta (8 ½ x 11)',
      'AUT-DEBCTA': 'carta (8 ½ x 11)',
      'POLV-GEN': 'carta (8 ½ x 11)',
      'PAGARE': 'carta (8 ½ x 11)',
      'DECL-SAL': 'carta (8 ½ x 11)',
      'CON-FEDEI': 'carta (8 ½ x 11)',
      'TRASP-REG': 'carta (8  ½ x 11)',
      'TRASP-IMP': 'carta (8  ½ x 11)',
      'AUT-DESEM': 'carta (8  ½ x 11)',
      'PER-FWLA': 'carta (8  ½ x 11)',

      //HIPOTECA
      'CHECK-LIST': 'carta (8  ½ x 11)',
      'PAZ-SAL-IM': 'carta (8  ½ x 14)',
      'CAR-PA-SAL': 'carta (8  ½ x 11)'

    });
}(window));
