(function(win) {
  win.MainApp.Values
    .value('bgModelIpcWrapperData', {
      obj: {
        task: {
          product: {
            id: 0,
            type: {
              id: ''
            }
          },
          person: {
            entityId: 0,
            apcData: {
              apcTemporaryFlag: false
            }
          },
          stage: {
            id: '',
            name: ''
          },
          status: {
            id: '',
            name: ''
          }
        },
        wizardFlag: false,
        differenceFlag: false,
        newClientFlag: false,
        customerDataUpdated: false,
        preQuoteDataUpdated: false,
        isPrincipalParticipant: true,
        dataSheetPrint: false,
        dataSheetPrintRequired: false,
        withProduct: true,
        location: null,
        inboxLayout: {
          activeTab: 1
        },
        liabilityOpeningData: {
          entityId: 0,
          newCustomer: false ,
          pep: false,
          maxDepositExceeded: false,
          product: {
            id: 0,
            type: {
              id: 0
            },
            subtype: {
              id: 0,
              name: null
            }
          },
          purpose: {
            id: 0,
            name: null
          }
        }
      }
    });

}(window));
