(function(win){
	win.MainApp.Values
	.value('bgModelDetailData', {
	  obj: {
	    cardName: '',
	    mileageNumber: '',
	    connectMilesNumber: '',
	    connectMilesEmail: '',
	    additionalClients: {},
	    delivery: {
	      chkDeliveryInfo: '',
	      courierAddress: '',
	      branch: ''
	    }
	  }
	});

}(window));