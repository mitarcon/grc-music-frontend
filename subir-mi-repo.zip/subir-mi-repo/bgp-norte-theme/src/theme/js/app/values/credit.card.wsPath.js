(function(win) {

  /*
   * Ruta de servicios usados en la aplicación
   * Al agregar un nuevo proyecto se debe agregar un value 'wsPathXXX'
   * Se debe agregar en el switch de la funcion serviceRoute del archivo
   * bgp.norte.invoke.service.js este value
   */

  win.MainApp.Values
    .value('wsPathCreditCard', {
      'ws': {
        'initCreditCardQuote': {
          'route': '/o/api/credit-card-quote/manager/initCreditCardQuote/',
          'method': 'POST'
        },
        'updateCreditCardQuoteSession': {
          'route': '/o/api/credit-card-quote/manager/updateCreditCardQuoteSession/',
          'method': 'POST'
        },
        'findCreditCardCatalog': {
          'route': '/o/api/credit-card-quote/findCreditCardCatalog/',
          'method': 'POST'
        },
        'executeBusinessRule': {
          'route': '/o/api/credit-card-quote/manager/executeCreditCardQuoteRule/',
          'method': 'POST'
        },
        'findTaskValidUser': {
          'route': '/o/api/credit-card-quote/findTaskValidUser/',
          'method': 'POST'
        },
        'updateCustomerAPCFlag': {
          'route': '/o/api/credit-card-quote/manager/updateCustomerAPCFlag/',
          'method': 'POST'
        },
        'findAPC': {
          'route': '/o/api/credit-card-quote/manager/findAPC/',
          'method': 'POST'
        },
        'clientAccountsPromise':{
          'route': '/o/api/credit-card-quote/clientAccount',
          'method': 'POST'
        },
        'findDifferences': {
          'route': '/o/api/credit-card-quote/findDifferences/',
          'method': 'POST'
        },
        'getCatalogs': {
          'route': '/o/api/credit-card-quote/catalogs/',
          'method': 'GET'
        },
        'getParameters': {
          'route': '/o/api/credit-card-quote/creditCardParameters/',
          'method': 'GET'
        },
        'validateQuote':{
          'route': '/o/api/credit-card-quote/action/validate/',
          'method': 'POST'
        },
        'findTaskByQuoteIdFromSession':{
          'route': '/o/api/credit-card-quote/taskQuoteFromSession/',
          'method': 'POST'
        },
        'saveQuote': {
          'route': '/o/api/credit-card-quote/manager/save',
          'method': 'POST'
        },
      //
      //Servicios para imprimir documentos

      'uploadDocument':{
        'route': '/o/api/quote-document/uploadDocument',
        'method': 'POST'
      },
      'updatePrintedField':{
        'route': '/o/api/quote-document/updatePrintedField',
        'method': 'POST'
      },
      'updateUploadedField':{
        'route': '/o/api/quote-document/updateUploadedField',
        'method': 'POST'
      },
      'findFiles':{
        'route': '/o/api/quote-document/findFiles',
        'method': 'POST'
      },
      'downloadFile':{
        'route': '/o/api/quote-document/downloadFile/',
        'method': 'POST'
      },
      //promesas de los reportes
      'acceptanceLetterReportPromise':{
        'route': '/o/api/credit-card-quote/acceptanceLetterReportPromise',
        'method': 'POST'
      },
      'validateAcceptanceLetterReportData':{
        'route': '/o/api/credit-card-quote/validateAcceptanceLetterReportData',
        'method': 'POST'
      },
      'quotationReportPromise':{
        'route': '/o/api/credit-card-quote/quotationReportPromise',
        'method': 'POST'
      },
      'validateQuotationReportData':{
        'route': '/o/api/credit-card-quote/validateQuotationReportData',
        'method': 'POST'
      },
      'preQualificationReportPromise':{
        'route': '/o/api/credit-card-quote/preQualificationReportPromise',
        'method': 'POST'
      },
      'validatePreQualificationReportData':{
        'route': '/o/api/credit-card-quote/validatePreQualificationReportData',
        'method': 'POST'
      },
      'apcLetterReportPromise': {
        'route': '/o/api/credit-card-quote/apcLetterReportPromise',
        'method': 'POST'
      },
      'customerDataSheetReportPromise':{
        'route': '/o/api/credit-card-quote/customerDataSheetReportPromise',
        'method': 'POST'
      },
      'validateCustomerDataSheetReportData':{
        'route': '/o/api/credit-card-quote/validateCustomerDataSheetReportData',
        'method': 'POST'
      },
      'validateApcLetterReportData': {
        'route': '/o/api/credit-card-quote/validateApcLetterReportData',
        'method': 'POST'
      },
      }
    });
}(window));
