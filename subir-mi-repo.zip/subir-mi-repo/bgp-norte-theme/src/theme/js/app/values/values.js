/* jshint maxlen: 200 */
(function(win){

  win.MainApp.Values
  .value('apps', {
    credit: 'credit',
    car: 'car',
    mortgage : 'mortgage',
    casacash: 'casacash',
    commons: 'common',
    wizard: 'wizard',
    clientDetails: 'clientDetails',
    quote : 'quote',
    maintenance : 'maintenance',
    neighborhood: 'neighborhood',
    task : 'task',
    carCatalogs: 'carCatalogs',
    clientSearch: 'clientSearch',
    notification: 'notification',
    quoteRecord: 'quoteRecord',
    quoteSummary:'quoteSummary',
    quoteEvaluation: 'quoteEvaluation',
    quoteHead: 'quoteHead',
    quoteDocument: 'quoteDocument',
    carQuoteDetails: 'carQuoteDetails',
    quoteCommunication:'quoteCommunication',
    taskCarQuoteLayout: 'taskCarQuoteLayout',
    quoteClient: 'quoteClient',
    quoteReview:'quoteReview',
    accountOpening: 'accountOpening',
    carQuoteLiquidation: 'carQuoteLiquidation',
    liabilityAdvice: 'liabilityAdvice',
    customerManagement: 'customerManagement',
    accountOpeningApproval: 'accountOpeningApproval'
  })

  .value('WebContextPath',{
    car: 'bgp-norte-car-quote-web',
    maintenance: 'bgp-norte-maintenance-web',
    wizard: 'bgp-norte-wizard-web',
    clientDetails: 'bgp-norte-client-details-web',
    clientSearch: 'bgp-norte-search-client-web',
    carCatalogs: 'bgp-norte-sb-car-catalog-web',
    quoteRecord:'bgp-norte-quote-record-web',
    depositProductsOpening: 'bgp-norte-deposit-products-opening-web',
    liabilityOpening: 'bgp-norte-liability-opening-layout',
    accountOpening: 'bgp-norte-account-opening-web',
    accountOpeningAdvice: 'bgp-norte-account-opening-advice-web',
    liabilityOpeningAdvice: 'bgp-norte-liability-opening-advice-web',
    quoteSummary: 'bgp-norte-quote-summary-web',
    quoteEvaluation: 'bgp-norte-quote-evaluation-web',
    quoteHead: 'bgp-norte-quote-head-web',
    quoteDocument: 'bgp-norte-quote-document-web',
    quoteCommunication:'bgp-norte-quote-communication-web',
    carQuoteDetails: 'bgp-norte-car-quote-details-web',
    quoteClient: 'bgp-norte-quote-client-web',
    quoteReview: 'bgp-norte-car-quote-review-web',
    liabilityOpeningLayout: 'bgp-norte-liability-opening-layout',
    carQuoteLiquidation: 'bgp-norte-car-quote-liquidation-web',
    credit: 'bgp-norte-credit-card-quote-web',
    customerManagement: 'bgp-norte-customer-management-web',
    customerManagementLayout: 'bgp-norte-customer-management-layout',
    accountOpeningApproval: 'bgp-norte-account-opening-approval-web'
  })

  .value('countryCode',[
    {id: 0,code: "(+507) PANAMA"},
    {id: 1, code: "(+49) ALEMANIA"},
    {id: 2, code: "(+55) BRASIL"},
    {id: 3, code: "(+1) CANADA"},
    {id: 4, code: "(+45) DINAMARCA"},
    {id: 5, code: "(+421) ESLOVAQUIA"},
    {id: 6, code: "(+33) FRANCIA"},
    {id: 7, code: "(+30) GRECIA"},
    {id: 8, code: "(+36) HUNGRIA"},
    {id: 9, code: "(+39) ITALIA"},
    {id: 10,code: "(+7) RUSIA"},
])

  .value('product', {
    credit: 'TDC',
    car: 'AUTOS',
    mortgage : 'HIP'
  })

  .value('deliveryAddress', {
    branchOffice: 'RS',
    courier:'EM'
  })

  .value('accountStatement', {
    branchOffice: 'RS',
    online: 'BEL'
  })

  .value('apcFlagOptions', {
    mark: 'A',
    tempMark: 'B'
  })

  .value('clientSearchAction',{
    quote: 'quote',
    details: 'clientDetails',
    addParticipant: 'addParticipant',
    liabilityAdvice: 'liabilityAdvice'
  })

  .value('genderTypes',{
    male : 'M',
    female : 'F'
  })

  .value('panamaCode', '61')
  .value('codeHipoteca', 'HIPOTECA')
  .value('codeHouseRental', 'ALQ')

  .value('cardMinValue', 400)

  .value('creditCardOperationCode', 'TDC')

  .value('creditCardOperationNumber', 43)

  .value('retiredPositionCode', 295)

  .value('rentDefaultApplyToCode', 'END')

  .value('rentDefaultPaymentMethodCode', 'PV')

  .value('defaultPaymentMethodCode', 'DCTA')

  .value('defaultRegion', 'M')

  .value('defaultDomesticEmployeeCode', 294)

  .value('codeEvaluationTypes',{
    promoCode: 'PROMO',
    codeMyFirstCredtit: 'MP10',
    codeEvidenceIncome: 'EVID',
    codeCampaign: 'CAMP',
    extraordinaryApproval: 'APEXT'
  })

  .value('idEvaluationTypes',{
    pig: 'PIG',
  })

  .value('addressTypeOptions', [
    {personal: 'D', labor: 'E', template: 'directionLocalForm'},
    {personal: 'L', labor: 'M', template: 'directionForeignForm'}
  ])

  .value('addressTypeOptionsManagement', [
    {personal: 'D', labor: 'E', template: '/o/bgp-norte-customer-management-layout/templates/partials/bg-directions/local.html'},
    {personal: 'L', labor: 'M', template: '/o/bgp-norte-customer-management-layout/templates/partials/bg-directions/foreign.html'}
  ])

  .value('bones',[
    {
      id: 1,
      bonesO: {
        id:'L',
        name:'APARTADO 1',
      },
      type: 'Entrega General',
    },
    {
      id: 2,
      bonesO: {
        id:'L',
        name:'APARTADO 2',
      },
      type: 'Entrega General X32',
    }
  ])

  .value('postOffice',[
    {id: 1, name: "Seleccionar"},
    {id: 2, name: "Estafeta 1"},
    {id: 3, name: "Estafeta 2"},
  ])

  .value('radioCheck',[
    {id:1, name:"Entrega general"},
    {id:2, name:"Casilla postal"}
  ])

  .value('postalCountry',[
    {id: -1, country: "Seleccionar"},
    {id: 0, country: "Alemania"},
    {id: 1, country: "Brasil"},
    {id: 2, country: "Canadá"},
    {id: 3, country: "Dinamarca"},
    {id: 4, country: "Eslovaquia"},
    {id: 5, country: "Francia"},
    {id: 6, country: "Grecia"},
    {id: 7, country: "Hungria"},
    {id: 8, country: "Italia"},
    {id: 9,country: "Panamá"},
    {id: 10,country: "Rusia"},
])

  .value('addressType',[
    {id: 'L', name: "LOCAL"},
    {id: 'E', name: "EXTRANJERO"},
  ])

  .value('scoringPhaseStatus', {
    'evaluationPhase': 'E',
    'scoringPhase': 'C',
    'scoringProgressStatus': 'EC',
    'scoringCancelStatus': 'DE'
  })

  .value('annualExpenses', {
    firstYear : 'PRI_MEMBRE',
    secondYear: 'SEG_MEMBRE',
    additionalMember: 'ADI_MEMBRE',
    annualTax: 'ITBMS_ANU'
  })

  .value('monthlyExpenses', {
    fraudInsurance: 'SEG_FRAUDE'
  })

  .value('bgPatternsList', {
    'alpha': /^[A-Z]*$/i,
    'alphaSpace': /[^a-zA-Z ]/g,
    'alphaNum': /^[A-Z0-9]+$/i,
    'alphaNumSpace': /[^0-9a-zA-ZñáéíóúüÑÁÉÍÓÚÜ'., -]/g,
    'alphaLatin': /^((([a-zñáéíóúü])+)(\s|')?)+([a-zñáéíóúü])+$/i,
    'alphaNumLatin': /^[0-9a-zñáéíóúü'., -]+$/i,
    'alphaNumLatinwithoutAccent': /^(?!\,)(?!.*\,$)(?!.*?\,\,)[\wñ,.() -]+$/i,
    'email': /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
    'number': /^\d+$/i,
    'numberOnly': /[^0-9]/g,
    'phone': /^[0-9]+([-][0-9]+)*$/,
    'identificationProvince': /^(([0][0-9])|([1][0-3]))$/,
    'identificationAlpha': /^([ ][ ])|([EN][1 ])|([N][T])|([P][EI])|([A][V])|(EE)|(SB)$/i,
    'identificationFolio': /^(([0][0-4][0-9][0-9])|([0][5](([3][0-2])|([0-2][0-9])))|([0][7-9][0-9][0-9])|([1][0-9][0-9][0-9]))$/,
    'identificationSeat': /^[0-9]{6}$/,
    'currency': /^[0-9]+\.?[0-9]*$/,
    'currencyOnly': /[^0-9](\.{1}[0-9]{2})?/g,
    'currencyPositiveNumber': /^(?!0+\.00)(?=.{1,9}(\.|$))(?!0(?!\.))\d{1,3}(,\d{3})*(\.\d+)?$/,
    'multiLine': /^[A-Za-z0-9 Ññ!"#$%&'()*+,-.\/:;?@<=>\[\\\]\^_{}¡ÁÉÍÓÚÄËÏÖÜáéíóúäëïöü°®©]*$/,
    'alphaLatinWithoutHyphen': /^[a-zñáéíóúü' ]+$/i,
    'alphaLatinWithoutLimit': /^$|^(?=[a-zñ' ]+$)(?:[a-zñ]+[' ]){0,6}[a-zñ]+$/i,
    'carMileage': /^[0-9]{1,6}$/,
    'identification': /^(PE|E|N|[23456789](?:AV|PI)?|1[0123]?(?:AV|PI)?)-((0?[0-4]?[0-9]?[0-9])|(0?[5](([3][0-2])|([0-2][0-9])))|(0?[7-9][0-9][0-9])|([1][0-9][0-9][0-9]))-(\d{1,5})$/i,
    'company': /^[-@./#!&%'()*"$,:;+\w?\sÑñ]*$/
  })

  .value('blockCharactersRegex', {
    identification: /[^\w\s-]/gi,
    noCharacters: /[^\w\s]/gi,
    noCharactersAndNumbers: /[^\w\sñáéíóúü]|[\d]/gi,
    noCharactersAndNumbersWithApostrophe: /[^\w\sñáéíóúü']|[\d]/gi
  })

  .value('patternAsString', {
    currencyPositiveNumber: "^[0-9,.]*$",
    alphaLatin: "^[a-zA-ZñáéíóúüÑÁÉÍÓÚÜ ]*$",
    alphaNum: "^[a-zA-Z0-9 ]*$",
    alphaNumWithHyphen: "^[a-zA-Z0-9-]*$",
    alphaLatinNum: "^[a-zA-Z0-9ñáéíóúüÑÁÉÍÓÚÜ ]*$",
    number: "^[0-9]*$",
    alphaNumWithHyphenDotAndSlash:"^[a-zA-Z0-9-./]*$",
    normalText: "^[A-Z0-9 Ñ!\"#$%&'()*+,-.\/:;?@<=>\[\\\]\^_{}¡\\\\]*$",
    memoText: "^[A-Za-z0-9 Ññ!\"#$%&'()*+,-.\/:;?@<=>\[\\\]\^_{}¡ÁÉÍÓÚÄËÏÖÜáéíóúäëïöü°®©\\\\]*$"
  })

  .value('clientNameRule', {
    name: {maxLength: 40, pattern: 'alphaLatin'},
    secondName: {maxLength: 40, pattern: 'alphaLatin'},
    lastName: {maxLength: 26, pattern: 'alphaLatin'},
    secondLastName: {maxLength: 26, pattern: 'alphaLatin'},
    legalName: {maxLength: 26, pattern: 'alphaLatin'},
    marriedLastName: {maxLength: 26, pattern: 'alphaLatin'},
    passport: {maxLength: 20, pattern: 'alphaNum'},
    province: {maxLength: 2, pattern: 'identificationProvince'},
    alpha: {maxLength: 2, pattern: 'identificationAlpha'},
    folio: {maxLength: 4, pattern: 'identificationFolio'},
    seat: {maxLength: 6, pattern: 'identificationSeat'},
    cdname: {maxLength: 25, pattern: 'alphaLatinWithoutLimit'},
    cdlimit: {min: 1, pattern: 'currency'},
    email: {maxLength: 120, pattern: 'email'},
    mileagePlus: {maxLength: 25},
    frequentFlyer: {maxLength: 15},
    connectMiles: {maxLength: 25},
    phone:{maxLength:14, pattern:'phone'},
    identification: {maxLength: 14, pattern: 'identification'},
    addres: {maxLength: 250}
  })

  .value('carQuoteValidations', {
    engineSerialNumber: {maxLength: 30, pattern: 'alphaNumLatin'},
    chassisSerialNumber: {maxLength: 30, pattern: 'alphaNumLatin'},
    color: {maxLength: 50, pattern: 'alphaNumLatin'},
    signatureUserName: {maxLength: 40, pattern: 'alphaLatinWithoutHyphen'},
    signatureUserChannel: {maxLength: 40, pattern: 'alphaNumLatin'},
    beneficiaryCompleteName: {maxLength: 40, pattern: 'alphaLatinWithoutHyphen'},
    beneficiaryDocumentNumber: {maxLength: 20, pattern: 'alphaNumLatin'},
    carQuoteObservation: {maxLength: 255, pattern: 'multiLine'},
    carPrice: {maxLength: 10},
    carQuoteFileName: {maxLength: 100},
    carDeposit: {maxLength: 10},
    carDepositPercent: {maxLength: 7},
    carQuotePayments: {maxLength: 3},
    carQuoteSellerName: {maxLength: 50, pattern: 'multiLine'},
    carQuoteValuationAmount: {maxLength: 10, pattern: 'currency'},
    carQuotePaymentThirdAccountNumber: {maxLength: 90, pattern: 'alphaNumLatin'},
    carQuoteMileage: {maxLength: 6, pattern: 'carMileage'},
    insuranceNumber:{maxLength: 30, pattern: 'company'},
    carCoverageDescription:{maxLength: 64, pattern: 'company'},
    carPolicyAmount:{maxLength: 10},
    signatureUserNameDetails:{maxLength:255,pattern:'alphaNumLatin'}
  })

  .value('mortgageValidations', {
    money: {maxLength: 12, pattern: 'currencyPositiveNumber'},
    meters: {maxLength:10},
    newProjectName: {maxLength:50},
    price: {maxLength: 10},
    deposit: {maxLength: 10},
    weight: {maxLength: 3, pattern: 'number'}
  })

  .value('validationsQuote', {
    comment: {maxLength: 255, pattern: 'multiLine'},
    instructionsForDelivery: {maxLength: 120, pattern: 'alphaNumLatinwithoutAccent'},
    exceptionSupport: {maxLength: 255, pattern: 'multiLine'},
    documentComment: {maxLength: 240, pattern: 'multiLine'},
    obligationInstitution: {maxLength: 240, pattern: 'alphaNumLatin'},
    obligationComment: {maxLength: 255, pattern: 'multiLine'},
    obligationMortgageAmount: {pattern: 'currencyPositiveNumber'},
    obligationMortgagePercentage: {pattern: 'currencyPositiveNumber'}
  })

  .value('globalValidations', {
    observation: {maxLength: 255, pattern: 'multiLine'}
  })

  /* TODO: Reemplazar a futuro con respuesta de REGLAS */
  .value('percentMortgage', 50)

  .value('riesgoCredito', "09")
  .value('apcColorGray', 'gray')
  .value('apcColorGreen', 'green')
  .value('apcColorRed', 'red')
  .value('apcColorYellow', 'yellow')
  .value('codeDomestic','1531336')

  .value('identificationType',{
    'local':1,
    'commerce':2,
    'foreign':3
  })

  .value('warningsCode',{
    'cs' : 'VC-TC',
  })

  .value('warningsType',{
    block: "BLOCK"
  })

  .value('getAmerica',{
    'american':29
  })

  .value('debtorLostApcFlagCode', 99)

  .value('documentTypeCodes',{
    ced: 'CED',
    passport: 'PAS'
  })

  .value('carAgenciesWithoutDealer',{
    naturalPerson: 'PERSONA NATURAL',
    legalPerson: 'PERSONA JURIDICA'
  })

  .value('addAdditionalOptions', [
    'client.add.opt.present',
    'client.add.opt.not.present',
    'client.add.opt.not.present.docs'
  ])

  .value('antiqueness', {
    new: 'AN',
    used: 'AU'
  })

  .value('dismissTimeOut', 5000)

  .value('carQuoteParticipantType', {
    debtor: "D",
    owner: "U",
    ownerDebtor: "N",
    guarantor: "F"
  })

  .value('carExpensesCodes', {
    POL_VIDA: "POL_VIDA",
    NOTARIA: "NOTARIA",
    TIMBRE: "TIMBRE",
    COM_MAN:"COM_MAN"
  })

  .value('valuationType', {
    invoice: 'P',
    assessment: 'A'
  })

  .value('codeBenefit', {
    mileagePlus: 'MILEAGE',
    connectMilles: 'CONNECT'
  })

  .value('mortgageType', [
    {id: 'COMPRA', name: 'COMPRA DE PROPIEDAD'},
    {id: 'TRASPASO', name: 'TRASPASO DE OTRO BANCO', disabled: true},
    {id: 'CASACASH', name: 'CASACASH', disabled: true}
  ])

  .value('mortgageTypeValue', {
    buyProperty: 'COMPRA',
    transfer: 'TRASPASO',
    casacash: 'CASACASH'
  })

  .value('propertyType', [
    {id: 'INM_APART', name: 'APARTAMENTO'},
    {id: 'CASA', name: 'CASA'},
    {id: 'TERRAIN', name: 'TERRENO', disabled: true}
  ])

  .value('propertyTypeValue', {
    apartment: 'INM_APART',
    house: 'CASA',
    terrain: 'TERRAIN'
  })

  .value('antiquenessValue', {
    new: "HN",
    used: "HU"
  })

  .value('yesNo', [
    {id: 1, name: "SI", value: true, charValue: "S", lowerCaseName: "Sí"},
    {id: 2, name: "NO", value: false, charValue: "N", lowerCaseName: "No"}
  ])

  .value('yesNoCharValues', {
    yes: "S",
    no: "N"
  })


  .value('timeOfPregnant', [
    {id: 1, name: "Menos de 24", value: true},
    {id: 2, name: "Más de 24", value: false}
  ])

  .value('parturitionType', [
      {id: "C", name: "Cesárea"},
      {id: "N", name: "Natural"}
  ])

  .value('quoteWithAppraisalValue', {
    yes: true,
    no: false
  })

  .value('quoteWithProjectValue', {
    yes: true,
    no: false
  })

  .value('appraisalOption', {
    sellFast: "VR",
    market: "ME"
  })

  .value('propertyUse', [
    {id: 'VIV_INV', name: 'INVERSION'},
    {id: 'SEG_RES', name: 'SEGUNDA RESIDENCIA'},
    {id: 'VACAC', name: 'VACACIONAL'},
    {id: 'DE_VIVPRI', name: 'VIVIENDA PRINCIPAL'}
  ])

  .value('newProjectCode', "0")

  .value('month', [
    {id:1, value: "ENERO"},
    {id:2, value: "FEBRERO"},
    {id:3, value: "MARZO"},
    {id:4, value: "ABRIL"},
    {id:5, value: "MAYO"},
    {id:6, value: "JUNIO"},
    {id:7, value: "JULIO"},
    {id:8, value: "AGOSTO"},
    {id:9, value: "SEPTIEMBRE"},
    {id:10, value: "OCTUBRE"},
    {id:11, value: "NOVIEMBRE"},
    {id:12, value: "DICIEMBRE"}
  ])

  .value('appraisalValue', [
    {id:"ME", name: "VALOR DE MERCADO"},
    {id:"VR", name: "VALOR DE VENTA RAPIDA"}
  ])

  .value('appraisalValueId', {
    market:"ME",
    sellFast:"VR"
  })

  .value('mortgageInit', {
    type: {id: 'COMPRA', name: 'COMPRA DE PROPIEDAD'},
    mortgage: {
      propertyType: null,
      antiqueness: null,
      cascoViejo: false,
      propertyUse: null,
      sellPrice: null,
      meters: null,
      bedrooms: null,
      bathrooms: null,
      minimunSellPrice: 120000,
      minimunBedrooms: 1,
      minimunBathrooms: 1,
      quoteWithProject: true,
      project: null,
      projectInfo: null,
      assessmentInfo: {},
      promoter: null,
      year : null,
      month : null,
      day: 1,
      quoteWithAppraisal: true,
      appraisalValue: "VR",
      appraisalDefaultValue: null,
      projectOptions: null,
      promoterOptions: null,
      newProjectId: "0",
      newProjectName: null,
      maxYearsParam: 10
    },
  })

  .value('mortgageQuoteInit', {
    miviInfo: {},
    closeCommisionOptions: [],
    monthlyManagementOptions: [],
    renovationsOptions: [],
    anticipatedCancelationOptions: []
  })

  .value('mortgageMnemonic', {
    apartmentAlert: "GWARN_APAR",
    warning: "WARN",
    minAge : "HIED_MIN",
    maxAge : "HIED_MAX",
    minBedrooms: "RMINREC",
    maxBedrooms: "RMAXREC",
    minBathrooms: "RMINBA",
    maxBathrooms: "RMAXBA",
    estimatedDeliveryYears: "AN_ENTREGA",
    maxParticipantsQuantity: "PARHIP",
    squareMeterAlert: "GWARN_MTS",
    noParameters: "BLOCK_NPAR",
    financingMeters: "GWARN_FIN",
    aparmentMandatoryFields: "WARN_APAR"
  })

  .value('carMnemonic',{
    lowestDeposit : 'ABO_PORC',
    maxDateValidForPrint: "IMPAUT"
  })

  .value('standardQuoteTabs', {
    quotation: 0,
    clients: 1,
    details:2 ,
    documents: 3,
    history: 4
  })

  .value('borrowerTypesMortgage',
    {
      'debtor': 'D',
      'owner': 'U',
      'ownerDebtor': 'N',
      'solidaryGuarantor': 'F',
    }
  )

  .value('creditCardBorrowerTypes',
    {
      debtor: "P",
      additional: "A"
    }
  )

  .value('initHealtData',{
    pregnant : undefined,
    pregnancyTime : {},
    firstPregnancy : undefined,
    parturitionType : {},
  })

  .value('weekPregnancyValue',{
    more24 : 'MY',
    less24 : 'MN'
  })

  .value('pregnancyValue',{
    yes : true,
    no :  false
  })

  .value('firstPregnancyValue',{
    yes : true,
    no : false
  })

  .value('defaultSelect',{
    value: '-1'
  })

  .value('emptyMessageDeposit',{
    show : false,
    text : '',
    typeIco : 'info',
    color : 'notify',
  })

  .value('nemonic',{
    sizeDecimalPercentage : 'DECIMA',
    sizeDecimalNumber : 'MONDEC',
  })

  .value('obligationTypes', {
    manual: 'MA',
    automatic: 'OB',
    })

  .value('civilStatus',{
    married : 'C',
    marriedFatherLastname : 'N',
    single : 'S',
    united : 'U',
    widowMarriedLastName : 'X',
    widow : 'V',
  })

  .value('academicDataType',{
    education : 'education',
    profession : 'profession',
  })

  .value('orientationType',{
    right : 'right',
    left : 'left',
  })
  .value('documentSection',{
    prov : 'province',
    alpha : 'alpha',
    folio : 'folio',
    seat : 'seat',
  })

  .value('catalogItem',{
    country : 'countries',
    civil : 'civilStatus',
    sex : 'sexes',
    identiType : 'identificationType'
  })

  .value('contactType',{
    mail : "M",
    celPhone : "C",
    workPhone : "O",
    housePhone : "T"
  })

  .value('contactTypeWorkEmail',{
    id : "N"
  })

  .value('searchByOptions', [
    {id: 1, name: 'Cédula'},
    {id: 2, name: 'Nombre'},
    {id: 3, name: 'Pasaporte'}
  ])

  .value('searchByValues', {
    identification: 1,
    name: 2,
    passport: 3
  })

  .value('paramsNemonic', {
    percentage: "PCCPRM",
    domestic: "ENTDOM",
    independent: "ENTIND",
    legalEntity: "CEJUGE",
    validityMonth: "VIGFIC",
    tdcParticipantQty: "PARTDC",
    auParticipantQty: "PARAUT",
    refineClientFinderSearch: "BUSTOT",
    minAgeToQuote: "TCED_MIN",
    managerName:"GE_NOM",
    managerExt:"GE_EXT",
    managerEmail:"GE_MAIL",
    minAgeParam:"AUED_MIN",
    maxAgeParam:"AUED_MAX"
  })

  .value('wizardState', {
    personal: "personalData",
    labor: "laborData",
    apc: "apcData"
  })

  //Validacion de pestanias pendientes, wizard - mantenimiento
  .value('pendingAddForms', {
    contacts: false,
    references: false,
    personalAddresses: false,
    laborAddresses: false,
    employments: false,
    regulatory: false
  })

  .value('creditHistory',{
    good:'RBUENA',
    regular:'RREGUL',
    higher:'RMAYOR'
  })

  .value('contactsLimits', {
    emails: 2,
    phones: 3,
    sendByEmail: 2
  })

  .value('phoneLabels', {
    mobile: "Celular",
    residential: "Residencial",
    work: "Trabajo"
  })

  .value('employmentTypes', {
    active: "E",
    outgoing: "C"
  })

  .value('postalMailTypes', {
    local: "L",
    foreign: "E"
  })

  //INBOX TASKS SECTION

  .value('multiSelectBranchOfficesLabels', {
    "itemsSelected": "global.multiselect.itemsSelected",
    "selectAll": "global.multiselect.selectAll",
    "unselectAll": "global.multiselect.unselectAll",
    "search": "global.multiselect.search",
    "select": "global.multiselect.select"
  })

  .value('taskStagesPhases', {
    quote: 'C',
    evaluation: 'E',
    communication: 'M',
    formalization: 'F',
    liquidation: 'L', // liquidacion
    pLiquidation: 'P' //previous liquidation
  })

  .value('accountOpeningTaskStagesPhases', {
    aprobation: 'APR',
    request: 'SOL'
  })

  .value('denyViewTaskOptionPhase', 'COTIZACION')

  .value('taskPriority', [
    {id: '0', name: 'TODOS'},
    {id: '10', name: 'ALTA'},
    {id: '20', name: 'MEDIA'},
    {id: '30', name: 'BAJA'}
  ])

  .value('taskStatus', [
	{name: 'APROBADO', cssClass: 'text-brand-green-variation-1'},
	{name: 'APROBADO SUJETO A', cssClass: 'text-brand-green-variation-1'},
	{name: 'EN CURSO', cssClass: 'text-brand-green-variation-1'},
	{name: 'NEGADO', cssClass: 'text-color-brand-red'},
	{name: 'DEVUELTO', cssClass: 'text-color-brand-orange'},
	{name: 'CLIENTE DESISTE', cssClass: 'text-color-gray-variation-1'},
	{name: 'BANCO DESISTE', cssClass: 'text-color-gray-variation-1'},
	{name: 'NEGADO COMUNICADO', cssClass: 'text-color-gray-variation-1'},
	{name: 'LIQUIDADO', cssClass: 'text-color-gray-variation-1'},
  ])

  //opciones del popup de seleccion de opciones/siguiente de enrutamiento de tareas
  .value('routingTaskOptionsTypes', {
    optionButtonVal: 'OPC',
    nextButtonVal: 'SIG'
  })

  .value('processingDocumentsDummy',
  [
    {
    "code": "DOCSUS",
    "creationUser": {},
    "uploadingRequired": false,
    "received": false,
    "type": "CLT",
    "printingRequired": false,
    "printed": false,
    "sequence": 2,
    "name": "DOCUMENTOS DE SUSTENTACIÓN PARA ENVIAR A EVALUAR",
    "printUser": {
      "name": ""
    },
    "printingWithDataRequired": false,
    "status": "V",
    "order": 100
    },
    {
    "code": "LIC-COND",
    "creationUser": {},
    "uploadingRequired": false,
    "received": false,
    "type": "CLT",
    "printingRequired": false,
    "printed": false,
    "sequence": 2,
    "name": "LICENCIA DE CONDUCIR",
    "printUser": {
      "name": ""
    },
    "printingWithDataRequired": false,
    "status": "V",
    "order": 120
    },
    {
    "code": "CART-TRA",
    "creationUser": {},
    "uploadingRequired": false,
    "received": false,
    "type": "CLT",
    "printingRequired": false,
    "printed": false,
    "sequence": 1,
    "name": "CARTA DE TRABAJO PRINCIPAL (VIGENCIA DE 30 DÍAS)",
    "printUser": {
      "name": ""
    },
    "printingWithDataRequired": false,
    "status": "V",
    "order": 200
    },
    {
    "code": "FIC-TRAAC",
    "creationUser": {},
    "uploadingRequired": false,
    "received": false,
    "type": "CLT",
    "printingRequired": false,
    "printed": false,
    "sequence": 1,
    "name": "FICHA ORIGINAL VIGENTE DE LA CSS DEL TRABAJO PRINCIPAL",
    "printUser": {
      "name": ""
    },
    "printingWithDataRequired": false,
    "status": "V",
    "order": 220
    },
    {
    "code": "UL-COMP",
    "creationUser": {},
    "uploadingRequired": false,
    "received": false,
    "type": "CLT",
    "printingRequired": false,
    "printed": false,
    "sequence": 1,
    "name": "ÚLTIMO COMPROBANTE DE PAGO DEL TRABAJO PRINCIPAL (TALONARIO). (NO APLICA PARA JUBILADO DE EEUU)",
    "printUser": {
      "name": ""
    },
    "printingWithDataRequired": false,
    "status": "V",
    "order": 230
    },
  ])

  .value('documentsUploadDummy',
  [
    {
      'name': 'documento-de-sustentacion-FINAL.pdf',
      'date': "Apr 21, 1983 12:00:00 AM",
      'updateBy': "SOYLA MESA"
    },
    {
      'name': 'docu-3.pdf',
      'date': "Apr 21, 1983 12:00:00 AM",
      'updateBy': "ARMANDO PAREDES"
    },
    {
      'name': 'CEDULA-identidad.pdf',
      'date': "Apr 21, 1983 12:00:00 AM",
      'updateBy': "HARRY POTTER"
    },
  ]
)

  .value('recordTypes',{
    binnacle:'BITAC',
    notes:{
      id: 'NOTAS',
      name:'NOTAS/COMENTARIOS'
    },
    phase:{
      id:'ETAPA',
      name:'CAMBIOS DE ETAPA/ESTADO'
    }
  })

  .value('clientSearchStates', {
    search: 'clientSearch',
    recentQuotes: 'recentQuotes',
    block: 'SEGURIDAD',
    review: 'review',
    noReview: 'noReview',
  })

  .value('quoteSummary', {
    'producto': 'AUTO',
    'Antiguedad': 'NUEVO',
    'Uso': 'PARTICULAR',
    'PRECIO': '150000',
    'Abono': '(20%) 3000',
    'Marca': 'TOYOTA',
    'Modelo': 'YARIS',
    'Total a financiar': '12000',
    'Tasa': '7.75%',
    'Pagos': '84 meses',
    'Mensualidad': '209.00',
    'Forma de pago': 'CARGO A CUENTA',
  })

  .value('accountProduct' , [
    {id: '4', name: 'AHORRO'},
    {id: '3', name: 'CORRIENTE'}
  ])

  .value('accountProductObject' , {
    savings: {id: '4', name: 'AHORRO'},
    checking: {id: '3', name: 'CORRIENTE'}
  })

  .value('accountProductOptions', {
    checking: '3',
    savings: '4'
  })

  .value('depositFormOptions', {
    deposit: "DEPCAJ",
    betweenBGAccounts: "TRACBG",
    localTransfer: "TRAACH",
    internationalTransfer: "TRAINT"
  })

  .value('statementDelivery' , [
    {id: "N", name: 'Consultar en banca en línea'},
    {id: "R", name: 'Retener en sucursal (con costo)'}
  ])

  .value('statementDeliveryOptions' , {
    bel: "N",
    office: "R"
  })

  .value('checkbooksQuantity', [
    {id: 1, name: 1},
    {id: 2, name: 2}
  ])

  .value('initDepositProductOpening', {
    statementDelivery: "N",
    checkbooksQuantity: 1
  })

  .value('depositProductsOpeningValidations', {
    fundsProvenance: {maxLength: 40}
  })

  .value('inboxTabs', {
    myTask: 1,
    allTask: 2,
    tracing: 3,
    notifications: 4
  })

  .value('evaluationCarTabs', {
    summary: 1,
    evaluation: 2,
    record: 3,
  })

  .value('communicationCarTabs', {
    summary: 1,
    communication:2,
    details: 3,
    record: 4,
  })

  .value('formalizationCarTabs', {
    summary: 1,
    details:2,
    clients: 3,
    documents: 4,
    record: 5,
  })

  .value('previousLiquidationCarTabs', {
    summary: 1,
    review:2,
    details: 3,
    record: 4,
    documents: 6
  })

  .value('liquidationCarTabs',{
    summary: 1,
    liquidation: 2,
    record: 3,
    details: 4,
    documents: 5
  })

  .value('evaluationTDCTabs', {
    summary: 1,
    evaluation: 2,
    record: 3
  })

  .value('comunicationTDCTabs', {
    summary: 1,
    communication:2,
    details: 3,
    documents:4,
    record: 5
  })

  .value('clientMaxResults', 50)

  .value('associateAccountToCard' , [
    {id: true, name: 'Nueva'},
    {id: false, name: 'Existente'}
  ])

  .value('timeToGetNewNotifications', 60000)

  .value('associateAccountToCardOptions' , {
    new: "S",
    existent: "N"
  })

  .value('initRelatedProducts', {
    associateAccountToCard: "S"
  })

  .value('answerQuestion', [
    {id: 0, name : 'Si', value : true},
    {id: 1, name : 'No', value : false}
  ])

  .value('customerManagementDocumentsToSign', [
    {code:"CART-APC", name: "CARTA DE APC", required: true}
  ])

  .value('customerManagementDocumentsToPrinted', [
    {code:"HOJ-DAT", name: "HOJA DE DATOS DEL CLIENTE", required: false}
  ])

  .value('pepCategory', [
    {id: -1, name : 'Seleccionar'},
    {id: "01", name : 'PEP LOCAL'},
    {id: "02", name : 'PEP EXTRANJERO'}
  ])

  .value('ralationCategory', [
    {id: -1, relation : 'Seleccionar'},
    {id: 1, relation : 'FAMILIAR PEP LOCAL'},
    {id: 2, relation : 'FAMILIAR PEP EXTRANJERO'},
    {id: 3, relation : 'ESTRECHO COLABORADOR DE PEP LOCAL'},
    {id: 4, relation : 'ESTRECHO COLABORADOR DE PEP EXTRANJERO'}
  ])

  .value('familiarRelation', [
    {id: -1, relationship : 'Seleccionar'},
    {id: 1, relationship : 'PADRE'},
    {id: 2, relationship : 'MADRE'},
    {id: 3, relationship : 'HERMANO(A)'},
    {id: 4, relationship : 'HIJO(A)'},
    {id: 5, relationship : 'CÓNYUGE'},
    {id: 6, relationship : 'ESTRECHO COLABORADOR'}
  ])

  // TODO: Eliminar cuando se obtengan los catálogos de customerManagement

  .value('personType', [
    {id: 1, name: 'CLIENTE'},
    {id: 2, name: 'ACCIONISTA DE E.G.I'},
    {id: 3, name: 'DIRECTOR DE E.G.I'},
    {id: 4, name: 'JUBILADO'},
    {id: 5, name: 'DIRECTOR DE B.G.'}
  ])

  .value('companyType',{
    retired:{ id:'JU',name:'JUBILADO'}
  })

  .value('relatedProductsOptions', {
    bel: 'B',
    visa: 'VISADEB',
    clave: 'CLAVE'
  })

  .value('adviceRatesChargesCommissions', [
    {
      id: "AHORRO",
      link: "http://miredestrella/TasasyCargos/Lists/Tasas%20y%20Cargos/DispForm.aspx?ID=7&Source=http://miredestrella/TasasyCargos/Lists/Tasas%2520y%2520Cargos/AllItems.aspx"
    },
    {
      id: "AHORROSR",
      link: "http://miredestrella/TasasyCargos/Lists/Tasas%20y%20Cargos/DispForm.aspx?ID=7&Source=http://miredestrella/TasasyCargos/Lists/Tasas%2520y%2520Cargos/AllItems.aspx"
    },
    {
      id: "DEPLAFI",
      link: "http://miredestrella/TasasyCargos/Lists/Tasas%20y%20Cargos/DispForm.aspx?ID=12&Source=http://miredestrella/TasasyCargos/Lists/Tasas%2520y%2520Cargos/AllItems.aspx"
    },
    {
      id: "CHEQUERA",
      link: "http://miredestrella/TasasyCargos/Lists/Tasas%20y%20Cargos/DispForm.aspx?ID=6&Source=http://miredestrella/TasasyCargos/Lists/Tasas%2520y%2520Cargos/AllItems.aspx"
    }
  ])

  .value('accountOpeningAdviceRowValue', {
    check: "<i class='fa fa-check green-check'></i>"
  })

  .value('accountOpeningMnemonics', {
    claveMask: 'MASPLACLAV',
    debitVisaMask: 'MASPLAVISD',
    accountOpeningMask: 'MASCTADEP',
    approvalTime: 'DIASRETDAV',
    maxDepositAmount: 'MONTO_DEPOSITO'
  })

  .value('tabError',{
    quote: "quoteErrorIcon",
    customer: "customerErrorIcon",
    documents : "documentErrorIcon",
    record: "recordErrorIcon",
    summary: "summaryErrorIcon",
    evaluation: "evaluationErrorIcon",
    details: "detailsErrorIcon",
    review: "reviewErrorIcon",
    settlement: "settlementErrorIcon",
    communication: "communicationErrorIcon",
    clients: "clientsErrorIcon"
  })

  .value('tabErrorIcon',{
    notApply: "N",
    good: "V",
    withError: "X",
  })

  .value('accountOpeningRole', [
    {id: 'P', name: 'TITULAR'},
    {id: 'F', name: 'FIRMA AUTORIZADA'},
  ])

  .value('requiremetsMnemonics', {
    evidenceOfIncome: "EVI-ING"
  })

  .value('evidenceOfIncomeViewOptionLink', 'income-type-table-url')

  .value('alertWithWarning', {
    "1359838": {
      "warning": true,
      "quoteAlerts": [{
        "items": ["No se puede proceder con el trámite de ERNESTO DXP."]
      }]
    }
  })

  .value('backOfficeTask', [
    {id: 1, name: "Afiliar tarjeta clave de MARIA LIEBANA PEREZ al servicio de planilla salarial en COBIS ATM."}
  ])

  .value('bgPayRoll',
    {salarySlip : '8'}
  )

  .value('statusStepsInterfaceService',{
    "ERROR": "ERROR",
    "OK": "OK",
    "START": "RUN",
    "WAIT": "WAIT"

  })

  .value('timeInterfaceLiquidation',{
    "interval": 1000*1, // 1 segundos
    "incrementInterval": 1000*2, //2 segundos
    "maxTime": 1000*60*5 // 5 minutos
  })

  // TODO: Eliminar cuando se obtengan los catálogos de customerManagement

  .value('typeOfRetiree', {
    socialSecuriy: "490350",
    controllerGeneralRepublic: "1407863"
  })

  .value('formNumber', [
    {id: 1, name: "01-1 - PENSIONADO DEFINITIVA / PENSIONADO PROVISIONAL"},
    {id: 2, name: "05-1 - PENSIONADO SOBREVIVIENTE DE RIESGO"},
    {id: 3, name: "06-1 - PENSIONADO ABSOLUTA / DEFINITIVA"},
    {id: 4, name: "13 - PENSIONADO POR INVALIDEZ"}
  ])

  .value('costPerCardIssuance', [
    {id: false, name: "Cobrar"},
    {id: true, name: "Exonerar"}
  ])

  .value('lifePolicyActions',{
    notApply :{id:'NA',name:'NO APLICA'},
    apply:{id: 'AP', name: 'APLICA'},
    endorsement:{id: 'EN', name: 'ENDOSAR'}
  })

  .value('checkingEsencialAccountId', '10')

  .value('codCatalogTDCDetails',{
      'originDeliveryType': {
        'otrosCanales': 'ENTORI-OTC',
        'sucursal': 'ENTORI-ASU'
      },
      'deliveryType': {
        'bg': 'RS',
        'mensajeria': 'EM'
      },
      'deliveryTypeBg':{
        'otrosCanales': 'ENTDES-OTC',
        'sucursal': 'ENTDES-ASU'
      }
  })

  .value('lenghtNameTDC', '25')

  .value('maxLengthStreet', '60');

}(window));
