(function(win){
	win.MainApp.Values
	.value('initCarQuoteDummy', {
    "car": {
      "carBrand": {
        "id": 0,
        "name": "TOYOTA"
      },
      "carModel": {
        "brandId": 0,
        "name": "COROLLA"
      },
      "carAgency": {
        "name": "RICARDO PEREZ TUMBA MUERTO",
        "concessionaire": "RICARDO PEREZ, S.A."
      },
      "antiqueness": {
        "id": "AN",
        "name": "AUTO NUEVO"
      },
      "year": 2017,
      "color": "azul",
      "useType": {
        "id": "P",
        "name": "PARTICULAR"
      },
      "mileage": 0,
      "chassisSerialNumber": "bb",
      "engineSerialNumber": "aa",
      "registrationMunicipality": {
        "id": "1"
      },
      "priceWithTax": 17550,
      "carType": {},
      "assessmentCompany": {},
      "assessmentDate": "Jul 17, 2017 12:00:00 AM"
    },
    "depositA": 1755,
    "depositP": 10,
    "minDepositA": 1755,
    "minDepositP": 10,
    "autoFlashFlag": false,
    "discountCommission": 0,
    "baseCommission": 507.02,
    "principalParticipant": {
      "customerType": {
        "id": "N"
      },
      "working": true,
      "continuedEmployment": false,
      "employmentStability": true,
      "calculatedSalary": 5200,
      "exceptions": [
        {
          "code": "AU018",
          "description": "REFERENCIAS DE CREDITO MAYORES ACTIVAS",
          "type": "A"
        },
        {
          "code": "AU031",
          "description": "DIRECCION O INGRESOS EN EL EXTRANJERO",
          "type": "A"
        }
      ],
      "documents": [
        {
          "code": "IDENTIF",
          "name": "CÉDULA O PASAPORTE (VIGENTE)",
          "type": "CLT",
          "status": "V",
          "order": 100,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": false,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        },
        {
          "code": "LIC-COND",
          "name": "LICENCIA DE CONDUCIR",
          "type": "CLT",
          "status": "V",
          "order": 120,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": false,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        },
        {
          "code": "CART-TRA",
          "name": "CARTA DE TRABAJO PRINCIPAL (VIGENCIA DE 30 DÍAS)",
          "type": "CLT",
          "status": "V",
          "order": 200,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": false,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 2
        },
        {
          "code": "FIC-TRAAC",
          "name": "FICHA ORIGINAL VIGENTE DE LA CSS DEL TRABAJO PRINCIPAL",
          "type": "CLT",
          "status": "V",
          "order": 220,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": false,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 2
        },
        {
          "code": "UL-COMP",
          "name": "ÚLTIMO COMPROBANTE DE PAGO DEL TRABAJO PRINCIPAL (TALONARIO). (NO APLICA PARA JUBILADO DE EEUU)",
          "type": "CLT",
          "status": "V",
          "order": 230,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": false,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 2
        },
        {
          "code": "PRO-AVALUO",
          "name": "PROFORMA O AVALÚO ( VIGENCIA DE 30 DÍAS )",
          "type": "CLT",
          "status": "V",
          "order": 710,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": false,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        },
        {
          "code": "REC-ABONO",
          "name": "RECIBOS DE ABONO",
          "type": "CLT",
          "status": "V",
          "order": 720,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": false,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        },
        {
          "code": "POL-AUTO",
          "name": "PÓLIZA DEL AUTO",
          "type": "CLT",
          "status": "V",
          "order": 730,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": false,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        },
        {
          "code": "CART-APC",
          "name": "CARTA DE APC",
          "type": "BG",
          "status": "V",
          "order": 101,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": true,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        },
        {
          "code": "HOJ-DAT",
          "name": "HOJA DE DATOS DEL CLIENTE",
          "type": "BG",
          "status": "V",
          "order": 102,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": true,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        },
        {
          "code": "COTIZ",
          "name": "COTIZACIÓN",
          "type": "BG",
          "status": "V",
          "order": 103,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": true,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        },
        {
          "code": "PRECA",
          "name": "MEMO DE PRECALIFICACIÓN",
          "type": "BG",
          "status": "V",
          "order": 104,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": true,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        },
        {
          "code": "DECL-SAL",
          "name": "DECLARACIÓN DE SALUD",
          "type": "BG",
          "status": "V",
          "order": 110,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": true,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        },
        {
          "code": "POLV-GEN",
          "name": "PÓLIZA DE SEGURO DE VIDA",
          "type": "BG",
          "status": "V",
          "order": 111,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": true,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        },
        {
          "code": "AUT-DEBCTA",
          "name": "AUTORIZACIÓN DE DÉBITO A CUENTA",
          "type": "BG",
          "status": "V",
          "order": 112,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": true,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        },
        {
          "code": "PAGARE",
          "name": "PAGARÉ",
          "type": "BG",
          "status": "V",
          "order": 114,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": true,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        },
        {
          "code": "CON-FEDEI",
          "name": "CONTRATO DE FIDEICOMISO",
          "type": "BG",
          "status": "V",
          "order": 115,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": true,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        },
        {
          "code": "CART-ATT",
          "name": "CARTA DE ATTT",
          "type": "BG",
          "status": "V",
          "order": 116,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": true,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        },
        {
          "code": "CART-MUN",
          "name": "CARTA DE MUNICIPIO",
          "type": "BG",
          "status": "V",
          "order": 117,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": true,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        },
        {
          "code": "CART-PROM",
          "name": "CARTA PROMESA",
          "type": "BG",
          "status": "V",
          "order": 118,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": true,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        },
        {
          "code": "TRASP-REG",
          "name": "TARJETAS DE TRASPASO ( 3 ) - CLIENTE REGULAR",
          "type": "BG",
          "status": "V",
          "order": 119,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": false,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        },
        {
          "code": "TRASP-IMP",
          "name": "TARJETAS DE TRASPASO ( 3 ) - CLIENTE EXONERADO DE IMPUESTOS",
          "type": "BG",
          "status": "V",
          "order": 120,
          "uploadingRequired": false,
          "printingRequired": false,
          "printingWithDataRequired": false,
          "printed": false,
          "received": false,
          "creationUser": {},
          "printUser": {
            "name": ""
          },
          "sequence": 1
        }
      ],
      "healthData": {
        "medicalCheckRequired": false
      },
      "personViability": {
        "paymentCapacityPolicyP": 35,
        "paymentCapacityPolicyA": 1820,
        "initialPaymentCapacityP": 0,
        "initialPaymentCapacityA": 0,
        "finalPaymentCapacityP": 6.04,
        "finalPaymentCapacityA": 314.22,
        "debtLevelPolicyP": 50,
        "debtLevelPolicyA": 2600,
        "initialDebtLevelP": 5.12,
        "initialDebtLevelA": 266.08,
        "finalDebtLevelP": 11.16,
        "finalDebtLevelA": 580.3
      },
      "exceptionsSupport": "excepciones del principal.",
      "participantType": {
        "id": "N",
        "name": "DUEÑO-DEUDOR"
      },
      "totalCommissions": 0,
      "totalRepresentationExpenses": 0,
      "totalExpenses": 0,
      "totalVehicularPlan": 0,
      "totalBaseSalary": 5200,
      "alert": false,
      "needRevision": false,
      "exonerated": false,
      "retention": false,
      "fulfillment": false,
      "kidnapping": false,
      "internalReferences": "NINGUNA",
      "order": 1,
      "apcData": {
        "apcHeader": {
          "apcDate": "Jul 17, 2017 12:00:00 AM",
          "apcStatus": 4,
          "connectionStatus": "PS_OK,APC_OK",
          "daysAfterLastUpdate": 3
        },
        "creditHistory": {
          "id": "RMAYOR",
          "name": "MAYOR"
        },
        "apcReferenceSummary": {
          "activeGoodCount": 1,
          "activeBadCount": 1,
          "activeNotApplicable": 3,
          "activeRegularCount": 1,
          "hasActiveBadRef": true,
          "paidGoodCount": 0,
          "paidBadCount": 0,
          "paidNotApplicable": 4,
          "paidRegularCount": 0
        },
        "apcFlag": true,
        "activeObligations": [
          {
            "appliesTo": "NING",
            "spAppliesTo": "NING",
            "payments": 24,
            "daysOverdue": 1285,
            "lastPaymentDate": "Mar 11, 2015 12:00:00 AM",
            "paymentMethod": {
              "id": "PAGOS VOLUNTARIOS"
            },
            "apcAmount": 21.77,
            "spApcAmount": 21.77,
            "lastPaymentAmount": 8,
            "percentage": 0,
            "balance": 138.53,
            "type": "OB",
            "status": "A",
            "individualClasification": "RMAYOR",
            "pointColor": "ROJO",
            "relationship": {
              "id": "LINEA ROTATIVA"
            },
            "startDate": "Dec 20, 2010 12:00:00 AM",
            "endDate": "Dec 31, 2011 12:00:00 AM",
            "history": "999999999999999999999999",
            "amount": 522.7,
            "userObservation": "comentario de sustentacion",
            "referenceId": "2010035930",
            "sequence": 1,
            "entityName": "POWERTRONIC CORPORATION ( CREDI CHIP'S )",
            "entityType": "COMERCIO-S",
            "lastUpdate": "Apr 7, 2015 12:00:00 AM"
          },
          {
            "appliesTo": "END",
            "spAppliesTo": "END",
            "payments": 361,
            "daysOverdue": 0,
            "lastPaymentDate": "Mar 31, 2015 12:00:00 AM",
            "paymentMethod": {
              "id": "PAGOS VOLUNTARIOS"
            },
            "apcAmount": 136.18,
            "spApcAmount": 136.18,
            "lastPaymentAmount": 70,
            "percentage": 100,
            "balance": 14149.56,
            "type": "OB",
            "status": "A",
            "individualClasification": "RREGUL",
            "pointColor": "AMAR",
            "relationship": {
              "id": "HIPOTECA"
            },
            "startDate": "Jul 29, 2002 12:00:00 AM",
            "endDate": "Aug 1, 2032 12:00:00 AM",
            "history": "111111111111111110111333",
            "amount": 17704,
            "referenceId": "2002112782",
            "sequence": 2,
            "entityName": "BANCO GENERAL",
            "entityType": "BANCO",
            "lastUpdate": "Apr 6, 2015 12:00:00 AM"
          },
          {
            "appliesTo": "END",
            "spAppliesTo": "END",
            "payments": 186,
            "daysOverdue": 0,
            "lastPaymentDate": "Mar 19, 2015 12:00:00 AM",
            "paymentMethod": {
              "id": "DESCUENTO DIRECTO"
            },
            "apcAmount": 109.9,
            "spApcAmount": 109.9,
            "lastPaymentAmount": 109.9,
            "percentage": 0,
            "balance": 2417.8,
            "type": "OB",
            "status": "A",
            "individualClasification": "RBUENA",
            "pointColor": "VERD",
            "relationship": {
              "id": "PREST. PERSONAL"
            },
            "startDate": "Jun 30, 2009 12:00:00 AM",
            "endDate": "May 10, 2017 12:00:00 AM",
            "history": "110101101010111111110011",
            "amount": 9231.6,
            "referenceId": "2009669688",
            "sequence": 3,
            "entityName": "FINANCOMER, S.A.",
            "entityType": "FINANCIERA",
            "lastUpdate": "Apr 1, 2015 12:00:00 AM"
          },
          {
            "appliesTo": "END",
            "spAppliesTo": "END",
            "payments": 62,
            "daysOverdue": 30,
            "lastPaymentDate": "Mar 19, 2015 12:00:00 AM",
            "paymentMethod": {
              "id": "DESCUENTO DIRECTO"
            },
            "apcAmount": 20,
            "spApcAmount": 20,
            "lastPaymentAmount": 20,
            "percentage": 0,
            "balance": 1010.43,
            "type": "OB",
            "status": "A",
            "individualClasification": "RMAYOR",
            "pointColor": "ROJO",
            "relationship": {
              "id": "L. CREDITO"
            },
            "startDate": "Mar 8, 2014 12:00:00 AM",
            "endDate": "Oct 24, 2019 12:00:00 AM",
            "history": "222223323223188888765432",
            "amount": 1240,
            "userObservation": "comentario",
            "referenceId": "2013000493",
            "sequence": 4,
            "entityName": "CASA CONFORT S.A.",
            "entityType": "MUEBLERIA",
            "lastUpdate": "Apr 6, 2015 12:00:00 AM"
          },
          {
            "appliesTo": "NING",
            "spAppliesTo": "NING",
            "payments": 0,
            "daysOverdue": 0,
            "lastPaymentDate": "Oct 2, 2008 12:00:00 AM",
            "paymentMethod": {
              "id": "PAGOS VOLUNTARIOS"
            },
            "apcAmount": 25.23,
            "spApcAmount": 25.23,
            "lastPaymentAmount": 25.23,
            "percentage": 0,
            "balance": 145.74,
            "type": "OB",
            "status": "A",
            "individualClasification": "RBUENA",
            "pointColor": "GRIS",
            "relationship": {
              "id": "SERVICIOS"
            },
            "startDate": "Sep 25, 2007 12:00:00 AM",
            "history": "111111111111111111111111",
            "amount": 0,
            "userObservation": "sdfsdfsdf",
            "referenceId": "2007857606",
            "sequence": 5,
            "entityName": "CABLE ONDA S.A.",
            "entityType": "COMERCIO-S",
            "lastUpdate": "Apr 13, 2015 12:00:00 AM"
          },
          {
            "appliesTo": "NING",
            "spAppliesTo": "NING",
            "payments": 0,
            "daysOverdue": 458,
            "lastPaymentDate": "Dec 17, 2012 12:00:00 AM",
            "paymentMethod": {
              "id": "PAGOS VOLUNTARIOS"
            },
            "apcAmount": 61.32,
            "spApcAmount": 61.32,
            "lastPaymentAmount": 33.93,
            "percentage": 0,
            "balance": 61.32,
            "type": "OB",
            "status": "A",
            "individualClasification": "RMAYOR",
            "pointColor": "ROJO",
            "relationship": {
              "id": "SERVICIOS"
            },
            "startDate": "Jul 27, 2004 12:00:00 AM",
            "history": "9999888888765",
            "amount": 0,
            "userObservation": "coimentario 2",
            "referenceId": "2013473252",
            "sequence": 6,
            "entityName": "CABLE & WIRELESS PANAMA",
            "entityType": "COMERCIO-S",
            "lastUpdate": "Jun 17, 2014 12:00:00 AM"
          }
        ],
        "paidObligations": [
          {
            "paidDate": "May 31, 2010 12:00:00 AM",
            "type": "OB",
            "status": "C",
            "individualClasification": "RBUENA",
            "pointColor": "GRIS",
            "relationship": {
              "id": "LINEA ROTATIVA"
            },
            "startDate": "Dec 4, 2009 12:00:00 AM",
            "endDate": "Apr 30, 2010 12:00:00 AM",
            "history": "1222111",
            "amount": 89.4,
            "referenceId": "2009891470",
            "sequence": 1,
            "entityName": "POWERTRONIC CORPORATION ( CREDI CHIP'S )",
            "entityType": "COMERCIO-S"
          },
          {
            "paidDate": "Jul 7, 2009 12:00:00 AM",
            "type": "OB",
            "status": "C",
            "individualClasification": "RMAYOR",
            "pointColor": "GRIS",
            "relationship": {
              "id": "TARJ. CREDITO"
            },
            "startDate": "Jan 26, 1999 12:00:00 AM",
            "history": "111122432999999999999999",
            "amount": 1097.68,
            "referenceId": "2002466247",
            "sequence": 2,
            "entityName": "BANCO CITIBANK (PANAMA), S.A.",
            "entityType": "BANCO"
          },
          {
            "paidDate": "Sep 15, 2008 12:00:00 AM",
            "type": "OB",
            "status": "C",
            "individualClasification": "RMAYOR",
            "pointColor": "GRIS",
            "relationship": {
              "id": "PREST. PERSONAL"
            },
            "startDate": "Nov 22, 1999 12:00:00 AM",
            "endDate": "Nov 22, 2005 12:00:00 AM",
            "history": "199999999999999999999999",
            "amount": 4660.68,
            "referenceId": "2002329457",
            "sequence": 3,
            "entityName": "BANCO CITIBANK (PANAMA), S.A.",
            "entityType": "BANCO"
          },
          {
            "paidDate": "Aug 20, 2013 12:00:00 AM",
            "type": "OB",
            "status": "C",
            "individualClasification": "RBUENA",
            "pointColor": "GRIS",
            "relationship": {
              "id": "TARJ. CREDITO"
            },
            "startDate": "Sep 30, 2000 12:00:00 AM",
            "history": "111111111111111111111111",
            "amount": 882.57,
            "userObservation": "sdfsdfsdf",
            "observation": "SALD.TRANS. VENTA CARTERA",
            "referenceId": "2009756121",
            "sequence": 4,
            "entityName": "BANCO CITIBANK (PANAMA), S.A.",
            "entityType": "BANCO"
          }
        ],
        "apcTemporaryFlag": false,
        "apcMark": "S"
      },
      "age": 44,
      "educationLevel": {
        "id": "09"
      },
      "actualEmployments": [
        {
          "id": 5,
          "jobTitle": {
            "id": "037",
            "name": "ACUPUNTURISTA"
          },
          "startDate": "Jan 1, 2001 12:00:00 AM",
          "compliesWithContinuedEmployment": false,
          "employmentStability": true,
          "socialSecurityNumber": "?",
          "baseSalary": 5200,
          "totalSalary": 5200,
          "principalWork": true,
          "vehicularPlanAmount": 0,
          "representationExpensesAmount": 0,
          "commissions": 0,
          "sequence": 5,
          "socialSecurityRecord": {
            "record01": 0,
            "record02": 0,
            "record03": 0,
            "record04": 0,
            "record05": 0,
            "record06": 0,
            "record07": 0,
            "record08": 0,
            "record09": 0,
            "record10": 0,
            "record11": 0,
            "record12": 0,
            "expired": "N",
            "months": 0
          },
          "company": {
            "companyType": {
              "id": "PR",
              "name": "PRIVADA"
            },
            "id": "1",
            "name": "LILIA"
          },
          "status": {
            "id": "E",
            "name": "EMPLEADO"
          },
          "employmentSupportData": {
            "lastYear": ""
          },
          "riskClasification": {
            "id": "CLASIFICADA"
          },
          "workingRegion": {
            "id": "M"
          },
          "type": {
            "id": "E",
            "name": "EMPLEADO"
          },
          "selectedForQuote": false,
          "deleted": false,
          "modified": false
        }
      ],
      "previousEmployments": [],
      "civilStatus": {
        "id": "S"
      },
      "birthDate": "Feb 7, 1973 12:00:00 AM",
      "profession": {
        "id": "015"
      },
      "cobisSegment": {
        "id": "002",
        "segmentDescription": "ESTRELLAS PLATINO",
        "subSegmentId": "28",
        "subSegmentDescription": "ADULTOS JOVENES",
        "category": {
          "id": "4",
          "name": "FUERTE"
        }
      },
      "gender": {
        "id": "F"
      },
      "otherIncome": {
        "amount": 0,
        "modificationFecha": "Jul 19, 2017 12:00:00 AM",
        "type": "OI"
      },
      "contactData": [
        {
          "modificationDate": "Jul 17, 2017 12:00:00 AM",
          "type": {
            "id": "M",
            "name": "CORREO ELECTRONICO"
          },
          "id": "8",
          "name": "falso@holamundo.com"
        },
        {
          "modificationDate": "Mar 6, 2017 12:00:00 AM",
          "type": {
            "id": "M",
            "name": "CORREO ELECTRONICO"
          },
          "id": "6",
          "name": "falso@holamundo.com"
        },
        {
          "modificationDate": "Mar 6, 2017 12:00:00 AM",
          "type": {
            "id": "M",
            "name": "CORREO ELECTRONICO"
          },
          "id": "7",
          "name": "falso@holamundo.com"
        },
        {
          "modificationDate": "Jul 3, 2017 12:00:00 AM",
          "type": {
            "id": "O",
            "name": "TELEFONO DE TRABAJO"
          },
          "id": "0",
          "name": "2535000"
        }
      ],
      "lifePolicyNumber": "DIFE-103752-2017",
      "documentType": "CED",
      "documentNumber": "08  042900099",
      "nationality": {
        "id": "61"
      },
      "secondNationality": {
        "id": "61"
      },
      "addresses": [
        {
          "country": {
            "id": "61",
            "name": "PANAMA"
          },
          "province": {
            "id": "4",
            "name": "CHIRIQUI"
          },
          "district": {
            "id": "20",
            "name": "BOQUETE"
          },
          "township": {
            "id": "994",
            "name": "JARAMILLO"
          },
          "neighborhood": {
            "id": "3",
            "name": "CASA DEL TIGRE"
          },
          "street": "CALLE AMARILLA",
          "foreignAddress": "CASA DEL TIGRE, CALLE AMARILLA",
          "modificationDate": "Jul 3, 2017 12:00:00 AM",
          "addressType": {
            "id": "E",
            "name": "EMPLEO LOCAL"
          },
          "id": "3"
        },
        {
          "country": {
            "id": "177",
            "name": "\"WALLIS Y FUTUNA, ISLAS\""
          },
          "province": {
            "id": "0",
            "name": "OTROS"
          },
          "district": {
            "id": "0",
            "name": "OTROS"
          },
          "township": {
            "id": "0",
            "name": "OTROS"
          },
          "foreignAddress": "TYU",
          "modificationDate": "Jul 3, 2017 12:00:00 AM",
          "addressType": {
            "id": "L",
            "name": "DOMICILIARIA EXTRANJERO"
          },
          "id": "2"
        }
      ],
      "firstName": "FABIOLA",
      "lastName": "MARRERO",
      "creationDate": "Oct 16, 1999 12:00:00 AM",
      "creatorUser": "1006",
      "completeName": "FABIOLA MARRERO",
      "entityId": 301598,
      "foreignFlag": false
    },
    "additionalParticipants": [
      {
        "customerType": {
          "id": "D"
        },
        "working": true,
        "continuedEmployment": false,
        "employmentStability": false,
        "calculatedSalary": 1750,
        "exceptions": [
          {
            "code": "AU009",
            "description": "ESTABILIDAD LABORAL",
            "type": "A"
          },
          {
            "code": "AU018",
            "description": "REFERENCIAS DE CREDITO MAYORES ACTIVAS",
            "type": "A"
          },
          {
            "code": "AU023",
            "description": "MERCADO INDEFINIDO NO REVISADO",
            "type": "A"
          }
        ],
        "documents": [
          {
            "code": "IDENTIF",
            "name": "CÉDULA O PASAPORTE (VIGENTE)",
            "type": "CLT",
            "status": "V",
            "order": 100,
            "uploadingRequired": false,
            "printingRequired": false,
            "printingWithDataRequired": false,
            "printed": false,
            "received": false,
            "creationUser": {},
            "printUser": {
              "name": ""
            },
            "sequence": 2
          },
          {
            "code": "LIC-COND",
            "name": "LICENCIA DE CONDUCIR",
            "type": "CLT",
            "status": "V",
            "order": 120,
            "uploadingRequired": false,
            "printingRequired": false,
            "printingWithDataRequired": false,
            "printed": false,
            "received": false,
            "creationUser": {},
            "printUser": {
              "name": ""
            },
            "sequence": 2
          },
          {
            "code": "CART-TRA",
            "name": "CARTA DE TRABAJO PRINCIPAL (VIGENCIA DE 30 DÍAS)",
            "type": "CLT",
            "status": "V",
            "order": 200,
            "uploadingRequired": false,
            "printingRequired": false,
            "printingWithDataRequired": false,
            "printed": false,
            "received": false,
            "creationUser": {},
            "printUser": {
              "name": ""
            },
            "sequence": 1
          },
          {
            "code": "FIC-TRAAC",
            "name": "FICHA ORIGINAL VIGENTE DE LA CSS DEL TRABAJO PRINCIPAL",
            "type": "CLT",
            "status": "V",
            "order": 220,
            "uploadingRequired": false,
            "printingRequired": false,
            "printingWithDataRequired": false,
            "printed": false,
            "received": false,
            "creationUser": {},
            "printUser": {
              "name": ""
            },
            "sequence": 1
          },
          {
            "code": "UL-COMP",
            "name": "ÚLTIMO COMPROBANTE DE PAGO DEL TRABAJO PRINCIPAL (TALONARIO). (NO APLICA PARA JUBILADO DE EEUU)",
            "type": "CLT",
            "status": "V",
            "order": 230,
            "uploadingRequired": false,
            "printingRequired": false,
            "printingWithDataRequired": false,
            "printed": false,
            "received": false,
            "creationUser": {},
            "printUser": {
              "name": ""
            },
            "sequence": 1
          },
          {
            "code": "CART-APC",
            "name": "CARTA DE APC",
            "type": "BG",
            "status": "V",
            "order": 101,
            "uploadingRequired": false,
            "printingRequired": false,
            "printingWithDataRequired": true,
            "printed": false,
            "received": false,
            "creationUser": {},
            "printUser": {
              "name": ""
            },
            "sequence": 2
          },
          {
            "code": "HOJ-DAT",
            "name": "HOJA DE DATOS DEL CLIENTE",
            "type": "BG",
            "status": "V",
            "order": 102,
            "uploadingRequired": false,
            "printingRequired": false,
            "printingWithDataRequired": true,
            "printed": false,
            "received": false,
            "creationUser": {},
            "printUser": {
              "name": ""
            },
            "sequence": 2
          }
        ],
        "healthData": {
          "medicalCheckRequired": false
        },
        "personViability": {
          "paymentCapacityPolicyP": 35,
          "paymentCapacityPolicyA": 612.5,
          "initialPaymentCapacityP": 0,
          "initialPaymentCapacityA": 0,
          "finalPaymentCapacityP": 17.96,
          "finalPaymentCapacityA": 314.22,
          "debtLevelPolicyP": 50,
          "debtLevelPolicyA": 875,
          "initialDebtLevelP": 15.2,
          "initialDebtLevelA": 266.08,
          "finalDebtLevelP": 33.16,
          "finalDebtLevelA": 580.3
        },
        "exceptionsSupport": "excepciones del secundario",
        "participantType": {
          "id": "D",
          "name": "DEUDOR"
        },
        "totalCommissions": 0,
        "totalRepresentationExpenses": 0,
        "totalExpenses": 0,
        "totalVehicularPlan": 0,
        "totalBaseSalary": 1750,
        "alert": false,
        "needRevision": false,
        "exonerated": false,
        "retention": false,
        "fulfillment": false,
        "kidnapping": false,
        "internalReferences": "NINGUNA",
        "relationshipWithPrincipal": {
          "id": "A",
          "name": "CONYUGE (CONTEMPLA UNIDOS)"
        },
        "order": 2,
        "apcData": {
          "apcHeader": {
            "apcDate": "Jul 11, 2017 12:00:00 AM",
            "apcStatus": 4,
            "connectionStatus": "PS_OK",
            "daysAfterLastUpdate": 9
          },
          "creditHistory": {
            "id": "RMAYOR",
            "name": "MAYOR"
          },
          "apcFlag": true,
          "activeObligations": [
            {
              "appliesTo": "NING",
              "spAppliesTo": "NING",
              "payments": 24,
              "daysOverdue": 1285,
              "lastPaymentDate": "Mar 11, 2015 12:00:00 AM",
              "paymentMethod": {
                "id": "PAGOS VOLUNTARIOS"
              },
              "apcAmount": 21.77,
              "spApcAmount": 21.77,
              "lastPaymentAmount": 8,
              "percentage": 0,
              "balance": 138.53,
              "type": "OB",
              "status": "A",
              "individualClasification": "RMAYOR",
              "pointColor": "ROJO",
              "relationship": {
                "id": "LINEA ROTATIVA"
              },
              "startDate": "Dec 20, 2010 12:00:00 AM",
              "endDate": "Dec 31, 2011 12:00:00 AM",
              "history": "999999999999999999999999",
              "amount": 522.7,
              "userObservation": "aaaa",
              "referenceId": "2010035930",
              "sequence": 1,
              "entityName": "POWERTRONIC CORPORATION ( CREDI CHIP'S )",
              "entityType": "COMERCIO-S",
              "lastUpdate": "Apr 7, 2015 12:00:00 AM"
            },
            {
              "appliesTo": "END",
              "spAppliesTo": "END",
              "payments": 361,
              "daysOverdue": 0,
              "lastPaymentDate": "Mar 31, 2015 12:00:00 AM",
              "paymentMethod": {
                "id": "PAGOS VOLUNTARIOS"
              },
              "apcAmount": 136.18,
              "spApcAmount": 136.18,
              "lastPaymentAmount": 70,
              "percentage": 100,
              "balance": 14149.56,
              "type": "OB",
              "status": "A",
              "individualClasification": "RREGUL",
              "pointColor": "AMAR",
              "relationship": {
                "id": "HIPOTECA"
              },
              "startDate": "Jul 29, 2002 12:00:00 AM",
              "endDate": "Aug 1, 2032 12:00:00 AM",
              "history": "111111111111111110111333",
              "amount": 17704,
              "userObservation": "COMENTARIO JAVIER LLINARES",
              "referenceId": "2002112782",
              "sequence": 2,
              "entityName": "BANCO GENERAL",
              "entityType": "BANCO",
              "lastUpdate": "Apr 6, 2015 12:00:00 AM"
            },
            {
              "appliesTo": "END",
              "spAppliesTo": "END",
              "payments": 186,
              "daysOverdue": 0,
              "lastPaymentDate": "Mar 19, 2015 12:00:00 AM",
              "paymentMethod": {
                "id": "DESCUENTO DIRECTO"
              },
              "apcAmount": 109.9,
              "spApcAmount": 109.9,
              "lastPaymentAmount": 109.9,
              "percentage": 0,
              "balance": 2417.8,
              "type": "OB",
              "status": "A",
              "individualClasification": "RBUENA",
              "pointColor": "VERD",
              "relationship": {
                "id": "PREST. PERSONAL"
              },
              "startDate": "Jun 30, 2009 12:00:00 AM",
              "endDate": "May 10, 2017 12:00:00 AM",
              "history": "110101101010111111110011",
              "amount": 9231.6,
              "referenceId": "2009669688",
              "sequence": 3,
              "entityName": "FINANCOMER, S.A.",
              "entityType": "FINANCIERA",
              "lastUpdate": "Apr 1, 2015 12:00:00 AM"
            },
            {
              "appliesTo": "END",
              "spAppliesTo": "END",
              "payments": 62,
              "daysOverdue": 30,
              "lastPaymentDate": "Mar 19, 2015 12:00:00 AM",
              "paymentMethod": {
                "id": "DESCUENTO DIRECTO"
              },
              "apcAmount": 20,
              "spApcAmount": 20,
              "lastPaymentAmount": 20,
              "percentage": 0,
              "balance": 1010.43,
              "type": "OB",
              "status": "A",
              "individualClasification": "RMAYOR",
              "pointColor": "ROJO",
              "relationship": {
                "id": "L. CREDITO"
              },
              "startDate": "Mar 8, 2014 12:00:00 AM",
              "endDate": "Oct 24, 2019 12:00:00 AM",
              "history": "222223323223188888765432",
              "amount": 1240,
              "userObservation": "aa",
              "referenceId": "2013000493",
              "sequence": 4,
              "entityName": "CASA CONFORT S.A.",
              "entityType": "MUEBLERIA",
              "lastUpdate": "Apr 6, 2015 12:00:00 AM"
            },
            {
              "appliesTo": "NING",
              "spAppliesTo": "NING",
              "payments": 0,
              "daysOverdue": 0,
              "lastPaymentDate": "Oct 2, 2008 12:00:00 AM",
              "paymentMethod": {
                "id": "PAGOS VOLUNTARIOS"
              },
              "apcAmount": 25.23,
              "spApcAmount": 25.23,
              "lastPaymentAmount": 25.23,
              "percentage": 0,
              "balance": 145.74,
              "type": "OB",
              "status": "A",
              "individualClasification": "RBUENA",
              "pointColor": "GRIS",
              "relationship": {
                "id": "SERVICIOS"
              },
              "startDate": "Sep 25, 2007 12:00:00 AM",
              "history": "111111111111111111111111",
              "amount": 0,
              "referenceId": "2007857606",
              "sequence": 5,
              "entityName": "CABLE ONDA S.A.",
              "entityType": "COMERCIO-S",
              "lastUpdate": "Apr 13, 2015 12:00:00 AM"
            },
            {
              "appliesTo": "NING",
              "spAppliesTo": "NING",
              "payments": 0,
              "daysOverdue": 458,
              "lastPaymentDate": "Dec 17, 2012 12:00:00 AM",
              "paymentMethod": {
                "id": "PAGOS VOLUNTARIOS"
              },
              "apcAmount": 61.32,
              "spApcAmount": 61.32,
              "lastPaymentAmount": 33.93,
              "percentage": 0,
              "balance": 61.32,
              "type": "OB",
              "status": "A",
              "individualClasification": "RMAYOR",
              "pointColor": "ROJO",
              "relationship": {
                "id": "SERVICIOS"
              },
              "startDate": "Jul 27, 2004 12:00:00 AM",
              "history": "9999888888765",
              "amount": 0,
              "userObservation": "aaa",
              "referenceId": "2013473252",
              "sequence": 6,
              "entityName": "CABLE & WIRELESS PANAMA",
              "entityType": "COMERCIO-S",
              "lastUpdate": "Jun 17, 2014 12:00:00 AM"
            }
          ],
          "paidObligations": [
            {
              "paidDate": "May 31, 2010 12:00:00 AM",
              "type": "OB",
              "status": "C",
              "individualClasification": "RBUENA",
              "pointColor": "GRIS",
              "relationship": {
                "id": "LINEA ROTATIVA"
              },
              "startDate": "Dec 4, 2009 12:00:00 AM",
              "endDate": "Apr 30, 2010 12:00:00 AM",
              "history": "1222111",
              "amount": 89.4,
              "referenceId": "2009891470",
              "sequence": 1,
              "entityName": "POWERTRONIC CORPORATION ( CREDI CHIP'S )",
              "entityType": "COMERCIO-S"
            },
            {
              "paidDate": "Jul 7, 2009 12:00:00 AM",
              "type": "OB",
              "status": "C",
              "individualClasification": "RMAYOR",
              "pointColor": "GRIS",
              "relationship": {
                "id": "TARJ. CREDITO"
              },
              "startDate": "Jan 26, 1999 12:00:00 AM",
              "history": "111122432999999999999999",
              "amount": 1097.68,
              "referenceId": "2002466247",
              "sequence": 2,
              "entityName": "BANCO CITIBANK (PANAMA), S.A.",
              "entityType": "BANCO"
            },
            {
              "paidDate": "Sep 15, 2008 12:00:00 AM",
              "type": "OB",
              "status": "C",
              "individualClasification": "RMAYOR",
              "pointColor": "GRIS",
              "relationship": {
                "id": "PREST. PERSONAL"
              },
              "startDate": "Nov 22, 1999 12:00:00 AM",
              "endDate": "Nov 22, 2005 12:00:00 AM",
              "history": "199999999999999999999999",
              "amount": 4660.68,
              "referenceId": "2002329457",
              "sequence": 3,
              "entityName": "BANCO CITIBANK (PANAMA), S.A.",
              "entityType": "BANCO"
            },
            {
              "paidDate": "Aug 20, 2013 12:00:00 AM",
              "type": "OB",
              "status": "C",
              "individualClasification": "RBUENA",
              "pointColor": "GRIS",
              "relationship": {
                "id": "TARJ. CREDITO"
              },
              "startDate": "Sep 30, 2000 12:00:00 AM",
              "history": "111111111111111111111111",
              "amount": 882.57,
              "userObservation": "aaaa",
              "observation": "SALD.TRANS. VENTA CARTERA",
              "referenceId": "2009756121",
              "sequence": 4,
              "entityName": "BANCO CITIBANK (PANAMA), S.A.",
              "entityType": "BANCO"
            }
          ],
          "apcTemporaryFlag": false,
          "apcMark": "S"
        },
        "age": 34,
        "educationLevel": {
          "id": "04"
        },
        "actualEmployments": [
          {
            "id": 19,
            "jobTitle": {
              "id": "009",
              "name": "ABOGADO"
            },
            "startDate": "May 14, 2016 12:00:00 AM",
            "compliesWithContinuedEmployment": false,
            "employmentStability": false,
            "baseSalary": 1750,
            "totalSalary": 1750,
            "principalWork": true,
            "vehicularPlanAmount": 0,
            "representationExpensesAmount": 0,
            "commissions": 0,
            "sequence": 19,
            "socialSecurityRecord": {
              "record01": 0,
              "record02": 0,
              "record03": 0,
              "record04": 0,
              "record05": 0,
              "record06": 0,
              "record07": 0,
              "record08": 0,
              "record09": 0,
              "record10": 0,
              "record11": 0,
              "record12": 0,
              "expired": "N",
              "months": 0
            },
            "company": {
              "companyType": {
                "id": "PR",
                "name": "PRIVADA"
              },
              "id": "299436",
              "name": "MERCANTIL DE COMERCIO PANAMENA, S.A.    (MERCOPANSA)"
            },
            "status": {
              "id": "E",
              "name": "EMPLEADO"
            },
            "employmentSupportData": {
              "lastYear": ""
            },
            "riskClasification": {
              "id": "INDEF-NO REVIS"
            },
            "workingRegion": {
              "id": "M"
            },
            "type": {
              "id": "E",
              "name": "EMPLEADO"
            },
            "selectedForQuote": false,
            "deleted": false,
            "modified": false
          }
        ],
        "previousEmployments": [],
        "civilStatus": {
          "id": "U"
        },
        "birthDate": "Apr 21, 1983 12:00:00 AM",
        "profession": {
          "id": "080"
        },
        "cobisSegment": {
          "id": "004",
          "segmentDescription": "ESTRELLAS PLATEADA",
          "subSegmentId": "28",
          "subSegmentDescription": "ADULTOS JOVENES",
          "category": {
            "id": "1",
            "name": "BAJO"
          }
        },
        "gender": {
          "id": "M"
        },
        "otherIncome": {
          "amount": 0,
          "modificationFecha": "Jul 19, 2017 12:00:00 AM",
          "type": "OI"
        },
        "contactData": [
          {
            "modificationDate": "Jul 3, 2017 12:00:00 AM",
            "type": {
              "id": "C",
              "name": "TELEFONO CELULAR"
            },
            "id": "0",
            "name": "123456789"
          },
          {
            "modificationDate": "Jun 28, 2017 12:00:00 AM",
            "type": {
              "id": "M",
              "name": "CORREO ELECTRONICO"
            },
            "id": "1",
            "name": "falso@holamundo.com"
          }
        ],
        "documentType": "CED",
        "documentNumber": "00E 016905161",
        "nationality": {
          "id": "84"
        },
        "secondNationality": {
          "id": "0"
        },
        "addresses": [
          {
            "country": {
              "id": "61",
              "name": "PANAMA"
            },
            "province": {
              "id": "4",
              "name": "CHIRIQUI"
            },
            "district": {
              "id": "18",
              "name": "BARU"
            },
            "township": {
              "id": "410",
              "name": "PROGRESO"
            },
            "neighborhood": {
              "id": "11",
              "name": "PASO CANOA INTERNACIONAL"
            },
            "street": "50",
            "building": "SAN JACINTO 100",
            "foreignAddress": "PASO CANOA INTERNACIONAL, 50, SAN JACINTO 100",
            "modificationDate": "Jul 3, 2017 12:00:00 AM",
            "addressType": {
              "id": "D",
              "name": "DOMICILIARIA LOCAL"
            },
            "id": "3"
          },
          {
            "country": {
              "id": "61",
              "name": "PANAMA"
            },
            "province": {
              "id": "8",
              "name": "PANAMA"
            },
            "district": {
              "id": "1",
              "name": "PANAMA"
            },
            "township": {
              "id": "880",
              "name": "SAN FRANCISCO"
            },
            "neighborhood": {
              "id": "1",
              "name": "SAN FRANCISCO"
            },
            "street": "50",
            "building": "SAN FELIPE 300",
            "foreignAddress": "SAN FRANCISCO, 50, SAN FELIPE 300",
            "modificationDate": "Jul 3, 2017 12:00:00 AM",
            "addressType": {
              "id": "D",
              "name": "DOMICILIARIA LOCAL"
            },
            "id": "2"
          },
          {
            "country": {
              "id": "61",
              "name": "PANAMA"
            },
            "province": {
              "id": "8",
              "name": "PANAMA"
            },
            "district": {
              "id": "1",
              "name": "PANAMA"
            },
            "township": {
              "id": "880",
              "name": "SAN FRANCISCO"
            },
            "neighborhood": {
              "id": "1",
              "name": "SAN FRANCISCO"
            },
            "street": "50",
            "building": "SAN JUAN 200",
            "foreignAddress": "SAN FRANCISCO, 50, SAN JUAN 200",
            "modificationDate": "Jul 3, 2017 12:00:00 AM",
            "addressType": {
              "id": "D",
              "name": "DOMICILIARIA LOCAL"
            },
            "id": "1"
          },
          {
            "country": {
              "id": "61",
              "name": "PANAMA"
            },
            "province": {
              "id": "4",
              "name": "CHIRIQUI"
            },
            "district": {
              "id": "18",
              "name": "BARU"
            },
            "township": {
              "id": "410",
              "name": "PROGRESO"
            },
            "neighborhood": {
              "id": "11",
              "name": "PASO CANOA INTERNACIONAL"
            },
            "street": "DQWEQWEWQE",
            "building": "12",
            "foreignAddress": "PASO CANOA INTERNACIONAL, DQWEQWEWQE, 12",
            "modificationDate": "Jul 3, 2017 12:00:00 AM",
            "addressType": {
              "id": "E",
              "name": "EMPLEO LOCAL"
            },
            "id": "4"
          }
        ],
        "firstName": "JAVIER",
        "middleName": "JOSE",
        "lastName": "LLINARES",
        "motherLastName": "CARRILLO",
        "creationDate": "Oct 31, 2016 12:00:00 AM",
        "creatorUser": "8999",
        "completeName": "JAVIER JOSE LLINARES CARRILLO",
        "entityId": 1357011
      }
    ],
    "carInsurancePolicyAmount": 52,
    "rateFlag": false,
    "carExposure": {
      "id": "NA",
      "name": "NO APLICA"
    },
    "expenses": [
      {
        "debitFromAccount": false,
        "description": "COM_MAN",
        "baseAmmount": 473.85,
        "taxAmmount": 33.17,
        "totalAmmount": 507.02
      },
      {
        "debitFromAccount": false,
        "applies": true,
        "endorsement": false,
        "description": "POL_VIDA",
        "baseAmmount": 449.82,
        "taxAmmount": 0,
        "totalAmmount": 449.82
      },
      {
        "debitFromAccount": false,
        "description": "HON_FID",
        "baseAmmount": 176.55,
        "taxAmmount": 0,
        "totalAmmount": 176.55
      },
      {
        "debitFromAccount": false,
        "description": "NOTARIA",
        "baseAmmount": 1.5,
        "taxAmmount": 0,
        "totalAmmount": 1.5
      },
      {
        "debitFromAccount": false,
        "description": "TIMBRE",
        "baseAmmount": 17.1,
        "taxAmmount": 0,
        "totalAmmount": 17.1
      }
    ],
    "valuationType": {
      "id": "P",
      "name": "PROFORMA"
    },
    "promotion": {},
    "seller": {},
    "quoteViability": {
      "paymentCapacityPolicyP": 35,
      "paymentCapacityPolicyA": 2432.5,
      "initialPaymentCapacityP": 0,
      "initialPaymentCapacityA": 0,
      "finalPaymentCapacityP": 4.52,
      "finalPaymentCapacityA": 314.22,
      "paymentCapacityFlag": false,
      "initialPaymentCapacityFlag": false,
      "paymentCapacityExcess": 0,
      "paymentCapacityAvalabilityP": 0,
      "paymentCapacityAvalabilityA": 0,
      "debtLevelPolicyP": 50,
      "debtLevelPolicyA": 3475,
      "initialDebtLevelP": 7.66,
      "initialDebtLevelA": 532.16,
      "finalDebtLevelP": 12.18,
      "finalDebtLevelA": 846.38,
      "debtLevelFlag": false,
      "initialDebtLevelFlag": false,
      "preApproved": false
    },
    "channel": {
      "id": "700",
      "name": "FINANZAS"
    },
    "operationType": {
      "id": "AUTOS",
      "name": "PRÉSTAMO AUTO"
    },
    "office": {
      "id": "1",
      "name": "CASA MATRIZ"
    },
    "status": {
      "reason": {},
      "id": "EC"
    },
    "stage": {
      "id": "C",
      "name": "COTIZACION"
    },
    "creationDate": "Jul 19, 2017 12:00:00 AM",
    "paymentMethod": {
      "type": "DCTA",
      "id": "DCTA",
      "name": "CARGO A CUENTA"
    },
    "totalSalary": 6950,
    "compliesWithEmployment": true,
    "creditHistory": {
      "id": "RMAYOR",
      "name": "MAYOR"
    },
    "technicalProduct": {
      "account": "0301010848319",
      "description": "CARTERA",
      "name": "JAVIER JOSE LLINARES CARRILLO",
      "product": "7",
      "holdersAmount": "1"
    },
    "coin": {
      "id": "1",
      "name": "DOLARES"
    },
    "observation": "Comentario para evaluador.",
    "user": {
      "channel": {
        "id": "700",
        "name": "FINANZAS"
      },
      "extensionNumber": "70162",
      "jobTitle": "SUBGERENTE DE TECNOLOGIA",
      "location": "Centro Operativo - Piso 3",
      "description": "TI - Desarrollo",
      "emailAddress": "kfuentes@bgeneral.com",
      "id": "1006",
      "name": "Karem Fuentes"
    },
    "signatureUser": {
      "channel": {
        "name": "FINANZAS"
      }
    },
    "commission": 3,
    "rate": 6.5,
    "ratePolicy": 7,
    "suggestedBankRate": 6.5,
    "totalToFinance": 16946.99,
    "payments": 84,
    "recommendedPaymentsNumber": 84,
    "minPaymentsNumber": 6,
    "maxPaymentsNumber": 84,
    "beneficiary": {},
    "totalBaseSalary": 6950,
    "totalExpenses": 0,
    "warnings": [
      {
        "comment": {
          "id": "VC-TC"
        },
        "experience": {
          "id": "El cliente no aplica para venta cruzada con préstamo de auto nuevo (VCAU)."
        },
        "type": {
          "id": "PRECA-COT"
        }
      }
    ],
    "paysFeci": true,
    "baseToFinance": 15795,
    "monthlyPayment": 262.22,
    "crossSelling": {
      "maxLimit": 0,
      "minLimit": 0,
      "suggestLimit": 0,
      "applies": false,
      "accepted": false,
      "creditCard": {}
    },
    "minRate": 3,
    "maxRate": 11,
    "effectiveRate": 7.44,
    "amortizationData": {
      "paymentDay": 1,
      "daysInYear": 360,
      "differsInterests": false,
      "startDate": "Jul 17, 2017 12:00:00 AM",
      "firstPaymentDate": "Sep 1, 2017 12:00:00 AM",
      "firstPaymentInterest": 0,
      "monthlyPayment": 262.22,
      "amount": 16946.99,
      "ballonAmount": -60.71,
      "paysInDecember": true,
      "payments": 84,
      "FeciP": 0.01,
      "receivesMonthlyPayment": false,
      "rate": 0.065,
      "rateWithfeci": 0.075,
      "totalInterest": 5018.47,
      "casaCashCalculationFlag": false
    },
    "actualDate": "Jul 20, 2017 4:05:33 PM",
    "id": 1132209
  });

}(window));
