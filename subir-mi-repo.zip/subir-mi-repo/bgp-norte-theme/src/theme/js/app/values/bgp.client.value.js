(function(win){
	win.MainApp.Values
	.value('bgModelClientData', {
	  obj: {
	    general: {
	      difunto: 'N',
	      tipoClienteNatural: {
	        codigo: 1,
	        nombre: 'CLIENTE'
	      },
	      personaNatural: {
	        apellidoMaterno: '',
	        apellidoPaterno: '',
	        fechaNacimiento: undefined,
	        numeroSeguroSocial: '',
	        primerNombre: '',
	        segundoNombre: '',
	        apellidoCasada: '',
	        nivelEducativo: {},
	        riskClasification: {},
	        subClasificacion: {},
	        calificacion: {},
	        sexo: undefined,
	        profesion: {},
	        estadoCivil: {
	          codigo: '',
	          nombre: ''
	        },
	        documentoIdentidad: '',
	        nacionalidad: {
	          codigo: 61,
	          nacionalidad: ''
	        },
	        nombreCompleto: '',
	        riesgoPais: {
	          codigo: 0,
	          nombre: ''
	        }
	      },
	      autorizacionAPC: 'N',
	      exonerado: 'N',
	      retencion: 'N',
	      malasReferencias: 'N',
	      numero: undefined,
	      referenciasInternas: 'NINGUNA',
	      funcionarioNumero: 0,
	      isCustomer: false
	    },
	    contacts: [],
	    employments: [],
	    references: [],
	    addresses: [],
	    laborAddressList: undefined,
	    personalAddressList: undefined,
	    otherIncomes: [{
	      codigoCotizacion: 0,
	      codigoCliente: 0,
	      monto: 0,
	      fechaCreacion: undefined,
	      usuarioCreacion: '',
	      fechaModificacion: undefined,
	      usuarioModificacion: '',
	      tipoIngreso: {
	        codigo: '',
	        nombre: ''
	      }
	    }]
	  }
	});

}(window));