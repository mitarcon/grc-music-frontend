(function(win){
	win.MainApp.Values
	.value('bgDocumentCode', {

    //COMUNES
    cardAcceptance: 'CAR-ACEP',
    cardApc: 'CART-APC',
    quotation: 'COTIZ',
    dataSheet: 'HOJ-DAT',
    preca: 'PRECA',
    docSustent: 'DOC-SUST',
    perfwla: 'PER-FWLA',
    //fin COMUNES

    att: 'CART-ATT',
    municipality: 'CART-MUN',
    promiseLetter: 'CART-PROM',
    debitAuthorization: 'AUT-DEBCTA',
    lifePolicy: 'POLV-GEN',
    promissoryNote: 'PAGARE',
    healthDeclaration: 'DECL-SAL',
    trustAgreement: 'CON-FEDEI',
    regularTransferCard: 'TRASP-REG',
    exemptTaxTransferCard: 'TRASP-IMP',
    disbursementAuthorization: 'AUT-DESEM',

    //Documentos de hipoteca
    proforma : 'PROFORMA',
    mortgageQuotation : 'COT',
    businessResearch : 'INV-EMP',
    debitAccountAuthorization : 'AUT-DEB-CU',
    checkList : 'CHECK-LIST',

    typeBg: 'BG', //Imprimir
    typeClt: 'CLT', //Cliente Archivar
    typeClm: 'CLM', //Cliente Archivar manual
    typeClg: 'CLG', // Cliente Gestion
  });

}(window));
