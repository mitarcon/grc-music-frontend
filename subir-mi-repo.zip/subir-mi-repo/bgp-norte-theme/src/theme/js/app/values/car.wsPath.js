(function(win){

  /*
   * Ruta de servicios usados en la aplicación
   * Al agregar un nuevo proyecto se debe agregar un value 'wsPathXXX'
   * Se debe agregar en el switch de la funcion serviceRoute del archivo
   * bgp.norte.invoke.service.js este value
   */

  win.MainApp.Values
  .value('wsPathCar', {
    'ws': {
      'initCarQuote': {
        'route': '/o/api/car-quote/manager/initCarQuote/',
        'method': 'POST'
      },
      'updateCarQuote': {
        'route': '/o/api/car-quote/manager/updateCarQuoteSession/',
        'method': 'POST'
      },
      'validateQuote':{
        'route': '/o/api/car-quote/action/validate/',
        'method': 'POST'
      },
      'executeBusinessRule': {
        'route': '/o/api/car-quote/manager/executeCarQuoteRule/',
        'method': 'POST'
      },
      'getCarBrands': {
        'route': '/o/api/carcatalog/getCarBrands',
        'method': 'POST'
      },
      'getCarModels': {
        'route': '/o/api/carcatalog/getCarModels',
        'method': 'POST'
      },
      'getCarAgencies': {
        'route': '/o/api/carcatalog/getCarAgencies',
        'method': 'POST'
      },
      'getYears': {
        'route': '/o/api/car-quote/getYears/',
        'method': 'GET'
      },
      'getParameters':{
        'route': '/o/api/car-quote/carParameters/',
        'method': 'GET'
      },
      'getCatalogs':{
        'route': '/o/api/car-quote/catalogs/',
        'method': 'GET'
      },
      'saveQuote':{
        'route': '/o/api/car-quote/manager/save',
        'method': 'POST'
      },
      'findDifferences':{
        'route': '/o/api/car-quote/findDifferences/',
        'method': 'POST'
      },
      'cancelQuote':{
        'route': '/o/api/car-quote/action/cancel',
        'method': 'POST'
      },
      'clientAccountsPromise':{
        'route': '/o/api/car-quote/clientAccount',
        'method': 'POST'
      },
      'updateCustomerAPCFlag':{
        'route': '/o/api/car-quote/manager/updateCustomerAPCFlag/',
        'method': 'POST'
      },
      'findAPC':{
        'route': '/o/api/car-quote/manager/findAPC/',
        'method': 'POST'
      },
      'nextStage':{
        'route': '/o/api/car-quote/nextStage/',
        'method': 'POST'
      },
      'findTaskValidUser':{
        'route': '/o/api/car-quote/findTaskValidUser/',
        'method': 'POST'
      },
      //Servicios para imprimir documentos
      'acceptanceLetterReportPromise':{
        'route': '/o/api/car-quote/acceptanceLetterReportPromise',
        'method': 'POST'
      },
      'validateAcceptanceLetterReportData':{
        'route': '/o/api/car-quote/validateAcceptanceLetterReportData',
        'method': 'POST'
      },
      'municipalityReportPromise':{
        'route': '/o/api/car-quote/municipalityReportPromise',
        'method': 'POST'
      },
      'validateMunicipalityReportData':{
        'route': '/o/api/car-quote/validateMunicipalityReportData',
        'method': 'POST'
      },
      'attReportPromise':{
        'route': '/o/api/car-quote/attReportPromise',
        'method': 'POST'
      },
      'validateAttReportData':{
        'route': '/o/api/car-quote/validateAttReportData',
        'method': 'POST'
      },
      'quotationReportPromise':{
        'route': '/o/api/car-quote/quotationReportPromise',
        'method': 'POST'
      },
      'validateQuotationReportData':{
        'route': '/o/api/car-quote/validateQuotationReportData',
        'method': 'POST'
      },
      'lifePolicyReportPromise':{
        'route': '/o/api/car-quote/lifePolicyReportPromise',
        'method': 'POST'
      },
      'validateLifePolicyReportData':{
        'route': '/o/api/car-quote/validateLifePolicyReportData',
        'method': 'POST'
      },
      'promissoryNoteReportPromise':{
        'route': '/o/api/car-quote/promissoryNoteReportPromise',
        'method': 'POST'
      },
      'validatePromissoryNoteReportData':{
        'route': '/o/api/car-quote/validatePromissoryNoteReportData',
        'method': 'POST'
      },
      'preQualificationReportPromise':{
        'route': '/o/api/car-quote/preQualificationReportPromise',
        'method': 'POST'
      },
      'validatePreQualificationReportData':{
        'route': '/o/api/car-quote/validatePreQualificationReportData',
        'method': 'POST'
      },
      'healthStatementReportPromise':{
        'route': '/o/api/car-quote/healthStatementReportPromise',
        'method': 'POST'
      },
      'validateHealthStatementReportData':{
        'route': '/o/api/car-quote/validateHealthStatementReportData',
        'method': 'POST'
      },
      'trustAgreementReportPromise':{
        'route': '/o/api/car-quote/trustAgreementReportPromise',
        'method': 'POST'
      },
      'validateTrustAgreementReportData':{
        'route': '/o/api/car-quote/validateTrustAgreementReportData',
        'method': 'POST'
      },
      'regularTransferCardReportPromise':{
        'route': '/o/api/car-quote/regularTransferCardReportPromise',
        'method': 'POST'
      },
      'validateRegularTransferCardReportData':{
        'route': '/o/api/car-quote/validateRegularTransferCardReportData',
        'method': 'POST'
      },
      'exemptTaxTransferCardReportPromise':{
        'route': '/o/api/car-quote/exemptTaxTransferCardReportPromise',
        'method': 'POST'
      },
      'validateExemptTaxTransferCardReportData':{
        'route': '/o/api/car-quote/validateExemptTaxTransferCardReportData',
        'method': 'POST'
      },
      'customerDataSheetReportPromise':{
        'route': '/o/api/car-quote/customerDataSheetReportPromise',
        'method': 'POST'
      },
      'validateCustomerDataSheetReportData':{
        'route': '/o/api/car-quote/validateCustomerDataSheetReportData',
        'method': 'POST'
      },
        'customerProfileReportPromise':{
        'route': '/o/api/car-quote/customerProfileReportPromise',
        'method': 'POST'
      },
        'validateCustomerProfileReportPromise':{
        'route': '/o/api/car-quote/validateCustomerProfileReportPromise',
        'method': 'POST'
      },
      'validateApcLetterReportData': {
        'route': '/o/api/car-quote/validateApcLetterReportData',
        'method': 'POST'
      },
      'apcLetterReportPromise': {
        'route': '/o/api/car-quote/apcLetterReportPromise',
        'method': 'POST'
      },
      'uploadDocument':{
        'route': '/o/api/quote-document/uploadDocument',
        'method': 'POST'
      },
      'updatePrintedField':{
        'route': '/o/api/quote-document/updatePrintedField',
        'method': 'POST'
      },
      'updateUploadedField':{
        'route': '/o/api/quote-document/updateUploadedField',
        'method': 'POST'
      },
      'findFiles':{
        'route': '/o/api/quote-document/findFiles',
        'method': 'POST'
      },
      'downloadFile':{
        'route': '/o/api/quote-document/downloadFile/',
        'method': 'POST'
      },
      'findCreditCardCatalog':{
        'route': '/o/api/car-quote/findCreditCardCatalog/',
        'method': 'POST'
      },
      'findTaskByQuoteIdFromSession':{
        'route': '/o/api/car-quote/taskQuoteFromSession/',
        'method': 'POST'
      },
      'promiseLetterReportPromise': {
        'route': '/o/api/car-quote/promiseLetterReportPromise/',
        'method': 'POST'
      },
      'validatePromiseLetterReportData': {
        'route': '/o/api/car-quote/validatePromiseLetterReportData',
        'method': 'POST'
      },
      'debitAuthorizationReportPromise': {
        'route': '/o/api/car-quote/debitAuthorizationReportPromise/',
        'method': 'POST'
      },
      'validateDebitAuthorizationReportData': {
        'route': '/o/api/car-quote/validateDebitAuthorizationReportData/',
        'method': 'POST'
      },
      'disbursementAuthorizationReportPromise': {
        'route': '/o/api/car-quote/disbursementAuthorizationReportPromise/',
        'method': 'POST'
      },
      'validateDisbursementAuReportData': {
        'route': '/o/api/car-quote/validateDisbursementAuReportData/',
        'method': 'POST'
      },
      'validateClientAccount': {
        'route': '/o/api/car-quote/validateClientAccount',
        'method': 'POST'
      },
      'additionalRoleChange': {
        'route': '/o/api/car-quote/additionalRoleChange',
        'method': 'POST'
      }
    }
  });
}(window));
