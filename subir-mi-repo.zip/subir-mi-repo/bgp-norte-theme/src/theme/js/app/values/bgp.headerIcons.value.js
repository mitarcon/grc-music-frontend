(function(win){
	win.MainApp.Values
	.value('bgModelHeaderIcons', {
	  obj: {
	    credit: true,
	    client: true,
	    details: true,
	    documents: true
	  }
	});

}(window));