(function(win){
	win.MainApp.Values
	.value('bgModelAPCData', {
	  obj: {
	    status: false,
	    authorization: false,
	    daysAfterLastUpdate: 0,
	    clientName: '',
	    clientLastname: '',
	    partnerName: '',
	    creationDate: undefined,
	    deathDate: undefined,
	    lastUpdateDate: undefined,
	    apcRequestCompleted: '',
	    obligationsUses: [],
	    obligations: [],
	    concepts: [],
	    applies: [],
	    paymentMethods: [],
	    summary: {
	      good: 0,
	      regular: 0,
	      high: 0,
	      notApply: 0
	    },
	    obligationsToDelete: [],
	    forceStatus: false
	  }
	});

}(window));