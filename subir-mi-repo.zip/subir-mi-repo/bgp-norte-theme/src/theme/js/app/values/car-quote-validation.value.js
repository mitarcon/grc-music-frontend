/**
 * Value for inputs in car quote validation 
 * @param  {[type]} function [description]
 * @return {[type]}          [description]
 */
(function (win) {
    "use strict";

    var getCarQuoteValidationsValues = function () {
        return {
          engineSerialNumber: {maxLength: 30, pattern: 'alphaNumLatin'},
          chassisSerialNumber: {maxLength: 30, pattern: 'alphaNumLatin'},
          color: {maxLength: 50, pattern: 'alphaNumLatin'},
          signatureUserName: {maxLength: 40, pattern: 'alphaLatinWithoutHyphen'},
          signatureUserChannel: {maxLength: 40, pattern: 'multiLine'},
          beneficiaryCompleteName: {maxLength: 40, pattern: 'alphaLatinWithoutHyphen'},
          beneficiaryDocumentNumber: {maxLength: 20, pattern: 'alphaNumLatin'},
          carQuoteObservation: {maxLength: 255, pattern: 'multiLine'},
          carPrice: {maxLength: 10},
          carDeposit: {maxLength: 10},
          carDepositPercent: {maxLength: 7},
          carQuotePayments: {maxLength: 3},
          carQuoteSellerName: {maxLength: 50, pattern: 'multiLine'},
          carQuoteValuationAmount: {maxLength: 10, pattern: 'currency'},
          carQuotePaymentThirdAccountNumber: {maxLength: 90, pattern: 'alphaNumLatin'},
          carQuoteMileage: {maxLength: 6, pattern: 'carMileage'},
        };
    };

    win.MainApp.Values
        .value("carQuoteValidations", getCarQuoteValidationsValues);
}(window));
