(function(win){
	win.MainApp.Values
	.value('bgModelRulesData', {
	  obj: {
	    general: {},
	    creditCard: {}
	  }
	});

}(window));