(function(win){
	win.MainApp.Values
	.value('bgModelExceptionsData', {
	  obj: {
	    excepciones: [],
	    sustentacion: {},
	    exceptionsToDelete: []
	  }
	});

}(window));
