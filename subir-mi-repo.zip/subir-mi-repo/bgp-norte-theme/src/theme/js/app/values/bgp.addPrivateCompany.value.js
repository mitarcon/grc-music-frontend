(function(win){

  win.MainApp.Values
    .value('bgModelAddPrivateCompany', {
      obj: {
        classification: {
          id: 'INDEF-NO REVIS',
          name: 'MERCADO INDEFINIDO NO REVISADO'
        },
        id: 0,
        name: '',
        companyType: {
          name: 'PRIVADA',
          id: 'PR'
        },
        ruc: ''
      }
    });

}(window));
