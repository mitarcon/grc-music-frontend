(function(win){
  
  win.MainApp.Values
    .value('bgModelJobsData', {
      'id': null,
      'jobTitle': {
        'id': '',
        'name': ''
      },
      'startDate': undefined,
      'modificationDate': undefined,
      'compliesWithContinuedEmployment': false,
      'appliesToContinuedEmployment': false,
      'administrativeCareer': false,
      'employmentStability': false,
      'ruleClasification': '',
      'objectiveMarket': false,
      'sheepNumber': '',
      'socialSecurityNumber': '',
      'baseSalary': 0.0,
      'totalSalary': 0.0,
      'minimumSalaryFlag': false,
      'principalWork': false,
      'incomeType': '',
      'vehicularPlanAmount': 0.0,
      'representationExpensesAmount': 0.0,
      'commissions': 0.0,
      'riskClasification': {},
      'company': {
        'id': '',
        'name': '',
        'companyType': {
          'id': 'PR',
          'name': 'PRIVADA'
        },

      },
      'socialSecurityRecord': {
        'record01': 0.0,
        'record02': 0.0,
        'record03': 0.0,
        'record04': 0.0,
        'record05': 0.0,
        'record06': 0.0,
        'record07': 0.0,
        'record08': 0.0,
        'record09': 0.0,
        'record10': 0.0,
        'record11': 0.0,
        'record12': 0.0,
        'expired': 'N',
        'months': 0
      },
      'employmentSupportData': {
        'supportType': 'R',
        'supportDescription': '',
        'lastAmount': undefined,
        'penultimateAmount': undefined,
        'lastYear': '',
        'penultimateYear': ''
      },
      'type': {
        'id': 'E',
        'name': 'EMPLEADO'
      },
      // initial validate for independent working year
      'yValid': true,
      'workingRegion': {
        "id": '',
        "name": ''
      }
    });


}(window));
