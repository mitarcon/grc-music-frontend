(function(win) {
  /*
   * Ruta de servicios usados en la aplicación Al agregar un nuevo proyecto se
   * debe agregar un value 'wsPathXXX' Se debe agregar en el switch de
   * bgp-norte-service-route.js este value
   */

  win.MainApp.Values.value('wsPathMaintenance', {
    'ws': {
      'getCatalogs': {
        'route': '/o/api/maintenance/catalogs',
        'method': 'GET'
      },
      'initCustomerData': {
        'route': '/o/api/maintenance/initCustomerData',
        'method': 'POST'
      },
      'saveCustomer': {
        'route': '/o/api/maintenance/saveCustomer',
        'method': 'POST'
      },
      'executeRules': {
        'route': '/o/api/maintenance/executeRules',
        'method': 'POST'
      },
      'getParameters': {
        'route': '/o/api/maintenance/parameters',
        'method': 'GET'
      },
      'getCompanies': {
        'route': '/o/api/maintenance/findCompanies',
        'method': 'POST'
      },
      'customerDataSheetReportPromise': {
        'route': '/o/api/maintenance/customerDataSheetReportPromise',
        'method': 'POST'
      },
      'acceptanceLetterReportPromise': {
        'route': '/o/api/maintenance/acceptanceLetterReportPromise',
        'method': 'POST'
      }
    }
  }).value('wsPathCommon', {
    'ws': {
      'getParameters': {
        'route': '/o/api/commonService/parameters/',
        'method': 'GET'
      },
      'getCompanies': {
        'route': '/o/api/commonService/findCompanies/',
        'method': 'POST'
      },
      'executeRules': {
        'route': '/o/api/commonService/executeRules/',
        'method': 'POST'
      },
      'findLDAPUserData': {
        'route': '/o/api/common-service/findLDAPUserData/',
        'method': 'POST'
      },
      'clearSession': {
        'route': '/o/api/common-service/clearSession/',
        'method': 'POST'
      },
      'generateSessionToken': {
        'route': '/o/api/common-service/generateSessionToken/',
        'method': 'GET'
      }
    }
  }).value('wsPathWizard', {
    'ws': {
      'getCatalogs': {
        'route': '/o/api/wizard/catalogs',
        'method': 'GET'
      },
      'initCustomerData': {
        'route': '/o/api/wizard/initCustomerData',
        'method': 'POST'
      },
      'executeRules': {
        'route': '/o/api/wizard/executeRules',
        'method': 'POST'
      },
      'saveCustomer': {
        'route': '/o/api/wizard/saveCustomer',
        'method': 'POST'
      },
      'getParameters': {
        'route': '/o/api/wizard/parameters',
        'method': 'GET'
      },
      'getCompanies': {
        'route': '/o/api/wizard/findCompanies',
        'method': 'POST'
      },
      'apcLetterReportPromise': {
        'route': '/o/api/wizard/apcLetterReportPromise',
        'method': 'POST'
      }
    }
  }).value('wsPathNeighborhood', {
    'ws': {
      'getNeighborhood': {
        'route': '/o/api/neighborhoodcatalog/searchAddressCatalog',
        'method': 'POST'
      }
    }
  }).value('wsPathClientDetails', {
    'ws': {
      'findCustomerGeneralData': {
        'route': '/o/api/client-details/findCustomerGeneralData',
        'method': 'POST'
      }
    }
  }).value('wsPathQuote', {
    'ws': {
      'findQuotesByAssigned': {
        'route': '/o/api/quote/findQuotesByAssigned/',
        'method': 'POST'
      },
      'findQuotesByFilter': {
        'route': '/o/api/quote/findQuotesByFilter/',
        'method': 'POST'
      },
      'findQuoteDifferences': {
        'route': '/o/api/quote/findQuoteDifferences/',
        'method': 'POST'
      }
    }
  }).value('wsPathTask', {
    'ws': {
      'getCatalogs': {
        'route': '/o/api/task/catalogs/',
        'method': 'GET'
      },
      'findCategories': {
        'route': '/o/api/task/findCategories/',
        'method': 'POST'
      },
      'findTaskByAdvanceSearch': {
        'route': '/o/api/task/findTaskByAdvanceSearch/',
        'method': 'POST'
      },
      'findAssigmentOptions': {
        'route': '/o/api/task/findAssigmentOptions/',
        'method': 'POST'
      },
      'selectAssigmentOption': {
        'route': '/o/api/task/selectAssigmentOption/',
        'method': 'POST'
      },
      'findUserData':{
        'route': '/o/api/task/findUserData/',
        'method': 'GET'
      },
      'findUsersRol':{
    	'route': '/o/api/task/findUsersRol/',
    	'method': 'GET'
      },
      'findUserOffices':{
        'route': '/o/api/task/findUserOffices/',
        'method': 'GET'
      },
      'isMine':{
        'route': '/o/api/task/isMine/',
        'method': 'GET'
      }
    }
  }).value('wsPathCarCatalogs', {
    'origin': '/o/api/carcatalog/',
    'ws': {
      'getCarBrands': {
        'route': '/o/api/carcatalog/getCarBrands/',
        'method': 'POST'
      },
      'getCarAgencies': {
        'route': '/o/api/carcatalog/getCarAgencies/',
        'method': 'POST'
      },
      'getCarModels': {
        'route': '/o/api/carcatalog/getCarModels/',
        'method': 'POST'
      },
      'load': {
        'route': '/o/api/carcatalog/load/',
        'method': 'GET'
      }
    }
  }).value('wsPathClientSearch', {
    'ws': {
      'findClients': {
        'route': '/o/api/client-search/findCustomersByFilter',
        'method': 'POST'
      },
      'findQuotes': {
        'route': '/o/api/client-search/findQuotes',
        'method': 'POST'
      },
      'findParticipantDetail': {
        'route': '/o/api/client-search/findParticipantDetail',
        'method': 'POST'
      },
      'getCustomerDetails': {
        'route': '/o/api/client-search/details',
        'method': 'POST'
      }
    }
  }).value('wsPathCatalogs', {
    'ws': {
      'getCatalogs': {
        'route': '/o/api/catalog/quoteCatalogs/',
        'method': 'GET'
      },
      'findCreditCardCatalog':{
        'route': '/o/api/car-quote/findCreditCardCatalog/',
        'method': 'POST'
      }
    }
  }).value('wsPathNotifications', {
    'ws': {
      'getNotificationsByUser': {
        'route': '/o/api/notification/getNotificationsByUser/',
        'method': 'POST'
      },
      'deleteNotification': {
        'route': '/o/api/notification/deleteNotification/',
        'method': 'POST'
      },
      'deleteAllNotifications': {
        'route': '/o/api/notification/deleteAllNotifications/',
        'method': 'POST'
      },
      'updateAllNotifications': {
        'route': '/o/api/notification/updateAllNotifications/',
        'method': 'POST'
      }
    }
  }).value('wsPathSummary', {
	'ws': {
	   'findQuoteSummaryByProduct': {
	     'route': '/o/api/quote-summary/findQuoteSummaryByProduct',
	     'method': 'POST'
	   }
	}
  }).value('wsPathRecord', {
	 'ws': {
	    'findQuoteHistory':{
	      'route': '/o/api/quote-record/findQuoteHistory',
	      'method': 'POST'
	     },
	     'saveTrackingNotes':{
	       'route': '/o/api/quote-record/saveTrackingNotes',
	       'method': 'POST'
	     },
       'updateSession':{
         'route': '/o/api/quote-record/updateSession',
	       'method': 'POST'
       }
	  }
  }).value('wsPathQuoteEvaluation', {
    'ws': {
      'initEvaluationQuote':{
        'route': '/o/api/quote-evaluation/initEvaluationQuote',
        'method': 'POST'
      },
      'findQuoteSpecificReasons':{
        'route': '/o/api/quote-evaluation/findQuoteSpecificReasons',
        'method': 'POST'
      },
      'findUserData':{
        'route': '/o/api/quote-evaluation/findUserData',
        'method': 'POST'
      },
      'updatePrintedField':{
        'route': '/o/api/quote-document/updatePrintedField',
        'method': 'POST'
      },
      'findFiles':{
        'route': '/o/api/quote-document/findFiles',
        'method': 'POST'
      },
      'downloadFile':{
        'route': '/o/api/quote-document/downloadFile/',
        'method': 'POST'
      }
    }
  }).value('wsPathQuoteCommunication', {
	 'ws': {
     'findCommunicationByProduct':{
       'route': '/o/api/quote-communication/findCommunicationByProduct',
       'method': 'POST'
      },
      'saveCommunication':{
        'route': '/o/api/quote-communication/saveCommunication',
        'method': 'POST'
      },
      'findFiles':{
        'route': '/o/api/quote-document/findFiles',
        'method': 'POST'
      },
      'downloadFile':{
        'route': '/o/api/quote-document/downloadFile/',
        'method': 'POST'
      },
      'updateTaskSession':{
        'route': '/o/api/quote-communication/updateTaskSession/',
        'method': 'POST'
      }
	  }
    })
    .value('wsPathCarQuoteDetails', {
      'ws': {
        'initCarQuote': {
          'route': '/o/api/car-quote-details/manager/initCarQuote',
          'method': 'POST'
        },
        'getCatalogs': {
          'route': '/o/api/car-quote-details/catalogs',
          'method': 'GET'
        }
      }
  }).value('wsPathTaskCarQuoteLayout', {
    'ws': {
      'validateTask': {
        'route': '/o/api/car-quote/action/validateStage/',
        'method': 'POST'
      }
    }
  }).value('wsPathAccountOpening', {
    'ws': {
      'findAPC':{
        'route': '/o/api/account-opening/findAPC/',
        'method': 'POST'
      }
    }
  }).value('wsPathQuoteReview', {
    'ws': {
      'initReview':{
        'route': '/o/api/quote-review/initReview/',
        'method': 'POST'
      },
      'saveReview':{
        'route': '/o/api/quote-review/saveReview/',
        'method': 'POST'
      },
      'updateTaskSession':{
        'route': '/o/api/quote-review/updateTaskSession/',
        'method': 'POST'
      }
    }
  }).value('wsPathCustomerManagement', {
    'ws': {
      'getCatalogs': {
        'route': '/o/api/customer-management/catalogs',
        'method': 'GET'
      },
      'initCustomerData': {
        'route': '/o/api/customer-management/initCustomerData',
        'method': 'POST'
      },
      'saveCustomer': {
        'route': '/o/api/customer-management/saveCustomer',
        'method': 'POST'
      },
      'executeRules': {
        'route': '/o/api/customer-management/executeRules',
        'method': 'POST'
      },
      'getParameters': {
        'route': '/o/api/customer-management/parameters',
        'method': 'GET'
      },
      'getCompanies': {
        'route': '/o/api/customer-management/findCompanies',
        'method': 'POST'
      },
      'customerDataSheetReportPromise': {
        'route': '/o/api/customer-management/customerDataSheetReportPromise',
        'method': 'POST'
      },
      'acceptanceLetterReportPromise': {
        'route': '/o/api/customer-management/acceptanceLetterReportPromise',
        'method': 'POST'
      }
    }
  }).value('wsPathAccountOpeningApproval', {
    'ws': {
      'findAPC':{
        'route': '/o/api/account-opening-approval/findAPC/',
        'method': 'POST'
      }
    }
  });
}(window));
