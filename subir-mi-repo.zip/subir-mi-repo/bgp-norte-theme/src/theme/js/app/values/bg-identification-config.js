(function(win){
  'use strict';
  function identificationConfig(clientNameRule){
    return[
      {
        name: 'province',
        max: 2,
        placeholder: '',
        defaultHolder: '0',
        input: '',
        complete: '',
        required: true,
        css: '2',
        classes: '',
        pattern: clientNameRule.province.pattern,
        pad: 'left'
      },
      {
        name: 'alpha',
        max: 2,
        placeholder: '',
        defaultHolder: ' ',
        input: '',
        complete: '',
        required: true,
        css: '2',
        classes: '',
        pattern: clientNameRule.alpha.pattern,
        pad: 'right'
      },
      {
        name: 'folio',
        max: 4,
        defaultHolder: '0',
        placeholder: '',
        input: '',
        complete: '',
        required: true,
        css: '3',
        classes: '',
        pattern: clientNameRule.folio.pattern,
        pad: 'left'
      },
      {
        name: 'seat',
        max: 6,
        placeholder: '',
        defaultHolder: '0',
        input: '',
        complete: '',
        required: true,
        css: '4',
        classes: '',
        pattern: clientNameRule.seat.pattern,
        pad: 'left'
      }
    ];
  }
  identificationConfig.$inject = ['clientNameRule'];
  win.MainApp.Values
    .factory('identificationConfig', identificationConfig);
}(window));
