(function(win) {
  "use strict";

  var ThemeController = function($log, modalService, storage,
    bgProductConfig, bgValue, translate, redirect, popUpService,
    queryParamsService, routeInvoker, isEmpty) {

    $log.debug("[Liferay/Angular/ThemeController] Initializing...");

    /*
     * ============== VALUES ==============
     */

    // VM
    var vm = this;

    // Loader
    vm.showLoading = false;

    /*
     * ============== METHODS ==============
     */

     function isBGLogoDisabled() {

       var url = redirect.getAllUrls();
       var disableLogoUrls;
       var canRedirect = true;

       if(!isEmpty(url)) {
         disableLogoUrls = [url.clientUrl, url.accountOpeningUrl, url.accountOpeningApprovalUrl,
           url.customerManagementUrl, url.liabilityAdviceUrl];

         for (var i = 0; i < disableLogoUrls.length; i++) {
           if(window.location.href.includes(disableLogoUrls[i])) {
             canRedirect = false;
           }
         }
       }

       return canRedirect;

     }

    vm.searchClient = function() {
      var attrs = {
        bgModalTitle: translate.getValue('search.client'),
        bgModalTpl: "bgp-norte-theme/angular/partials/bgp-popup/bg-client-search.html",
        bgSize: "lg",
        bgModalData: {
          clientSearchAction: bgValue('clientSearchAction').details
        }
      };
      openModal(attrs);
    };

    //TODO: Se eliminará esta función cuando toda el portal este en modo pestaña

    vm.changeUrlValidation = function(url) {

      if(isBGLogoDisabled()) {

        if (!angular.isDefined(angular
            .element(
              document.getElementById('quoteMasterForm')).scope()) &&
              !angular.isDefined(angular
                  .element(
                    document.getElementById('masterForm')).scope())) {
          vm.toInbox();
          return;
        }
        if (unsavedChange()) {

          var attrs = {
            bgPopupTitle: translate.getValue('global.unsaved.changes'),
            bgPopupMessage: translate.getValue('global.unsaved.changes') + "." +
              translate.getValue('global.want.to.leave.without.saving'),
            bgPopupOkText: translate.getValue('global.exit.without.saving'),
            bgPopupCancelText: translate.getValue('quote.save.back'),
            bgPopupFromService: true,
            bgPopupMethod: function() {
              vm.toInbox();
            }
          };

          popUpService.open(attrs);

        } else {
          vm.toInbox();
        }
      }

    };

    function unsavedChange() {
      var taskMasterForm = angular
        .element(
          document.getElementById('masterForm')).scope();
      var masterQuoteScope = angular
        .element(
          document.getElementById('quoteMasterForm')).scope();
        return (angular.isDefined(masterQuoteScope) &&
            angular.isDefined(masterQuoteScope.ctrl) &&
            angular.isDefined(masterQuoteScope.ctrl.global.quoteMasterForm) &&
            masterQuoteScope.ctrl.global.quoteMasterForm.$dirty) ||
          (angular.isDefined(masterQuoteScope) &&
            angular.isDefined(masterQuoteScope.ctrl) &&
            angular.isDefined(masterQuoteScope.ctrl.global.dirtyFormFlag) &&
            masterQuoteScope.ctrl.global.dirtyFormFlag.flagDirty) ||
          (angular.isDefined(taskMasterForm) &&
          angular.isDefined(taskMasterForm.layCtrl) &&
            angular.isDefined(taskMasterForm.layCtrl.global.masterForm) &&
          taskMasterForm.layCtrl.global.masterForm.$dirty);
    }

    vm.newQuote = function(product) {

          product = product.toUpperCase();

          var typeQuote;

          switch (product) {
            case bgProductConfig.get(bgValue('apps').car).title:
              typeQuote = bgValue('apps').car;
              break;
            case bgProductConfig.get(bgValue('apps').credit).title:
              typeQuote = bgValue('apps').credit;
              break;
            default:
              // TODO: Modal de alerta
              return null;
          }

        //  if(product == bgProductConfig.get(bgValue('apps').typeQuote).title) {
            storage.setProductConfig(bgProductConfig.get(typeQuote));

            var attrs = {
              bgModalTitle: translate.getValue('search.title', [storage.getProductConfig().title]),
              bgModalTpl: "bgp-norte-theme/angular/partials/bgp-popup/bg-client-search.html",
              bgSize: "lg",
              bgModalData: {
                clientSearchAction: bgValue('clientSearchAction').quote,
                initTracing: vm.initTracing
              }
            };

            openModal(attrs);
          //}

        };

    function openModal(attrs) {
      modalService.open(attrs);
    }

    vm.redirectTo = function(name, url) {

      var attrs = {};

      if(name == 'Apertura de Cuentas de Depósito') {

        storage.setProductConfig(bgProductConfig.get(bgValue('apps').liabilityAdvice));
        attrs = {
          bgModalTitle: translate.getValue('search.client'),
          bgModalTpl: "bgp-norte-theme/angular/partials/bgp-popup/bg-client-search.html",
          bgSize: "lg",
          bgModalData: {
            clientSearchAction: bgValue('clientSearchAction').liabilityAdvice,
            addNewClientMessage: translate.getValue('account.opening.to.new.client')
          }
        };

        openModal(attrs);

      } else {
        window.location.assign(url);
      }


    };

    vm.toInbox = function() {
      redirect.toInbox();
    };

    vm.generateSessionToken = function() {
      return routeInvoker.invoke(bgValue('apps').commons,
        'generateSessionToken');
    };

    /*
     * ============== SETUP ==============
     */

    vm.setup = function() {

      var xhr = vm.generateSessionToken();

      xhr.then(function(response) {
        redirect.toInit();
        vm.messageTitle = queryParamsService.get("messageTitle");
        vm.sessionToken = true;
      });

      xhr.catch(function(exception) {
        $log.error("Error en CommunicationController.saveCommunication ",
          exception);
      });

    };

    vm.setup();
  };

  /*
   * ============== CONFIGURATION ==============
   */
  ThemeController.$inject = [
    "$log",
    "modalService",
    "storageService",
    "bgProductConfig",
    "bgValueFilter",
    "translateService",
    "bgRedirectService",
    'bgPopUpService',
    "queryParamsService",
    "routeInvoker",
    "isEmptyFilter"
  ];

  win.MainApp.Controllers.controller("ThemeController", ThemeController);

}(window));
