(function(win){
  "use strict";


    var formerWorkplaceController = function(log,scope) {

      log.debug("[CompanyController] Initializing...");

      /*
      ==============
      VALUES
      ==============
      */

      scope.modal=['anotherCompany'];

      /*
      ==============
      METHODS
      ==============
      */

      scope.changeModal = function (value) {
        scope.chargeModal = value;
      };

      scope.hideSustainedWork = function(data){
        for (var i = 0; i < scope.data.length; i++) {

          if(angular.isDefined(scope.data[i].config.beforeEmployment) &&
              scope.data[i].type.id.trim()==='E' &&
              angular.equals(scope.data[i].config.beforeEmployment, data)){

            return true;
          }
        }
        return false;
      };

      scope.listValidData = function (data) {
        return data.type.id.trim()==='C' &&
          (data.company.companyType.id === 'PR' ||
          data.company.companyType.id === 'PU') &&
          !scope.hideSustainedWork(data);
      };


    };


    formerWorkplaceController.$inject = ['$log','$scope'];
    win.MainApp.Controllers
      .controller('formerWorkplaceController',formerWorkplaceController);

}(window));
