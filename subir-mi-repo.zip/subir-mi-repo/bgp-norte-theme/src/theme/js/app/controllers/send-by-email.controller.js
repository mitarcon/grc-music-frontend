(function (win) {
  "use strict";

  var sendByEmailController = function ($log, filter, scope, bgValue, isEmpty) {

    $log.debug(
      "[Liferay/Angular/sendByEmailController] Initializing...");

    /*
     * ============== VALUES ==============
     */

    // VM
    var vm = this;

    // Loader
    vm.showLoading = false;

    vm.setEmailsSelected = function() {

      var selectedEmails = [];
      var emailsAsString = "";

      if (scope.data.emailData.participants.length <= 0) {
        return emailsAsString;
      }

      for (var i = 0; i < scope.data.emailData.participants.length; i++) {
        selectedEmails.push(filter('filter')
          (scope.data.emailData.participants[i].emails, {selected: true}, true));
      }

      for (var j = 0; j < selectedEmails.length; j++) {
        for(var k = 0; k < selectedEmails[j].length; k++) {
          emailsAsString = emailsAsString + selectedEmails[j][k].name + ";";
        }
      }

      return emailsAsString;
    };

    vm.setRequirements = function() {

      var participants = scope.data.emailData.participants;

      var requirementsAsString = "";

      for (var i = 0; i < participants.length; i++) {
        requirementsAsString = requirementsAsString + "" +
          participants[i].completeName + "%0D%0A";
        if(!isEmpty(participants[i].requirements)) {
          for (var j = 0; j < participants[i].requirements.length; j++) {
            requirementsAsString = requirementsAsString + "   %E2%80%A2   " +
              participants[i].requirements[j].name + "%0D%0A";
          }
        }
      }

      return requirementsAsString + "%0D%0A";

    };


  };

  /*
   * ============== CONFIGURATION ==============
   */
  sendByEmailController.$inject = [
    "$log",
    "$filter",
    "$scope",
    "bgValueFilter",
    "isEmptyFilter"
  ];

  win.MainApp.Controllers
    .controller("sendByEmailController", sendByEmailController);

}(window));
