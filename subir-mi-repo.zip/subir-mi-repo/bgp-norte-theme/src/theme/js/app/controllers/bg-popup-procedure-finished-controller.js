(function(win) {
  "use strict";

  function ProcedureFinishedCtrl(
    alertNotifyService,
    $log,
    bgValue,
    isEmpty
  ) {

    // VM
    var vm = this;
    vm.setup = setup;
    vm.tryAgain = tryAgain;
    vm.initialTime = new Date();

    var interval = bgValue('timeInterfaceLiquidation').interval;
    var incrementInterval = bgValue('timeInterfaceLiquidation').incrementInterval;
    var maxTime = bgValue('timeInterfaceLiquidation').maxTime;

    /*
     * ==============
     *      SETUP
     * ==============
     */
    function setup(data) {
      vm.data = data;
      callRecursiveService();
    }

    function callRecursiveService(){

      if(vm.data.init.stopCall || !applyCallRecursive()){
        return;
      }
      recursiveService();
    }

    function recursiveService(){
      var data = {
        quoteId: vm.data.task.procedureId,
        statusFromTail: true
      };
      vm.data.checkStatusInterfaceService(data)
      .then(function(response){
        vm.data.init = validateSteps(response.data);
        interval = interval + incrementInterval;
        setTimeout(callRecursiveService, interval);
      })
      .catch(function(exception){
        $log.error("Error en ProcedureFinishedCtrl checkStatusInterfaceService", exception);
        alertNotifyService.showErrorT('common-unexpected-error');
      });
    }
    function applyCallRecursive(){
      var actualTime = new Date();
      var diffMs = (actualTime - vm.initialTime);
      return diffMs < maxTime;
    }
    function tryAgain(){
      var data = {
          quoteId: vm.data.task.procedureId,
        };
      vm.data.retryInterfaceService(data)
      .then(function(response){
        vm.initialTime = new Date();
        vm.data.init = validateSteps(response.data);
        callRecursiveService();
      })
      .catch(function(exception){
        $log.error("Error en ProcedureFinishedCtrl retryInterfaceService", exception);
        alertNotifyService.showErrorT('common-unexpected-error');
      });
    }
    function validateSteps (object){
      if(isEmpty(object.steps))
        object.steps = vm.data.init.steps;

      return object;
    }
  }

  /*
   * ================
   *  CONFIGURATION
   * ================
   */

  ProcedureFinishedCtrl.$inject = [
    'alertNotifyService',
    '$log',
    'bgValueFilter',
    'isEmptyFilter'
  ];

  win.MainApp.Controllers
    .controller('ProcedureFinishedCtrl', ProcedureFinishedCtrl);

}(window));
