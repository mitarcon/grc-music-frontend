(function (win) {
  "use strict";

  var PopupNextController = function (
    filter,
    isEmpty,
    alertNotifyService,
    translateService,
    scope,
    bgRedirectService,
    translate,
    bgValue) {

    // VM
    var vm = this;

    vm.findUserFn = findUserFn;
    vm.selectTaskNext = selectTaskNext;
    vm.isDisabled = isDisabled;
    vm.showSaleCatalog = showSaleCatalog;
    
    function isDisabled() {
      return scope.nextTaskForm.$valid === false;
    }

    function selectTaskNext(attrs) {
      var option = {};
      if (!isEmpty(vm.data.availableOptions) &&
        vm.data.availableOptions instanceof Array &&
        vm.data.availableOptions.length > 0) {
        var type = filter('bgValue')('routingTaskOptionsTypes').nextButtonVal;
        option = filter('filter')(vm.data.availableOptions, function (item) {
          return item.type === type;
        })[0];

      }

      var nextStageWrapper = {
        'task': vm.data.sharedService.task,
        'observation': attrs.observation,
        'action': {
          'id': option.id
        },
        'user': attrs.user,
        'salesModel': attrs.salesModel.id,
        'forward': true
      };

      vm.showLoading = true;
      vm.data.services.moveToNextStage(nextStageWrapper)
        .then(function (response) {
          updateSharedServideByProductType(response.data, vm.data.product);
          bgRedirectService.toTaskFromNextTask(
            response.data.task,
            response.data.myTask,
            translate.getValue('global.quote'));
        }).catch(function (response) {
          if (response.data && response.data.name) {
            alertNotifyService.showError(response.data.name);
          } else {
            alertNotifyService.showError(
              translateService.getValue('constant.error.unexpected'));
          }
        }).finally(function () {
          vm.showLoading = false;
        });

    }

    function findUserFn(userId) {

      vm.showLoading = true;
      vm.data.services.findTaskValidUser({
          'id': userId
        })
        .then(function (response) {
          if (!isEmpty(response.data.error) && response.data.error) {
            scope.nextTaskForm.cobisUser.$setValidity('nextValidUserTask',
              false);
          } else {
            scope.nextTaskForm.cobisUser.$setValidity('nextValidUserTask',
              true);
          }

          vm.user = response.data.user;
        }).catch(function (data) {

          scope.nextTaskForm.cobisUser.$setValidity('nextValidUserTask',
            false);
        }).finally(function () {
          vm.showLoading = false;
        });

    }

    function updateSharedServideByProductType(data, product) {
      vm.data.sharedService.task = data.task;
      switch (product) {
        case bgValue('product').car:
          updateSharedServiceQuote(vm.data.sharedService.carQuote, data);
          break;
        case bgValue('product').credit:
          updateSharedServiceQuote(vm.data.sharedService.creditCardQuote,
            data);
          break;
        case bgValue('product').mortgage:
          updateSharedServiceQuote(vm.data.sharedService.mortgageQuote,
            data);
          break;
        default:
          break;
      }
    }

    function updateSharedServiceQuote(quote, data) {
      quote.stage = data.task.stage;
      quote.status = data.task.status;
      quote.user = data.assignedUser;
    }

    function showSaleCatalog() {
        var product = vm.data.product;
        switch (product) {
          case bgValue('product').car:
              return true;     	  
            break;
          case bgValue('product').credit:
        	  return false;
            break;
          default:
            break;
        }
      }
    
    /*
     * ==============
     *      SETUP
     * ==============
     */
    vm.setup = function (data) {
      vm.data = data;
      vm.user = angular.copy(vm.data.user);
    };

  };

  /*
   * ================
   *  CONFIGURATION
   * ================
   */

  PopupNextController.$inject = [
    '$filter',
    'isEmptyFilter',
    'alertNotifyService',
    'translateService',
    '$scope',
    'bgRedirectService',
    'translateService',
    'bgValueFilter'
  ];
  win.MainApp.Controllers
    .controller('PopupNextController', PopupNextController);

}(window));
