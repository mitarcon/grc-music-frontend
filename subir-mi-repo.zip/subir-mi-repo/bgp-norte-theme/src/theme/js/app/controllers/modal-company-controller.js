(function(win){
  "use strict";


    var CompanyController = function(log, isEmpty, translate, catalogService,
    modelAddPrivateCompany, paramService, commonFunctions, routeInvoker,
    NgTableParams, alertNotifyService, scope) {

      log.debug("[CompanyController] Initializing...");

      /*
      ==============
      VALUES
      ==============
      */


      // VM
      var vm = this;

      vm.typeCompany = {};
      vm.company = [];
      vm.addAnotherCompany = false;
      vm.filter = {};
      var filterCompany = {};
      vm.filter.typeCompany = catalogService.item(
        'PR', 'typeCompany',scope.product);
      vm.newPrivateCompany = angular.copy(modelAddPrivateCompany.obj);
      vm.newPrivateCompany.id = paramService.getLegalEntity();
      vm.showTables = false;

      vm.modal = ['searchWorkplace', 'addPrivateCompany',
        'companyIndefiniteMarket'
      ];

      /*
      ==============
      METHODS
      ==============
      */

      vm.changeModal = function (value) {
        vm.newPrivateCompany.name = vm.filter.companyName;
        vm.chargeModal = value;
      };

      var companyTableConfig = function () {
      var initialParams = {
        count: 5 // rows count per page
      };
      var initialSettings = {
        // rows count per page buttons (right set of buttons in demo)
        counts: null,
        // determines the pager buttons (left set of buttons in demo)
        paginationMaxBlocks: 7, //maximum of pager blocks
        paginationMinBlocks: 1, //minimum of pager blocks
        dataset: vm.company
      };
      return new NgTableParams(initialParams, initialSettings);
    };


      var checkCompanyList = function (dataList) {
        vm.company = [];
        if (dataList.length > 0) {
          vm.company = dataList;
        }
        vm.companyTable = companyTableConfig();

      };

      var companysMessage = function (numberJobsFound) {
        vm.messageColor = false;
        if (numberJobsFound === 0 && vm.filter.companyName.length > 0) {
          vm.message = translate.getValue('job.zeroWorkplacesFound', [vm.filter
            .companyName.toUpperCase()
          ]);
          vm.messageColor = true;
        }
        if (numberJobsFound === 1) {
          vm.message = translate.getValue('job.oneWorkplacesFound', [vm.filter
            .companyName.toUpperCase()
          ]);
        }
        // Menos de 50 registros
        if (numberJobsFound > 1 && numberJobsFound < 50) {
          vm.message = translate.getValue('job.title.workplacesFound',
            [vm.numberJobsFound,
              vm.filter.companyName.toUpperCase()
            ]);
        }
        // 50 o mas de 50 registros
        if (numberJobsFound > 49) {
            vm.message = translate.getValue('job.manyResultsFound');
            vm.messageColor = true;
          }
      };

      vm.findCompany = function () {
        if (isEmpty(vm.filter.typeCompany.id) || isEmpty(vm.filter
          .companyName)) {
          return;
        }

        filterCompany = {
          typeCompany: vm.filter.typeCompany.id,
          companyName: vm.filter.companyName.toUpperCase()
        };

        log.debug("[findCompanies data].... ", filterCompany);

        if (isEmpty(filterCompany)) {
          return;
        }

        routeInvoker.invoke(scope.product, "getCompanies",
          filterCompany).then(
          function(response) {
            log.debug('[findCompany response]....', response.data);

            vm.numberJobsFound = angular.isDefined(response.data) ?
              response.data.length : 0;
            companysMessage(vm.numberJobsFound);
            checkCompanyList(response.data);

            vm.addAnotherCompany = filterCompany.typeCompany.trim() ==='PR';
            vm.showTable(vm.company, filterCompany.typeCompany);
            // Ocultar/mostrar boton añadir otra empresa
            if (response.data.length > 49) {
          	  	vm.addAnotherCompany = false;
              } else {
              	vm.addAnotherCompany = true;
              }
          },
          /*
         * TODO: jgiron
         * Manejar en respuesta del servicio
         *Valor diferente a String
         */
          function(data) {
            alertNotifyService.showErrorT(data);
            if (data.data === 'MUCHOS REGISTROS') {
              vm.message = translate.getValue('job.manyResultsFound');
              vm.messageColor = true;
              vm.company = {};
              vm.showTables = false;
            }
          }
        );
      };

      vm.showAddAnotherCompany = function () {
        checkCompanyList([]);
        vm.addAnotherCompany = false;
        vm.numberJobsFound = {};
        vm.filter.companyName = '';
        vm.message = '';
        vm.showTables = false;
      };

      vm.undefinedMarket = function (paramt) {
        vm.marketNotRevised = paramt;
        vm.chargeModal = 'companyIndefiniteMarket';
      };

      vm.showTable = function (company, typeCompany) {
        vm.showTables = false;
        if (company.length > 0) {
          vm.showTables = true;
        }
        if (company.length === 0 && typeCompany.trim() === 'PR') {
          vm.showTables = true;
        }
      };
    };

    /*
    ================
    CONFIGURATION
    ================
    */

    CompanyController.$inject = [
      '$log','isEmptyFilter','translateService',
      'catalogService','bgModelAddPrivateCompany','bgParamsService',
      'commonFunctions','routeInvoker','NgTableParams',
      'alertNotifyService','$scope'];
    win.MainApp.Controllers
      .controller('CompanyController',CompanyController);

}(window));
