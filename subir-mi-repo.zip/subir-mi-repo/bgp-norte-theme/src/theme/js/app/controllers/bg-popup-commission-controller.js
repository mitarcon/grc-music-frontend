(function(win){
  "use strict";


    var CommissionController = function(log,scope, $filter,
       isEmpty, commissionsService) {

         /**
          * Get the appropiate quantity of fields to show and capture
          * commissions information inside an array, linked to its employment.
          */
         scope.latestMonths = [];
         scope.monthSelected = {};
         scope.quantityList = [6, 7, 8, 9, 10,11, 12];
         scope.quantity = scope.quantityList[scope.quantityList.length - 1];
         scope.monthList = []; // labels
         scope.records = {}; //fields
         scope.commissions = []; //commissions
         scope.init = true; //first time open
         var firstLoad = true;
         /**
          * Load the array of months to be used in labels.
          */
         var loadMonths = function() {
           return moment.localeData(navigator.language)._months;
         };

         /**
          * Load options in select of last month to choose,
          * with the five last months.
          */
         var loadOptions = function() {

           var date = new Date();
           var monthNumber = date.getMonth();
           var month = {
             code: monthNumber,
             value: $filter('date')(date, 'MMMM yyyy'),
             year: date.getFullYear()
           };

           for (var i = 1; i <= 5; i++) {
             date.setDate(1);
             date.setMonth(date.getMonth() - 1);
             monthNumber = date.getMonth();
             month = {
               code: monthNumber,
               value: $filter('date')(date, 'MMMM yyyy'),
               year: date.getFullYear()
             };
             scope.latestMonths.push(month);
             scope.monthSelected = scope.latestMonths[0];
           }
         };

         /**
          * Get the right ammount of fields to display, depending on
          * the month or quantity selected.
          */
         var getCommissionMonths = function() {
           return  commissionsService.get(
             scope.monthSelected, scope.quantity, scope.monthList);
         };

         scope.changeMonthsFields = function() {
           scope.records = getCommissionMonths();
           scope.records.totalCommissions = 0;
         };

         scope.validate = function () {
           if (scope.records.fields[0].commissions === undefined) {
             scope.commissions = scope.records.fields[1].commissions;
           } else {
             scope.commissions = scope.records.fields[0].commissions.concat(
               scope.records.fields[1].commissions);
           }
           scope.records.disabled = true;
           scope.okParam(scope.records);
         };

         scope.average = function() {
           var commissions = 0;
           angular.forEach(scope.records.fields, function(field) {
             angular.forEach(field.commissions, function(commission) {
               commissions += isNaN(parseFloat(commission)) ?
                 0 : parseFloat(commission);
                 if (commissions !== 0){firstLoad = false;}
             });
           });
           if(commissions !== 0){
             commissions =
               ((commissions / scope.quantity) -
               scope.data.baseSalary - scope.data.representation) *
               scope.data.percentage;
           }
           scope.records.totalCommissions = commissions;
         };

         scope.hasComissionError = function() {
           if (!firstLoad) {
             return scope.records.totalCommissions <= 0;
           }
         };

         /*
          ==============
          SETUP
          ==============
         */

         scope.setup = function() {
           if (scope.init) {
             loadOptions();
             scope.monthList = loadMonths();
             scope.init = false;
           }

           if (isEmpty(scope.data.records)) {
             scope.records = getCommissionMonths();
             scope.records.totalCommissions = 0;
           } else {
             scope.monthSelected = scope.data.records.options;
             scope.quantity = scope.data.records.quantity;
             scope.records = scope.data.records;
           }
           scope.average();
         };

    };

    /*
    ================
    CONFIGURATION
    ================
    */

    CommissionController.$inject = ['$log',
                                    '$scope',
                                    '$filter',
                                    'isEmptyFilter',
                                    'bgCommissionsService'];
    win.MainApp.Controllers
      .controller('CommissionModalInstanceCtrl',CommissionController);

}(window));
