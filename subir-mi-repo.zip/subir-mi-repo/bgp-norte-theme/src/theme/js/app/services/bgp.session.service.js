(function(win) {
  "use strict";

  var sessionService = function($log, bgValue, routeInvoker) {

    $log.debug("[Liferay/Angular/sessionService] Initializing...");

    var commons = bgValue('apps').commons;
    
    function clearSession(data) {
      return routeInvoker.invoke(commons, 'clearSession', data);
    }
    
    return {
    	clearSession: clearSession
    };

  };

  sessionService.$inject = ["$log", "bgValueFilter", "routeInvoker"];

  win.MainApp.Services.service("sessionService", sessionService);

}(window));
