/* globals _ */

(function (win) {
    "use strict";

    var formErrorsService = function ($log) {
        $log.debug("[Liferay/Angular/formErrorsService] Initializing...");

        function dispatch(form, errors) {
            _.map(errors, function (error) {
                if (form.hasOwnProperty(error.name)) {
                    form[error.name].$setValidity(error.message, false);
                }
            });
        }

        return {
            dispatch: dispatch
        };
    };

    formErrorsService.$inject = ["$log"];

    win.MainApp.Services
        .service("formErrorsService", formErrorsService);
}(window));
