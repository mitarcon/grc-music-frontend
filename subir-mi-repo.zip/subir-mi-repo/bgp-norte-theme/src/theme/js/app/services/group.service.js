(function(win) {
  "use strict";

  var WS_PATH = "/group/";

  var groupService = function($log, liferayServiceInvoker) {

    $log.debug("[Liferay/Angular/GroupService] Initializing...");

    function getGroupDisplayUrl(data) {
      return liferayServiceInvoker.invoke(WS_PATH + "get-group-display-url", data);
    }

    return {
      getGroupDisplayUrl: getGroupDisplayUrl
    };

  };

  groupService.$inject = ["$log", "liferayServiceInvoker"];

  win.MainApp.Services.service("groupService",
    groupService);

}(window));
