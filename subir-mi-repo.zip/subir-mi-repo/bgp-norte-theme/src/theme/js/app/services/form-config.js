/**
 * Configuration file for extend angular agility
 * It defines how an input using 'field-group' should be rendered in html
 */
(function (win) {
  "use strict";

  function FormConfigService(log,ext, t) {
    /**
     * Puts a label over the input with validation
     */

    function defaultLabelStrategy(element, labelText, isRequired,
      extraParent) {
      var label = angular.element('<label>')
        .attr('for', element[0].id)
        .html(labelText);
      var unsupported = [
        'button',
        'submit'
      ];

      if (unsupported.indexOf(element[0].type) !== -1) {
        throw new Error("Generating a label for and input type " +
          element[0].type + " is unsupported.");
      }
      if (extraParent) {
        element.parent().parent().prepend(label);
      } else {
        element.parent().prepend(label);
      }
    }

    function labelCurrencyStrategy(element, labelText, isRequired) {
      defaultLabelStrategy(element, labelText, isRequired, true);
    }

    var emptyLabelStrategy = function (element) {
      element.parent().prepend('');
    };

    var fieldGroupStrategy = function (element) {
      if (!element.prop('class')) {
        element.addClass('form-control validation-control');
      }
      element.wrap('<div></div>');
    };

    var notChangeStrategy = function (element) {
      if (!element.prop('class')) {
        element.addClass('validation-control');
      }
      element.wrap('<div></div>');
    };

    var currencyStrategy = function (element) {
      if (!element.prop('class')) {
        element.addClass('form-control validation-control');
      }

      element.wrap('<div class="currency"></div>');
      element.parent().prepend(angular.element('<span>$</span>'));
    };

    var datePickerStrategy = function (element) {
      var method = element.attr('aa-open-method');
      var methodParam = element.attr('aa-open-method-param');
      element.wrap("<div class='input-group'></div>");

      element.after(angular.element(
        '<span class="input-group-btn">' +
        '<button type="button"' +
        'class="btn btn-default bnt-calendar-custom"' +
        'ng-click="' + method + '(' + "'" + methodParam +"'" +')">' +
        '<span class="fa fa-calendar"></span>' +
        '</button>' +
        '</span>'));

      element.parent().parent().removeClass('input-group');
    };

    var datePickerRequiredStrategy = function (element) {
      var method = element.attr('aa-open-method');
      var methodParam = element.attr('aa-open-method-param');
      var condition = element.attr('aa-required-condition');
      element.wrap("<div class='input-group'></div>");

      element.after(angular.element(
        '<span class="input-group-btn">' +
        '<button type="button"' +
        'class="btn btn-default bnt-calendar-custom"' +
        'ng-class="' + condition + '? ' + "'required-background-color' :''" + '"' +
        'ng-click="' + method + '(' + "'" + methodParam +"'" +')">' +
        '<span class="fa fa-calendar"></span>' +
        '</button>' +
        '</span>'));

      element.parent().parent().removeClass('input-group');
    };

    return {
      init: function () {
        ext.labelStrategies.customStrategy = defaultLabelStrategy;
        ext.labelStrategies.emptyStrategy = emptyLabelStrategy;
        ext.labelStrategies.labelCurrencyStrategy = labelCurrencyStrategy;
        ext.defaultLabelStrategy = 'customStrategy';

        ext.fieldGroupStrategies.customStrategy = fieldGroupStrategy;
        ext.fieldGroupStrategies.currencyStrategy = currencyStrategy;
        ext.fieldGroupStrategies.notChangeStrategy = notChangeStrategy;
        ext.fieldGroupStrategies.datePickerStrategy = datePickerStrategy;
        ext.fieldGroupStrategies.datePickerRequiredStrategy = datePickerRequiredStrategy;
        ext.defaultFieldGroupStrategy = 'customStrategy';

        ext.defaultOnNavigateAwayStrategy = 'none';

        ext.validationMessages = {
          required: t.getValue('validation.required'),
          email: t.getValue('validation.email'),
          date: t.getValue('validation.date'),
          minlength: t.getValue('validation.minlength'),
          maxlength: t.getValue('validation.maxlength'),
          min: t.getValue('validation.min'),
          max: t.getValue('validation.max'),
          minInclude: t.getValue('validation.min.include'),
          maxInclude: t.getValue('validation.max.include'),
          pattern: t.getValue('validation.pattern'),
          url: t.getValue('validation.url'),
          number: t.getValue('validation.number'),
          alpha: t.getValue('validation.alpha'),
          alphaLatin: t.getValue('validation.alpha'),
          alphaNum: t.getValue('validation.alphaNum'),
          alphaNumLatin: t.getValue('validation.alphaNum'),
          alphaNumLatinwithoutAccent: t.getValue('validation.alphaNum'),
          alphaLatinWithoutHyphen: t.getValue('validation.alpha'),
          alphaLatinWithoutLimit: t.getValue('validation.alpha'),
          phone: t.getValue('validation.phone'),
          company:t.getValue('global.client.multiline.error'),
          bgRangeLimit: t.getValue('validation.bgRangeLimit'),
          currency: t.getValue('validation.currency'),
          mileagePlusNumber: t.getValue(
            'validation.mileage.plus.number'),
          connectMilesNumber: t.getValue(
            'validation.connect.miles.number'),
          bgClientIdentification: t.getValue(
            'global.client.identification.error'),
          multiLine: t.getValue('global.client.multiline.error'),
          bgDateLimit: t.getValue('global.date.error'),
          bgUntilDateLimit: t.getValue('global.until.date.error'),
          repeatEngineSerialNumber: t
            .getValue('validation.engine.chassis.match'),
          repeatChassisSerialNumber: t
            .getValue('validation.engine.chassis.match'),
          bgValidEvalType: t.getValue('validation.evaluationType'),
          thirdAccountMessage: '',
          bgSuperableVal: t.getValue('validation.superableValue'),
          bgCardApplies: t.getValue('validation.appliesToCard'),
          bgYearValid: t.getValue('global.message.error.independent'),
          carMileage: t.getValue('validation.unknown'),
          currencyPositiveNumber: t.getValue('validation.unknown'),
          greaterThanZero: t.getValue('validation.greater.than.zero'),
          identification: t.getValue('validation.invalid.document.number'),
          dateFormat: t.getValue('validation.quote.dateFormat'),
          dateSelect: t.getValue('validation.quote.dateSelect'),
          dateGreaterThan30: t.getValue('validation.quote.dateGreaterThan30'),
          dateGreaterThan: t.getValue('validation.quote.dateGreaterThan'),
          dateLowerThan: t.getValue('validation.quote.dateLowerThan'),
          dateGreaterThanToday: t.getValue('validation.quote.dateGreaterThanToday'),
          nextValidUserTask: t.getValue('quote.header.next.valid.user'),
          bgRequiredCondition : t.getValue('validation.value.required'),
          dateGreaterLower: t.getValue('validation.quote.dateGreaterLower'),
          dateLowerGreater: t.getValue('validation.quote.dateLowerGreater'),
          emptyCheckboxButton: t.getValue('validation.confirm.this.option'),
          validateCarAssessment : t.getValue('validation.car.assessment.price'),
          assignmentDateGreaterThan30: t.getValue('validation.car.assessment.date'),
          validateCarPolicyAmount: t.getValue('validation.car.policy.policyAmount'),
          validateEndorsementAmount: t.getValue('validation.car.endorsement.amount'),
          validateLifePolicyAmount: t.getValue('validation.car.life.policy.amount'),
          validateLifePolicyEndorsement: t.getValue('validation.car.life.policy.endorsement'),
          bgMinAmountLimit: t.getValue('global.min.amount.error'),
          bgMaxAmountLimit: t.getValue('global.max.amount.error'),
          bgMaxlength: t.getValue('validation.bgMaxlength')
        };

      },
      validateAccountMessage: function (message) {
        ext.validationMessages.thirdAccountMessage = message;
      },
      changeValidateMessage: function (field, message) {
        ext.validationMessages[field] = message;
      }
    };
  }

  FormConfigService.$inject = ['$log','aaFormExtensions', 'translateService'];

  win.MainApp.Services
    .service("formConfig", FormConfigService);
}(window));
