(function(win){
  'use strict';

  function servicesCache($cacheFactory) {
    return $cacheFactory('services-cache');
  }
  servicesCache.$inject = ['$cacheFactory'];
  win.MainApp.Services
    .factory('servicesCache', servicesCache);


  function ajaxServices($http, /*serviceUrl,*/ cache, $q, $rootScope) {
    var activePromises = 0;
    var PortletBackend = function() {

      var handlePromise = function(promise) {
        $rootScope.isLoading = true;
        activePromises++;
        promise.then(function() {
          activePromises--;
          $rootScope.isLoading = activePromises !== 0;
        }, function() {
          activePromises--;
          $rootScope.isLoading = activePromises !== 0;
        });
        return promise;
      };

      this.ajaxPost = function(project,method, jsonData) {
        routeInvoker.invoke(bgValue('apps').project, method, jsonData);
        serviceResp = serviceInvoker.invoke("POST", WS_PATH + method);

        return serviceResp;
      };

      this.getFromCache = function(method, jsonData) {
        var key = JSON.stringify({
          method: method,
          params: jsonData
        });
        var deferred = $q.defer();
        var result = cache.get(key);
        if (angular.isUndefined(result)) {
          var promise = this.ajaxPost(method, jsonData);
          promise.then(function(response) {
            cache.remove(key);
            cache.put(key, response);
          });
          cache.put(key, promise);
          return promise;
        }
        if (angular.isDefined(result.data)) {
          deferred.resolve(result);
          return deferred.promise;
        }
        return cache.get(key);
      };

      this.pdfPost = function(method, jsonData) {
        // var promise = $http({
        //   url: serviceUrl + "&javax.portlet.action=" + method,
        //   method: 'POST',
        //   headers: {
        //     'Content-Type': 'application/json'
        //   },
        //   responseType: 'arraybuffer',
        //   data: jsonData
        // });
        // return handlePromise(promise);
      };

      /*
       * Quote services
       */
      this.scoringByEntityListPromise = function(filters) {
        return this.ajaxPost("findQuoteByEnte", filters);
      };

      this.scoringByIdListPromise = function(filters) {
        return this.ajaxPost("findQuoteByDocument", filters);
      };

      this.scoringByNameListPromise = function(filters) {
        return this.ajaxPost("findQuoteByName", filters);
      };

      this.scoringByPassportListPromise = function(filters) {
        return this.ajaxPost("findQuoteByPassport", filters);
      };

      this.scoringByUserListPromise = function() {
        return this.ajaxPost("findQuoteByUser");
      };

      this.quoteListPromise = function(client) {
        return this.ajaxPost("findQuotes", client);
      };

      this.clientScoringData = function() {
        return this.ajaxPost("clientScoringData");
      };

      this.findEmploymentSiv = function(filters) {
        return this.ajaxPost("findEmploymentSiv", filters);
      };

      this.findQuoteByNumber = function(filter) {
        return this.ajaxPost("findQuoteByNumber", filter);
      };

      this.findCustomerProduct = function(ente) {
        return this.ajaxPost("findCustomerProduct", ente);
      };

      this.findInternalCreditReferences = function(ente) {
        return this.ajaxPost("findInternalCreditReferences", ente);
      };

      this.quoteDataPromise = function(quoteCode) {
        return this.ajaxPost("quoteData", quoteCode);
      };

      /*
       * Customer services
       */

      this.initCustomerData = function(ipcWrapper) {
        return this.ajaxPost("initCustomerData", ipcWrapper);
      };

      this.datosGenerales = function(entity) {
        return this.ajaxPost("clientDatosGenerales", entity);
      };

      this.findClientGeneralDataByEntityId = function(entity) {
        return this.ajaxPost("findClientGeneralDataByEntityId", entity);
      };

      this.clientListPromise = function(filters) {
        return this.ajaxPost("findCustomersByFilter", filters);
      };

      this.clientContactData = function(entity) {
        return this.ajaxPost("clientContactData", entity);
      };

      this.clientEmploymentsPromise = function(filtersEmployment) {
        return this.ajaxPost("clientEmployments", filtersEmployment);
      };

      this.saveCustomer = function(customer) {
        return this.ajaxPost('saveCustomer', customer);
      };

      this.clientReferencesPromise = function(entity) {
        return this.ajaxPost("clientReferences", entity);
      };

      this.findCompaniesPromise = function(companyValue) {
        return this.getFromCache("findCompanies", companyValue);
      };

      this.findCompaniesNoCachePromise = function(companyValue) {
        return this.ajaxPost("findCompanies", companyValue);
      };

      this.quoteDifferences = function(quoteNumber) {
        return this.ajaxPost("findDifferences", quoteNumber);
      };

      this.updateRevisionDatePromise = function(ente) {
        return this.ajaxPost("updateRevisionDate", ente);
      };

      this.validateDuplicatedIdPromise = function(filter) {
        return this.ajaxPost("validateDuplicatedId", filter);
      };

      /*
       * Catalog services
       */
      this.catalogListPromise = function() {
        return this.ajaxPost("getCatalogs");
      };

      /*
       * List All Countries
       */
      this.countriesListPromise = function() {
        return this.ajaxPost("listAllCountries");
      };

      /*
       * Find address
       */
      this.findClientAddress = function(entity) {
        return this.ajaxPost("findClientAddress", entity);
      };

      /*
       * Search for Neighborhoods
       */
      this.searchNeighborhoodsPromise = function(filter) {
        return this.ajaxPost("searchNeighborhoodByKeywords", filter);
      };

      /*
       * List All Provincies from Panama
       */
      this.provinceListPromise = function() {
        return this.ajaxPost("listAllProvincesFromPanama");
      };

      /**
       * Client's accounts
       */
      this.clientAccountsPromise = function(clientsAccountsFilter) {
        return this.ajaxPost("findClientsAccounts", clientsAccountsFilter);
      };

      /*
       * APC services
       */
      this.apcPromise = function(filter) {
        return this.ajaxPost("findAPC", filter);
      };

      this.updateCustomerAPCFlagPromise = function(apcFilter) {
        return this.ajaxPost(
          "updateCustomerAPCFlag", apcFilter);
      };

      this.directionClientPromise = function(entity) {
        return this.ajaxPost("getDirectionClient", entity);
      };

      /*
       * Parameters
       */
      this.findParametersPromise = function() {
        return this.ajaxPost("findParameters");
      };

      this.findQuoteExceptionsPromise = function(quoteNumber) {
        return this.ajaxPost("findQuoteExceptions", quoteNumber);
      };

      this.executeRulesPromise = function(scoring) {
        return this.ajaxPost("executeRules", scoring);
      };

      this.clearTabSessionDataPromise = function() {

        return this.ajaxPost("clearTabSessionData");
      };

      this.findParticipantDetail = function(generalInitWrapper) {
        return this.ajaxPost("findParticipantDetail",
          generalInitWrapper);
      };

      this.roleChange = function(roleChangeWrapper) {
        return this.ajaxPost("roleChange",
          roleChangeWrapper);
      };

      /**
       * Quote differences
       */
      this.findDifferences = function (quote) {
        return this.ajaxPost("findDifferences", quote);
      };

      this.cancelQuote = function (params) {
        return this.ajaxPost("cancelQuote", params);
      };

      this.sendToAssess = function (params) {
        return this.ajaxPost("sendToAssess", params);
      };

    };

  return new PortletBackend();
  }
ajaxServices.$inject = ['$http', /*'serviceUrl',*/ 'servicesCache', '$q',
'$rootScope'];
win.MainApp.Services
.factory('ajaxServices',ajaxServices);

}(window));
