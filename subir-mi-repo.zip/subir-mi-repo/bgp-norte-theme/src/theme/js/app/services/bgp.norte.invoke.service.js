/* globals MainApp */

(function (win) {
  "use strict";

  function routeInvoker(serviceInvoker, isEmpty, $log, $q, translate, bgValue,
    $cacheFactory) {

    $log.debug("[Liferay/Angular/routeInvoker] Initializing...");
    //TODO - @Jgiron
    // Realizar documentacion de métodos y variables
    var cache = $cacheFactory('services-cache');

    return {
      invoke: invoke,
      invokeFromCache: invokeFromCache,
      invokePrintDocument: invokePrintDocument,
      invokeWithoutHandle: invokeWithoutHandle
    };

    function invoke(project, service, data) {
      var aux = serviceRoute(project, service);
      if(!isEmpty(aux)){
        return serviceInvoker.invoke(aux.method, aux.url, data);
      } else {
        $log.debug("[Liferay/Angular/routeInvoker] Service does not exist...");
        var d = $q.defer();
        /*
         * TODO: Este mensaje se debe adaptar para ser recibido en los catch y
         * desplegarse en la vista correctamente
         */
        var output = {
          'userMessasge': translate.getValue('global.service.doesnt.exist',
            [project, service])
        };
        d.reject(output);
        return d.promise;
      }
    }
    function invokeFromCache(project, service, data) {
      var key = JSON.stringify({
        method: service,
        params: data
      });
      var deferred = $q.defer();
      var result = cache.get(key);
      if (angular.isUndefined(result)) {
        var promise = invoke(project, service, data);
        promise.then(function(response) {
          cache.remove(key);
          cache.put(key, response);
        });
        cache.put(key, promise);
        return promise;
      }
      if (angular.isDefined(result.data)) {
        deferred.resolve(result);
        return deferred.promise;
      }
      return cache.get(key);
    }
    function serviceRoute(project, service) {
      if(!isEmpty(project) && !isEmpty(service)){
        var output = {};
        switch (project) {
          case bgValue('apps').car:
            output = bgValue('wsPathCar');
            break;
          case bgValue('apps').credit:
            output = bgValue('wsPathCreditCard');
            break;
          case  bgValue('apps').commons:
            output = bgValue('wsPathCommon');
            break;
          case  bgValue('apps').wizard:
            output = bgValue('wsPathWizard');
            break;
          case  bgValue('apps').maintenance:
            output = bgValue('wsPathMaintenance');
            break;
          case 'neighborhood':
            output = bgValue('wsPathNeighborhood');
            break;
          case bgValue('apps').clientDetails:
            output = bgValue('wsPathClientDetails');
            break;
          case 'quote':
            output = bgValue('wsPathQuote');
            break;
          case 'task':
            output = bgValue('wsPathTask');
            break;
          case output = bgValue('apps').carCatalogs:
            output = bgValue('wsPathCarCatalogs');
            break;
          case 'catalog'   :
            output = bgValue('wsPathCatalogs');
            break;
          case output = bgValue('apps').clientSearch:
            output = bgValue('wsPathClientSearch');
            break;
          case output = bgValue('apps').notification:
            output = bgValue('wsPathNotifications');
            break;
          case output = bgValue('apps').quoteRecord:
            output = bgValue('wsPathRecord');
            break;
          case output = bgValue('apps').carQuoteDetails:
            output = bgValue('wsPathCarQuoteDetails');
            break;
          case output = bgValue('apps').quoteSummary:
            output = bgValue('wsPathSummary');
            break;
          case output = bgValue('apps').quoteHead:
            output = bgValue('wsPathQuoteHead');
            break;
          case output = bgValue('apps').quoteEvaluation:
            output = bgValue('wsPathQuoteEvaluation');
            break;
          case output = bgValue('apps').quoteCommunication:
            output = bgValue('wsPathQuoteCommunication');
            break;
          case output = bgValue('apps').taskCarQuoteLayout:
            output = bgValue('wsPathTaskCarQuoteLayout');
            break;
          case output = bgValue('apps').quoteDocument:
            output = bgValue('wsPathQuoteDocument');
            break;
          case output = bgValue('apps').quoteClient:
            output = bgValue('wsPathQuoteClient');
            break;
          case output = bgValue('apps').accountOpening:
            output = bgValue('wsPathAccountOpening');
            break;
          case output = bgValue('apps').quoteReview:
            output = bgValue('wsPathQuoteReview');
            break;
          case output = bgValue('apps').carQuoteLiquidation:
            output = bgValue('wsPathQuoteLiquidation');
            break;
          case output = bgValue('apps').customerManagement:
            output = bgValue('wsPathCustomerManagement');
            break;
          case output = bgValue('apps').accountOpeningApproval:
            output = bgValue('wsPathAccountOpeningApproval');
            break;
          default:
        }
        return !isEmpty(output.ws[service]) ?
          {
            'url': output.ws[service].route,
            'method': output.ws[service].method
          }
          : undefined;
      }
    }
    function invokePrintDocument(project, service, data){
      var aux = serviceRoute(project, service);
      if(!isEmpty(aux)){
        return serviceInvoker.invokePrintDocument(aux.url, data);
      } else {
        $log.debug("[Liferay/Angular/routeInvoker] Service does not exist...");
        var d = $q.defer();
        /*
         * TODO: Este mensaje se debe adaptar para ser recibido en los catch y
         * desplegarse en la vista correctamente
         */
        var output = {
          'userMessasge': translate.getValue('global.service.doesnt.exist',
            [project, service])
        };
        d.reject(output);
        return d.promise;
      }
      // return $http({
      //    url: path,
      //    method: 'POST',
      //    headers: {
      //      'Content-Type': 'application/json'
      //    },
      //    responseType: 'arraybuffer',
      //    data: data
      //  });
    }
    function invokeWithoutHandle(project, service, data) {
      var aux = serviceRoute(project, service);
      if(!isEmpty(aux)){
        return serviceInvoker.invokeWithoutHandle(aux.method, aux.url, data);
      } else {
        $log.debug("[Liferay/Angular/routeInvoker] Service does not exist...");
        var d = $q.defer();
        /*
         * TODO: Este mensaje se debe adaptar para ser recibido en los catch y
         * desplegarse en la vista correctamente
         */
        var output = {
          'userMessasge': translate.getValue('global.service.doesnt.exist',
            [project, service])
        };
        d.reject(output);
        return d.promise;
      }
    }
  }

  routeInvoker.$inject = ['serviceInvoker', 'isEmptyFilter', '$log', '$q',
  'translateService', 'bgValueFilter', '$cacheFactory'];

  win.MainApp.Services
    .service('routeInvoker', routeInvoker);

}(window));
