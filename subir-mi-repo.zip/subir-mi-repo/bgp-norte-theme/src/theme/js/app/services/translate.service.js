/* globals MainApp, BGP_i18n */

(function (win) {
  "use strict";

  var TranslateService = function () {

    var interpolateArgs = function(string, args) {
      return string.replace(/{(\d+)}/g, function(match, argIndex) {
        var arg = args[argIndex];
        return arg === undefined ? match : arg;
      });
    };

    var getValue = function(key, args) {
      var value = BGP_i18n[key];

      if (value && args)
        value = interpolateArgs(value, args);

      return value;
    };

    var interpolate = function(string, args) {
      if (args)
        string = interpolateArgs(string, args);

      string = string.replace(/\$(.+?)\$/g, function(match, key) {
        var value = getValue(key);
        return value === undefined ? match : value;
      });

      return string;
    };

    return {
      getValue: getValue,
      interpolate: interpolate
    };
  };

  win.MainApp.Services.service("translateService", TranslateService);

}(window));
