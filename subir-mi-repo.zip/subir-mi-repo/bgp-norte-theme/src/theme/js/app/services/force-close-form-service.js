(function (win) {
      "use strict";

      var forceCloseFormService = function ($log) {
          $log.debug("[Liferay/Angular/forceCloseFormService] Initializing...");

          var isForceClose = false;

          return {
            force: function () {
              isForceClose = true;
            },
            clean: function () {
              isForceClose = false;
            },
            get: function () {
              return isForceClose;
            }
          };
      };

      forceCloseFormService.$inject = [
        '$log'
      ];

      win.MainApp.Services
          .service("forceCloseFormService", forceCloseFormService);
  }(window));
