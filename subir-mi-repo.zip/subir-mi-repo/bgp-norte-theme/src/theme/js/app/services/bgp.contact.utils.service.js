(function(win){
/**
 * Utility Service for Contacts
 * Created by fnovoa on 04/18/2016.
 */
'use strict';
  function contactUtils(filter, describe) {
    var structureData=['C', 'O', 'T', 'M'];

    var contactTypeExist = function(contactList, code){
      return filter(contactList,
        function (contact) {
          return contact.type.id===code;
        }).length>0;
    };

    var insertType = function(contactList, code, project){
      contactList.push({
          type: {
            id: structureData[code],
            name: describe(structureData[code],'contactType', project)
          },
          name: '',
          isFromView:true
        }
      );
      return contactList;
    };

    var sortFunction = function(a, b){
      var aIndex = structureData.indexOf(a.type.id);
      var bIndex = structureData.indexOf(b.type.id);

      if (aIndex === bIndex) {
        return 0;
      } else if (aIndex > bIndex) {
        return 1;
      }
      return -1;
    };

    return {
      complete: function (contactList, project) {
        angular.forEach(structureData, function(code, index){
          if(!contactTypeExist(contactList, code)){
            contactList = insertType(contactList, index, project);
          }
        });
        contactList.sort(sortFunction);
        return contactList;
      },
      defaultContacts: function(contacts){
        var contactsResult = [];
        angular.forEach(contacts,function(item){
          if (!contactTypeExist(contactsResult, item.type.id)) {
            contactsResult.push(item);
          }
        });
        return contactsResult;
      },
      firstContactOfType: function(code,contacts){
        var contact;
        angular.forEach(contacts,function(item){
          if(angular.isUndefined(contact) &&
          item.type.id === code){
            contact = item;
          }
        });

        return angular.isDefined(contact)?contact:{};
      }
    };
}
contactUtils.$inject = ['filterFilter', 'describeFilter'];
win.MainApp.Services
  .service('contactUtils', contactUtils);

}(window));
