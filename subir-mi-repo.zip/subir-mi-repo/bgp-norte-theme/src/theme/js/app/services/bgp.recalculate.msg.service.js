(function(win) {
  "use strict";

  function recalculateMsgService(bgPopUpService, trans) {

    return {
      get: get
    };

    function get(data){
      var response = {text: ''};
      getArrayMsg(data.clients, 'C', response);
      if (response.block) {
        return response;
      }
      getArrayMsg(data.employments, 'E', response);
      replaceLastComma(response);
      return response;
    }

    /**
     * Function to replace last comma with dot.
     */
    function replaceLastComma(response) {
      var length = response.text.length;
      if (length === 0) {
        return;
      }
      response.text = response.text.substr(0, length - 1) + '.';
    }

    /**
     * Function to proccess string msg.
     */
    function processMsg(resp, obj, length, itemName) {
      for (var y in obj) {
        if (String(obj[y]).trim() === 'DC') {
          var languageKey = 'calculate.' + y;
          resp.text += ' ' + trans.getValue(languageKey) + ',';
        }
      }
      if (resp.text === '') {
        return;
      }
      resp.text = resp.text.substr(0, resp.text.length - 1) + itemName + ',';
    }
    /**
     * Function to process array of data and get the corresponding message.
     */
    function getArrayMsg(array, type, resp) {

      // loop through an array and check if it blocks the app
      // or just return the message
      for(var x in array) {
        var diffObj = angular.copy(array[x]);
        var auxCompanyName = ' ' + trans.getValue('calculate.companyLbl') + ' ' +
          diffObj.companyName;
        var auxClientName = ' ' + trans.getValue('global.of') + ' ' +
          diffObj.name;
        if (diffObj.check && diffObj.check.trim() === 'N') {
          continue;
        }
        if (diffObj.nonExistent && String(diffObj.nonExistent).trim() === 'S') {
          var nonExistentMsg = ' ' + trans.getValue('calculate.the.job') + ' ' +
            diffObj.companyName + ' ' + trans.getValue(
              'calculate.deleted.or.made.inactive') + ',';
          resp.text += nonExistentMsg;
          continue;
        }
        if (diffObj.apc && diffObj.apc.trim() === 'BL') {
          resp.block = true;
          resp.text = trans.getValue('calculate.msg.blk.apc');
          return;
        }

        var toSusbtract = type === 'C' ? 3 : 5;
        var objLength = Object.keys(diffObj).length - toSusbtract;

        if (objLength > 0) {
          var itemName = '';
          if (type === 'E') {
            itemName = auxCompanyName;
          } else {
            itemName = auxClientName;
          }
          //var companyName = type === 'E' ? auxName : '';
          processMsg(resp, diffObj, objLength, itemName);
        }
      }
      return;
    }
  }

  recalculateMsgService.$inject = ['bgPopUpService','translateService'];
  win.MainApp.Services
   .service("recalculateMsgService", recalculateMsgService);
}(window));
