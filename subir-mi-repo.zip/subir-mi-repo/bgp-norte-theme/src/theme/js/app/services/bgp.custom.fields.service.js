(function(win) {
	"use strict";

	var WS_PATH = "/o/api/common-service/";

	var customFieldsService = function($log, serviceInvoker) {

		$log.debug("[Liferay/Angular/customFieldsService] Initializing...");

		function getCustomFieldsUrl() {
			return serviceInvoker.invoke("POST", WS_PATH + 'getCustomFieldsUrl', null);
		}

		return {
			getCustomFieldsUrl: getCustomFieldsUrl
		};

	};

	customFieldsService.$inject = [ "$log", "serviceInvoker"];

	win.MainApp.Services.service("customFieldsService", customFieldsService);

}(window));
