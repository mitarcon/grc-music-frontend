(function(win){
/**
 * Utility Service for Contacts
 * Created by fnovoa on 04/18/2016.
 */
'use strict';
  function bgActiveEmploymentsService(filter, storage, isEmpty) {

        var hasAlreadyMain = function(fullEmp){
          for(var index  in fullEmp){
            if (fullEmp[index].config && fullEmp[index].config.isMain) {
              return true;
            }
          }
          return false;
        };

        var setMainEmploymentsFromQuote = function (quoteEmployments, fullEmp) {

          var employmentCodes = [];
          if (isEmpty(fullEmp) || hasAlreadyMain(fullEmp)) {
            return;
          }
          var mainEmployment;
          for (var i in quoteEmployments) {
            if(quoteEmployments[i].esEmpleoPrincipal==='S'){
              mainEmployment = quoteEmployments[i];
            }
            employmentCodes.push(String(quoteEmployments[i].secuencial));
          }

          angular.forEach(fullEmp, function (item) {
            if (employmentCodes.indexOf(item.id) >= 0 &&
               item.type.id!=='C') {
              if(!item.config) {
                item.config = {};
              }
              item.config.isActiveJob = true;
              if(mainEmployment) {
                item.config.isMain =
                  String(mainEmployment.secuencial) === item.id;
              }
            }
          });
        };

        var setFirstAsMainEmployment = function (fullEmp) {

          if ((!isEmpty(fullEmp) && fullEmp[0].config) ||
            storage.getScoring({}).credit.quote !== 0 ||
            isEmpty(fullEmp)) {
            return;
          }
          for (var index in fullEmp) {
            var employment = fullEmp[index];
            if (employment.type.id === 'E') {
              employment.config = {
                isActiveJob: true,
                isMain : true
              };
              return;
            }
          }
        };

        return {
          get: function (client) {
            var quoteEmployments = storage.getScoring({}).credit.findEmployments;

            var fullEmp =
              angular.copy(client);

            if (quoteEmployments) {
              setMainEmploymentsFromQuote(quoteEmployments, fullEmp);
            }
            else {
              setFirstAsMainEmployment(fullEmp);
            }

            var actives = filter(
              fullEmp, function (emp) {
                return emp.config ? emp.config.isActiveJob : false;
              });
            if (actives.length === 1) {
              actives[0].config.isMain = true;
            }

            return actives;
          },
          getForRules: function () {
            var listEmployments = this.get();
            angular.forEach(listEmployments, function(value) {
              if (value.config.beforeEmployment) {
                listEmployments.push(value.config.beforeEmployment);
              }
            });
            return listEmployments;
          },
          getMain: function () {
            var activeEmployments = this.get();
            for (var index in activeEmployments) {
              if (activeEmployments[index].config &&
                activeEmployments[index].config.isMain) {
                return activeEmployments[index];
              }
            }
            return {};
          }
        };


}
bgActiveEmploymentsService.$inject = ['filterFilter',
                                      'storageService',
                                      'isEmptyFilter'];
win.MainApp.Services
  .service('bgActiveEmploymentsService', bgActiveEmploymentsService);

}(window));



//Fin
//F
