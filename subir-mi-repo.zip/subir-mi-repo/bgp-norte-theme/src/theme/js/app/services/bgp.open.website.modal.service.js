(function(win) {
  'use strict';

  var openWebSiteModalService = function($log, modalService, $document) {

    $log.debug(
      "[Liferay/Angular/openWebSiteModalService] Initializing...");

    var externalWebSite = function(link){

      var bgpTheme =
        angular.element($document[0].querySelector(".bgp-norte-theme"));

      modalService.open({
        bgModalTpl: "bgp-norte-theme/angular/partials/external-website/open_website_modal.html",
        bgModalTitle: 'external-link-modal-open-website-title',
        bgAppendTo: bgpTheme,
        bgModalData: {
        }
      });

    };

    return {
      externalWebSite : externalWebSite
    };
  };

  openWebSiteModalService.$inject = ["$log", "modalService", "$document"];

  win.MainApp.Services.service("openWebSiteModalService",
    openWebSiteModalService);


}(window));
