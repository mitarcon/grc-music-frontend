(function(win) {
  "use strict";

  var WS_PATH = "/o/api/common-service/";

  var tabHandlerService = function($log, serviceInvoker) {

    $log.debug("[Liferay/Angular/tabHandlerService] Initializing...");

    function openNewTab() {
      return serviceInvoker.invoke("GET", WS_PATH + 'new-tab');
    }

    function getTabConfigWrapper() {
      return serviceInvoker.invoke("GET", WS_PATH + 'tab-config');
    }

    return {
      openNewTab: openNewTab,
      getTabConfigWrapper: getTabConfigWrapper
    };

  };

  tabHandlerService.$inject = ["$log", "serviceInvoker"];

  win.MainApp.Services.service("tabHandlerService", tabHandlerService);

}(window));