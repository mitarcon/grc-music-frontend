/* globals MainApp */
(function (win) {
  "use strict";

  function findDifferencesService(storage, isEmpty, popUpService, trans,
  recalculateMsg, bgValue) {

    return {
      /*
       * [Used in car quote to display de clients tab message
       */
      setOutdatedMessages : setOutdatedMessages,
      resetQuoteDifferenceObj : resetQuoteDifferenceObj,
      get: get,
      getDifferenceEmpCodes: getDifferenceEmpCodes,
      run: run,
      revelantForQuoteLoad: revelantForQuoteLoad,
      evaluateDifference: evaluateDifference,
      stopServiceMsg: stopServiceMsg
    };
    
    function evaluateDifference (diff) {
      if (!isEmpty(diff.clients)) {
        for(var i in diff.clients) {
          if ((diff.clients[i].clientType === 'P' ||
               diff.clients[i].clientType === 'N' ||
               diff.clients[i].clientType === 'D') &&
               diff.clients[i].stopServiceSecurity === 'BT') {
            return true;
          }
        }
      }
      return false;
    }
    
    function stopServiceMsg () {
      var attrs = {
        bgPopupTitle: trans.getValue('pantallazo.title'),
        bgPopupMessage: trans.getValue('pantallazo.message'),
        bgPopupCancelText: trans.getValue('pantallazo.finalizar.button'),
        bgPopupData: {messageBlock: 'pantallazo.message'},
        bgPopupTpl : 'partials/bgp-popup/client-block.html'
      };
      popUpService.open(attrs);
    }

    /**
     * Function to determine what actions should be taken,
     * the message to build and execute rules if applies.
     * @param data [response with objects containing differences in quote]
     * @param holder [objet passed to hold flag that blocks quote]
     * @param method [a function to be executed if applies]
     */
    function calculateMsg(data, holder, method) {
      // TODO: debemos implementar esta funcion en el storage - getFirstLoadQuote
      if (!angular.isFunction(method) || storage.getFirstLoadQuote()) {
        return;
      }
      var msg = recalculateMsg.get(data);
      if (isEmpty(msg.text)) {
        return;
      }
      if (msg.block) {
        callPopUp(msg.text);
        holder.blockQuote = true;
        return;
      }
      method().then(function () {
        callPopUp(trans.getValue('calculate.msg.default', [msg.text]));
      });
    }
    /**
     * Calls a pop-up to be shown in racalculate mode.
     * @param msg [String concatenated as msg]
     */
    function callPopUp(msg) {
      var attrs = {
        bgPopupTitle: trans.getValue('calculate.title'),
        bgPopupOkText: trans.getValue('global.accept'),
        bgPopupMessage: msg
      };
      popUpService.open(attrs);
    }
    /**
     * Checks scoring status to know when to call findQuoteDifferencesPromise.
     * @param  phase  [quote phase (C, E)]
     * @param  status [quote status (EC, DE)]
     * @return {[type]}        [description]
     */
    function checkScoringStatus(phase, status) {
      if (!isEmpty(phase) &&
      phase.trim() === bgValue('scoringPhaseStatus').evaluationPhase) {
        return true;
      }
      if (!isEmpty(phase) &&
      phase.trim() === bgValue('scoringPhaseStatus').scoringPhase &&
      !isEmpty(status) &&
      status.trim() === bgValue('scoringPhaseStatus').scoringCancelStatus) {
        return true;
      }
    }
    function getDiffMsg(obj) {
      if ('EMP_CLI' === obj.diffType) {
        return 'global.both.outdatedJobs';
      } else if ('EMP' === obj.diffType /*|| isNotWorking()*/) {
        return 'global.employments.outdated';
      } else if ('CLI' === obj.diffType) {
        return 'global.clients.outdated';
      } else {
        return undefined;
      }
    }
    /**
     * Remove last space and comma from message to display alert
     */
    function getStopServiceMsg(list, names, holder) {
      var msg = '';
      holder.stopServiceMsg = '';
      if (!isEmpty(list)) {
        names = names.substr(0, names.length - 2);
        msg = trans.getValue('calculate.additional.stopService', [names]);
        holder.stopServiceMsg = msg;
        holder.stopServiceList = list;
      }
    }
    function processStopService(cli, auxHolder){
      if (cli.stopServiceSecurity === 'BL') {
        auxHolder.stopServiceList[cli.client] = cli.name;
        auxHolder.stopServiceNames = auxHolder.stopServiceNames +
          cli.name + ', ';
      }
    }
    /**
     * Sets the proper message for each case in quote differences.
     * Wether emps or personal data has changed from MIS.
     * @param holder [object that holds the corresponding message]
     *        ex. Is used in client tab to show alert.
     * @param res [Response with objects containing wich elements has changed]
     */
    function setOutdatedMessages(holder, res){
      // save difference response to be used in [resetQuoteDifferenceObj].
      holder.differences = res;
      var emp = res.employments, cli = res.clients;
      holder.outdatedMessages = [];

      var auxIterationList = [], diffClientsList = [];
      var auxObjHolder = {stopServiceList: [], stopServiceNames: ''};

      for(var i in emp) {
        if (emp[i].check && emp[i].check.trim() !== 'N') {
          if (auxIterationList.indexOf(emp[i].client) < 0) {
            auxIterationList.push(emp[i].client);
            diffClientsList.push({entity: emp[i].client, diffType: 'EMP'});
          }
        }
      }
      for(var j in cli) {
        if (cli[j].check && cli[j].check.trim() !== 'N') {
          processStopService(cli[j], auxObjHolder);

          if (auxIterationList.indexOf(cli[j].client) < 0) {
            auxIterationList.push(cli[j].client);
            diffClientsList.push({entity: cli[j].client, diffType: 'CLI'});
          } else {
            var innerIndex = auxIterationList.indexOf(cli[j].client);
            if (diffClientsList[innerIndex].diffType === 'EMP') {
              diffClientsList[innerIndex].diffType = 'EMP_CLI';
            }
          }
        }
      }

      if (!isEmpty(diffClientsList)) {
        for (var k in diffClientsList) {
          holder.outdatedMessages[diffClientsList[k].entity] = getDiffMsg(
            diffClientsList[k]);
        }
      }
      getStopServiceMsg(auxObjHolder.stopServiceList,
        auxObjHolder.stopServiceNames, holder);
    }
    /**
     * This function is called when a participant is deleted, so the alert
     * below the names is removed or changed it´s description
     * @param {[obj]} holder [description]
     */
    function resetQuoteDifferenceObj(holder){
      if (isEmpty(holder.stopServiceList)) {
        holder.stopServiceMsg = '';
        return;
      }
      var cli = holder.differences.clients, auxParticipant = null ;
      var auxObjHolder = {stopServiceList: [], stopServiceNames: ''};

      for(var j in cli) {
        auxParticipant = holder.stopServiceList[cli[j].client];
        if (cli[j].check && cli[j].check.trim() !== 'N' && auxParticipant) {
          processStopService(cli[j], auxObjHolder);
        }
      }
      getStopServiceMsg(auxObjHolder.stopServiceList,
        auxObjHolder.stopServiceNames, holder);
    }
    /**
     * Calls a command to find differences in quote.
     * Set the message to alert according with each case.
     * @param holder [holds values to be listened in its controller scope]
     * @return promise [return a promise to wait until it finish]
     */
    function get(holder){
      // TODO: se debe implementar en storage la funcion getScoring
      var quoteCode = storage.getScoring({}).credit.quote;
      var status = storage.getScoring({}).credit.status;
      var phase = storage.getScoring({}).credit.phase;
      if (checkScoringStatus(phase, status)) {
        return;
      }
      if (quoteCode) {
        // TODO: Este servicio debe ser llamado en el routeInvoker debe haber un
        // web service que tenga implementado este rest
        //revisar si hace lo mismo que findDifferences
        // var promise: routeInvoker.invoke('findDifferences')
        var promise = services.quoteDifferences(quoteCode);
        if (!holder) {
          return promise;
        }
        promise.then(function (response) {
          // TODO: Implementar setQuoteDifferenceObj en el storage
          storage.setQuoteDifferenceObj(angular.copy(response.data));
          setOutdatedMessages(holder, response.data);
        });
        return promise;
      }
    }
    /**
     * Checks if difference obj exist in storage,
     * then return an obj with the flag for clients list anda employments list
     * @return {[List]} [List of String]
     */
    function getDifferenceEmpCodes(){
      // TODO: agregar getQuoteDifferenceObj a storage
      var diffObj = storage.getQuoteDifferenceObj();
      var diffCodes = [];
      if (diffObj) {
        var emps = diffObj.employments;
        for (var i in emps) {
          if (emps[i].check && String(emps[i].check).trim() === 'S') {
            diffCodes.push(String(emps[i].sequence));
          }
        }

      }
      return diffCodes;
    }
    function getRelevantMsg(data){
      if (!angular.isDefined(data) || storage.getFirstLoadQuote()) {
        return;
      }
      return processRelevantMsg(data.clients);
    }
    function processRelevantMsg(dataArray){
      for(var x in dataArray) {
        var diffObj = angular.copy(dataArray[x]);
        if (diffObj.apc && diffObj.apc.trim() === 'BL') {
          return true;
        }
      }
      return false;
    }
    /**
     * Calls the function that build message and shows pop-up,
     * also execute rules in quote.
     * Set the flag that indicates first load in quote consulting.
     * @param  response [response from get promise]
     * @param  holder   [obj to hold values]
     * @param  method   [function to be executed]
     */
    function run(response, holder, method){
      calculateMsg(response.data, holder, method);
      //TODO: discutir sobre la implementacion de esta funcion en storage
      storage.setFirstLoadQuote(true);
    }
    function revelantForQuoteLoad(response){
        return getRelevantMsg(response.data);
    }
  }

  findDifferencesService.$inject = [
    'storageService',
    'isEmptyFilter',
    'bgPopUpService',
    'translateService',
    'recalculateMsgService',
    'bgValueFilter'
  ];

  win.MainApp.Services
    .service('findDifferencesService', findDifferencesService);

}(window));
