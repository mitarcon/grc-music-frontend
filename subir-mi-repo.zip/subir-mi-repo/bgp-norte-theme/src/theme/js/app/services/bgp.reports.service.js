/* globals MainApp */

(function(win) {
  "use strict";

  function reportsService(bgValue, jasperServices, routeInvoker) {
    return {
      buildEmpty: buildEmpty,
      getReportPromises: getReportPromises
    };

    function buildEmpty(wrapper) {
      // Estructura del wrapper
      // wrapper = {
      //   scope: ?? no encuentro donde se utiliza en el build,
      //   getQuoteScope: funcion que retorna el quote, //revisar porque podria enviarse solo el principalParticipant
      //   product
      // };


      // En la migracion se eliminan lso condicionales porque se unifican las
      // cotizaciones y los nombres de los campos
      var principalParticipant = wrapper.getQuoteScope().principalParticipant;
      angular.forEach(principalParticipant.documents,
        function(doc) {
          if (!doc.printingWithDataRequired &&
            doc.type === bgValue('bgDocumentCode').typeBg) {
            /**
             * NOTE: adelrosario
             * the next "if" sentence... because the rule dont make any
             * difference between the empty docs and the required when adding
             * new participant
             */
            if (doc.code === bgValue('bgDocumentCode').cardApc ||
              doc.code === bgValue('bgDocumentCode').dataSheet ||
              doc.code === bgValue('bgDocumentCode').cardAcceptance) {
              var data = {
                productPerson: undefined,
                productType: wrapper.product
              };
              getReportPromises(doc.code, wrapper.product).reportPromise(data)
                .then(function(report) {
                  jasperServices.openReport(report);
                }, function(data) {
                  // TODO: migrar a la funcion de error
                });
            }
          }
        });
    }

    function getReport(value) {
      switch (value) {
        case bgValue('bgDocumentCode').cardApc:
          return {
            reportPromise: 'apcLetterReportPromise',
            valid: 'validateApcLetterReportData'
          };
        case bgValue('bgDocumentCode').municipality:
          return {
            reportPromise: 'municipalityReportPromise',
            valid: 'validateMunicipalityReportData'
          };
          case bgValue('bgDocumentCode').lifePolicy:
            return {
              reportPromise: 'lifePolicyReportPromise',
              valid: 'validateLifePolicyReportData'
            };
        case bgValue('bgDocumentCode').promiseLetter:
          return {
            reportPromise: 'promiseLetterReportPromise',
            valid: 'validatePromiseLetterReportData'
          };
        case bgValue('bgDocumentCode').debitAuthorization:
          return {
            reportPromise: 'debitAuthorizationReportPromise',
            valid: 'validateDebitAuthorizationReportData'
          };
        case bgValue('bgDocumentCode').promissoryNote:
          return {
            reportPromise: 'promissoryNoteReportPromise',
            valid: 'validatePromissoryNoteReportData'
          };
        case bgValue('bgDocumentCode').preca:
          return {
            reportPromise: 'preQualificationReportPromise',
            valid: 'validatePreQualificationReportData'
          };
        case bgValue('bgDocumentCode').healthDeclaration:
          return {
            reportPromise: 'healthStatementReportPromise',
            valid: 'validateHealthStatementReportData'
          };
        case bgValue('bgDocumentCode').trustAgreement:
          return {
            reportPromise: 'trustAgreementReportPromise',
            valid: 'validateTrustAgreementReportData'
          };
        case bgValue('bgDocumentCode').regularTransferCard:
          return {
            reportPromise: 'regularTransferCardReportPromise',
            valid: 'validateRegularTransferCardReportData'
          };
        case bgValue('bgDocumentCode').exemptTaxTransferCard:
          return {
            reportPromise: 'exemptTaxTransferCardReportPromise',
            valid: 'validateExemptTaxTransferCardReportData'
          };
        case bgValue('bgDocumentCode').dataSheet:
          return {
            reportPromise: 'customerDataSheetReportPromise',
            valid: 'validateCustomerDataSheetReportData'
          };
        case bgValue('bgDocumentCode').perfwla:
          return {
            reportPromise: 'customerProfileReportPromise',
            valid: 'validateCustomerProfileReportPromise'
          };
        case bgValue('bgDocumentCode').cardAcceptance:
          return {
            reportPromise: 'acceptanceLetterReportPromise',
            valid: 'validateAcceptanceLetterReportData'
          };
        //Documentos propios de hipoteca
        case bgValue('bgDocumentCode').proforma:
          return {
            reportPromise: 'proformaReportPromise',
            valid: 'validateProformaReportData'
          };
        case bgValue('bgDocumentCode').businessResearch:
          return {
            reportPromise: 'businessResearchReportPromise',
            valid: 'validateBusinessResearchReportData'
          };
        case bgValue('bgDocumentCode').debitAccountAuthorization:
          return {
            reportPromise: 'debitAccountAuthorizationReportPromise',
            valid: 'validateDebitAccountAuthorizationReportData'
          };
        case bgValue('bgDocumentCode').checkList:
          return {
            reportPromise: 'checkListReportPromise',
            valid: 'validateCheckListReportData'
          };
        case bgValue('bgDocumentCode').quotation:
          return {
            reportPromise: 'quotationReportPromise',
            valid: 'validateQuotationReportData'
            };
        case bgValue('bgDocumentCode').disbursementAuthorization:
          return {
            reportPromise: 'disbursementAuthorizationReportPromise',
            valid: 'validateDisbursementAuReportData'
          };
        case bgValue('bgDocumentCode').att:
          return {
            reportPromise: 'attReportPromise',
            valid: 'validateAttReportData'
          };
        default:
          return {
            reportPromise: 'ERROR-FILE',
            valid: 'ERROR-FILE'
          };
      }
    }

    function getReportPromises(value, product) {
      var report = getReport(value);
      return {
        reportPromise: function(data) {
          return routeInvoker
            .invokePrintDocument(product, report.reportPromise, data);
        },
        valid: function(data) {
          return routeInvoker.invoke(product, report.valid, data);
        }
      };
    }
  }

  reportsService.$inject = [
    'bgValueFilter',
    'jasperServices',
    'routeInvoker'
  ];

  win.MainApp.Services
    .service('reportsService', reportsService);

}(window));
