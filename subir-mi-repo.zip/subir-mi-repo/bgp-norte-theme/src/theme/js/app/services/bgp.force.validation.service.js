(function(win){

  'use strict';

    function bgForceValidation() {
      return {
        run: function (form, field, validation, message) {
          var elm = form.$aaFormExtensions[field];
          if(undefined === elm) return;
          elm.$addError(message, validation, false);
          elm.showErrorReasons.push('hadFocus');
          elm.$element.addClass('aa-had-focus');
          elm.$calcErrorMessages();
        },
        clean: function (form, field, validation) {
          var elm = form.$aaFormExtensions[field];
          if(undefined === elm) return;
          elm.$element.removeClass('explicit-add-error');
          form[field].$setValidity(validation, true);
        }
      };
    }
    bgForceValidation.$inject =[];

    win.MainApp.Services
      .service('bgForceValidation', bgForceValidation);

}(window));
