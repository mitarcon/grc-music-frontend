(function(win){
  'use strict';

  function bgProductConfig (translate, apps) {

    var config = {
      car: {
        id: 'AUTOS',
        name: apps.car,
        title: translate.getValue('global.product.car'),
        ruleOperation: 'AUTOS',
        urlValue: 'carUrl'
      },
      credit:{
        id: 'TDC',
        name: apps.credit,
        title: translate.getValue('global.product.card'),
        ruleOperation: 'TDC',
        urlValue: 'creditCardUrl'
      },
      mortgage:{
        name: apps.mortgage,
        title: translate.getValue('global.product.mortgage'),
        ruleOperation: 'HIP',
        urlPreValue: 'preMortgageUrl',
        urlValue: 'mortgageUrl'
      },
      accountOpeningSaving:{
        id: '4',
        name: apps.accountOpening,
        title: translate.getValue('global.product.account.opening'),
        ruleOperation: 'CUENTA DE AHORROS',
        urlValue: 'accountOpeningUrl'
      },
      accountOpeningChecking:{
        id: '3',
        name: apps.accountOpening,
        title: translate.getValue('global.product.account.opening'),
        ruleOperation: 'CUENTA CORRIENTE',
        urlValue: 'accountOpeningUrl'
      },
      liabilityAdvice:{
        name: apps.liabilityAdvice,
        title: translate.getValue('search.client'),
        ruleOperation: 'AC',
        urlValue: 'liabilityAdviceUrl'
      }
    };

    return {
      get: function (name) {
        return config[name];
      },
      getFromProductId: function (productId){
        for(var key in config) {
          if(config[key].id === productId){
            return config[key];
          }
        }
      }
    };
  }

  bgProductConfig.$inject = ['translateService', 'apps'];

  win.MainApp.Services
    .service('bgProductConfig', bgProductConfig);

}(window));
