(function(win) {
  'use strict';

  function bgRedirectService(
    window,
    storage,
    bgValue,
    customFieldsService,
    sessionService,
    translateService,
    $log,
    $timeout,
    bgProductConfig,
    tabHandlerService,
    alertNotifyService,
    isEmpty
  ) {

    var url = {
      inboxUrl: null,
      creditCardUrl: null,
      customerUrl: null,
      carUrl: null,
      wizardUrl: null,
      mortgagePurchaseUrl: null,
      preMortgageUrl: null,
      mortgageCasacashUrl: null,
      clientUrl: null,
      carEvaluationTaskUrl: null,
      carCommunicationTaskUrl: null,
      accountOpeningUrl: null,
      incomeTypeTableUrl: null,
      customerManagementUrl: null,
      liabilityAdviceUrl: null,
      accountOpeningApprovalUrl: null
    };

    function init() {
      var xhr = customFieldsService.getCustomFieldsUrl();

      xhr.then(function(response) {

        url.customerUrl = response.data['customer-url'];
        url.inboxUrl = response.data['inbox-url'];
        url.clientUrl = response.data['client-url'];
        url.wizardUrl = response.data['wizard-url'];
        url.accountOpeningUrl = response.data['account-opening-url'];
        url.accountOpeningApprovalUrl = response.data['account-opening-approval-url'];
        url.creditCardUrl = response.data['credit-card-url'];
        url.carUrl = response.data['car-url'];

        url.carEvaluationTaskUrl = response.data['car-evaluation-url'];
        url.carCommunicationTaskUrl = response.data['car-communication-url'];
        url.carFormalizationTaskUrl = response.data['car-formalization-url'];
        url.carLiquidationTaskUrl = response.data['car-liquidation-url'];
        url.carPLiquidationTaskUrl = response.data['car-previous-liquidation-url'];
        url.incomeTypeTableUrl = response.data[bgValue('evidenceOfIncomeViewOptionLink')];
        url.customerManagementUrl = response.data['customer-management-url'];
        url.liabilityAdviceUrl = response.data['liability-advice-url'];

      });
    }

    var openUrlHandler = function(url, newTab) {

      if (newTab) {

        var xhr = tabHandlerService.getTabConfigWrapper();

        xhr.then(function(response) {

          if (!response.data.newTabAvailable) {

            alertNotifyService.showErrorNoTimeout("Has llegado al limite de pestañas!");
            return;

          }

          var token = window.sessionStorage.getItem("ngStorage-ngsesid");
          window.sessionStorage.removeItem("ngStorage-ngsesid");

          window.open(url);
          window.sessionStorage.setItem("ngStorage-ngsesid", token);

        });

        xhr.catch(function(exception) {

          var error = exceptionHandlerService.handleError(
            exception, vm.serviceTitleKey);

          if (error) {
            alertNotifyService.showErrorNoTimeout(exception.data.name);
          }

        });

      } else {

        window.location.assign(url);

      }

    };

    function switchQuote() {
      switch (storage.getProductConfig().name) {
        case bgValue('apps').car:
          if (!isEmpty(url.carUrl))
            window.location.assign(url.carUrl);
          break;
        case bgValue('apps').credit:
          if (!isEmpty(url.creditCardUrl))
            window.location.assign(url.creditCardUrl);
          break;
        case bgValue('apps').mortgage:
          if (!isEmpty(url.mortgagePurchaseUrl))
            window.location.assign(url.mortgagePurchaseUrl);
          break;
        case bgValue('apps').casacash:
          if (!isEmpty(url.mortgageCasacashUrl))
            window.location.assign(url.mortgageCasacashUrl);
          break;
      }
    }

    return {
      toWizard: function() {
        window.location.assign(url.wizardUrl);
      },
      toPreQuote: function() {
        if (angular.isDefined(storage.getProductConfig().urlPreValue)) {
          window.location.assign(url.preMortgageUrl);
        } else {
          switchQuote();
        }
      },
      toQuote: function() {
        switchQuote();
      },
      toCustomer: function() {
        window.location.assign(url.customerUrl);
      },
      toAccountOpening: function() {
        openUrlHandler(url.accountOpeningUrl, false);
      },
      toAccountOpeningApproval: function() {
        openUrlHandler(url.accountOpeningApprovalUrl, false);
      },
      toInbox: function() {
        //Se limpia session en server
        var xhr = sessionService.clearSession();

        xhr.then(function() {
          $log.debug("Ejecutado servicio - clearSession: ");
        });

        xhr.catch(function(exception) {
          $log.error(
            translateService.getValue('constant.error.unexpected'));
        });

        xhr.finally(function() {
          $log.debug("End clearSession");
        });

        // Se limpia el storage cada vez que se vaya a bandeja
        storage.cleanStorage();
        window.location.assign(url.inboxUrl);
      },
      toClient: function() {
        openUrlHandler(url.clientUrl, true);
      },
      toTask: function(task, isMine) {

        var redirect = taskRedirectUrl(task, isMine);

        var product = bgProductConfig.getFromProductId(task.product.type.id);

        if (isEmpty(redirect)) {
          return;
        }

        if (bgValue('apps').accountOpening == product.name) {

          $timeout(function() {
            openUrlHandler(redirect, true);
          }, 500);

        } else {

          $timeout(function() {
            window.location.assign(redirect);
          });

        }

      },
      toTaskFinished: function(oldStage) {
        $timeout(function() {
          window.location.assign(url.inboxUrl + "?messageTitle=" + oldStage);
        });
      },
      toTaskFromNextTask: function(task, isMine, oldStage) {
        if (!isMine) {
          $timeout(function() {
            window.location.assign(url.inboxUrl + "?messageTitle=" + oldStage);
          });
        } else {
          this.toTask(task, isMine);
        }
      },
      toIncomeTypeTable: function() {
        window.open(url.incomeTypeTableUrl);
      },
      toCustomerManagement: function() {
        window.location.assign(url.customerManagementUrl);
      },
      toLiabilityAdvice: function() {
        openUrlHandler(url.liabilityAdviceUrl, true);
      },
      toInit: function() {
        init();
      },
      getAllUrls: function() {
        return url;
      }
    };

    function taskRedirectUrl(task, isMine) {

      var redirect = "";

      var product = bgProductConfig.getFromProductId(task.product.type.id);

      var taskStages = task.stage.id;

      switch (product.name) {

        case bgValue('apps').car:

          if (!isMine) {

            redirect = url.carUrl;

            task.person = {
              entityId: task.customersId,
              completeName: task.customerName,
            };

            task.product.id = task.procedureId;

          } else {

            switch (task.stage.id) {

              case bgValue('taskStagesPhases').quote:

                redirect = url.carUrl;

                task.person = {
                  entityId: task.customersId,
                  completeName: task.customerName,
                };

                task.product.id = task.procedureId;

                break;

              case bgValue('taskStagesPhases').evaluation:
                redirect = url.carEvaluationTaskUrl;
                break;

              case bgValue('taskStagesPhases').communication:
                redirect = url.carCommunicationTaskUrl;
                break;

              case bgValue('taskStagesPhases').formalization:
                redirect = url.carFormalizationTaskUrl;
                break;

              case bgValue('taskStagesPhases').liquidation:
                redirect = url.carLiquidationTaskUrl;
                break;

              case bgValue('taskStagesPhases').pLiquidation:
                redirect = url.carPLiquidationTaskUrl;
                break;
            }

          }

          break;
        case bgValue('apps').credit:
          if (!isMine) {

            redirect = url.creditCardUrl;

            task.person = {
              entityId: task.customersId,
              completeName: task.customerName,
            };

            task.product.id = task.procedureId;

          } else {

            switch (task.stage.id) {

              case bgValue('taskStagesPhases').quote:

                redirect = url.creditCardUrl;

                task.person = {
                  entityId: task.customersId,
                  completeName: task.customerName,
                };

                task.product.id = task.procedureId;

                break;
            }

          }
          break;
        case bgValue('apps').accountOpening:

          if(!isMine) {

            alertNotifyService.showWarningT('error.task.user.not.ownership');
            return null;

          } else {

            switch (taskStages) {
              case bgValue('accountOpeningTaskStagesPhases').request:
                redirect = url.accountOpeningUrl;
                break;

              case bgValue('accountOpeningTaskStagesPhases').aprobation:
                redirect = url.accountOpeningApprovalUrl;
                break;

            }

          }

          break;

      }

      storage.setProductConfig(product);
      storage.updateTask({}, task);

      return redirect;
    }

  }

  bgRedirectService.$inject = [
    '$window',
    'storageService',
    'bgValueFilter',
    'customFieldsService',
    'sessionService',
    'translateService',
    '$log',
    '$timeout',
    'bgProductConfig',
    'tabHandlerService',
    'alertNotifyService',
    'isEmptyFilter'
  ];

  win.MainApp.Services
    .factory('bgRedirectService', bgRedirectService);

}(window));
