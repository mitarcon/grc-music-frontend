/* globals MainApp */

(function (win) {
  "use strict";

  function jasperServices() {

    return {
      openReport: openReport
    };

    function openReport(report){
      var file = new Blob([report.data], {type: 'application/pdf'});
      var fileURL = URL.createObjectURL(file);
      window.open(fileURL, 'SIVE'+new Date().getTime(), 'fullscreen=yes');      
    }
  }

  jasperServices.$inject = [];

  win.MainApp.Services
   .service('jasperServices', jasperServices);

}(window));
