(function (win) {
  "use strict";

  var BgpUrlsServices = function () {
    return {
      DASHBOARD:                    '/group/guest/dashboard',

      ACCOUNT_DETAILS:              '/group/guest/detalle-de-cuenta',

      PAYMENT:                      '/group/guest/pagos',

      TRANSFER_PERSONAL:            '/group/guest/cuentas-propias',
      TRANSFER_THIRD_PARTY:         '/group/guest/terceros',
      TRANSFER_INTERNATIONAL:       '/group/guest/internacionales',

      TRANSACTION_SCHEDULED:        '/group/guest/programadas',
      TRANSACTION_PERFORMED:        '/group/guest/realizadas',

      PERSONAL_DATA:                '/group/guest/datos-personales',

      NO_ACCOUNTS:                  '/group/guest/no-accounts',

      DEFAULT:                      '/group/guest/'

    };
  };

  win.MainApp.Services.service('bgpUrls', BgpUrlsServices);

}(window));
