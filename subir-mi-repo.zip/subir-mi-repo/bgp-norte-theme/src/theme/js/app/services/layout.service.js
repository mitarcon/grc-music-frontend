(function(win) {
  "use strict";

  var WS_PATH = "/layout/";

  var layoutService = function($log, liferayServiceInvoker) {

    $log.debug("[Liferay/Angular/LayoutService] Initializing...");

    function getLayouts(data) {
      return liferayServiceInvoker.invoke(WS_PATH + "get-layouts", data);
    }

    return {
      getLayouts: getLayouts
    };

  };

  layoutService.$inject = ["$log", "liferayServiceInvoker"];

  win.MainApp.Services.service("layoutService",
    layoutService);

}(window));
