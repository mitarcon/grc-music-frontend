(function(win){
  'use strict';


  function bgPopUpService(modal) {

    var modalInstance = {}, parentScope = {};

    var whenCancel = function () {
      if (angular.isDefined(parentScope.bgPopupCancelMethod)) {
        if (!parentScope.bgPopupFromService) {
          parentScope.$eval(parentScope.bgPopupCancelMethod);
        }else {
          parentScope.bgPopupCancelMethod();
        }
      }
      modalInstance.result.catch(function () { modalInstance.close(); });
      return modalInstance.dismiss('cancel');
    };

    var whenCancelParam = function (param) {
      if (angular.isDefined(parentScope.bgPopupCancelMethod)) {
        var assignFunction  = parentScope.bgPopupCancelMethod;
        if(!parentScope.bgPopupFromService) {
          assignFunction = parentScope.$eval(parentScope.bgPopupCancelMethod);
        }
        assignFunction(param);
      }
      modalInstance.result.catch(function () { modalInstance.close(); });
      return modalInstance.dismiss('cancel');
    };

    var whenOkParam = function (param) {
      if (angular.isDefined(parentScope.bgPopupMethod)) {
        var assignFunction  = parentScope.bgPopupMethod;
        if(!parentScope.bgPopupFromService) {
          assignFunction = parentScope.$eval(parentScope.bgPopupMethod);
        }
        assignFunction(param);
      }
      return modalInstance.close();
    };

    var whenOk = function () {

      if (angular.isDefined(parentScope.bgPopupMethod)) {
        if (!parentScope.bgPopupFromService) {
          parentScope.$eval(parentScope.bgPopupMethod);
        } else {
          parentScope.bgPopupMethod();
        }
      }
      return modalInstance.close();
    };

    return {
      open: function (scope) {
        parentScope = scope;
        var customClass = angular.isDefined(scope.bgPopupClass) ?
          scope.bgPopupClass : 'bg-modal-sm';

        var tpl = angular.isDefined(scope.bgPopupTpl) ?
          scope.bgPopupTpl : 'partials/bgp-popup/bg-popup.html';

        var lockScreen = angular.isDefined(scope.bgPopupLockScreen) ?
          scope.bgPopupLockScreen : false;

        modalInstance = modal.open({
          animation: true,
          templateUrl: window.baseThemeURL + tpl,
          controller: ['$scope',
            function ($scope) {
              $scope.title = scope.bgPopupTitle;
              $scope.message = scope.bgPopupMessage;
              $scope.okText = scope.bgPopupOkText;
              $scope.cancelText = scope.bgPopupCancelText;
              $scope.data = scope.bgPopupData;
              $scope.blocked = scope.bgPopupBlocked;
              $scope.product = scope.product;
              $scope.ok = whenOk;
              $scope.cancel = whenCancel;
              $scope.cancelParam = whenCancelParam;
              $scope.okParam = whenOkParam;
              $scope.lockScreen = lockScreen;
              $scope.tittleTwoLine = scope.bgPopupTittleTwoLine;
            }],
          windowClass: customClass,
          backdrop: 'static',
          keyboard: !lockScreen
        });
        return modalInstance;
      },
      cancel: whenCancel,
      cancelParam: whenCancelParam,
      ok: whenOk,
      okParam: whenOkParam
    };
  }
  bgPopUpService.$inject = ['$uibModal'];
  win.MainApp.Services
    .factory('bgPopUpService', bgPopUpService);

}(window));
