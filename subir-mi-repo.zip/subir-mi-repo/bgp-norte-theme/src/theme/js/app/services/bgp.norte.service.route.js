/* globals MainApp */

(function (win) {
  "use strict";

  function bgpServiceRoute(isEmpty, bgValue, $filter) {

    /*
     * ***** OJO *****
     * el switch de este archivo fue movido a bgp.norte.invoke.service,
     * este archivo sera eliminado luego de validar que su migracion no trajera
     * consecuencias a otros desarrollos
     */
    return function (project, service) {

      if (!isEmpty(project) && !isEmpty(service)) {
        var output = {};
        switch (project) {
          case 'car':
            output = bgValue('wsPathCar');
            break;
          case 'common':
            output = bgValue('wsPathCommon');
            break;
          case 'wizard':
            output = bgValue('wsPathWizard');
            break;
          case 'maintenance':
            output = bgValue('wsPathMaintenance');
            break;
          case 'neighborhood':
            output = bgValue('wsPathNeighborhood');
            break;
          case bgValue('apps').clientDetails:
            output = bgValue('wsPathClientDetails');
            break;
          case 'quote':
            output = bgValue('wsPathQuote');
            break;
          case 'task':
            output = bgValue('wsPathTask');
            break;
          case bgValue('apps').notification:
            output = bgValue('wsPathNotifications');
            break;
          case bgValue('apps').quoteRecord:
            output = bgValue('wsPathRecord');
            break;
          case bgValue('apps').carQuoteDetails:
            output = bgValue('wsPathCarQuoteDetails');
            break;
          default:
        }
        return !isEmpty(output.ws[service]) ?
          {
            'url': output.origin + output.ws[service].route,
            'method': output.ws[service].method
          }
          : undefined;
      }
    };
  }

  bgpServiceRoute.$inject = ['isEmptyFilter', 'bgValueFilter', '$filter'];

  win.MainApp.Services.service('bgpServiceRoute', bgpServiceRoute);

}(window));
