(function(win) {
  'use strict';

  function commonFunctions(
    log, isEmpty, filter, translate, cedFilter, documentTypeCodes,
    paramService, $locale, rootScope, popUpService, storage, bgValue,
    redirect,
    uppercase, $q
  ) {

    log.debug('[commonFunctions] Initializing....');
    var contains = function(list, name) {
      return angular.isArray(list) && list.indexOf(name) !== -1;
    };

    var upper = function(obj, excludes) {
      if (isEmpty(obj)) {
        return obj;
      }
      if (typeof obj === 'string') {
        return uppercase(obj);
      }
      if (typeof obj !== 'object') {
        return obj;
      }
      angular.forEach(Object.keys(obj), function(name) {
        if (!contains(excludes, name)) {
          obj[name] = upper(obj[name], excludes);
        }
      });
      return obj;
    };
    //
    //   var propagateProperty = function (property, value, toScope) {
    //     toScope[property] = value;
    //     if (toScope.$parent) {
    //       propagateProperty(property, value, toScope.$parent);
    //     }
    //     return this;
    //   };
    //
    //   var isPanamanianWithID = function (person) {
    //     return person.nationality.id === panamaCode;
    //   };
    //
    return {
      objectUppercase: function(obj, excludes) {
        return upper(obj, excludes);
      },
      isEmpty: function(obj) {
        return angular.isUndefined(obj) ||
          obj === '' ||
          obj === null;
      },

      generateSequentialArray: function(from, to, keyWord) {
        var singular = translate.getValue(keyWord);
        var plural = translate.getValue(keyWord + '.plural');
        return Array.apply([], {
            length: to + 1
          })
          .map(Number.call, Number)
          .splice(from, to + 1)
          .map(function(num) {
            return {
              value: num,
              text: num + (' ' + (num !== 1 ? plural : singular))
            };
          });
      },
      //   getSafeURL: function (url, context, params) {
      //     var result;
      //     params = angular.isDefined(params) ? params : '';
      //     if (url.charAt(url.length - 1) === '/') {
      //       result = url + context + params;
      //     } else {
      //       result = url + '/' + context + params;
      //     }
      //     return result;
      //   },
      //   propagate : function(objectProperty, scope){
      //     angular.forEach(Object.keys(objectProperty), function(item){
      //       propagateProperty(item, objectProperty[item], scope);
      //     });
      //   },

      //   mergeObjects: function (obj1, obj2) {
      //     var result = angular.copy(obj1);
      //     angular.forEach(Object.keys(obj2), function (item) {
      //       result[item] = angular.copy(obj2[item]);
      //     });
      //     return result;
      //   },
      updateObject: function(srcObj, destObj) {
        for (var key in destObj) {
          if (destObj.hasOwnProperty(key) && !srcObj.hasOwnProperty(key)) {
            srcObj[key] = undefined;
          }
          if (destObj.hasOwnProperty(key) && srcObj.hasOwnProperty(key)) {
            destObj[key] = srcObj[key];
          }
        }
      },
      updateReferenceObject: function(srcObj, destObj) {
        for (var key in srcObj) {
          if (srcObj.hasOwnProperty(key)) {
            destObj[key] = srcObj[key];
          }
        }
      },
      getCommissionFieldName: function(counter) {
        return counter < 10 ? 'record0' + counter :
          'record' + counter;
      },
      formatQuoteCode: function(quote) {
        return quote.replace(/^(.{1})(.{3})(.*)$/, '$1 $2 $3');
      },
      //   getDocumentNumber: function (person){
      //     if (isPanamanianWithID(person)) {
      //       return cedFilter(person.documentoIdentidad);
      //     }
      //     return person.pasaporte;
      //   },
      getAPCDocumentNumber: function(documentNumber, documentType) {
        if (documentType === documentTypeCodes.ced) {
          return cedFilter(documentNumber);
        }
        return documentNumber;
      },
      getAPCIdentificationType: function(documentNumber, documentType) {
        if (documentType === documentTypeCodes.ced) {
          return 1;
        }
        return 3; // PASSPORT
      },
      getPrintApcLetterWrapper: function(participant) {
        var wrapper = {
          entityId: participant.entityId,
          documentType: participant.documentType,
          completeName: participant.completeName,
        };

        if (isEmpty(participant.documentNumber)) {
          wrapper.documentNumber = participant.passport;
        } else {
          wrapper.documentNumber = participant.documentNumber;
        }

        return wrapper;
      },
      getSafeValue: function(value, isDefault, isDate) {
        if (!isEmpty(value)) {
          return isDate ? new Date(value) : value;
        }
        return angular.isUndefined(isDefault) ? '' : isDefault;
      },

      // Constructor del Init de todas las cotizaciones
      buildInitWrapperQuote: function(scope) {
        var ipcWrapper = storage.getIpcWrapper(scope);
        // TODO: Este objeto se esta consturyendo para cotizaciones que vienen
        // desde crear o editar una nueva, se necesita validar la estructura
        // para cuando se viene de wizard o mantenimiento
        return {
          apcFilter: {
            quoteCode: ipcWrapper.task.product.id,
            customerId: ipcWrapper.task.person.entityId,
            forceUpdate: false,
            addHouseRentalObligation: true
          },
          editedProductPerson: ipcWrapper.task.person,
          wizardFlag: ipcWrapper.wizardFlag,
          newClientFlag: ipcWrapper.newClientFlag,
          customerDataUpdated: ipcWrapper.customerDataUpdated,
          preQuoteDataUpdated: ipcWrapper.preQuoteDataUpdated,
          completeName: ipcWrapper.task.person.completeName,
          dataSheetPrint: ipcWrapper.dataSheetPrint,
          dataSheetPrintRequired: ipcWrapper.dataSheetPrintRequired,
          clientEditionCanceled: ipcWrapper.clientEditionCanceled
        };

        // return {
        // 	"apcFilter": {
        // 		"quoteCode": 1132268,
        // 		"customerId": 1356875,
        // 		"forceUpdate": false,
        // 		"addHouseRentalObligation": true
        // 	},
        // 	"editedProductPerson": {
        // 		"entityId": 1356875,
        // 		"apcData": {
        // 			"apcTemporaryFlag": false
        // 		}
        // 	},
        // 	"wizardFlag": false,
        // 	"newClientFlag": false,
        // 	"customerDataUpdated": false,
        // 	"dataSheetPrint": false,
        // 	"dataSheetPrintRequired": false,
        // 	"differenceFlag": false
        // };
      },
      goToCustomer: function(scope, row, isPrincipalParticipant, disabled,
        product, quoteId, stageId, statusId, isDataSheetPrinted,
        isDataSheetPrintedRequired, withProduct) {

        if (!disabled) {

          var ipcWrapper = {
            task: {
              procedureId: quoteId,
              stage: {
                id: stageId
              },
              status: {
                id: statusId
              },
              product: {
                id: quoteId,
                type: {
                  id: product,
                  name: product
                }
              },
              person: {
                entityId: row.entityId,
                actualEmployments: row.actualEmployments,
                previousEmployments: row.previousEmployments,
                contactData: row.contactData,
                otherIncome: row.otherIncome,
                participantType: row.participantType,
                apcData: row.apcData
              },
            },
            isPrincipalParticipant: isPrincipalParticipant,
            newClientFlag: false,
            wizardFlag: false,
            customerDataUpdated: false,
            dataSheetPrint: isDataSheetPrinted,
            withProduct: withProduct,
            dataSheetPrintRequired: isDataSheetPrintedRequired,
            activeTab: bgValue('standardQuoteTabs').clients,
            deletedEmployments: (!scope.deletedEmployments ||
              !scope.deletedEmployments[row.entityId]) ? [] : scope.deletedEmployments[
              row.entityId]
          };

          storage.updateIpcWrapper(scope, ipcWrapper.task, 'task');
          storage.updateIpcWrapper(scope, ipcWrapper.isPrincipalParticipant,
            'isPrincipalParticipant');
          storage.updateIpcWrapper(scope, ipcWrapper.newClientFlag,
            'newClientFlag');
          storage.updateIpcWrapper(scope, ipcWrapper.wizardFlag,
            'wizardFlag');
          storage.updateIpcWrapper(scope, ipcWrapper.dataSheetPrint,
            'dataSheetPrint');
          storage.updateIpcWrapper(scope, ipcWrapper.dataSheetPrintRequired,
            'dataSheetPrintRequired');
          storage
            .updateProductConfigPropertyActiveTab(scope, ipcWrapper.activeTab);
          storage.updateIpcWrapper(scope, ipcWrapper.deletedEmployments,
            'deletedEmployments');

          storage.updateIpcWrapper(scope, withProduct, 'withProduct');

          redirect.toCustomer();
        }
      },
      /**
       * Build basic general rules request and pass it as parameter to
       * employment directive. Its use to reload rules inside each employment
       */
      getBasicGeneralRulesRequest: function(cli) {
        var clientRq = {
          actualEmployments: [],
          birthDate: cli.birthDate,
          documentNumber: cli.documentNumber,
          apcData: {
            apcFlag: cli.apcData ? cli.apcData.apcFlag : false
          },
          gender: {
            id: cli.gender ? cli.gender.id : null
          },
          civilStatus: {
            id: cli.civilStatus ? cli.civilStatus.id : null
          }
        };
        return clientRq;
      },
      //   /**
      //   * Dado un monto calcula el monto
      //   **/
      //   calculatePercentageUseAmount : function (total, percentage){
      //     return !isEmpty(total) ? (percentage*100)/total : percentage;
      //   },
      //   /*
      //   * Dado un porcentaje calcula el monto
      //   */
      //   calculateAmountUsePer : function (total, percentage){
      //     return (percentage*total)/100;
      //   },
      getSizeDecimalNumber: function() {
        var aux = parseInt(paramService.getSizeNumber());
        if (isNaN(aux)) {
          aux = parseInt(translate.getValue("global.decimal.number"));
          return isNaN(aux) ? 0 : aux;
        } else {
          return aux;
        }
      },
      getSizeDecimalPercentage: function() {
        var aux = parseInt(paramService.getSizePercentage());
        if (isNaN(aux)) {
          aux = parseInt(translate.getValue("global.decimal.number"));
          return isNaN(aux) ? 0 : aux;
        } else {
          return aux;
        }
      },
      //   //type puede ser 'percentage', 'number' o recibir un numero a truncar
      //   truncateNumber : function (number, type) {
      //
      //     switch (type) {
      //       case 'percentage':
      //         return trunk (number, this.getSizeDecimalPercentage());
      //       case 'number':
      //         return trunk (number, this.getSizeDecimalNumber());
      //       default:
      //         return trunk(number, type);
      //     }
      //
      //     function trunk (_number, size){
      //       var arr = _number.toString()
      //         .split($locale.NUMBER_FORMATS.DECIMAL_SEP);
      //       size = parseInt(size);
      //       if(arr[1] === undefined || isNaN(size) || size <0 ||
      //         arr[1].length <= size){
      //         return _number;
      //       }else{
      //         return parseFloat( arr[0]+$locale.NUMBER_FORMATS.DECIMAL_SEP+
      //           arr[1].substring(0, size));
      //       }
      //     }
      //   },
      //   /**
      //   * Dado el arreglo de adicionales retorna los adicionales que cumplen la
      //   * condición
      //   */
      getAdditionalForField: function(additionalParticipants,
        field) {
        var output = [];
        if (isEmpty(additionalParticipants)) {
          return output;
        }

        var arraylength = additionalParticipants.length;

        for (var i = 0; i < arraylength; i++) {
          if (!isEmpty(additionalParticipants[i][field]) &&
            !additionalParticipants[i][field]) {
            output.push(additionalParticipants[i]);
          }
        }
        return output;
      },
      //   /**
      //   * Valida si el principal y los adicionales cumplen la condicion, sino es
      //   * así levanta la modal de mensaje
      //   */
      validateApply: function(principal, additionalParticipants,
        redirectToError, fieldPrincipal, fieldAdditional) {

        var arrayToPrint = [];

        if (!isEmpty(principal[fieldPrincipal]) &&
          !principal[fieldPrincipal]) {
          arrayToPrint.push(principal);
        }

        var additionalDontApply = this
          .getAdditionalForField(additionalParticipants,
            fieldAdditional);

        if (additionalDontApply.length > 0) {
          arrayToPrint = arrayToPrint.concat(additionalDontApply);
        }

        if (arrayToPrint.length > 0) {
          var attrs = {
            bgPopupData: {
              arrayAdditional: arrayToPrint,
              title: translate.getValue('quote.modal.under.age.tittle'),
              titleButton: translate.getValue('global.accept'),
              textForSingular: translate.getValue(
                'quote.modal.under.age.text.singular'),
              textForPlural: translate.getValue(
                'quote.modal.under.age.text.plural'),
            },
            bgPopupClass: "bg-modal-lg",
            bgPopupTpl: 'partials/bgp-popup/bg-popup-apply-additional.html',
            bgPopupMethod: redirectToError,
            bgPopupLockScreen: true,
            bgPopupFromService: true,
          };

          popUpService.open(attrs);
          return false;
        } else {
          return true;
        }
      },
      // var dLFile = {
      //   processType: Proceso al que esta asociado el documento actualmente 'tramite'
      //   documentDTO: documento al que esta asociado el archivo
      //   producTypeId: producto con el que se esta trabajando 'storage.getProductConfig().ruleOperation',
      //   procedureId: id de la cotizacion,
      //   dlfileName: nombre del archivo,
      //   fileDescription: decripcion del archivo,
      //   contentFile: contenido del archivo en base 64, cuando se sube un
      // archivo aca asigno el file java script y luego se usa 'manageFile.createDLFileWrapper'
      // para que cree el base64
      //   docEntityId: Cuando se asigne el usuario aca debe ir el entityId,
      //   subFolder: la subcarpeta en el tramite donde se guardara el archivo 'quote',
      // };
      createDLFileWrapper: function(processType, documentDTO, producTypeId,
        procedureId, dlfileName, fileDescription, contentFile, docEntityId,
        subFolder, extension) {
        return {
          processType: processType,
          documentDTO: documentDTO,
          producTypeId: producTypeId,
          procedureId: procedureId,
          dlfileName: dlfileName,
          fileDescription: fileDescription,
          contentFile: contentFile,
          docEntityId: docEntityId,
          subFolder: subFolder,
          extension: extension
        };
      },
      createObjectTaskInfoForStorage: function(task) {
        return {
          product: task.product,
          quoteId: task.procedureId,
          stage: task.stage,
          status: task.status
        };
      },
      // Recibe un objeto con la declaracion de funciones que retornan una promesa,
      // las ejecuta y retorna un objeto de promesas
      objectToObjectPromise: function(objectFunction) {
        var promises = {};
        angular.forEach(objectFunction, function(object, key) {
          if (angular.isFunction(object)) {
            promises[key] = object();
          }
        });
        return $q.all(promises);
      },
      // Retorna un objeto 'seccion' con campo para error o no
      createSection: function(section, error) {
        var output = {
          'name': translate.getValue(section)
        };
        if (!isEmpty(error)) {
          var errorLabel = 'participantResults';
          output[errorLabel] = [];
          output[errorLabel][0] = {
            messages: [{
              description: translate.getValue(error)
            }]
          };
        }
        return output;
      },
      // Funcion usada para crear la estructura del objeto para la modal de
      // guardar en tareas
      // "arrayResponse" es un objeto formado por la respuesta de los save de cada tarea
      // "arrayToCreate" es un arreglo de objetos del tipo
      // {
      //   section: quoteSummary,
      //   labelSection: 'global.summary'
      // }
      createArraySectionSave: function(arrayResponse, arrayToCreate) {
        var sectionsSave = [];
        if (arrayResponse === undefined || arrayToCreate === undefined) {
          return sectionsSave;
        }
        for (var i = 0; i < arrayToCreate.length; i++) {
          if (isEmpty(arrayResponse[arrayToCreate[i].section])) {
            sectionsSave.push(
              this.createSection(arrayToCreate[i].labelSection));
          } else {
            sectionsSave.push(arrayResponse[arrayToCreate[i].section]);
          }
        }
        return sectionsSave;
      },
      getValidLastYear: function(empl) {
        var actualYear = new Date().getFullYear();
        if (isEmpty(empl.employmentSupportData)) {
          empl.yValid = true;
        } else {
          if (isEmpty(empl.employmentSupportData.lastYear)) {
            empl.yValid = true;
            empl.employmentSupportData.penultimateYear = undefined;
            return empl.yValid;
          } else if (empl.employmentSupportData.lastYear > actualYear - 3 &&
            empl.employmentSupportData.lastYear <= actualYear) {
            empl.yValid = true;
            empl.employmentSupportData.penultimateYear =
              empl.employmentSupportData.lastYear - 1;
            return empl.yValid;
          } else {
            empl.yValid = false;
            empl.employmentSupportData.penultimateYear = undefined;
            return empl.yValid;
          }
        }
      },
      changeTaskNameToView: function(taskname) {
        return isEmpty(taskname) ? taskname :
          translate.getValue('task.stage.' + taskname.replace(' ', '_'));
      },
      getAppFromProduct: function(product) {
        var valueProduct = bgValue('product');
        var valueApp = bgValue('apps');
        switch (product) {
          case valueProduct.car:
            return valueApp.car;
          case valueProduct.credit:
            return valueApp.credit;
          case valueProduct.mortgage:
            return valueApp.mortgage;
          default:
            return '';
        }
      },
      getPrintDocuments: function(app) {
        var valueApp = bgValue('apps');
        var documentCode = bgValue('bgDocumentCode');
        var aux = {};
        switch (app) {
          case valueApp.car:
            aux[documentCode.cardApc] = {
              'printWithNewQuote': true,
              'printWithDirtyForm': true,
            };
            aux[documentCode.regularTransferCard] = {
              'printWithNewQuote': true,
              'printWithDirtyForm': true,
            };
            aux[documentCode.exemptTaxTransferCard] = {
              'printWithNewQuote': true,
              'printWithDirtyForm': true,
            };
            aux[documentCode.defaultVal] = {
              'printWithNewQuote': false,
              'printWithDirtyForm': false,
            };
            return aux;
          case valueApp.credit:
            aux[documentCode.cardApc] = {
              'printWithNewQuote': true,
              'printWithDirtyForm': true,
            };
            aux[documentCode.cardAcceptance] = {
              'printWithNewQuote': false,
              'printWithDirtyForm': false,
            };
            aux[documentCode.defaultVal] = {
              'printWithNewQuote': false,
              'printWithDirtyForm': false,
            };
            aux[documentCode.defaultVal] = {
              'printWithNewQuote' : false,
              'printWithDirtyForm' : false,
            };
            return aux;
          case valueApp.mortgage:
            return {};
          default:
            return {};
        }
      },
      canPrintDocumentWhenQuoteFinished: function (modificationDate, actualDate, app){
        // search diffDay en bgParamsService
        // Debe haberse cargado los datos de la tabla parametro primero

        if (isEmpty(modificationDate) || isEmpty(actualDate))
          return false;

        var diffDayMax;
        var valueApp = bgValue('apps');

        switch (app) {
          case valueApp.car:
            diffDayMax = paramService.getMaxDateValidForPrintInCar();
            break;
          default:
            diffDayMax = -1;
        }


        // El valor por defecto si no existe el parametro sera bloqueado
        diffDayMax = isEmpty(diffDayMax) ? -1 : parseInt(diffDayMax);

        if (diffDayMax < 0) {

          // No puedo imprimir
          return false;
        } else if (diffDayMax === 0) {

          //Puedo imprimir
          return true;
        } else {

          //Dependera de la diferencia de fechas

          actualDate = new Date(actualDate);
          modificationDate = new Date(modificationDate);

          var parseactualDate = Date.parse(actualDate);
          var parseModificationDate = Date.parse(modificationDate);


          var difference_ms = Math.abs(parseactualDate - parseModificationDate);
          var ONE_DAY = 1000 * 60 * 60 * 24;

          return diffDayMax >= difference_ms/ONE_DAY;

        }

      }
    };
  }
  commonFunctions.$inject = [
    '$log',
    'isEmptyFilter',
    '$filter',
    'translateService',
    'cedFilter',
    'documentTypeCodes',
    'bgParamsService',
    '$locale',
    '$rootScope',
    'bgPopUpService',
    'storageService',
    'bgValueFilter',
    'bgRedirectService',
    'uppercaseFilter',
    '$q'
  ];

  win.MainApp.Services
    .service('commonFunctions', commonFunctions);
}(window));
