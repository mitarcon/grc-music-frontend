(function(win) {
  "use strict";

  var exceptionHandlerService = function($log, tFilter, modalService,
    $document) {

    var attrs = {};
    var noServiceErrorCode = 503;
    var modalAppendClass = ".bgp-norte-theme";

    $log.debug("[Liferay/Angular/ExceptionHandlerService] Initializing...");

    function handleError(exception, title) {

      if (exception.status === noServiceErrorCode) {

        var bgpTheme =
          angular.element($document[0].querySelector(modalAppendClass));

        attrs = {
          bgModalTpl: 'bgp-norte-theme/angular/partials/service-error.html',
          bgModalTitle: title,
          bgModalData: {},
          bgAppendTo: bgpTheme
        };

        modalService.open(attrs);

        return false;

      } else {
        return true;
      }
    }

    return {
      handleError: handleError
    };

  };

  exceptionHandlerService.$inject = ['$log', 'tFilter', 'modalService',
    '$document'
  ];

  win.MainApp.Services.service('exceptionHandlerService',
    exceptionHandlerService);

}(window));
