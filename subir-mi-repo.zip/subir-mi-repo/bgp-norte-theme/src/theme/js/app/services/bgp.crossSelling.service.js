(function (win) {
  'use strict';

 var creditCardCrossSellingService = function($log,alertNotifyService,isEmpty,
   routeInvoker) {

    var CreditCardsModel = {
      cards: [],
      cardCategorySection: []
    };


    function findCatalogCreditCard(credit) {
      routeInvoker.invoke('catalog', 'findCreditCardCatalog', credit)
      .then(function (response) {
        setCardCatalog(response.data.catalogCreditCards);
      })
      .catch(function(exception){
        $log.error("Error en detailsService.initCarQuote ", exception);
        alertNotifyService.showErrorT('global.defaultError');
      })
      .finally(function(){
        // vm.global.showLoading = false;
      });
      return CreditCardsModel;
    }

    function setCrossSellingState(crossSelling){

      if (!isEmpty(crossSelling) &&
        crossSelling.applies) {

        if(isEmpty(crossSelling.creditCard)){
          crossSelling.creditCard = {};
        }

        if(isEmpty(crossSelling.creditCard.benefit)){
          crossSelling.creditCard.benefit = {};
        }

        if (isEmpty(crossSelling.creditCard) ||
          isEmpty(crossSelling.creditCard.limit) ||
          crossSelling.creditCard.limit > crossSelling.suggestLimit){
            crossSelling.creditCard.limit =
              angular.copy(crossSelling.suggestLimit);
        }
        //TODO - @Sparker
        //- Cuando se envie wrapper al servicio
        //- descomentar esta linea
        // var credit = {limit: vm.global.carQuote.crossSelling.creditCard.limit };

        var credit = crossSelling.creditCard.limit;
        crossSelling = findCatalogCreditCard(credit);
      }

      return crossSelling;
    }

    function setCardCategorySection(list) {
      CreditCardsModel.cardCategorySection = [];
      var section = CreditCardsModel.cardCategorySection;
      angular.forEach(list, function (item) {
        if (section.indexOf(item.category.id) < 0) {
          if (item.applies){
            section.push(item.category.id);
          }
        }
      });
      CreditCardsModel.cardCategorySection = section;
    }

    function setCardCatalog(cardCatalogList) {
      if (!isEmpty(cardCatalogList)) {
        CreditCardsModel.cards = cardCatalogList;
      }
      setCardCategorySection(cardCatalogList);
    }

    return {
      setCardCatalog: setCardCatalog,
      setCardCategorySection: setCardCategorySection,
      setCrossSellingState: setCrossSellingState,
      findCatalogCreditCard: findCatalogCreditCard
    };
  };



  creditCardCrossSellingService.$inject = [
    '$log','alertNotifyService','isEmptyFilter',
    'routeInvoker'
  ];

  win.MainApp.Services
    .service('creditCardCrossSellingService', creditCardCrossSellingService);

}(window));
