(function(win){

  'use strict';

  function stringUtils(translateService) {
    return {
      pluralizer: function (value, keyDate, enableZero) {
        if (value > 0 || (value>=0  && enableZero)) {
          return ' ' +
            value + ' ' +
            translateService.getValue(keyDate+(value!==1 ?'.plural':''));
        }
        return '';
      }
    };
  }
  stringUtils.$inject = ['translateService'];
  win.MainApp.Services
    .service('stringUtils', stringUtils);

}(window));
