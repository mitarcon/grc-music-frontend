(function(win) {
  "use strict";
  function manageFileService (
    $log,
    $q,
    translateService
  ){

    $log.debug("[Liferay/Angular/manageFileService] Initializing...");

    return {
      createDLFileWrapper: createDLFileWrapper,
      createDLFileWrapper64Promise: createDLFileWrapper64Promise
    };

    function getBase64(file) {
       var reader = new FileReader();
       var deferred = $q.defer();
       reader.readAsDataURL(file);
       reader.onload = function () {
         deferred.resolve(reader.result);
       };
       reader.onerror = function (error) {
         deferred.reject(translateService.getValue("error.file.upload"));
       };
       return deferred.promise;
    }
    // function createDLFileWrapper64Promise (data){
    function createDLFileWrapper64Promise(processType, documentDTO, producTypeId,
    procedureId, dlFileName, fileDescription, contentFile, docEntityId,
    subFolder, extension){
      var data = createDLFileWrapper(processType, documentDTO, producTypeId,
      procedureId, dlFileName, fileDescription, contentFile, docEntityId,
      subFolder, extension);

      var deferred = $q.defer();
      getBase64(data.contentFile)
      .then(function(file64){
        data.contentFile = file64;
        deferred.resolve(data);
      })
      .catch(function(error){
        deferred.reject(error);
      });
      return deferred.promise;
    }
    // var dLFile = {
    //   processType: Proceso al que esta asociado el documento actualmente 'tramite'
    //   documentDTO: documento al que esta asociado el archivo
    //   producTypeId: producto con el que se esta trabajando 'storage.getProductConfig().ruleOperation',
    //   procedureId: id de la cotizacion,
    //   dlfileName: nombre del archivo,
    //   fileDescription: decripcion del archivo,
    //   contentFile: contenido del archivo en base 64, cuando se sube un
    // archivo aca asigno el file java script y luego se usa 'manageFile.createDLFileWrapper'
    // para que cree el base64
    //   docEntityId: Cuando se asigne el usuario aca debe ir el entityId,
    //   subFolder: la subcarpeta en el tramite donde se guardara el archivo 'quote',
    // };
    function createDLFileWrapper(processType, documentDTO, producTypeId,
    procedureId, dlFileName, fileDescription, contentFile, docEntityId,
    subFolder, extension){
      return {
        processType: processType,
        documentDTO: documentDTO,
        producTypeId: producTypeId,
        procedureId: procedureId,
        dlFileName: dlFileName,
        fileDescription: fileDescription,
        contentFile: contentFile,
        docEntityId: docEntityId,
        subFolder: subFolder,
        extension: extension
      };
    }

  }

  manageFileService.$inject = [
    '$log',
    '$q',
    'translateService'
  ];

  win.MainApp.Services
    .service("manageFileService", manageFileService);

}(window));
