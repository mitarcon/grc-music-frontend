(function (win) {
  'use strict';

  function bgGeneralRuleService(log, storage, bgValue, routeInvoker) {

    log.debug('[bgGeneralRuleService] Initializing...');

    var prepareFilters = function (client, employments) {
      var filters = {
        'client': client,
        'operation': storage.getProductConfig().ruleOperation
      };

      if (angular.isDefined(employments)) {
        if (employments instanceof Array) {
          filters.client.actualEmployments = employments;
        } else {
          filters.client.actualEmployments = [employments];
        }
      }

      return filters;
    };

    return {
      run: function (appName, client, employments) {

        return routeInvoker.invoke(appName, 'executeRules',
          prepareFilters(client, employments));
      }
    };
  }
  bgGeneralRuleService.$inject = ['$log', 'storageService', 'bgValueFilter',
    'routeInvoker'
  ];
  win.MainApp.Services
    .service('bgGeneralRuleService', bgGeneralRuleService);

}(window));
