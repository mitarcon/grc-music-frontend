(function(win){
  'use strict';
  function identificationUtils(log, isEmpty){
    
    log.debug('[identificationUtils] Initializing...');

    return {
      textToModel: function (identification) {
        if (angular.isDefined(identification)) {
          var document = identification.trim();
          var completeSeat = document.substring(8, 14);
          if (completeSeat.length < 6) {
            completeSeat =
              new Array(7 - completeSeat.length).join('0') + completeSeat;
          }
          return {
            province: document.substring(0, 2),
            alpha: document.substring(2, 4),
            folio: document.substring(4, 8),
            seat: completeSeat
          };
        }
        return {};
      },
      //120517 - JGIRON - OPTIMIZACIÓN
      modelToText: function (identification) {
        if (!isEmpty(identification)) {
          var seat = '';
          if(identification.seat) {
              seat = identification.seat.trim();

            if (seat[0] === '0') {
              seat = seat.substring(1, 6);
            }
          }
          return identification.province +
            identification.alpha +
            identification.folio +
            seat;
        }
      }

    };
  }
  identificationUtils.$inject = ['$log','isEmptyFilter'];
  win.MainApp.Services
    .service('identificationUtils', identificationUtils);
}(window));
