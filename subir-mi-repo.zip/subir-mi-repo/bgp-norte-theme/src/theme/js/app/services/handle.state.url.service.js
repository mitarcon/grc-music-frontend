(function (win) {
    "use strict";

    var handleStateUrlService = function ($log, $state, $window) {
        $log.debug("[Liferay/Angular/handleStateUrlService] Initializing...");

        function go(state, data, historyStateData) {
            if (state.charAt(0) == "/") {
                $window.location.href = state;
            }
            else {
                $state.go(state, { data: data, historyStateData: historyStateData });
            }
        }

        return {
            go: go
        };
    };

    handleStateUrlService.$inject = [
        "$log",
        "$state",
        "$window"
    ];

    win.MainApp.Services
        .service("handleStateUrlService", handleStateUrlService);
}(window));
