(function(win){
  'use strict';

  function storageService(log, storage, ipcWrapperData, isEmpty) {
    log.debug('[storageService] Initializing...');

    function buildEmptyConfig() {
      return {
        ipcWrapper: angular.copy(ipcWrapperData.obj),
        productConfig: null
      };
    }
    function validateScope(scope) {
      if (!scope.storage) {
        scope.storage = storage;
      }
      if (!scope.storage.browser) {
        scope.storage.browser = buildEmptyConfig();
      }
    }
    function updateEntityIdProperty(scope, data){
      if(isEmpty(scope.storage.browser.ipcWrapper.task.person.entityId)) {
        scope.storage.browser.ipcWrapper.task.person.entityId =
          buildEmptyConfig().ipcWrapper.task.person.entityId;
      }
      scope.storage.browser.ipcWrapper.task.person.entityId = data;
    }
    function updatePassportProperty(scope, data){
      if(isEmpty(scope.storage.browser.ipcWrapper.task.person.passport)) {
        scope.storage.browser.ipcWrapper.task.person.passport =
          buildEmptyConfig().ipcWrapper.task.person.passport;
      }
      scope.storage.browser.ipcWrapper.task.person.passport = data;
    }
    function updateDocumentTypeProperty(scope, data){
      if(isEmpty(scope.storage.browser.ipcWrapper.task.person.documentType)) {
        scope.storage.browser.ipcWrapper.task.person.documentType =
          buildEmptyConfig().ipcWrapper.task.person.documentType;
      }
      scope.storage.browser.ipcWrapper.task.person.documentType = data;
    }
    function updateTaskProperty(scope,data,name){
      if (!scope.storage.browser.ipcWrapper.task) {
        scope.storage.browser.ipcWrapper.task = buildEmptyConfig().ipcWrapper.task;
      }
      scope.storage.browser.ipcWrapper.task[name] = data;
    }
    function updateIpcWrapperProperty(scope,data,name){
      if (!scope.storage.browser.ipcWrapper) {
        scope.storage.browser = buildEmptyConfig();
      }
      scope.storage.browser.ipcWrapper[name] = data;
    }
    function updateApcDataProperty(scope, data, name) {
      if (!scope.storage.browser.ipcWrapper.task) {
        scope.storage.browser.ipcWrapper.task = buildEmptyScoring(scope);
      }
      if (!scope.storage.browser.ipcWrapper.task.person.apcData) {
        scope.storage.browser.ipcWrapper.task.person.apcData = {};
      }
      scope.storage.browser.ipcWrapper.task.person.apcData[name] = data;
    }
    function updateProductIdProperty(scope, data){
      if (isEmpty(scope.storage.browser.ipcWrapper.task.product.id)) {
        scope.storage.browser.ipcWrapper.task.product.id =
          buildEmptyConfig().ipcWrapper.task.product.id;
      }
      scope.storage.browser.ipcWrapper.task.product.id = data;
    }
    function updateProductConfigProperty(scope, data, name){
      if (!scope.storage.browser.productConfig) {
        scope.storage.browser.productConfig = buildEmptyConfig().productConfig;
      }
      scope.storage.browser.productConfig[name] = data;
    }
    function updateLiabilityOpeningDataProperty(vm, data){
      if (isEmpty(vm.storage.browser.ipcWrapper.liabilityOpeningData)) {
        vm.storage.browser.ipcWrapper.liabilityOpeningData = buildEmptyConfig().liabilityOpeningData;
      }
      vm.storage.browser.ipcWrapper.liabilityOpeningData = data;
    }
    return {
      setProductConfig: function(value){
        if(isEmpty(storage.browser)){
          storage.browser = buildEmptyConfig();
        }
        storage.browser.productConfig = value;
      },
      getProductConfig: function(){
        return storage.browser.productConfig;
      },
      updateIpcWrapper: function (scope, propertyValue, ipcWrapperProperty ) {
        validateScope(scope);
        updateIpcWrapperProperty(scope, propertyValue, ipcWrapperProperty);
      },
      getIpcWrapper: function (scope) {
        validateScope(scope);
        return scope.storage.browser.ipcWrapper;
      },
      getIpcWrapperTask: function(scope){
        validateScope(scope);
        return scope.storage.browser.ipcWrapper.task;
      },
      updateApcDataProperty: function (scope, propertyValue, apcDataProperty ) {
        validateScope(scope);
        updateApcDataProperty(scope, propertyValue, apcDataProperty);
      },
      updateEntityId: function(vm, data) {
        validateScope(vm);
        updateEntityIdProperty(vm,data);
      },
      updatePassport: function(vm, data) {
        validateScope(vm);
        updatePassportProperty(vm,data);
      },
      updateDocumentType: function(vm, data) {
        validateScope(vm);
        updateDocumentTypeProperty(vm,data);
      },
      updateProduct: function (scope, product) {
        validateScope(scope);
        updateTaskProperty(scope, product, 'product');
      },
      updateProductId: function(vm, data) {
        validateScope(vm);
        updateProductIdProperty(vm,data);
      },
      updatePerson: function(scope, person) {
        validateScope(scope);
        updateTaskProperty(scope, person, 'person');
      },
      updateProductConfigPropertyActiveTab: function(scope, data){
        validateScope(scope);
        updateProductConfigProperty(scope, data, 'activeTab');
      },
      updateProductConfigRedirectTo: function(scope, data){
        validateScope(scope);
        updateProductConfigProperty(scope, data, 'redirecTo');
      },
      updateLiabilityOpeningData: function(vm, data){
        validateScope(vm);
        updateLiabilityOpeningDataProperty(vm, data);
      },
      cleanStorage: function(){
        storage.browser = buildEmptyConfig();
      },
      updateTask: function(scope, task){
        validateScope(scope);
        scope.storage.browser.ipcWrapper.task = task;
      }
    };
  }
  storageService.$inject =  [
    '$log','$sessionStorage','bgModelIpcWrapperData', 'isEmptyFilter'];
  win.MainApp.Services
    .factory('storageService',storageService);

}(window));
