(function (win) {
    "use strict";

    var dateUtilsService = function ($log) {
        $log.debug("[Liferay/Angular/dateUtilsService] Initializing...");

        function addYears(date, years) {
            return new Date(date.getFullYear() + years, date.getMonth(), date.getDate());
        }

        function checkForNext4Years(selectedDate) {
            var today = new Date();
            var todayTimestamp = today.getTime();

            selectedDate.setHours(today.getHours());
            selectedDate.setMinutes(today.getMinutes());
            selectedDate.setSeconds(today.getSeconds());
            selectedDate.setMilliseconds(today.getMilliseconds());

            var selectedDateTimestamp = selectedDate.getTime();
            var maxYear = today.getFullYear() + 4;
            var todayIn4YearsTimestamp = new Date(
                maxYear,
                today.getMonth(),
                today.getDate(),
                today.getHours(),
                today.getMinutes(),
                today.getSeconds(),
                today.getMilliseconds()
            ).getTime();

            return ((selectedDateTimestamp >= todayTimestamp) &&
                (selectedDateTimestamp <= todayIn4YearsTimestamp));
        }

        return {
            addYears: addYears,
            checkForNext4Years: checkForNext4Years
        };
    };

    dateUtilsService.$inject = [
        "$log",
        "$q",
        "$http"
    ];

    win.MainApp.Services
        .service("dateUtilsService", dateUtilsService);
}(window));
