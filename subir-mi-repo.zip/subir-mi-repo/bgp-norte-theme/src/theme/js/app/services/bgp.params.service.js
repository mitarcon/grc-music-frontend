(function(win){
  'use strict';

  /*
   * ==================== bgParamsService ====================
   */
  /**
   * Returns params of the params service
   * @param  filter        [filter to iterate catalog]
   * @param  isEmpty       [validate Empty Object]
   * @param  bgValue       [bgeneral constant Values]
   */

    function bgParamsService(filter, isEmpty, bgValue) {

      // Inicio
      var _PARAMS; //parametrers constant

      var getParamByMnemonic = function (mnemonic) {
        var list = filter(_PARAMS, function (item) {
          return item.mnemonic === mnemonic;
        });
        if (!isEmpty(list)) {
          return list[0].value;
        }
      };

      return {
        /**
         * Initialize general parameters in this context to be use to retrieve
         * a specific parameter by it's mnemonic key.
         */
        init: function(params) {
          _PARAMS = params;
        },
        getPercentageParam: function() {
          return getParamByMnemonic(
            bgValue('paramsNemonic').percentage);
        },
        getDomesticParam: function() {
          return getParamByMnemonic(
            bgValue('paramsNemonic').domestic);
        },
        getIndependentParam: function() {
          return getParamByMnemonic(
            bgValue('paramsNemonic').independent);
        },
        getLegalEntity: function() {
          return getParamByMnemonic(
            bgValue('paramsNemonic').legalEntity);
        },
        getValidityMonth: function() {
          return getParamByMnemonic(
            bgValue('paramsNemonic').validityMonth);
        },
        getValidityMonthTdc: function(){
          return getParamByMnemonic('');
        },
        getTdcParticipantQty: function() {
          return getParamByMnemonic(
            bgValue('paramsNemonic').tdcParticipantQty);
        },
        getAuParticipantQty: function() {
          return getParamByMnemonic(
            bgValue('paramsNemonic').auParticipantQty);
        },
        getRefineClientFinderSearch: function() {
          return getParamByMnemonic(
            bgValue('paramsNemonic')
          .refineClientFinderSearch);
        },
        getMinBedroomsAllowed: function() {
          return getParamByMnemonic(
            bgValue('mortgageMnemonic').minBedrooms);
        },
        getMaxBedroomsAllowed: function() {
          return getParamByMnemonic(
            bgValue('mortgageMnemonic').maxBedrooms);
        },
        getMinBathroomsAllowed: function() {
          return getParamByMnemonic(
            bgValue('mortgageMnemonic').minBathrooms);
        },
        getMaxBathroomsAllowed: function() {
          return getParamByMnemonic(
            bgValue('mortgageMnemonic').maxBathrooms);
        },
        getMinAgeToQuote: function(){
          return getParamByMnemonic(
            bgValue('paramsNemonic').minAgeToQuote);
        },
        getMinAgeToMortgageQuote : function () {
          return getParamByMnemonic(
            bgValue('mortgageMnemonic').minAge);
        },
        getMaxAgeToMortgageQuote : function () {
          return getParamByMnemonic(
            bgValue('mortgageMnemonic').maxAge);
        },
        getEstimatedDeliveryYears : function () {
          return getParamByMnemonic(
            bgValue('mortgageMnemonic').estimatedDeliveryYears);
        },
        getMaxParticipantsQuantity : function () {
          return getParamByMnemonic(
            bgValue('mortgageMnemonic').maxParticipantsQuantity);
        },
        getSizePercentage : function (){
          return getParamByMnemonic(
            bgValue('nemonic').sizeDecimalPercentage);
        },
        getSizeNumber : function (){
          return getParamByMnemonic(
            bgValue('nemonic').sizeDecimalNumber);
        },
        getManagerName : function (){
          return getParamByMnemonic(
            bgValue('paramsNemonic').managerName);
        },
        getManagerExt : function (){
          return getParamByMnemonic(
            bgValue('nemonic').managerExt);
        },
        getManagerEmail : function (){
          return getParamByMnemonic(
            bgValue('nemonic').managerEmail);
        },
        getMinAgeParam : function (){
          return getParamByMnemonic(
            bgValue('nemonic').minAgeParam);
        },
        getMaxAgeParam : function (){
          return getParamByMnemonic(
            bgValue('nemonic').maxAgeParam);
        },
        getAuLowestDeposit : function(){
          return getParamByMnemonic(
            bgValue('carMnemonic').lowestDeposit);
        },
        getClaveMask : function(){
          return getParamByMnemonic(
            bgValue('accountOpeningMnemonics').claveMask);
        },
        getDebitVisaMask : function(){
          return getParamByMnemonic(
            bgValue('accountOpeningMnemonics').debitVisaMask);
        },
        getAccountOpeningMask : function(){
          return getParamByMnemonic(
            bgValue('accountOpeningMnemonics').accountOpeningMask);
        },
        getAccountApprovalTime : function(){
          return getParamByMnemonic(
            bgValue('accountOpeningMnemonics').approvalTime);
        },
        getAccountMaxDepositAmount : function(){
          return getParamByMnemonic(
            bgValue('accountOpeningMnemonics').maxDepositAmount);
        },
        getMaxDateValidForPrintInCar : function(){
          return getParamByMnemonic(
            bgValue('carMnemonic').maxDateValidForPrint);
        },


      };

      // Fin
    }
    bgParamsService.$inject = ['filterFilter', 'isEmptyFilter',
    'bgValueFilter'];

    win.MainApp.Services
      .factory('bgParamsService', bgParamsService);

}(window));
