/* globals Liferay */

(function(win) {
  "use strict";

  var liferayServiceInvoker = function($log, $q) {

    $log.debug("[Liferay/Angular/LiferayServiceInvoker] Initializing...");

    /*
      Liferay returns a jQuery Promise. This method translates
      the jQuery to the angular $q promise
     */
    function invoke(path, data) {

      var deferred = $q.defer();

      Liferay.Service(path, data)
        .then(deferred.resolve)
        .fail(deferred.reject);

      return deferred.promise;

    }

    return {
      invoke: invoke
    };

  };

  liferayServiceInvoker.$inject = ["$log", "$q"];

  win.MainApp.Services.service("liferayServiceInvoker",
    liferayServiceInvoker);

}(window));
