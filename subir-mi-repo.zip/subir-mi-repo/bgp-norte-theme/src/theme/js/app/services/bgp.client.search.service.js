(function(win) {
  "use strict";

  var WS_PATH = "/o/api/client-search/";

  function clientSearchService(
    $log,
    routeInvoker,
    bgValue
  ){

  var clientSearch = bgValue('apps').clientSearch;

  $log.debug("[Liferay/Angular/clientSearchService] Initializing...");

  function findClients(searchClientWrapper) {
    return routeInvoker.invoke(clientSearch, 'findClients', searchClientWrapper);
  }

  function findQuotes(searchQuotesWrapper) {
    return routeInvoker.invoke(clientSearch, 'findQuotes', searchQuotesWrapper);
  }

  function findParticipantDetail(data){
    return routeInvoker.invoke(clientSearch, 'findParticipantDetail', data);
  }

  function getCustomerDetails(entityId){
    return routeInvoker.invoke(clientSearch, 'getCustomerDetails', entityId);
  }

  return {
    findClients: findClients,
    findQuotes: findQuotes,
    findParticipantDetail: findParticipantDetail,
    getCustomerDetails: getCustomerDetails
  };

  }

  clientSearchService.$inject = [
    "$log",
    "routeInvoker",
    "bgValueFilter"
  ];

  win.MainApp.Services
  .service("clientSearchService", clientSearchService);

}(window));
