(function (win) {
    "use strict";

    var stateKeeperService = function ($log) {
        $log.debug("[Liferay/Angular/stateKeeperService] Initializing...");

        function getState() {
            return window.CURRENT_STATES.pop();
        }

        function setState(state) {
            window.CURRENT_STATES.push(state);
        }

        function clear() {
            window.CURRENT_STATES = [];
        }

        return {
            get: getState,
            set: setState,
            clear: clear
        };
    };

    stateKeeperService.$inject = ["$log"];

    win.MainApp.Services
        .service("stateKeeperService", stateKeeperService);
}(window));
