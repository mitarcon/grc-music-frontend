(function(win) {
 'use strict';

 function buildClientNameService($log, isEmpty, uppercase, translateService) {


  $log.debug("build-Client-Name.Service...initializing");

  var hasEmptyMandatoryData = function(participant) {
   if (isEmpty(participant.gender.id) ||
    isEmpty(participant.civilStatus.id) ||
    isEmpty(participant.firstName)) {
    return true;
   }

   if (participant.gender.id === 'M' && !isEmpty(participant.marriedName)) {
    return ['X', 'V', 'C'].indexOf(participant.civilStatus.id) >= 0;
   }
   return false;
  };

  var getMode = function(participant) {
   if (participant.gender.id === 'F' && !isEmpty(participant.marriedName)) {
    return {
     X: 'married',
     C: 'married',
     V: 'widowed'
    }[participant.civilStatus.id];
   }
  };

  var cleanName = function(name) {
   if (isEmpty(name)) {
    return '';
   }
   return ' ' + name.trim();
  };

  return {
   getName: function(participant) {


    if (hasEmptyMandatoryData(participant)) {
     return;
    }

    var name;
    if (participant.firstName){
    	if (participant.middleName){
            name = uppercase(participant.firstName) + ' ' + uppercase(participant.middleName);
    	} else{
            name = uppercase(participant.firstName);
    	}
    }


    var mode = getMode(participant);

    if (['married', 'widowed'].indexOf(mode) >= 0) {
     if (!isEmpty(participant.lastName)) {
      name += ' ' + uppercase(participant.lastName);
     }
     name += ' ' + translateService.getValue('global.' + mode) + ' ' + uppercase(participant.marriedName);
    } else {
      name += ' ' + uppercase(participant.lastName);
      if (!isEmpty(participant.motherLastName)) {
       name += ' ' + uppercase(participant.motherLastName);
      }
    }
    return name;
   }

 };



 }

 buildClientNameService.$inject = [
  '$log',
  'isEmptyFilter',
  'uppercaseFilter',
  'translateService',
 ];

 win.MainApp.Services
  .service("buildClientNameService",
   buildClientNameService);

}(window));
