(function(win){
  'use strict';

  //Initial config
  var config = config || {};
  var defaultConfig = defaultConfig || {};

  /*
  =======
  t
  =======
  */

  function t(lang) {
    return function (input, params) {
      return lang.getText(input, params);
    };
  }
  t.$inject = ['lang'];
  win.MainApp.Filters
    .filter('t',t);

  /*
  ===========
  langService
  ===========
  */

  function lang(langProvider) {
    return {
      getText: function (key, args) {
        var text = (angular.isString(key) && key.length > 0) ?
          langProvider.getText(key) : 'MISSING-LANG-KEY';

        if (!angular.isDefined(args)) {
          return text;
        }
        return text.replace(/{(\d+)}/g, function (match, number) {
          return typeof args[number] !== 'undefined' ? args[number] : match;
        });
      },
      existsKey: function (key) {
        return angular.isDefined(config[key]) ||
          angular.isDefined(defaultConfig[key]);
      }
    };
  }
  lang.$inject =  ['langProvider'];
  win.MainApp.Services
    .service('lang',lang);

  /*
  =============
  langProvider
  =============
  */

  function langProvider() {
    return {
      getText: function (key) {
        var text = angular.isDefined(config[key]) ?
          config[key] : defaultConfig[key];

        return angular.isDefined(text) ? text : 'NOT_FOUND';
      }
    };
  }
  langProvider.$inject = [];
  win.MainApp.Services
    .service('langProvider',langProvider);

}(window));
