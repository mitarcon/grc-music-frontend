(function(win) {
  "use strict";

  var modalService = function($log, $uibModal, $rootScope) {

    $log.debug("[Liferay/Angular/ModalService] Initializing...");

    var modalInstance = {};
    var modalTitle = "Modal Title";

    var whenCancel = function() {
      return modalInstance.dismiss('cancel');
    };

    var whenOk = function() {
      return modalInstance.close();
    };

    var whenOkParam = function(param) {
      return modalInstance.close(param);
    };

    var setModalTitle = function(param) {
      this.modalTitle = param;
    };

    var getModalTitle = function() {
      return this.modalTitle;
    };

    return {
      open: function(attrs) {

        var lockScreen = angular.isDefined(attrs.bgModalLockScreen) ?
          attrs.bgModalLockScreen : false;

        var tpl = angular.isDefined(attrs.bgModalTpl) ?
          attrs.bgModalTpl : window.baseThemeURL + 'partials/bgp-modal/bgp-modal.html';

        var defaultController;
        var scope;

        if (attrs.bgModalController) {

          scope = $rootScope.$new();
          scope.modalTitle = attrs.bgModalTitle;
          scope.data = attrs.bgModalData;
          scope.okText = attrs.bgModalOkText;
          scope.cancelText = attrs.bgModalCancelText;
          scope.blocked = attrs.bgModalBlocked;
          scope.ok = whenOk;
          scope.cancel = whenCancel;
          scope.okParam = whenOkParam;

        } else {

          defaultController = ['$scope', function($modalScope) {

            $modalScope.modalTitle = attrs.bgModalTitle;
            $modalScope.message = attrs.bgModalMessage;
            $modalScope.okText = attrs.bgModalOkText;
            $modalScope.cancelText = attrs.bgModalCancelText;
            $modalScope.data = attrs.bgModalData;
            $modalScope.blocked = attrs.bgModalBlocked;
            $modalScope.method = attrs.bgModalMethod;
            $modalScope.ok = whenOk;
            $modalScope.cancel = whenCancel;
            $modalScope.okParam = whenOkParam;
            $modalScope.lockScreen = lockScreen;

          }];

        }

        modalInstance = $uibModal.open({

          animation: true,
          templateUrl: angular.isDefined(attrs.bgModalTpl) ? "/o/" + tpl : tpl,
          controller: attrs.bgModalController ? attrs.bgModalController : defaultController,
          bindToController: attrs.bgModalController ? true : false,
          scope: attrs.bgModalController ? scope : $rootScope,
          controllerAs: 'ctrl',
          backdrop: 'static',
          appendTo: attrs.bgAppendTo,
          size: attrs.bgSize,
          keyboard: !lockScreen
        });

        return modalInstance;
      },

      cancel: whenCancel,
      ok: whenOk,
      okParam: whenOkParam,
      getModalTitle: getModalTitle,
      setModalTitle: setModalTitle
    };

  };

  modalService.$inject = ['$log', '$uibModal', '$rootScope'];

  win.MainApp.Services.service('modalService', modalService);

}(window));
