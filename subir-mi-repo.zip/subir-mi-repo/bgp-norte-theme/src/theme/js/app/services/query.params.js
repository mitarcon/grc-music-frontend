(function (win) {
    "use strict";

    var queryParamsService = function ($log, $location) {
        $log.debug("[Liferay/Angular/queryParamsService] Initializing...");

        function getParam(name)  {
            var url = $location.$$absUrl;
            name = name.replace(/[\[\]]/g, "\\$&");

            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(url);

            if (!results) return null;
            if (!results[2]) return '';

            return decodeURIComponent(results[2].replace(/\+/g, " "));
        };

        function urlContains(stringToCompare){
            var url = $location.$$absUrl;
            return url.includes(stringToCompare);
        }

        return {
            get: getParam,
            urlContains: urlContains
        };
    };

    queryParamsService.$inject = [
        "$log",
        "$location"
    ];

    win.MainApp.Services
        .service("queryParamsService", queryParamsService);
}(window));
