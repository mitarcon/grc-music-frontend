/* globals MainApp */

(function (win) {

  "use strict";

  function catalogService($log, translate, routeInvoker, isEmpty, filter) {
    var data = {};
    var service = 'getCatalogs';
    var call = false;
    return {
      get: get,
      item: item,
      describe: describe,
      set: set
    };

    /**
     * Returns a catalog object given a catalog name
     */
    function get(element, project){
      if ((isEmpty(data) || isEmpty(data[project])) && !call) {
        data[project]={};
        call = true;
        routeInvoker.invoke(project, service).then(
          function(response) {
            call = false;
            data[project] = response.data;
          }, function(data) {
            /*
             * TODO: llamada de servicio de error en notificiación
             */
          });
      }
      return data[project][element];
      
    }

    function set(project, catalogs){
      data[project] = catalogs;
    }

    /**
     * Returns a catalog object given an id
     */
    function item(value, catalogName, project, defaultValue){
      var catalog = get(catalogName, project);
      defaultValue = angular.isDefined(defaultValue) ? defaultValue : '-1';
      var doFilterCatalog = function(filterBy) {
        return filter(catalog, function(element) {
          if (angular.isDefined(element.id) && angular.isDefined(filterBy)) {
            return element.id.trim() === String(filterBy).trim();
          }
        });
      };

      var results = doFilterCatalog(value);
      if (angular.isUndefined(results) || results.length === 0) {
        results = doFilterCatalog(defaultValue);
      }
      if (angular.isDefined(results) && angular.isDefined(results[0])) {
        return results[0];
      } else {
        return angular.isDefined(catalog) ? catalog[0] : [];
      }
    }

    /**
     * Returns proper description of a given id in a catalog item
     */
    function describe(value, catalogName, project, field){
      field = angular.isDefined(field) ? field : 'name';
      var aux = item(value, catalogName, project);
      if (angular.isDefined(aux) && aux.id !== '-1') {
        return aux[field];
      }
      return '';
    }

  }

  catalogService.$inject = ['$log', 'translateService', 'routeInvoker',
   'isEmptyFilter', 'filterFilter'];
  win.MainApp.Services
    .factory('catalogService', catalogService);
}(window));
