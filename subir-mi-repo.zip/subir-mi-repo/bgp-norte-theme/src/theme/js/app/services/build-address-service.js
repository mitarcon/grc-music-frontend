(function(win){
  'use strict';
  function buildLocalAddressService($log, isEmpty, uppercase, translateService) {


	  $log.debug("build-address-address-service...initializing");

     var buildLocalAddress = false;

     return {
       getAddress: function (province, district, area,
         neighborhood, street, houseNumber) {
         var address;

         if (isEmpty(province)) {
           province = '';
         } else {
           province = translateService.getValue('address.province.concat') + ' ' +
                      province.trim();
         }

         if (isEmpty(district)) {
           district = '';
         } else {
           district = translateService.getValue('address.district.concat') + ' ' +
                      district.trim();
         }

         if (isEmpty(area)) {
           area = '';
         } else {
           area = translateService.getValue('address.comma') + ' ' + area;
         }

         if (isEmpty(neighborhood)) {
           neighborhood = '';
         } else {
           neighborhood = translateService.getValue('address.comma') + ' ' + neighborhood;
         }

         if (isEmpty(street)) {
           street = '';
         } else {
           street = translateService.getValue('address.comma') + ' ' + street;
         }

         if (isEmpty(houseNumber)) {
           houseNumber = '';
         } else {
           houseNumber = translateService.getValue('address.comma') + ' ' + houseNumber;
         }

         address = province + district + area + neighborhood + street +
           houseNumber;

         return uppercase(address);
       },
       getForeignAddress: function(country, direction) {
         var foreignAddress;

         if (isEmpty(country)) {
           country = '';
         } else {
           country = country + translateService.getValue('address.comma');
         }

         if (isEmpty(direction)) {
           direction = '';
         }

         foreignAddress = country + direction;
         return uppercase(foreignAddress);
       }
     };
}

buildLocalAddressService.$inject = [
                '$log',
                'isEmptyFilter',
                'uppercaseFilter',
                'translateService',
                ];

win.MainApp.Services
  .service("buildLocalAddressService",
		  buildLocalAddressService);

}(window));
