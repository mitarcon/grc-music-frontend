(function (win) {
  /**
   * Utility Service for Contacts
   * Created by fnovoa on 04/18/2016.
   */
  'use strict';

  function wrapperEmploymentsService(commonFunctions, isEmpty, storage,
    commissionsService, $filter) {

    var getCommissions = function (empl) {
      var commissions = empl.config.records;
      if (isEmpty(commissions)) {
        return empl;
      }
      var counter = 0;
      angular.forEach(commissions.fields, function (field) {
        angular.forEach(field.commissions, function (com) {
          counter++;
          var prop = commonFunctions.getCommissionFieldName(
            counter);
          empl.socialSecurityRecord[prop] = com;
        });
      });
      empl.socialSecurityRecord.months = counter;
      empl.socialSecurityRecord.expired = empl.socialSecurityRecord.expired;
      var date = commissions.options;
      empl.socialSecurityRecord.date = new Date(date.year, date.code, 1);
      return empl;
    };

    var loadCommissions = function (actEmpl) {
      var records = actEmpl.config.records;
      var commissions = actEmpl.socialSecurityRecord || 0;
      if (!isEmpty(records) || actEmpl.type.id === 'C' ||
        isEmpty(actEmpl.socialSecurityRecord.date)) {
        return {};
      }

      var counter = 0;
      var date = new Date(actEmpl.socialSecurityRecord.date);
      var monthList = moment.localeData(navigator.language)._months;
      var dateObj = {
        code: date.getMonth(),
        value: $filter('date')(date, 'MMMM yyyy'),
        year: date.getFullYear()
      };
      records = commissionsService.get(
        dateObj, actEmpl.socialSecurityRecord.months, monthList);


      angular.forEach(records.fields, function (field) {
        var comm = field.commissions;
        for (var j = 0; j < comm.length; j++) {
          counter++;
          var prop = commonFunctions.getCommissionFieldName(counter);
          comm[j] = commissions[prop];
        }
      });
      return records;
    };

    var loadPreviousEmployments = function (actEmpl) {
      angular.forEach(actEmpl, function (item) {
        if (item.type.id === 'C' && angular.isDefined(item.tiedEmployment)) {
          angular.forEach(actEmpl, function (empl) {
            if (empl.id === item.tiedEmployment) {
              if(isEmpty(empl.config)) {
                empl.config = {};
              }
              empl.config.beforeEmployment = item;
              empl.config.isSustaining = true;
              if(isEmpty(item.config)) {
                item.config = {};
              }
            }
          });
        }
      });
    };

    return {
      setIpcwrapperEmployments: function (client) {
        var actualEmployments = [];
        var previousEmployments = [];
        var ipcWrapper = storage.getIpcWrapper({});
        angular.forEach(client.actualEmployments, function (value) {

          if (value.config.isMain) {
            value.principalWork = true;
          }
          if (value.config.isActiveJob) {
            value.selectedForQuote = true;
            if (value.config.dirty) {
              value.modified = true;
            }

            if (value.type.id === 'E') {
              actualEmployments.push(getCommissions(value));
            }
          }
          if (value.type.id === 'C' && value.tiedEmployment) {
            previousEmployments.push(value);
          }
        });
        ipcWrapper.task.person.previousEmployments = previousEmployments;
        ipcWrapper.task.person.actualEmployments = actualEmployments;
        ipcWrapper.task.person.otherIncome = client.otherIncome;
      },

      getConfigRecords: function (empl) {
        return loadCommissions(empl);
      },

      setBeforeEmpl: function (empl) {
        return loadPreviousEmployments(empl);
      },

      getSocialSecurityRecords: function (empl) {
        return getCommissions(empl);
      }

    };

  }
  wrapperEmploymentsService.$inject = ['commonFunctions',
    'isEmptyFilter',
    'storageService',
    'bgCommissionsService',
    '$filter'
  ];
  win.MainApp.Services
    .service('wrapperEmploymentsService', wrapperEmploymentsService);

}(window));



//Fin
//F
