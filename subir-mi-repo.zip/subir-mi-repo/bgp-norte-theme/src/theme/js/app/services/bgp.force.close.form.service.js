(function (win) {
  /**
   * Utility Service for Contacts
   * Created by fnovoa on 04/18/2016.
   */
  'use strict';

  function forceCloseForm() {

    var isForceClose = false;

    return {
      force: function () {
        isForceClose = true;
      },
      clean: function () {
        isForceClose = false;
      },
      get: function () {
        return isForceClose;
      }
    };

  }

  win.MainApp.Services
    .service('forceCloseFormService', forceCloseForm);

}(window));
