(function(win){
  'use strict';

  /**
   * Creates common templates
   */

   var commonTemplates = function(bgpTplRootUrl){

     return [
       {
         name: "directionLocalForm",
        //  url: tplRootUrl + 'common/bg-directions/local.html'
       url: bgpTplRootUrl('partials/bg-directions/local.html')
       }, {
         name: "directionForeignForm",
        //  url: tplRootUrl + 'common/bg-directions/foreign.html'
          url: bgpTplRootUrl('partials/bg-directions/foreign.html')
       }, {
         name: "directionForm",
        //  url: tplRootUrl + 'common/bg-directions/direction.html'
        url: bgpTplRootUrl('partials/bg-directions/direction.html')
       }, {
         name: "directionsTemplate",
        //  url: tplRootUrl + 'common/bg-directions/tpl.html'
          url: bgpTplRootUrl('partials/bg-directions/tpl.html')
       }
       // , {
       //   name: "SearchCustomer",
       //   url: tplRootUrl + 'common/bg-client-finder/searchCustomer.html'
       // }, {
       //   name: "SearchQuote",
       //   url: tplRootUrl + 'common/bg-client-finder/searchQuote.html'
       // }, {
       //   name: "StopService",
       //   url: tplRootUrl + 'common/bg-client-finder/stopService.html'
       // }, {
       //   name: "Diligence",
       //   url: tplRootUrl + 'common/bg-client-finder/digilence.html'
       // }, {
       //   name: "Mandatory",
       //   url: tplRootUrl + 'common/bg-client-finder/mandatoryDiligence.html'
       // }
     ];
   };
   commonTemplates.$inject = [
                    'BgpTplRootUrlFilter'

                      ];
   win.MainApp.Services
     .service('commonTemplates', commonTemplates);

  }(window));
