/* globals angular, Liferay */

(function (win) {
    "use strict";

    function assetsFilter() {
        return function (input, params) {
            return window.baseThemeImagesURL + input;
        };
    }

    angular
        .module(win.appName)
        .filter('assetPath', assetsFilter);

    assetsFilter.$inject = [];
}(window));
