(function (win) {
  "use strict";

  var CommissionsService = function (log) {
    log.debug("[bgCommissionsService] Initializing...");

    /**
     * Get an array for the model in commission's fields.
     */
    var getCommissionsModel = function (length) {
      var array = [];
      for (var i = 0; i < length; i++) {
        array[i] = 0;
      }
      return array;
    };

    return {
      get: function (date, monthNumber, monthList) {
        var month = date.code;
        var year = date.year;
        var quantity = monthNumber;
        var monthsOfYear = monthList;
        var firstHalf = [],
          secondHalf = [];
        var diff = month - quantity;

        if (diff >= 0) {
          firstHalf = monthsOfYear.slice(diff + 1, month + 1);
        } else {
          firstHalf = monthsOfYear.slice(0, month + 1);
          var begin = 12 - Math.abs(diff);
          secondHalf = monthsOfYear.slice(begin + 1, 12);
        }

        return {
          fields: [{
              year: year - 1,
              list: secondHalf,
              commissions: getCommissionsModel(secondHalf.length)
            },
            {
              year: year,
              list: firstHalf,
              commissions: getCommissionsModel(firstHalf.length)
            }
          ],
          options: date,
          quantity: monthNumber
        };
      }
    };


  };

  CommissionsService.$inject = ['$log'];

  win.MainApp.Services
    .service("bgCommissionsService", CommissionsService);
}(window));
