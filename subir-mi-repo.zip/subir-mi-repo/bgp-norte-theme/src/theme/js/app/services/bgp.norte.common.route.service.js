(function(win) {
	"use strict";

	var commonRouteService = function($log, serviceRoute, bgValue, routeInvoker) {

		$log.debug("[Liferay/Angular/commonRouteService] Initializing...");

    var commons =bgValue('apps').commons;

    //executeRules
		function executeRules(data){
			return  routeInvoker.invoke(commons, 'executeRules', data);
		}

    //getParameters
		function getParameters(){
			return routeInvoker.invoke(commons, 'getParameters');
		}

    //getCompanies
		function getCompanies(data){
			return routeInvoker.invokeFromCache(commons, 'getCompanies', data);
		}

		return {
			executeRules: executeRules,
      getCompanies: getCompanies,
      getParameters: getParameters
		};

	};

	commonRouteService.$inject = [ "$log", "bgpServiceRoute", "bgValueFilter",
	"routeInvoker"];

	win.MainApp.Services
  .service("commonRouteService", commonRouteService);

}(window));
