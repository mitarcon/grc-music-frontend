(function(win) {
  "use strict";

  function serviceInvoker(
    $log,
    $http
  ) {
    $log.debug("[Liferay/Angular/ServiceInvoker] Initializing...");
    var activePromises = 0;
    var isLoadingPromise = false;

    return {
      invoke: invoke,
      invokePrintDocument: invokePrintDocument,
      getIsLoadingPromise: getIsLoadingPromise,
      invokeWithoutHandle: invokeWithoutHandle
    };

    function getIsLoadingPromise() {
      return isLoadingPromise;
    }
    function invoke(method, path, data, isHandlePromise) {
      var promise = getPromise(method, path, data);
      if (typeof isHandlePromise === 'undefined') {
        return handlePromise(promise);
      }
      return promise;
    }
    function invokePrintDocument(path, data) {
      var promise = $http({
        url : path,
        method : 'POST',
        headers : {
          'Content-Type' : 'application/json'
        },
        responseType : 'arraybuffer',
        data : data
      });
      return handlePromise(promise);
    }
    function handlePromise(promise) {
      isLoadingPromise = true;
      activePromises++;
      promise.then(function() {
        activePromises--;
        isLoadingPromise = activePromises !== 0;
      }, function() {
        activePromises--;
        isLoadingPromise = activePromises !== 0;
      });
      return promise;
    }
    function invokeWithoutHandle(method, path, data){
      return getPromise(method, path, data);
    }
    function getPromise(method, path, data){
      switch (method) {
      case 'GET':
        return $http({
          method : method,
          headers : {
            'Content-type' : 'application/json'
          },
          url : path,
          params : data
        });
      case 'POST':
        return $http({
          method : method,
          headers : {
            'Content-type' : 'application/json'
          },
          url : path,
          data : data
        });
      default:
        return $http({
          method : method,
          headers : {
            'Content-type' : 'application/json'
          },
          url : path,
          data : data
        });
      }
    }
  }

  serviceInvoker.$inject = [
    '$log',
    '$http'
  ];

  win.MainApp.Services
    .service("serviceInvoker", serviceInvoker);

}(window));
