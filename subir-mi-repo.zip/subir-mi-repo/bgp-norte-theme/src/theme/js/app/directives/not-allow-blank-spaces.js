/* globals angular, appName */
(function(win) {
  "use strict";

  function notAllowBlankSpaces() {
    return {
      restrict: 'A',
      scope: {
        notAllowBlankSpaces: '='
      },
      link: function($scope, $element) {
        $element.bind('input', function() {
          $(this).val($(this).val().replace(/ /g, ''));
        });
      }
    };
  }
  angular
    .module(appName + ".directives")
    .directive('notAllowBlankSpaces', notAllowBlankSpaces);
}(window));
