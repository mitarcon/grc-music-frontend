(function (win) {
  'use strict';

  function bgPersonalData(log,
    catalogItem, dateFilter, panamaCode, isEmpty, documentType,
    clientNameRule, bgValue, translateService, alertNotifyService,
    commonFunctions, ruleService, upperCase
  ) {

    log.debug("[bgPersonalData] Initializing...");

    /*
    ===============
    VALUES
    ===============
    */

    return {
      restrict: 'E',
      scope: {
        client: '=ngModel',
        apps: '@'
      },
      require: 'ngModel',
      templateUrl: window.baseThemeURL + 'partials/bg-personal-data.html',

      link: function (scope, element, attrs) {

        scope.rulesResult = {};
        var entity = attrs.entity;
        var showDetail = scope.$eval(attrs.showDetail);
        var original = angular.copy(scope.client);
        scope.clientNameRule = clientNameRule;
        scope.panamaCode = panamaCode;
        scope.client.withProduct = scope.$eval(attrs.haveProduct);
        scope.sex1 = {
          name: 'Masculino'
        };
        scope.sex2 = {
          name: 'Femenino'
        };

        scope.personalData = {
          showDetail: showDetail
        };

        scope.calendar = {
          opened: false
        };
        scope.client.identificationType = {};

        scope.dateOptions = {
          showWeeks: false,
          startingDay: 1,
          yearColumns:4,
          yearRows:3
        };

        //  /*
        //  ===============
        //  METHODS
        //  ===============
        //  */
        //
        var buildBirthDate = function (birthDate) {
          return dateFilter(
            new Date(birthDate),
            translateService.getValue('global.date.format'));
        };


        var validateIsDefinedData = function (data) {
          if (angular.isUndefined(data)) {
            return '';
          }
          return data.id;
        };

        scope.setDefaultIdType = function () {
          var naturalPerson = scope.client;
          if (angular.isDefined(naturalPerson)) {

            if (!isEmpty(naturalPerson.documentNumber)) {
              naturalPerson.identificationType =
                catalogItem(documentType.ced,
                  bgValue('catalogItem').identiType, scope.apps, -1);
              naturalPerson.passport = undefined;

            } else {
              naturalPerson.identificationType =
                catalogItem(documentType.passport,
                  bgValue('catalogItem').identiType, scope.apps, -1);
              naturalPerson.documentNumber = undefined;
            }
          }
        };

        scope.initSelect = function (personalData) {
          log.debug('[initSelect_Iniciated]');
          personalData.nationality =
            catalogItem(angular.isDefined(personalData.nationality) ?
              personalData.nationality.id : -1,
              bgValue('catalogItem').country, scope.apps, -1);


          personalData.civilStatus =
            catalogItem(validateIsDefinedData(personalData.civilStatus),
            bgValue('catalogItem').civil, scope.apps, -1);

          scope.setDefaultIdType();

          if (personalData.gender && personalData.gender.id) {
            personalData.gender =
              catalogItem(personalData.gender.id,
                bgValue('catalogItem').sex, scope.apps, -1);
          }

          if (angular.isDefined(personalData.birthDate)) {
            personalData.birthDate = new Date(personalData.birthDate);
            scope.client.summaryBirthdate = buildBirthDate(
              personalData.birthDate);
          }
          scope._code = personalData.civilStatus.id;
          log.debug('[initSelect_Completed]');
        };
        //
        //  /**
        //   * Show married lastName in specified cases
        //   * @returns {boolean}
        //   */

        scope.validateSexAndCivilStatus = function () {
          var personalData = scope.client;
          var _code = personalData.civilStatus.id;
          var _sex;
          if (personalData.gender) {
            _sex = personalData.gender.id;
          }
          if (angular.isDefined(_code) && angular.isDefined(_sex)) {

            switch (_code.trim()) {
              case bgValue('civilStatus').married:
              case bgValue('civilStatus').widow:
              case bgValue('civilStatus').widowMarriedLastName:
                return (_sex.trim() === bgValue('genderTypes').female);
            }
          }
          return false;
        };

        scope.isPanamanian = function () {
          var naturalPerson = scope.client;
          if (angular.isDefined(naturalPerson) &&
            !isEmpty(naturalPerson.documentNumber)) {
            scope.client.identificationType =
              catalogItem(bgValue('documentTypeCodes').ced,
                bgValue('catalogItem').identiType, scope.apps);
            return true;
          }
        };

        scope.openCalendar = function () {
          scope.calendar.opened = true;
        };
        //  /**
        //   * Event to show the form of personal data and hide the summary
        //   */
        scope.edit = function () {
          scope.personalData.showDetail = false;
        };
        //
        scope.disableClientID = function () {
          return !isEmpty(scope.client.entityId) && scope.client.entityId >
            0;
        };


        //TODO @sparker - Pasar la ejecucion de reglas
        //TODO cundo reglas este en los servicios comunes

        scope.executeRules = function () {
          var rulesResult;
          if (isEmpty(scope.client.gender) || isEmpty(scope.client.civilStatus)) {
            return;
          }

          var client = commonFunctions.
          getBasicGeneralRulesRequest(scope.client);

          var xhr = ruleService.run(scope.apps, client);

          xhr.then(function (response) {

            scope.rulesResult = response.data;
            scope.client.applyToProduct = scope.rulesResult.client.applyToProduct;
            scope.client.age = scope.rulesResult.client.age;
          });

          xhr.catch(function (exception) {
            alertNotifyService.showError(
              translateService.getValue('global.error.rule'));
          });

          xhr.finally(function () {
            log.debug("---Fin rules---");
          });
        };


        scope.getMarriedLastNameRequired = function () {
          var sex;
          var status = scope.client.civilStatus.id;
          if (scope.client.gender) {
            sex = scope.client.gender.id;
          }
          return sex === bgValue('genderTypes').female &&
            (status === bgValue('civilStatus').married ||
              status === bgValue('civilStatus').widowMarriedLastName ||
              status === bgValue('civilStatus').widow);
        };



        //
        //  //TODO - @sparker
        //  //hace falta la revision de la funcionalidad del método
        //  //o el impacto que tendria cambiarlo
        //  scope.reportChanges = function() {
        //    if(original.entityId === 0){
        //      return;
        //    }
        //    var client = scope.client;
        //    if (!scope.validateSexAndCivilStatus()) {
        //      scope.client.marriedName = undefined;
        //    }
        //
        //    if (strCompare(client.firstName, original.firstName) &&
        //      strCompare(client.middleName, original.middleName) &&
        //      strCompare(client.lastName, original.lastName) &&
        //      strCompare(client.motherLastName, original.motherLastName) &&
        //      strCompare(client.marriedName, original.marriedName )) {
        //
        //      scope.personalData.changeAlert = false;
        //
        //      } else {
        //
        //      scope.personalData.changeAlert = true;
        //
        //    }
        //  };
        //
        var strCompare = function(value1, value2) {
          return upperCase(value1) === upperCase(value2) ||
            (value1 === '' && !value2);
        };

       scope.reportChanges = function() {
         if(original.entityId === 0){
           return;
         }
         var client = scope.client;
         if (!scope.validateSexAndCivilStatus()) {
           scope.client.marriedName = undefined;
         }

         if (
           strCompare(client.firstName, original.firstName) &&
           strCompare(client.middleName, original.middleName) &&
           strCompare(client.lastName, original.lastName) &&
           strCompare(client.motherLastName, original.motherLastName) &&
           strCompare(client.marriedName, original.marriedName )
         ) {
           scope.personalData.changeAlert = false;
           } else {
           scope.personalData.changeAlert = true;
         }
       };

        //  /*
        //  ===============
        //  SETUP
        //  ===============
        //  */
        //
        scope.setup = function () {
          if (!isEmpty(entity)) {
            scope.initSelect(scope.client);
          } else {
            scope.initSelect(scope.client);
            scope.personalData.showDetail = false;
          }
        };
      }
    };
  }

  /*
  ==============
  CONFIGURATION
  ==============
  */

  bgPersonalData.$inject = [
    '$log', 'catalogItemFilter', 'dateFilter', 'panamaCode','isEmptyFilter',
    'documentTypeCodes', 'clientNameRule', 'bgValueFilter', 'translateService',
    'alertNotifyService', 'commonFunctions', 'bgGeneralRuleService',
    'uppercaseFilter'
  ];

  win.MainApp.Directives
    .directive('bgPersonalData', bgPersonalData);
}(window));
