(function(win) {
'use strict';

function bgBtnCheck(
  log
){

  log.debug("[bg-btn-check] Initializing...");

  var directive = {
    restrict: 'E',
    // replace:true,
    templateUrl: window.baseThemeURL + 'partials/bg-btn-check.html',
    scope: {
      object : '=',
      element: '@',
      text: '@',
      change : '=',
      disabled: "="
    },
    link : linkFunction
  };

  return directive;

  function linkFunction (scope, element, attrs, ngModel) {
    // scope.changeElement = changeElement;
    //
    // function changeElement(){
    //   if(scope.disabled){
    //     return;
    //   }
    //   if(isEmpty(scope.object[scope.element])){
    //     scope.object[scope.element] = false;
    //   }
    //   scope.object[scope.element] = !scope.object[scope.element];
    //   if (!isEmpty(scope.change)) {
    //     scope.change();
    //   }
    //
    // }
  }

}

bgBtnCheck.$inject = [
  '$log'
];

win.MainApp.Directives
  .directive("bgBtnCheck",bgBtnCheck);

}(window));
