(function (win) {
    "use strict";

    function stepsComponent() {
        return {
            restrict: 'E',
            scope: {
                steps: '='
            },
            templateUrl: window.baseThemeURL + 'partials/steps_component.html'
        };
    }

    stepsComponent.$inject = [];

    win.MainApp.Directives
        .directive('stepsComponent', stepsComponent);
}(window));
