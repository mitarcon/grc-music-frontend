(function(win) {
  'use strict';

  function directive(
  ) {

    return {
      require: 'ngModel',
      scope: {
        max: '=?bgMaxlength'
      },
      link: linkFunction
    };

    function linkFunction (scope, element, attrs, ngModel) {
      ngModel.$parsers.unshift(function(viewValue) {

        validate(viewValue);

        return viewValue;
      });
      ngModel.$formatters.unshift(function(viewValue) {

        validate(viewValue);

        return viewValue;
      });

      scope.$watch('max', function(){

        if (scope.max - String(ngModel.$modelValue).length >= 0) {

          validate(ngModel.$modelValue);
        }

      });

      function validate(value) {

        if (String(value).length > scope.max) {

          ngModel.$setValidity('bgMaxlength', false);
        } else {

          ngModel.$setValidity('bgMaxlength', true);
        }
      }
    }

  }

  directive.$inject = [

  ];

  win.MainApp.Directives
    .directive('bgMaxlength', directive);

}(window));
