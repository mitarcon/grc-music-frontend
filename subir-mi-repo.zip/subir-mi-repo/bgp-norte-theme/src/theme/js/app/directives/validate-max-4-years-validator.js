(function(win) {
  "use strict";

  function bgDateOfTransactionValidator(dateUtilsService) {
    return {
      require: 'ngModel',
      link: function(scope, element, attrs, ngModel) {
        ngModel.$parsers.push(function(selectedDate) {
          var isValid = selectedDate !== nulll && dateUtilsService.checkForNext4Years(selectedDate);
          ngModel.$setValidity('validateMax4Years', isValid);
          return selectedDate;
        });
        element.on('blur', function() {
          if (ngModel.$modelValue !== undefined && ngModel.$modelValue.getDay() == 0) {
            ngModel.$setValidity('validateSundayDay', false);
          } else {
            ngModel.$setValidity('validateSundayDay', true);
          }
          return;
        });
      }
    };
  }
  bgDateOfTransactionValidator.$inject = ["dateUtilsService"];
  win.MainApp.Directives
    .directive('bgDateOfTransactionValidator', bgDateOfTransactionValidator);
}(window));
