/* globals angular, appName */
(function (win) {
  "use strict";

  var _isValid = function(value, comparator, notLowercase) {

    var valid = true;

    if (comparator && value && notLowercase != "true") {
      valid = (value.toLowerCase()) !== (comparator.toLowerCase());
    } else if (comparator && value) {
      valid = !angular.equals(value, comparator);
    }

    return valid;
  }

  function notEqualsValidator() {
    return {
      require : 'ngModel',
      restrict: 'A',
      link: function(scope, elements, attrs, ngModel) {

        var checkValidity = function(){
          var result = _isValid(ngModel.$viewValue, scope.$eval(attrs.notEqualsValidator), attrs.notLowercase);
          ngModel.$setValidity('notequals', result);
        }

        scope.$watch(attrs.notEqualsValidator, function(v, o) {
          checkValidity();
        });

        var v = function(viewValue) {
          checkValidity();
          return viewValue;
        };

        ngModel.$parsers.push(v);
      }
    };
  }

  notEqualsValidator.$inject = [];

  // add directive custom-server-message-validator
  angular
    .module(appName + ".directives")
      .directive('notEqualsValidator', notEqualsValidator);
}(window));
