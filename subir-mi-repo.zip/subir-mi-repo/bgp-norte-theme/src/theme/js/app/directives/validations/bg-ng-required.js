(function(win){
  'use strict';
/**
 * This directive is an override of ngRequired of angular.
 * It has the original code of angular and extended code of bGeneral
 */
  function ngRequired (isEmpty) {
    return {
      restrict: 'A',
      require: '?ngModel',
      priority: 100,
      link: function (scope, elm, attr, ctrl) {
        if (!ctrl) {
          return;
        }
        attr.required = true;

        ctrl.$validators.required = function (modelValue, viewValue) {
          /** Init: Bgeneral Custom code **/
          if (!isEmpty(viewValue) &&
            angular.isDefined(viewValue.id)) {
            return String(viewValue.id) !== '-1';
          }

          return !attr.required || !ctrl.$isEmpty(viewValue) ||
            !isEmpty(viewValue);

          /** End: Bgeneral Custom code**/

        };

        attr.$observe('required', function () {
          ctrl.$validate();
        });
      }
    };
  }
  ngRequired.$inject= ['isEmptyFilter' ];
  win.MainApp.Directives
    .directive('ngRequired',ngRequired);

}(window));
