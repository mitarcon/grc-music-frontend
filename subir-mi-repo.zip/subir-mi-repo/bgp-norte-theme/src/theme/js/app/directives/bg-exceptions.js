(function(win) {
'use strict';

  function bgExceptions ( catalog, isEmpty, filter ){

      return {
        restrict: 'E',
        transclude: true,
        scope: {
          previousVersion: '=',
          exceptions: '=ngModel',
          exceptionsSupport: '=',
          isDisabled: '=',
          app:'='
        },
        require: 'ngModel',
        templateUrl: window.baseThemeURL + 'partials/bg-exceptions.html',
        link:link
      };

      function link (scope){

        /*
        ===============
        VALUES
        ===============
        */
        scope.addExceptionTpl = true;
        scope.manualException = null;

        var automaticExceptionsCatalog = catalog('automaticExceptions',scope.app);

        /*
         ===============
         METHODS
         ===============
         */
        scope.addException = addException;
        scope.cancelAdd = cancelAdd;
        scope.deleteException = deleteException;
        scope.getDisabledStatus = getDisabledStatus;
        scope.getExceptionsDesc = getExceptionsDesc;
        scope.showTemplate = showTemplate;

        function addException(item) {
          if(isEmpty(scope.exceptions)){
            scope.exceptions = [];
          }
          scope.manualException = item;
          scope.exceptions.push({
            code: item.id,
            description: item.name,
            type: 'M',
            isNew: true
          });
          scope.addExceptionTpl = true;
        }

        function cancelAdd() {
          scope.addExceptionTpl = true;
        }

        function deleteException (index) {
          resetManualData();
          scope.addExceptionTpl = true;
          scope.exceptions.splice(index, 1);
        }

        function getDisabledStatus (item) {
          for (var index in scope.exceptions) {
            if (scope.exceptions[index].code === item.id) {
              return true;
            }
          }
        }

        function getExceptionsDesc(code) {
          for (var i in automaticExceptionsCatalog) {
            if(automaticExceptionsCatalog[i].id === code){
              return automaticExceptionsCatalog[i].name;
            }
          }
        }

        function resetManualData () {
          scope.manualException = "";
        }

        function showTemplate() {
          scope.disableBtn = true;
          scope.addExceptionTpl = !scope.addExceptionTpl;
          resetManualData();
        }
      }
  }

  bgExceptions.$inject = ['catalogFilter', 'isEmptyFilter', '$filter'];

  win.MainApp.Directives
    .directive("bgExceptions", bgExceptions);
}(window));
