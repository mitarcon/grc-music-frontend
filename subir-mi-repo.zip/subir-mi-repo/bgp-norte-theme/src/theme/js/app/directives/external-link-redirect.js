/* globals angular, appName */

(function () {
    "use strict";

    function externalLinkRedirect($rootScope, $window) {
        return {
            link: function ( scope, element ) {
                angular.element(element).bind("click", function (e) {
                    e.preventDefault();

                    $window.open($rootScope.externalLinkHref);
                    $rootScope.externalLinkHref = '/';
                    $("#externalLinkModal").modal('hide');
                });
            }
        };
    }

    angular
        .module(appName + ".directives")
        .directive('externalLinkRedirect', externalLinkRedirect);

    externalLinkRedirect.$inject = [
        '$rootScope',
        '$window'
    ];

}());
