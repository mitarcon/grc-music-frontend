(function(win) {
  "use strict";

  function bgClientSearch($log, $window, clientSearchService,
    exceptionHandlerService, alertNotifyService, NgTableParams, isEmpty,
    redirect, storage, bgValue, translateService, $filter, $timeout) {

    var ClientSearchController = function() {

      $log.debug("[Liferay/Angular/bgClientSearch] Initializing...");

      /*
       * ============== VALUES ==============
       */

      // VM
      var vm = this;

      // Loader
      vm.showLoading = false;

      // Service title
      vm.title = 'client-search-portlet-title';

      /*
       * ============== METHODS ==============
       */

      vm.cleanInputs = function() {

        vm.identification = null;
        vm.name = null;
        vm.secondName = null;
        vm.lastName = null;
        vm.secondLastName = null;
        vm.marriedLastName = null;

      };

      vm.redirectToInbox = function() {
        vm.clientsList = null;
      };

      /*
       * ============== SETUP ==============
       */

      vm.setup = function() {

      };

      vm.setup();
    };

    return {
      restrict: 'E',
      templateUrl: '/o/bgp-norte-theme/angular/partials/bgp-popup/bg-client-search-templates.html',
      controller: ClientSearchController,
      controllerAs: 'ctrl',
      bindToController: true,
      scope: {
        clientSearchAction: '@',
        addParticipantQuoteFn: '&',
        option: '=',
        addNewClientMessage: '='
      },
      link: link
    };

    function link(scope, element, attrs, vm) {

      //Inicializar variables

      // En parent se encuentran las funciones del controlador de modal
      vm.$parent = scope.$parent;

      var ipcWrapper = storage.getIpcWrapper(vm);

       vm.toLiabilityAdvice = function(newClient) {

        var task = angular.copy(storage.getIpcWrapperTask(vm));

        task.procedureId = null;

        storage.updateTask(vm, task);

        vm.showLoading = true;

        if (newClient) {

          var client = {
            entityId: 0,
          };

          setStorage(client);
          storage.updateIpcWrapper(vm, true, 'newClientFlag');

        } else {
          storage.updateIpcWrapper(vm, false, 'newClientFlag');
        }

      };

      // Se indica cual sera la modal al cargar la directiva
      if (ipcWrapper.location == bgValue('apps').clientDetails &&
        vm.clientSearchAction === bgValue('clientSearchAction').quote) {

        //TODO: Validar cuando entra en este caso
        findQuotes(ipcWrapper.task.person.entityId);
        vm.clientSearchState = bgValue('clientSearchStates').recentQuotes;

      } else if (ipcWrapper.location == bgValue('apps').clientDetails &&
        vm.clientSearchAction === bgValue('clientSearchAction').liabilityAdvice) {

        var xhr = clientSearchService.getCustomerDetails(ipcWrapper.task.person.entityId);

        xhr.then(function(response) {

          if(response.data.securityWarning) {
            vm.messageBlock = 'account.opening.warning';
            vm.clientSearchState = bgValue('clientSearchStates').block;
            return;
          }

          vm.toLiabilityAdvice(false);

          $timeout(function() {
            redirect.toLiabilityAdvice();
            vm.$parent.$close();
          }, 500);

        });
        xhr.catch(function(exception) {

          var error = exceptionHandlerService.handleError(
            exception, vm.serviceTitleKey);

          if (error) {
            alertNotifyService.showErrorNoTimeout(exception.data.name);
          }

        });

      } else {
        vm.clientSearchState = bgValue('clientSearchStates').search;
      }

      if (vm.clientSearchAction === bgValue('clientSearchAction').quote ||
        vm.clientSearchAction === bgValue('clientSearchAction').addParticipant) {

        vm.config = storage.getProductConfig();

      }

      // funciones de la directiva

      vm.cancelSearch = function() {

        if (vm.clientSearchAction !==
          bgValue('clientSearchAction').addParticipant) {

          storage.setProductConfig(null);

        }

        scope.$parent.cancel();

      };

      // control de paginator
      function tableConfig(paramsCount, settingsCount, maxBlocks, minBlocks,
        dataset) {

        var initialParams = {
          count: paramsCount // initial page size
        };

        var initialSettings = {
          // page size buttons (right set of buttons in demo)
          counts: settingsCount,
          // determines the pager buttons (left set of buttons in demo)
          paginationMaxBlocks: maxBlocks,
          paginationMinBlocks: minBlocks,
          dataset: dataset
        };

        return new NgTableParams(initialParams, initialSettings);

      }

      vm.findClients = function() {
        storage.updateIpcWrapper(vm, false, 'newClientFlag');

        vm.showLoading = true;

        uppercaseFilter();

        var searchClientWrapper = {
          filter: {
            searchBy: vm.searchBy.id,
            identification: vm.identification,
            name: vm.name,
            secondName: vm.secondName,
            lastName: vm.lastName,
            secondLastName: vm.secondLastName,
            marriedLastName: vm.marriedLastName
          }
        };

        var xhr = clientSearchService.findClients(searchClientWrapper);
        xhr.then(function(response) {
          vm.clientsList = response.data;
          if (vm.clientsList.length === 1) {
            vm.showLoading = true;
            setStorage(vm.clientsList[0]);
            if (vm.clientSearchAction === bgValue('clientSearchAction').details) {
              // TODO: Buscar forma para hacer que el storage se actualice
              // antes de la redirección
              scope.$parent.ok();

              $timeout(function() {
                redirect.toClient();
              }, 500);

            }
          }
          vm.clientsTable = tableConfig(6, null, 7, 1, vm.clientsList);
        });
        xhr.catch(function(exception) {
          var error = exceptionHandlerService.handleError(
            exception, vm.serviceTitleKey);
          if (error) {
            alertNotifyService.showErrorNoTimeout(exception.data.name);
          }
        });
        xhr.finally(function() {
          vm.showLoading = false;
        });
      };

      function findQuotes(entityId) {
        vm.showLoading = true;
        uppercaseFilter();
        var searchQuotesWrapper = {
          // client: true,
          filter: {
            entityId: entityId
          },
          productId: storage.getProductConfig().ruleOperation
        };

        var xhr = clientSearchService.findQuotes(searchQuotesWrapper);
        xhr.then(function(response) {

          vm.clientBasicData = response.data;

          vm.completeName = vm.clientBasicData.client.completeName;
          var quotes = vm.clientBasicData.quotes;

          var dateMod = $filter('bgDate')([new Date(
            vm.clientBasicData.lastModificationDate)]);

          vm.noModSince = isEmpty(dateMod) ?
            translateService.getValue('global.zeroDays') : dateMod;

          if (vm.clientBasicData.security ===
            bgValue('clientSearchStates').block) {
            vm.messageBlock = 'pantallazo.message';
            vm.clientSearchState = bgValue('clientSearchStates').block;
          } else if (quotes.length > 0) {
            vm.quotesLimit = 3;
            if (quotes.length > vm.quotesLimit) {
              vm.moreQuotes = quotes.length - vm.quotesLimit;
            }
            vm.clientSearchState = bgValue('clientSearchStates').recentQuotes;
          } else {
            needRevision();
          }

        });
        xhr.catch(function(exception) {

          var error = exceptionHandlerService.handleError(
            exception, vm.serviceTitleKey);

          if (error) {
            alertNotifyService.showErrorNoTimeout(exception.data.name);
          }

        });
        xhr.finally(function() {
          vm.showLoading = false;
        });

      }

      vm.makeNewQuote = function() {
        needRevision();
      };

      function needRevision() {
        if (!vm.clientBasicData.needRevision) {
          vm.clientSearchState = bgValue('clientSearchStates').noReview;
        } else if (vm.clientBasicData.needRevision) {
          vm.clientSearchState = bgValue('clientSearchStates').review;
        }
      }

      vm.selectClient = function(client) {

        vm.showLoading = true;
        switch (vm.clientSearchAction) {
          case bgValue('clientSearchAction').details:
            setStorage(client);
            scope.$parent.ok();
            $timeout(function() {
              redirect.toClient();
            }, 500);
            break;
          case bgValue('clientSearchAction').quote:
            setStorage(client);
            findQuotes(client.entityId);
            break;
          case bgValue('clientSearchAction').addParticipant:
            setStorage(client);
            searchParticipantDetail(client);
            break;
          case bgValue('clientSearchAction').liabilityAdvice:

          var xhr = clientSearchService.getCustomerDetails(client.entityId);

          xhr.then(function(response) {

            if(response.data.securityWarning) {
              vm.messageBlock = 'account.opening.warning';
              vm.clientSearchState = bgValue('clientSearchStates').block;
              return;
            }

            setStorage(client);

            vm.toLiabilityAdvice(false);

            $timeout(function() {

              vm.cancelSearch();
              redirect.toLiabilityAdvice();

            }, 500);

          });
          xhr.catch(function(exception) {

            var error = exceptionHandlerService.handleError(
              exception, vm.serviceTitleKey);

            if (error) {
              alertNotifyService.showErrorNoTimeout(exception.data.name);
            }

          });

            break;
          default:

        }

      };

      vm.selectQuote = function(index) {
        vm.showLoading = true;
        var selectedQuote = vm.clientBasicData.quotes[index];
        storage.updateProductId(vm, selectedQuote.id);
        storage.updatePerson(vm, vm.clientBasicData.client);
        scope.$parent.ok();
        redirect.toQuote();
      };

      vm.showMoreQuotes = function() {
        var ipcWrapper = storage.getIpcWrapper(vm);
        if (ipcWrapper.location == bgValue('apps').clientDetails) {
          vm.$parent.data.initTracing();
        }
        vm.$parent.ok();
      };

      vm.clickDontRevision = function() {

        if (vm.clientSearchAction ===
          bgValue('clientSearchAction').addParticipant) {
          if (!isEmpty(vm.addParticipantQuoteFn) &&
            angular.isFunction(vm.addParticipantQuoteFn)) {
            var operation = {
              callbackFn: scope.$parent.ok,
              args: undefined
            };
            vm.addParticipantQuoteFn()(vm.clientBasicData, operation);
          }
        }

        if (vm.clientSearchAction ===
          bgValue('clientSearchAction').quote) {
          vm.showLoading = true;
          scope.$parent.ok();
          redirect.toPreQuote();
        }


      };

      vm.addNewClient = function(newClient) {

        if (vm.searchBy.id != bgValue('searchByValues').name) {
          if (vm.clientSearchAction ===
            bgValue('clientSearchAction').liabilityAdvice) {

            vm.toLiabilityAdvice(newClient);

            $timeout(function() {
              vm.cancelSearch();
              redirect.toLiabilityAdvice();
            }, 500);

          } else {
            vm.toWizard(newClient);
          }
        }

      };

      vm.toWizard = function(newClient) {
        vm.showLoading = true;
        if (newClient) {
          var client = {
            entityId: 0,
          };
          setStorage(client);
          storage.updateIpcWrapper(vm, true, 'newClientFlag');
        } else {
          storage.updateIpcWrapper(vm, false, 'newClientFlag');
        }

        storage.updateIpcWrapper(vm, true, 'wizardFlag');

        if (vm.clientSearchAction ===
          bgValue('clientSearchAction').addParticipant) {
          storage.updateIpcWrapper(vm, false, 'isPrincipalParticipant');
          storage.updateProductConfigRedirectTo(vm, 'quote');
          storage.updateProductConfigPropertyActiveTab(
            vm, bgValue('standardQuoteTabs').clients);

          redirect.toWizard();
        }

        if (vm.clientSearchAction ===
          bgValue('clientSearchAction').quote) {
          storage.updateProductConfigRedirectTo(vm, 'pre-quote');
          scope.$parent.ok();
          redirect.toWizard();
        }

      };

      function setStorage(client) {

        var person = {
          entityId: client.entityId,
          apcData: {
            apcTemporaryFlag: false
          }
        };

        var documentType = null;

        if (vm.searchBy.id === bgValue('searchByValues').identification) {
          person.formattedIdentification = vm.identification;
          person.documentNumber = vm.identification;
          documentType = bgValue('documentTypeCodes').ced;
        } else if (vm.searchBy.id === bgValue('searchByValues').passport) {
          person.passport = vm.identification;
          documentType = bgValue('documentTypeCodes').passport;
        } else {
          documentType = client.documentType;
          if (documentType === bgValue('documentTypeCodes').ced) {
            person.formattedIdentification = client.formattedDocumentNumber;
            person.documentNumber = client.documentNumber;
          } else if (documentType === bgValue('documentTypeCodes').passport) {
            person.passport = client.documentNumber;
          }
        }

        person.documentType = documentType;
        // Agregar atributos cuando es agregar un participante
        // adicional de cotizacion
        if (vm.clientSearchAction ===
          bgValue('clientSearchAction').addParticipant && vm.option) {
          person.participantType = vm.option.participantType;
          person.relationshipWithPrincipal =
            vm.option.relationshipWithPrincipal;
        }

        storage.updatePerson(vm, person);
      }

      function uppercaseFilter() {
        if (!isEmpty(vm.identification)) {
          vm.identification = vm.identification.toUpperCase();
        }
        if (!isEmpty(vm.name)) {
          vm.name = vm.name.toUpperCase();
        }
        if (!isEmpty(vm.secondName)) {
          vm.secondName = vm.secondName.toUpperCase();
        }
        if (!isEmpty(vm.lastName)) {
          vm.lastName = vm.lastName.toUpperCase();
        }
        if (!isEmpty(vm.secondLastName)) {
          vm.secondLastName = vm.secondLastName.toUpperCase();
        }
        if (!isEmpty(vm.marriedLastName)) {
          vm.marriedLastName = vm.marriedLastName.toUpperCase();
        }
      }

      function searchParticipantDetail(client) {

        // Validamos que el nuevo cliente no existe en la cotizacion
        if (existInQuote(client.entityId)) {
          alertNotifyService.showWarningT('client.error.message.duplicate');
          vm.$parent.$close();
          return;
        }

        // Buscamos la información del participante
        vm.showLoading = true;
        var xhr = clientSearchService
          .findParticipantDetail(createWrapperParticipantDetail(client.entityId));

        xhr.then(function(response) {
          vm.clientBasicData = response.data;

          vm.completeName = vm.clientBasicData.completeName;

          // Validamos que particiante no tenga pantallazo
          if (!isEmpty(vm.clientBasicData.alert) && vm.clientBasicData.alert === true) {
            vm.messageBlock = 'pantallazo.message.additional';
            vm.clientSearchState = bgValue('clientSearchStates').block;
            return;
          }

          var dateMod = $filter('bgDate')([new Date(
            vm.clientBasicData.lastModificationDate)]);

          vm.noModSince = isEmpty(dateMod) ?
            translateService.getValue('global.zeroDays') : dateMod;
          // Se determina si es revision obligatoria
          if (!isEmpty(vm.clientBasicData.needRevision) &&
            vm.clientBasicData.needRevision === true) {
            // TODO: Debo llamar a la modal de revsion obligatoria
            vm.clientSearchState = bgValue('clientSearchStates').review;
            return;
          } else {
            // TODO: Debo llamar a la modal de revsion opcional
            vm.clientSearchState = bgValue('clientSearchStates').noReview;
          }
        });
        xhr.catch(function(exception) {
          var error = exceptionHandlerService.handleError(
            exception, vm.serviceTitleKey);
          if (error) {
            alertNotifyService.showErrorNoTimeout(exception.data.name);
          }
        });
        xhr.finally(function() {
          vm.showLoading = false;
        });
      }

      function existInQuote(entityId) {
        if (!isEmpty(vm.option)) {
          if (vm.option.principal.entityId === entityId) {
            // Es el principal
            return true;
          } else {
            for (var i = 0; i < vm.option.aditionals.length; i++) {
              if (vm.option.aditionals[i].entityId === entityId) {
                // Es un adicional
                return true;
              }
            }
          }
        }
        return false;
      }

      function createWrapperParticipantDetail(entityId) {
        return {
          apcFilter: {
            quoteCode: vm.option.quote.id,
            customerId: entityId,
            addHouseRentalObligation: false
          },
          editedProductPerson: {
            participantType: vm.option.participantType,
            relationshipWithPrincipal: vm.option.relationshipWithPrincipal
          },
          productType: {
            id: vm.config.ruleOperation
          },
          wizardFlag: false,
          customerDataUpdated: false,
        };
      }
    }
  }

  bgClientSearch.$inject = [
    "$log",
    "$window",
    "clientSearchService",
    "exceptionHandlerService",
    "alertNotifyService",
    "NgTableParams",
    "isEmptyFilter",
    "bgRedirectService",
    "storageService",
    "bgValueFilter",
    "translateService",
    "$filter",
    "$timeout"
  ];

  win.MainApp.Directives
    .directive('bgClientSearch', bgClientSearch);

}(window));
