(function(win) {
  "use strict";

  var FormErrorNotifyDirective = function(alertNotifyService) {
    return {
      restrict: 'A',
      require: '^form',
      link: function(scope, element, attrs, controller) {

        scope.$watch(function() {

          return controller.$invalid && controller.$submitted;

        }, function(showError) {

          if (showError) {

            alertNotifyService.showErrorT(attrs.formErrorNotifyText ?
              attrs.formErrorNotifyText : 'common-form-error-message',
              'form-error-notify');

          } else {
            alertNotifyService.close('form-error-notify');
          }

        });
      }
    };
  };

  FormErrorNotifyDirective.$inject = ['alertNotifyService'];

  win.MainApp.Directives.directive('formErrorNotify', FormErrorNotifyDirective);

}(window));
