(function (win) {
  "use strict";

  function bgPreventEnter() {
      return {
          link: function (scope, el, attrs) {
            el.bind('keydown', function (event) {
              if (13 == event.which) {
                  event.preventDefault();
              }
            });
          }
      };
  }

  angular
      .module(appName + ".directives")
      .directive('bgPreventEnter', bgPreventEnter);

      bgPreventEnter.$inject = [];
}(window));