(function(win){
  'use strict';
  function bgEmployment(
    log, commonFunctions, commonRouteService,
    bgDateFilter, jobModel, isEmpty,
    ruleService, filter, bgEstimatedDate,
    catalogService, retiredPositionCode, forceValidation,
    translateService, bgValue, routeInvoker,
    alertNotifyService, wrapperEmploymentsService
      ){

      log.debug('[bgEmployment] Initializing...');
      /*
      ===========
      VALUES
      ===========
      */
      return{
        restrict: 'E',
        scope: {
          employment: '=ngModel',
          employments: '=employments',
          auxFunction: '&?',
          cancelFunction: '&?',
          withNotWork: '@?',
          index: '@',
          rules: '=',
          percentage: '@',
          domesticParameter: '@',
          disabled: '=',
          client: '=',
          checkToContinue: '&?',
          pendingAddForms: '=?',
          app: '@',
          haveProduct: '='
        },
        templateUrl: window.baseThemeURL +
                         'partials/bg-employment/bg-employment.html',
        link: function(scope){
          var firstLoad = true;
          var firstFocus = true;
          var firstChange = true;
          var yearCopy;
          var monthCopy;
          var startDayCopy;
          var employmentCopy = {};
          var independentType;
          var unemployedType = {
            'id': 'C',
            'name': translateService.getValue('global.unemployed')
          };

          scope.comply = false;

          var defaultConfig = {
            vinculateJob: undefined,
            isSustaining: false,
            isActiveJob: false,
            toReactive: false,
            isToCreate: true,
            toDelete: false,
            isOpen: false,
            isMain: false,
            isNew: false,
            records: {}
          };

          //TODO - @Sparker
          // Realizar ajuste para fechas del lado de arquitectura
          // evitando la modificacion de (n) cantidad de archivos.
          // Actualmente solucion con las horas de las fechas solamente
          // implementada para el caso de sustentacion de empleos en el
          // wizard.

          /*
          ========
          METHODS
          ========
          */

          /**
          * Change string date from employment to js date object
          */
          var changeToDate = function (emp) {
            if (emp.startDate) {
              emp.startDate =
                new Date(emp.startDate);
                emp.startDate.setHours(0);
            }
          };

          /**
           * Find higher employment code
           */
          var higherEmploymentCode = function () {
            var higher = 0;
            angular.forEach(scope.employments, function (item) {
              var cod = parseInt(item.id);
              higher = cod > higher ? cod : higher;
            });
            return higher + 1;
          };

          /**
           * Get proper higher code for employment id
           */
          var nextConsecutive = function () {
            if (scope.employment.config && !scope.employment.config.isNew &&
              scope.employment.id) {
              return scope.employment.id;
            }
            return higherEmploymentCode();
          };

          var initParams = function () {
            scope.employment.sequence = nextConsecutive();
            scope.rule = '';
            scope.from = true;
            scope.until = false;
            scope.haveData = false;
            scope.stabilityStatus = "";
            scope.calendar = {opened: false};
            scope.calendarFrom = {opened: false};
            scope.calendarUntil = {opened: false};
            scope.baseTemplate = window.baseThemeURL+'partials/bg-employment/';

            scope.cboYears = commonFunctions
              .generateSequentialArray(0, 60, 'global.year');

            scope.cboMonths = commonFunctions
              .generateSequentialArray(0, 11, 'global.month');

            scope.dateAgo = {
              month: '0',
              year: '0'
            };

            scope.employmentsLength = scope.employments.length;

            scope.haveActiveJobs =
              filter(scope.employments, function (item) {
                return item.type.id === 'E';
              }).length > 0;

            changeToDate(scope.employment);

            if(scope.employment.startDate){
              var diff =
                moment.preciseDiff(scope.employment.startDate, new Date(),
                true);
                scope.dateAgo.year = diff.years.toString();
                scope.dateAgo.month = diff.months.toString();
            }

            if (isEmpty(scope.newClient)) {
              scope.newClient = false;
            }
          };

          var setFormattedCompany = function(employment, company){
            employment.company = {
              id: String(company.id),
              name: company.name.toUpperCase(),
              companyType: {
                id: company.companyType.id,
                name: company.companyType.name,
              }
            };
            if(company.classification &&
              employment.company.companyType.id !== 'JU') {
              employment.riskClasification  = {
                id: company.classification.id,
                name: company.classification.name
              };
            }
          };

          var displayContinuityAlert = function(){
            if (isEmpty(scope.employment.config.beforeEmployment)){
              scope.continuityAlert = true;
              return;
            }
            scope.continuityAlert = false;
          };

          scope.isDomestic = function(employmentCode) {
            if (!isEmpty(employmentCode) && !isEmpty(scope.domesticParameter)) {
              if(scope.domesticParameter === employmentCode){
                scope.employment.jobTitle.id = bgValue('getdefaultDomesticEmployeeCode');
                return true;
              }
            }
            return false;
          };

          scope.copyMonthsNYears = function (focus) {
            if (firstFocus && focus) {
              startDayCopy = angular.copy(scope.employment.startDate);
              firstFocus = false;
            }
            if (firstChange) {
              yearCopy = angular.copy(scope.dateAgo.year);
              monthCopy = angular.copy(scope.dateAgo.month);
              firstChange = false;
            }
          };

          var resetMonthsNYears = function(){
            scope.from = !(scope.from);
            scope.until = !(scope.until);
            scope.employment.startDate = employmentCopy.startDate;
            startDayCopy = employmentCopy.startDate;
            scope.dateAgo.month = monthCopy;
            scope.dateAgo.year = yearCopy;
          };

          scope.fromUntil = function () {
            if (scope.disabled) {
              return;
            }
            scope.from = !(scope.from);
            scope.until = !(scope.until);
            scope.copyMonthsNYears();
            if(scope.until){
              startDayCopy = angular.copy(scope.employment.startDate);
              var date = bgEstimatedDate(
                [scope.dateAgo.year, scope.dateAgo.month,
                  startDayCopy],'MM/DD/YYYY');
              scope.employment.startDate = new Date(date);
              scope.incomeChangeDate(date);
            }else{
              scope.employment.startDate = startDayCopy;
              scope.reloadRules();
            }
          };

          scope.closeMe = function (form) {
            //update outter object
            scope.pendingAddForms.employments = scope.employment.config.isNew ?
              false : scope.pendingAddForms.employments;

            if(angular.isDefined(scope.cancelFunction)) {
              scope.$eval(scope.cancelFunction)();
            }
            else if (!scope.employment.config.isNew) {
              if (scope.index) {
                employmentCopy.config.isMain = scope.employment.config.isMain;

                employmentCopy.config.isActiveJob =
                  scope.employment.config.isActiveJob;

                if (!employmentCopy.config.beforeEmployment) {
                  scope.employment.config.isSustaining = false;
                  scope.employment.config.beforeEmployment = undefined;
                }

                if (form.$dirty) {
                  commonFunctions.updateObject(employmentCopy,
                    scope.employment);
                  resetMonthsNYears();
                  scope.fromUntil();
                  form.$setPristine();
                }
                if (scope.employment.difference) {
                   scope.reloadRules();
                }
              }
              scope.employment.config.isOpen = false;
              firstFocus = true;
              firstChange = true;
            } else {
              scope.employment.config.toDelete = true;
            }
          };

          var updatePendingAddForms = function () {
            if (isEmpty(scope.employment.company.companyType.id)) {
              scope.pendingAddForms.employments = true;
            } else {
              scope.pendingAddForms.employments =
                scope.employment.config.isNew ? false :
                scope.pendingAddForms.employments;
            }
          };

          scope.addMe = function (formState) {
            //update outter object
            updatePendingAddForms();

            var beforeEmp = scope.employment.config.beforeEmployment;
            var alreadyHas;

            if (beforeEmp) {
              alreadyHas = filter(scope.employments, function(item) {
                // Actualizar los valores del empleo que sustenta
                if(item.type.id === 'C' && item.id === beforeEmp.id){
                  item.config.dirty = true;
                  item.modified = true;
                  item.startDate = beforeEmp.startDate;
                  item.endDate = beforeEmp.endDate;
                  return true;
                }
              }).length > 0;
              if(!alreadyHas){
                scope.employments.push(beforeEmp);
              }
            }

            if (!isEmpty(formState) && formState.$dirty) {
              scope.employment.config.dirty = true;
              monthCopy = scope.dateAgo.month;
              yearCopy = scope.dateAgo.year;
              startDayCopy = scope.employment.startDate;
              if (alreadyHas) {
                beforeEmp.config.dirty = true;
              }
            }

            if (scope.employment.id === 0 || isEmpty(scope.employment.id)){
              scope.employment.id = nextConsecutive();
            }
            if(angular.isDefined(scope.auxFunction)) {
              scope.$eval(scope.auxFunction)(scope.employment);
            }else{
              scope.employment.config.isOpen = false;
              if (scope.employment.hasDifference) {
                scope.employment.hasDifference = false;
                scope.employment.config.dirty = true;
              }
            }
            employmentCopy = angular.copy(scope.employment);
            //convert config.records to socialSecurityRecord
            scope.employment = wrapperEmploymentsService.
              getSocialSecurityRecords(scope.employment);
          };


          scope.resetToDefaults = function() {
            scope.employment.jobTitle = catalogService.item(
              scope.employment.company.companyType.id === 'JU' ?
              retiredPositionCode : '', 'charge', scope.app);
            if (isEmpty(scope.employment.company.companyType.id)) {
              scope.pendingAddForms.employments = false;
              scope.employment.company.name = '';
              return;
            }

            var companyType = catalogService.item(
              scope.employment.company.companyType.id,
                'sourceOfIncomes', scope.app);

            if (scope.employment.company.companyType.id === 'IN' &&
              !isEmpty(independentType)) {
              scope.employment.company.companyType.id =
                companyType.id;
              scope.employment.company.name = companyType.name;
              scope.employment.company.id = independentType[0].id;
              scope.employment.company.companyType.name =
                companyType.name;
              return;
            }
            scope.employment.company = {
              name: '',
              companyType: {
                id: companyType.id,
                name: companyType.name
              }
            };
          };

          scope.commissionsDisabled = function () {
            scope.employment.config.commissionsDisabled =
              !isEmpty(scope.employment.config.records);
          };

          scope.updateCommissions = function (records) {
            // Colocar atributo dirty al campo de comisiones.
            scope.innerForm.commissions.$setDirty();
            scope.employment.config.records = records;
            scope.employment.commissions = records.totalCommissions;
            scope.employment.config.commissionsDisabled = records.disabled;
            scope.commissionRecords.records = records;
            scope.reloadRules();
          };

          scope.showIf = function (options) {
            return options.indexOf(
              scope.employment.company.companyType.id) >= 0;
          };

          scope.cleanValue = function () {
            scope.employment.employmentSupportData.lastAmount = undefined;
            scope.employment.employmentSupportData.penultimateAmount =
              undefined;

            if (!firstLoad) {
              scope.employment.baseSalary = undefined;
              scope.employment.totalSalary = undefined;
            }
            firstLoad = false;
          /** Se comenta debido a IN:1228
           * Los campos de ultimo y penultimo año dejan de ser visibles
           *
            var reportType = scope.employment.employmentSupportData.supportType;
            scope.employment.employmentSupportData.penultimateYear =
              undefined;
            scope.employment.employmentSupportData.lastYear = undefined;
            scope.employment.yValid = true;
            if (scope.innerForm.independentIncomes && scope.employment.yValid) {
              forceValidation.clean(
                scope.innerForm.independentIncomes,
                'lastYear-' + reportType, 'bgYearValid');
            } else if (scope.innerForm.independentIncomes) {
              forceValidation.run(
                scope.innerForm.independentIncomes,
                'lastYear-' + reportType, 'bgYearValid');
          }*/
          };

          scope.reportType = function (type) {
            return scope.employment.employmentSupportData.supportType === type;
          };

          scope.receiveDataModal = function(input){
            setFormattedCompany(input.employment, input.empCompany);
            scope.reloadRules();
          };

          scope.openCalendar = function () {
            scope.calendar.opened = true;
          };

          scope.openCalendarFrom = function () {
            scope.calendarFrom.opened = true;
          };

          scope.openCalendarUntil = function () {
            scope.calendarUntil.opened = true;
          };

          var setBeforeEmploymentDates = function (befEmpl) {
            if (isEmpty(befEmpl)) {
              befEmpl = scope.employment.config.beforeEmployment;
            }
            if (isEmpty(befEmpl)) {
              return;
            }
            befEmpl.startDate = !isEmpty(befEmpl.startDate) ?
              new Date(befEmpl.startDate) : undefined;
            befEmpl.endDate = !isEmpty(befEmpl.endDate) ?
              new Date(befEmpl.endDate) : undefined;
          };

          var setBeforeEmploymentCode = function(){
            if(scope.employment.config.beforeEmployment.id){
              return;
            }
            if(scope.employment.config.isNew){
              scope.employment.config.beforeEmployment.id =
                scope.employment.id + 1;
            }else{
              scope.employment.config.beforeEmployment.id =
              higherEmploymentCode();
            }
            scope.employment.config.beforeEmployment.sequence =
              scope.employment.config.beforeEmployment.id;
          };

          scope.receiveBeforeEmployment = function (befEmpl) {
            scope.employment.id = nextConsecutive();
            if (angular.isDefined(befEmpl.empCompany)) {
              var fullEmpl = angular.copy(jobModel);
              setFormattedCompany(fullEmpl, befEmpl.empCompany);

              fullEmpl.type = unemployedType;
              fullEmpl.tiedEmployment = scope.employment.id;
              fullEmpl.config = defaultConfig;
              scope.employment.config.beforeEmployment = fullEmpl;
            } else {
              befEmpl.tiedEmployment = scope.employment.id;
              setBeforeEmploymentDates(befEmpl);
              scope.employment.config.beforeEmployment = befEmpl;
            }
            setBeforeEmploymentCode();
            scope.reloadRulesBeforeEmpl();
            displayContinuityAlert();
          };

          scope.evaluateBeforeEmployment = function(){
            if (scope.disabled) {
              return;
            }
            if (!scope.employment.config.isSustaining){
              resetBeforeEmployment();
            }
            displayContinuityAlert();
          };


          var setup = function () {
            initParams();
            displayContinuityAlert();
            routeInvoker.invokeFromCache(scope.app, 'getCompanies',
              {typeCompany: 'JU', companyName: ' '})
              .then(function (response) {
                scope.retiredType = response.data;
              }, function (data) {
                alertNotifyService.showError(data);
              });
            routeInvoker.invokeFromCache(scope.app, 'getCompanies',
              {typeCompany: 'IN', companyName: ' '})
              .then(function (response) {
                independentType = response.data;
              }, function (data) {
                alertNotifyService.showError(data);
              });
              if(scope.employment.company.companyType.id === 'IN'){
                var defaultSupportType = isEmpty(
                  scope.employment.employmentSupportData.supportType);
                  if(defaultSupportType){
                    scope.employment.employmentSupportData.supportType = 'R';
                  }
              }
            scope.commissionsDisabled();
            setBeforeEmploymentDates();
            if (!isEmpty(scope.employment.config.beforeEmployment)) {
              scope.employment.config.beforeEmployment.tiedEmployment =
                scope.employment.id;
            }
            employmentCopy = angular.copy(scope.employment);
            scope.updatecommissionRecords();
          };
          scope.updatecommissionRecords = function(){
            scope.commissionRecords = {
              records: scope.employment.config.records,
              baseSalary: scope.employment.baseSalary,
              percentage: scope.percentage,
              representation:scope.employment.representationExpensesAmount
            };
            scope.average();
          };
          /**
           * Funcion de calculo de comisionnes de bg-popup-commission-controller.js
           */
          scope.average = function() {
            var commissions = 0;
            if(!isEmpty(scope.commissionRecords) && !isEmpty(scope.commissionRecords.records) && 
                !isEmpty(scope.commissionRecords.records.fields)) {
              angular.forEach(scope.commissionRecords.records.fields, function(field) {
                angular.forEach(field.commissions, function(commission) {
                  commissions += isNaN(parseFloat(commission)) ?
                    0 : parseFloat(commission);
                    if (commissions !== 0){firstLoad = false;}
                });
              });
              
              if(isEmpty(scope.commissionRecords.representation)){
                scope.commissionRecords.representation = 0;
              }
              
              if(commissions !== 0){
                commissions =
                  ((commissions / scope.commissionRecords.records.quantity) -
                  scope.commissionRecords.baseSalary - scope.commissionRecords.representation) *
                          scope.commissionRecords.percentage;
              }
              scope.employment.commissions = commissions;
            }
          };
          
          scope.showStringStability = function (dateArray) {
            return angular.isDefined(dateArray[0]) &&
                  (angular.isDefined(dateArray[1]) ||
                   angular.isDefined(dateArray[2]));
          };
          scope.continuityBetweenJobs = function (dateArray, mode,employment) {
            var continuity;
            if (mode) {
              var date = bgEstimatedDate(
                  [dateArray[1], dateArray[2]],'MM/DD/YYYY');
              continuity = bgDateFilter(
                  [dateArray[0],new Date(date)],'YMD');
            } else {
              continuity = bgDateFilter(
                  [dateArray[0],dateArray[1]],'YMD');
            }

            employment.timeBetweenJobs = isEmpty(continuity) ? '' :continuity;

            return isEmpty(continuity) ? '' :
              translateService.getValue('job.continuityBetweenJobs', [continuity]);
          };

          scope.dateOptions = {
              showWeeks: false,
              startingDay: 1,
              yearColumns:4,
              yearRows:3
          };


          var getEmployment = function () {
            var bef = scope.employment.config.beforeEmployment;

            if (angular.isDefined(bef) && !isEmpty(bef.company) &&
              !isEmpty(bef.startDate) && !isEmpty(bef.endDate)) {
              return [scope.employment,
                scope.employment.config.beforeEmployment];
            }
            return scope.employment;
          };

          scope.reloadRulesBeforeEmpl = function () {
            if (scope.disabled) {
              return;
            }
            if (isEmpty(scope.employment.config.beforeEmployment) ||
            isEmpty(scope.employment.startDate)) {
              return;
            }
            var employment = scope.employment.config.beforeEmployment;
            if (isEmpty(employment.startDate) ||
                isEmpty(employment.endDate)) {
                return;
            }
            scope.reloadRules();
            scope.compliesWithContinuedEmployment();
          };

          //
          // /**
          //  * Update respective client employment with rules response.
          //  * It's necesary to keep object reference between scopes.
          //  */
          var updateEmploymentData = function (rulesEmployment, config) {
            rulesEmployment.config = config;
            changeToDate(rulesEmployment);
            commonFunctions.updateObject(rulesEmployment, scope.employment);
          };

          scope.compliesWithContinuedEmployment = function() {
            return scope.employment.compliesWithContinuedEmployment;
          };

          /**
           * Reload client data merged with rules result.
           * Validates company type before getting rules.
           */
          scope.reloadRules = function() {
            if (isEmpty(scope.employment.company.id)) {
              return;
            }
            var client = commonFunctions.
              getBasicGeneralRulesRequest(scope.client);
            var promise = ruleService.run(scope.app, client, getEmployment());

            promise.then(function (response) {
              var previousConfig = angular.copy(scope.employment.config);
              var rulesEmp = filter(response.data.client.actualEmployments,
                {type:{id:'E'}}, true)[0];
              updateEmploymentData(rulesEmp, previousConfig);
            });
            return promise;
          };

          // /**
          //  * Validate startDate from active employment to reload rules.
          //  * Check employmentStability to clear beforeEmployment data.
          //  * @param  {[boolean]} valid [valid date from form]
          //  */
          scope.validateCheck = function(valid){
            if (!valid) {
              return;
            }
            var promise = scope.reloadRules();
            if (!promise) {
              return;
            }
            promise.then(function () {
              if (scope.employment.employmentStability) {
                resetBeforeEmployment();
              }
            });
          };

          scope.setRetiredCompany = function(){
            var company = filter(scope.retiredType, function (item) {
              return scope.employment.company.id === String(item.id);
            })[0];
            setFormattedCompany(scope.employment, company);
          };

          scope.incomeChangeDate = function(date){
            if(isEmpty(date)){
              date = bgEstimatedDate(
                [scope.dateAgo.year, scope.dateAgo.month],'MM/DD/YYYY');
            }
            if(scope.dateAgo.year || scope.dateAgo.month){
              scope.employment.startDate = new Date(date);
            }
            var promise = scope.reloadRules();
            if (!promise) {
              return;
            }
            promise.then(function () {
              if (scope.employment.employmentStability) {
                resetBeforeEmployment();
              }
            });
          };

          function resetBeforeEmployment() {
            angular.forEach(scope.employments, function (item) {
              if (item.type.id === 'C' &&
                angular.isDefined(item.tiedEmployment)) {
                item.tiedEmployment = undefined;
              }
              scope.employment.config.isSustaining = false;
              scope.employment.config.beforeEmployment = undefined;
            });
          }

            scope.chageDateValue = undefined;
            scope.getUntilDateValue = function(value){
              scope.chageDateValue = value;
            };

          scope.yearsOfServiceBeforeEmployment = function(employment){
            if(!isEmpty(employment.config.beforeEmployment.startDate)&&
               !isEmpty(employment.config.beforeEmployment.endDate)){

              employment.yearsOfServiceBeforeEmployment =
                bgDateFilter([employment.config.beforeEmployment.startDate,
                employment.config.beforeEmployment.endDate],'YM');
                if(scope.chageDateValue !==
                  employment.config.beforeEmployment.endDate){
                  employment.config.beforeEmployment.modified = true;
                }
            }
          };
          //
          scope.continuityIconIsReady = function () {
            if (scope.disabled) {
              return true;
            }
            return scope.employment.startDate &&
              angular.isDefined(scope.employment.employmentStability);
          };

          scope.sustentIconIsReady = function () {
            if (scope.disabled) {
              return true;
            }
            return scope.employment.config.beforeEmployment &&
                   scope.employment.config.beforeEmployment.startDate &&
                   scope.employment.config.beforeEmployment.endDate &&
                   angular.isDefined(
                     scope.employment.compliesWithContinuedEmployment);
          };
          //
          scope.showSustainCheckValidation = function (){
            if (scope.disabled && scope.employment.config.isSustaining) {
              return true;
            }
              if (scope.until){
                return (scope.employment.appliesToContinuedEmployment &&
                  (scope.dateAgo.month || scope.dateAgo.year));
              }
              return (scope.employment.appliesToContinuedEmployment &&
                !isEmpty(scope.employment.startDate));
          };
          //
          scope.setRegionValue = function (workingRegion) {
            var value;
            if (isEmpty(workingRegion) || isEmpty(workingRegion.id)) {
              value = {id: '-1'};
            } else {
              value = workingRegion;
            }
            return value.id;
          };

          setup();
        }
      };
  }

  /*
  =================
  CONFIGURATION
  =================
  */

  bgEmployment.$inject = [
    '$log','commonFunctions','commonRouteService',
    'bgDateFilter', 'bgModelJobsData', 'isEmptyFilter',
    'bgGeneralRuleService', 'filterFilter','bgEstimatedDateFilter',
    'catalogService','retiredPositionCode', 'bgForceValidation',
    'translateService', 'bgValueFilter', 'routeInvoker',
    'alertNotifyService', 'wrapperEmploymentsService'
    ];
  win.MainApp.Directives
    .directive('bgEmployment', bgEmployment);
}(window));
