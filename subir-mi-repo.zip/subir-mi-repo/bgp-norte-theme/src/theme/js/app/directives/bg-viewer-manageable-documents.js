(function(win) {
  'use strict';

  function bgViewerManageableDocuments(filter, bgValue, isEmpty,
    alertNotifyService, translateService, popUpService) {

    var directive = {
      restrict: 'E',
      transclude: true,
      scope: {
        findFiles: '&',
        downloadFile: '&',
        documents: '=',
        ipcTask: '=',
        entityId: '='

      },
      templateUrl: window.baseThemeURL +
        'partials/bg-viewer-manageable-documents.html',
      link: link
    };
    return directive;

    function link(scope) {
      /*
      ===============
      VALUES
      ===============
      */
      /*
      ===============
      METHODS
      ===============
      */
      scope.callDocumentManage = callDocumentManage;
      scope.callDownloadFile = callDownloadFile;
      scope.searchFileObject = searchFileObject;
      scope.btnOpenDocumentManage = btnOpenDocumentManage;

      function btnOpenDocumentManage(document, entityId) {
        scope.findFiles()(searchFileObject(document))
          .then(function(response) {
            var attrs = {
              bgPopupTitle: translateService.getValue(
                'global.document.management'),
              bgPopupClass: "bg-modal-md",
              bgPopupTpl: 'partials/bgp-popup/bg-popup-document-management.html',
              bgPopupFromService: true,
              bgPopupData: {
                files: response.data,
                newFile: {},
                isManagement: false,
                isShow: true,
                document: document,
                downloadFile: scope.callDownloadFile,
                entityId: entityId
              }
            };
            popUpService.open(attrs);
          })
          .catch(function(error) {
            alertNotifyService.showErrorT('constant.error.unexpected');
          });
      }

      function callDocumentManage(document, auxParam) {
        if (document === 'PRECA') {
          // params: document, version
          scope.findFiles()(searchFileObject(scope.preca)).then(
            function(response) {
              if (!isEmpty(response.data)) {
                scope.fileData = response.data[0];
                if (!isEmpty(auxParam)) {
                  scope.callDownloadFile(scope.fileData, scope.fileData.versionId);
                }
              }
            });
        }
        if (document === 'DOC-SUST') {
          scope.btnOpenDocumentManage(scope.docSustent,
            scope.ipcTask.procedureId, auxParam);
        }
      }

      function callDownloadFile(dlFile, versionId) {
        var query = angular.copy(dlFile);
        query.versionId = versionId;
        // query.updateDate = undefined;
        // query.createDate = undefined;
        var xrh = scope.downloadFile()(query);
        xrh.then(function(response) {
            if (response.data.extension === 'pdf') {
              window.open(response.data.url, response.data.dlFileName + versionId,
                'fullscreen=yes');
            } else {
              window.open(response.data.url);
            }
          }).catch(function(exception) {
            alertNotifyService.showErrorT('constant.error.unexpected');
          })
          .finally(function() {

          });
      }

      function searchFileObject(document) {
        var obj = {
          documentDTO: document,
          processType: translateService.getValue(
            'constant.base.folder.process.type.tramite'),
          producTypeId: scope.ipcTask.product.type.name,
          subFolder: translateService.getValue('constant.base.subFolder.quote'),
          procedureId: parseInt(scope.ipcTask.procedureId, 10)
        };
        return obj;
      }

      function init() {
        if (scope.documents) {
          filter(scope.documents, function(item) {
            if (item.code === bgValue('bgDocumentCode').preca) {
              scope.preca = item;
            }
            if (item.code === bgValue('bgDocumentCode').docSustent) {
              scope.docSustent = item;
            }
          });
        }
      }
      init();
    }
  }

  bgViewerManageableDocuments.$inject = [
    'filterFilter',
    'bgValueFilter',
    'isEmptyFilter',
    'alertNotifyService',
    'translateService',
    'bgPopUpService'
  ];
  win.MainApp.Directives
    .directive('bgViewerManageableDocuments', bgViewerManageableDocuments);
}(window));