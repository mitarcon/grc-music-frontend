(function(win) {
  'use strict';

  function bgReferenceAccordion(log, isEmpty, upperCase, catalogService,
    forceCloseForm, commonFunctions, clientNameRule
    // ,dateFilter, panamaCode, documentType,/*
    // bgGeneralRuleService, */clientNameRule,/*, upperCase,
  ) {

    log.debug("[bgReferenceAccordion] Initializing...");

    /*
    ===============
    VALUES
    ===============
    */

    return {
      scope: {
        data: '=',
        rules: '=',
        pendingAddForms: '=',
        app: '='
      },
      restrict: 'E',
      transclude: true,
      templateUrl: window.baseThemeURL +
        'partials/bg-references/references-accordion.html',
      link: function($scope) {

        $scope.tpl = window.baseThemeURL +
          'partials/bg-references/references-body.html';
        $scope.rules = clientNameRule;

        var newReference = function() {
          return {
            relationship: {},
            config: {
              isOpen: true,
              isNew: true,
              isToCreate: true
            }
          };
        };

        var createReference = function() {
          $scope.onEdit = newReference();
          //update outter object
          $scope.pendingAddForms.references = true;
        };

        var formUppercase = function(reference) {
          reference.name =
            upperCase(reference.name);
          reference.lastName =
            upperCase(reference.lastName);
          reference.motherLastName =
            upperCase(reference.motherLastName);
          reference.address =
            upperCase(reference.address);
          reference.email =
            upperCase(reference.email);
        };

        var handleNoData = function() {
          var result = $scope.data.length < 1;
          if (result) {
            createReference();
          }
          return result;
        };

        var loadTemp = function() {
          if (handleNoData()) {
            return;
          }
          angular.forEach($scope.data, function(ref) {
            if (!ref.config) {
              ref.config = {
                isOpen: false,
                isNew: false,
                isToCreate: false
              };
            }
            if (!isEmpty(ref.residentialPhoneNumber)) {
              ref.residentialPhoneNumber =
                ref.residentialPhoneNumber.trim();
            }
            if (!isEmpty(ref.otherPhoneNumber)) {
              ref.otherPhoneNumber =
                ref.otherPhoneNumber.trim();
            }
            if (!isEmpty(ref.officePhoneNumber)) {
              ref.officePhoneNumber =
                ref.officePhoneNumber.trim();
            }
          });
        };
        loadTemp();

        $scope.initializeRelationship = function() {
          if (isEmpty($scope.onEdit.relationship)) {
            $scope.onEdit.relationship =
            catalogService.item('-1', 'relationship',$scope.app);
          }
        };

        var closeOpenReference = function() {
          for (var index in $scope.data) {
            if ($scope.data.hasOwnProperty(index) &&
              $scope.data[index].config.isOpen) {
              $scope.close(index);
              return parseInt(index);
            }
          }
        };

        $scope.toggleOpen = function(ref, index) {
          if ($scope.onEdit) {
            if ($scope.onEdit.config.isNew) {
              return;
            }
            var closedIndex = closeOpenReference();
            if (closedIndex === index) {
              return;
            }
          }
          $scope.onEdit = angular.copy(ref);
          ref.config.isOpen = true;
        };

        $scope.phone = function(ref) {
          if (!isEmpty(ref.otherPhoneNumber)) {
            return ref.otherPhoneNumber;
          }
          if (!isEmpty(ref.residentialPhoneNumber)) {
            return ref.residentialPhoneNumber;
          }
          if (!isEmpty(ref.officePhoneNumber)) {
            return ref.officePhoneNumber;
          }
          return '';
        };

        $scope.emailAddress = function(ref) {
          if (!isEmpty(ref.address)) {
            return ref.address;
          }
          if (!isEmpty(ref.email)) {
            return ref.email;
          }
          return '';
        };

        $scope.close = function(index) {
          if ($scope.onEdit.config.isNew) {
            //update outter object
            $scope.pendingAddForms.references = false;
            delete $scope.onEdit;
            return;
          }
          delete $scope.onEdit;
          $scope.data[index].config.isOpen = false;
        };

        $scope.saveReference = function(index) {
          formUppercase($scope.onEdit);
          if ($scope.onEdit.config.isNew) {
            $scope.onEdit.config.isNew = false;
            $scope.onEdit.config.isOpen = false;
            $scope.data.push(angular.copy($scope.onEdit));
            //update outter object
            $scope.pendingAddForms.references = false;
            delete $scope.onEdit;
            return;
          }
          commonFunctions.updateReferenceObject($scope.onEdit,
            $scope.data[index]);
          $scope.data[index].config.isOpen = false;
          delete $scope.onEdit;
        };

        $scope.newReference = function() {
          createReference();
        };

        $scope.isForceClose = function() {
          return forceCloseForm.get();
        };

        $scope.deleteReference = function(index) {
          if ($scope.onEdit) {
            event.stopPropagation();
            return;
          }
          $scope.data.splice(index, 1);
          handleNoData();
          event.stopPropagation();
        };

      }

    };

    /*
    ==============
    CONFIGURATION
    ==============
    */
  }
  bgReferenceAccordion.$inject = [
    '$log', 'isEmptyFilter', 'uppercaseFilter', 'catalogService',
    'forceCloseFormService', 'commonFunctions', 'clientNameRule'
    // , 'dateFilter','panamaCode','documentTypeCodes',
    //  /*'bgGeneralRuleService',*/'clientNameRule',/*,'uppercaseFilter',
  ];

  win.MainApp.Directives
    .directive('bgReferenceAccordion', bgReferenceAccordion);
}(window));
