(function(win) {
  "use strict";

  function pagination() {
    return {
      restrict: 'E',
      scope: {
        paginationData: '=',
        onPageClick: '&'
      },
      templateUrl: window.baseThemeURL + 'partials/pagination.html',
      link: function(scope, element, attrs) {
        var NUMBER_OF_PAGES_TO_SHOW = 6;     
        scope.$watch('paginationData',function(paginationData){
          if(paginationData){
            if(paginationData.numberOfPages<=1){
              scope.pages = null;
              return;
            }
            var currentPage = paginationData.currentPage;
            var index = Math.floor((currentPage -1) / NUMBER_OF_PAGES_TO_SHOW); 
            var pages = [];
            if(index>0){
              pages.push({label:"<<", number:1});
            }
            pages.push({label:"<", number: (currentPage != 1) ? currentPage-1 : paginationData.numberOfPages});
            
            var pageNumber;
            for (var i = 1; i <= NUMBER_OF_PAGES_TO_SHOW && ((index * NUMBER_OF_PAGES_TO_SHOW) + i) <= paginationData.numberOfPages; i++) { 
              pageNumber = ((index * NUMBER_OF_PAGES_TO_SHOW) + i);
              pages.push({label:pageNumber, number:pageNumber, active: pageNumber == currentPage});
            }

            if(paginationData.numberOfPages > pageNumber){
              pages.push({label:"...", number: (((index + 1) * NUMBER_OF_PAGES_TO_SHOW) +1)});
            }

            pages.push({label:">", number: (currentPage!=paginationData.numberOfPages) ? currentPage+1 : 1});
            
            scope.pages = pages;
          } else{
            scope.pages = null;
          }
        });

        scope.paginationClick = function(page){
          if(!page.active){
            scope.onPageClick()(page.number);
          }
        }
      }
    };
  }

  pagination.$inject = [];

  win.MainApp.Directives
    .directive('pagination', pagination);
}(window));
