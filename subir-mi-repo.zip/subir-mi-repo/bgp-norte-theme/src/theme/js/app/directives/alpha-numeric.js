(function(win) {
  "use strict";

  function alphaNumericValidator() {
    return {
      restrict: 'A',
      require: 'ngModel',
      scope: {
        modelValue: '=ngModel'
      },
      link: function(scope, element, attrs, ngModel) {
        var checkValidity = function(value) {
          var rgexp = /^[a-zA-Z0-9 ]*$/i;
          var result = !!rgexp.test(value);
          ngModel.$setValidity('alphaNumeric', result);
        };
        
        if (scope.modelValue) {
          checkValidity(scope.modelValue);
        }
        
        ngModel.$parsers.push(function(value) {
          checkValidity(value);
          return value;
        });
      }
    };
  }
  alphaNumericValidator.$inject = [];
  win.MainApp.Directives
    .directive('alphaNumericValidator', alphaNumericValidator);
}(window));
