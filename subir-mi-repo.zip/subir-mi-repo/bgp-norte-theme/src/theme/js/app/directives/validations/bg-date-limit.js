
    (function(win) {
      'use strict';
      function bgDateLimit(translateService,uppercase){

        var checkToday = function (date, today) {
          if (!date._isValid){
            return true;
          }
          return date <= today;
        };
        var checkSecondDate = function (date, secondDate) {
          if (!secondDate||!date._isValid) {
            return true;
          }
          return date <= secondDate;
        };
        return {
          restrict: 'A',
          require: 'ngModel',
          link: function(scope, elm, attrs, ctrl) {
            function validation (viewValue) {
              var today = new Date();
              var dt = moment(viewValue, uppercase(
                translateService.getValue('global.date')));
              var sdt = attrs.bgDateLimitSecond ?
                new Date(attrs.bgDateLimitSecond.replace(/\"/g, '')) : undefined;

              if (!checkToday(dt, today)) {
                ctrl.$setValidity('bgDateLimit', false);
                ctrl.$setValidity('bgUntilDateLimit', true);
                return viewValue;
              }
              if (!checkSecondDate(dt, sdt)) {
                ctrl.$setValidity('bgUntilDateLimit', false);
                ctrl.$setValidity('bgDateLimit', true);
                return viewValue;
              }

              ctrl.$setValidity('bgDateLimit', true);
              ctrl.$setValidity('bgUntilDateLimit', true);
              return viewValue;
            }
            //For DOM -> model validation
            ctrl.$parsers.unshift(validation);
            //For model -> DOM validation
            ctrl.$formatters.unshift(validation);

          }
        };
      }


      bgDateLimit.$inject = [
        'translateService','uppercaseFilter'
      ];

      win.MainApp.Directives
        .directive('bgDateLimit',bgDateLimit);

    } (window));
