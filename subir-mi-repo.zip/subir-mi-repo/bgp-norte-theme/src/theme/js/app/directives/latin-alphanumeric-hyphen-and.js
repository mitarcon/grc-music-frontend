(function(win) {
  "use strict";
  
  var isValidRegex = function(value, additionalChars) {
    if (!value || value === '') {
      return true;
    }
    var rgexp = "^[A-Za-z0-9ÁÉÍÓÚÑáéíóúñ\\s\-";
    var suffix = "]+$";
    if (typeof additionalChars !== 'undefined') {
      rgexp = rgexp + additionalChars;
    }
    rgexp = rgexp + suffix;
    return new RegExp(rgexp).test(value);
  };
  
  function latinAlphanumericHyphenAnd() {
    return {
      restrict : 'A',
      require: 'ngModel',
      scope: {
        modelValue: '=ngModel'
      },
      link: function(scope, elements, attrs, ngModel) {
        var additionalChars = attrs.latinAlphanumericHyphenAnd;
        
        var checkValidity = function(value, additional) {
          ngModel.$setValidity('latinAlphanumericHyphenAnd', 
           isValidRegex(value, additionalChars));
        };
        
        if (scope.modelValue) {
          checkValidity(scope.modelValue);
        };
        
        ngModel.$parsers.push(function (viewValue) {
          checkValidity(viewValue);
          return viewValue;
        });
      }
    };
  }
  latinAlphanumericHyphenAnd.$inject = [];
  win.MainApp.Directives
    .directive('latinAlphanumericHyphenAnd', latinAlphanumericHyphenAnd);
}(window));