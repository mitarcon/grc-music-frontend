(function(win) {
  'use strict';

  function bgEmploymentsAccordion(log,
    isEmpty, jobmodel, filter, translateService, commonFunctions,
    catalogService, wrapperEmploymentsService, ruleService,
    activeEmploymentsService, bgValue, alertNotifyService
    /*services, */
    /* loadQuoteEmployments,
    retiredPositionCode*/
  ) {



    log.debug("[bg-employments-accordion] Initializing...");

    /*
    ==============
    VALUES
    ==============
     */
    //VM

    return {
      scope: {
        client: '=ngModel',
        clientCopy: '=',
        entity: '@',
        percentage: '@',
        domesticParameter: '@',
        legalParameter: '@',
        fromWizard: '@',
        isAddingJob: '=?',
        disabled: '=',
        pendingAddForms: '=?',
        application: '=app',
        haveProduct: '='
      },
      restrict: 'E',
      templateUrl: window.baseThemeURL +
        'partials/bg-employment-accordion.html',

      link: function(scope) {
        scope.records = !scope.disabled ? scope.client.actualEmployments :
          scope.client.employments;
        scope.pendingAddForms = isEmpty(scope.pendingAddForms) ? {} : scope
          .pendingAddForms;
        scope.isOpen = false;
        scope.employmentTemp = angular.copy(jobmodel);
        scope.employmentNotWorks = angular.copy(jobmodel);
        scope.employmentNotWorks.config = {};
        scope.employmentNotWorks.company = {
          'name': translateService.getValue('global.not.works'),
          'companyType': {
            "id": '',
            "name": translateService.getValue('global.not.works')
          }
        };
        scope.employmentTemp.config = {
          vinculateJob: undefined,
          isSustaining: false,
          isActiveJob: false,
          toReactive: false,
          isToCreate: true,
          toDelete: false,
          isAdding: true,
          isMain: false,
          isOpen: true,
          isNew: true,
          records: {}
        };
        /*
        ===============
        METHODS
        ===============
        */

        var doCheck = function(employment, actives) {
          if (!isEmpty(employment) && !isEmpty(actives)) {
            if (scope.fromWizard || !actives) {
              return false;
            }
            return filter(actives, function(item) {
              return employment.id === item.id;
            }).length > 0;
          }
        };

        var addConfigToList = function() {
          if (isEmpty(scope.records) || !isEmpty(scope.records[0].config)) {
            return;
          }

          var actives;
          var mainCode;
          if (!scope.fromWizard && !scope.disabled) {
            /**
             * TODO: edcaballero: Por el momento no es necesario para wizard
             */
            //actives = activeEmploymentsService.get();
            //mainCode = activeEmploymentsService.getMain().id;
          }
          angular.forEach(scope.records, function(item) {
            if (item.company.companyType.id === 'JU' && !item.jobTitle) {
              item.jobTitle = catalogService.item(retiredPositionCode,
                'charge', scope.application);
            }

            if (item.company.companyType.id === 'IN') {
              item.employmentSupportData.lastAmount =
                item.employmentSupportData.lastAmount === 0?
                 undefined : item.employmentSupportData.lastAmount;

              item.employmentSupportData.penultimateAmount =
                item.employmentSupportData.penultimateAmount === 0?
                undefined:item.employmentSupportData.penultimateAmount;
            }

            if (!scope.disabled) {
              item.config = {
                isActiveJob: doCheck(item, actives),
                vinculateJob: undefined,
                isSustaining: false,
                toReactive: false,
                isToCreate: false,
                toDelete: false,
                isOpen: false,
                isMain: mainCode === item.id,
                isNew: false,
                records: {}
              };
            } else {
              item.config = {};
            }
          });
          if (!scope.fromWizard) {
            //loadQuoteEmployments.get(scope.records, scope.disabled);
          }
        };

        var convertFlagsToConfig = function() {
          angular.forEach(scope.records, function(item) {

            item.principalWork =
              isEmpty(item.principalWork) ? false :
              item.principalWork;

            if (isEmpty(item.config)) {
              item.config = {};
            }

            if (!scope.fromWizard) {
              if (item.type.id === 'C') {
                item.config.isActiveJob = false;
              } else {
                item.config.isActiveJob = item.selectedForQuote;
              }
              item.config.isMain = item.principalWork;

              if (item.principalWork) {
                scope.tempEmployment = item;
              }
              item.config.records =
                wrapperEmploymentsService.getConfigRecords(item);
            } else {
              scope.tempEmployment = item.config.isMain ? item :
                scope.tempEmployment;
            }
          });
          wrapperEmploymentsService.setBeforeEmpl(scope.records);
        };

        scope.getSelectedEmployments = function() {
          return filter(scope.records, function(item) {
            if (isEmpty(item.config)) {
              return false;
            } else {
              return item.config.isActiveJob;
            }

          });
        };

        var setConfigForAll = function(name, value) {
          angular.forEach(scope.records, function(item) {
            item.config[name] = value;
            if (!isEmpty(item.principalWork) && name === 'isMain') {
              item.principalWork = value;
            }
          });
        };

        var addDefaultConfig = function(item) {
          item.config = {
            isSustaining: false,
            isActiveJob: false,
            toReactive: false,
            isToCreate: true,
            toDelete: false,
            isMain: false,
            isOpen: true,
            isNew: true,
            records: {}
          };
        };

        /**
         * Change string date from employment to js date object
         */
        var changeToDate = function(emp) {
          if (emp.startDate) {
            emp.startDate =
              new Date(emp.startDate);
          }
          if (emp.endDate) {
            emp.endDate =
              new Date(emp.endDate);
          }
        };
        //*TODO : Falta respuesta de las reglas
        var updateRecordsFromRules = function(rulesEmpList) {
          angular.forEach(rulesEmpList, function(respItem) {
            for (var i = 0; i < scope.records.length; i++) {
              if (scope.records[i].id === respItem.id) {
                respItem.config = angular.copy(scope.records[i].config);
                changeToDate(respItem);
                angular.merge(scope.records[i], respItem);
              }
            }
          });
        };

        //      TODO - @sparker
        //      Implementacion de reglas desde commons

        scope.executeRules = function() {
          log.debug("[execute Rules] Initializing...");
          if (scope.disabled) {
            return;
          }

          var client = commonFunctions.
          getBasicGeneralRulesRequest(scope.client);
          var xhr = ruleService.run(scope.application, client,
            scope.client.actualEmployments);

          xhr.then(function(response) {
            updateRecordsFromRules(response.data.client.actualEmployments);
          });

          xhr.catch(function(exception) {
            alertNotifyService.showError(
              translateService.getValue('global.error.rule'));
          });

          xhr.finally(function() {
            log.debug("---Fin rules---");
          });
        };

        function replaceRecordsContent(response) {
          scope.records.splice(0, scope.records.length);
          angular.forEach(response, function(element) {
            scope.records.push(element);
          });
        }

        scope.selectMainEmployment = function(item) {
          if (!isEmpty(item)) {
            setConfigForAll('isMain', false);
            item.config.isMain = true;
          }
          angular.forEach(scope.getSelectedEmployments(), function(empl) {
            empl.modified = true;
            if (!isEmpty(item) && empl.id === item.id) {
              empl.config.isMain = item.config.isMain;
            }
          });
        };

        var removeToDelete = function() {
          replaceRecordsContent(filter(scope.records, function(item) {
            return !item.config.toDelete;
          }));
        };

        scope.hasActiveJobs = function() {
          return angular.isDefined(scope.records) &&
            (filter(scope.records, function(item) {
              return item.type.id === 'E';
            }).length > 0);
        };

        scope.checkToContinue = function() {
          if (scope.client.entityId === 0 && scope.records.length === 0 &&
            !isEmpty(scope.employmentTemp.company.companyType.id)) {
            scope.isAddingJob = scope.employmentTemp.config.isOpen;
          } else {
            scope.isAddingJob = false;
          }
        };


        scope.showAddEmployment = function() {
          scope.adding = !scope.adding;
          scope.pendingAddForms.employments = true;
          if (scope.fromWizard) {
            scope.isAddingJob = scope.adding;
          }
        };

        scope.resetCreateEmployment = function() {
          scope.adding = false;
          if (scope.fromWizard) {
            scope.isAddingJob = scope.adding;
          }
          scope.employmentTemp = angular.copy(jobmodel);
          addDefaultConfig(scope.employmentTemp);
        };

        var validateDuplicateEmpl = function(records, employment) {
          for (var i in records) {
            //Empresas Creadas
            if (angular.equals(records[i].company.id,
                scope.legalParameter) &&
              angular.equals(records[i].company.name,
                employment.company.name)) {
              alertNotifyService.showWarning(translateService.getValue(
                'global.message.error.duplicate.work'));
              return true;
            }
            // Empresas publicas, privadas, jubilados
            if (angular.equals(records[i].company.id,
                employment.company.id) &&
              records[i].company.id !== scope.legalParameter) {
              alertNotifyService.showWarning(translateService.getValue(
                'global.message.error.duplicate.work'));
              return true;
            }
          }
        };


        scope.addConcreteEmployment = function(employment) {
          if (scope.employmentTemp.company.companyType.id === '') {
            scope.employmentTemp.company.companyType.id = 'PR';
            // update outter object
            scope.pendingAddForms.employments = true;
            return;
          }
          if (validateDuplicateEmpl(scope.records, employment)) {
            return;
          }

          employment.config.isOpen = false;
          employment.config.isNew = false;
          //convert config.records to socialSecurityRecord
          employment = wrapperEmploymentsService.getSocialSecurityRecords(
            employment);
          scope.records.push(employment);
          scope.resetCreateEmployment();
          // update outter object
          scope.pendingAddForms.employments = false;
        };

        scope.addEmploymentClosed = function(employment) {
          if (scope.employmentTemp.company.companyType.id === '') {
            scope.employmentTemp.company.companyType.id = 'PR';
            // update outter object
            scope.pendingAddForms.employments = true;
            return;
          }
          if (validateDuplicateEmpl(scope.records, employment)) {
            return;
          }
          employment.config.isOpen = false;
          employment.config.isNew = false;
          //convert config.records to socialSecurityRecord
          employment = wrapperEmploymentsService.getSocialSecurityRecords(
            employment);
          scope.records.push(employment);
          scope.resetCreateEmployment();
          // update outter object
          scope.pendingAddForms.employments = false;
        };

        var setActiveJob = function(records) {
          for (var job in records) {
            if (records[job].config.isActiveJob) {
              return;
            }
          }
          for (var job2 in records) {
            if (records[job2].type.id !== 'C') {
              records[job2].config.isMain = true;
              records[job2].config.isActiveJob = true;
              return;
            }
          }
        };

        scope.removeEmployment = function(index, item, records) {
          scope.client.hasRemovedJobs = true;
          if (item.config.isToCreate) {
            scope.records.splice(index, 1);
            setActiveJob(records);
            event.stopPropagation();
            return;
          }
          item.type = {
            'id': 'C',
            'name': translateService.getValue('global.unemployed')
          };

          // Set dirty to the employment, for it to be send to service
          item.config.dirty = true;

          if (!item.config.isActiveJob) {
            return;
          }
          item.config.isActiveJob = false;
          setActiveJob(records);

        };

        scope.toggleOpen = function(item) {
          if (scope.disabled) {
            item.config.isOpen = !item.config.isOpen;
            return;
          }
          if (!item.config.isOpen) {
            item.config.isOpen = true;
            removeToDelete();
          }
        };

        scope.selectEmployment = function(item) {
          if (item.config.isActiveJob &&
            scope.getSelectedEmployments().length > 2) {
            item.config.isActiveJob = false;
            return;
          }
          scope.executeRules();
          scope.tempEmployment = undefined;
          item.modified = true;
          var selected = scope.getSelectedEmployments();
          if (selected.length === 1) {
            setConfigForAll('isMain', false);
            if (item.config.isActiveJob) {
              item.config.isMain = true;
              return;
            }
            selected[0].config.isMain = true;
            return;
          }
          item.config.isMain = false;
        };

        var removeIfIsBeforeEmployment = function() {
          angular.forEach(scope.records, function(item) {
            if (angular.isDefined(item.config.beforeEmployment) &&
              item.type.id === 'E') {
              item.config.isSustaining = false;
              item.config.beforeEmployment = undefined;
            }
          });
        };

        scope.enableEmployments = function(items) {
          log.debug('[EnableEmployment.....]');
          scope.pendingAddForms.employments = false;
          angular.forEach(items, function(item) {
            if (item.config.toReactive) {
              item.type = {
                'id': 'E',
                'name': translateService.getValue('global.employed')
              };
            }
          });
          removeIfIsBeforeEmployment();
          /**
           * TODO: edcaballero
           * validar no hayan empleos activos al rectivar uno cesante
           * no se puede utilizar el objeto de reglas para esta validacion
           * ver que no hayan empleos activos, luego cambiar el estado del
           * empleo a reactivar y ejecutar reglas con esa lista.
           */
          //  scope.executeRules();
        };

        scope.showReactivateJobs = function(data) {
          for (var i = 0; i < data.length; i++) {
            if (data[i].type.id === 'C') {
              return true;
            }
          }
        };

        scope.updatePendingForm = function() {
          scope.pendingAddForms.employments = true;
        };

        scope.showRiskClassification = function(item) {
          if (item.company && item.company.companyType &&
            item.company.companyType.id === 'JU') {
            return "";
          }
          return item.riskClasification ? item.riskClasification.name : "";
        };

        scope.setup = function() {
          addDefaultConfig(scope.employmentTemp);
          addConfigToList();
          convertFlagsToConfig();
          scope.executeRules();
          scope.checkToContinue();
          if (isEmpty(scope.entity) || !isEmpty(scope.records) ||
            scope.disabled) {
            addConfigToList();
            return;
          }
        };

        scope.setup();
      }
    };
  }

  /*
  ==============
  CONFIGURATION
  ==============
  */
  bgEmploymentsAccordion.$inject = [
    '$log',
    'isEmptyFilter',
    'bgModelJobsData',
    'filterFilter',
    'translateService',
    'commonFunctions',
    'catalogService',
    'wrapperEmploymentsService',
    'bgGeneralRuleService',
    'bgActiveEmploymentsService',
    'bgValueFilter',
    'alertNotifyService'
    //        'ajaxServices',

    //        'loadQuoteEmploymentsService',
    //        'retiredPositionCode',
  ];

  win.MainApp.Directives
    .directive("bgEmploymentsAccordion",
      bgEmploymentsAccordion);

}(window));
