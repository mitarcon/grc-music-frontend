/* globals angular, $, appName */

(function () {
    "use strict";

    function accordion($timeout) {
        return {
            link: function ( scope, element ) {
                element.bind('click', function () {
                    var parent = $(element.parent());
                    var $element = $(element);

                    $timeout(function () {
                        $element.find('.fa').toggleClass('fa-angle-down');
                    }, 300);

                    parent.find('.collapse:first').collapse('toggle');
                });
            }
        };
    }

    accordion.$inject = ['$timeout'];

    angular
    .module(appName + ".directives")
    .directive('accordion', accordion);
}());
