(function(win) {
  "use strict";

  function emailValidator() {
    return {
      restrict: 'A',
      require: 'ngModel',
      scope: {
        modelValue: '=ngModel'
      },
      link: function(scope, element, attrs, ngModel) {
        var checkValidity = function(value) {
          var rgexp = /^([\w\-\+\&\*]+(?:\.[\w\-\_\+\&\*]+)*@(?:[\w-]+\.)+[a-zA-Z]{2,7})*$/;
          var result = !!rgexp.test(value);
          ngModel.$setValidity('email', result);
        };
        
        if (scope.modelValue) {
          checkValidity(scope.modelValue);
        }
        
        ngModel.$parsers.push(function(value) {
          checkValidity(value);
          return value;
        });
      }
    };
  }
  emailValidator.$inject = [];
  win.MainApp.Directives
    .directive('emailValidator', emailValidator);
}(window));
