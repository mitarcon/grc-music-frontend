/* globals _ */

(function (win) {
  "use strict";

  function securitySameQuestionValidator() {
    return {
      require: 'ngModel',
      link: function (scope, element, attrs, ngModel) {
        scope.$watch("sqsCtrl.flow.securityQuestions",
          function (newValue, oldValue) {
            if (newValue && (newValue.length > 1)) {
              var existsSameQuestion = _.where(newValue, {code: ngModel.$modelValue}).length > 1;
              if (!existsSameQuestion) {
                ngModel.$setValidity('isTheSameQuestion', true);
              }
            }
          }, true
        );

        ngModel.$parsers.push(function (value) {
          var theSame = _.find(scope.sqsCtrl.flow.securityQuestions, function (o) {
            return (o.code == value.code);
          });

          ngModel.$setValidity('isTheSameQuestion', !theSame);

          return value;
        });
      }
    };
  }

  securitySameQuestionValidator.$inject = [];

  win.MainApp.Directives
    .directive('securitySameQuestionValidator', securitySameQuestionValidator);
}(window));