(function(win) {
  "use strict";

  function phoneValidator() {
    return {
      restrict: 'A',
      require: 'ngModel',
      scope: {
        modelValue: '=ngModel'
      },
      link: function(scope, element, attrs, ngModel) {
        var checkValidity = function(value) {
          var rgexp = /^(^[\d|\-|.|\(|\)|\s]*)*$/;
          var result = !!rgexp.test(value);
          if(result){
            ngModel.$setValidity('phone', result);
            rgexp =  /^(^[2-9]\d{6,8}$|^(\([2-9]|[2-9])(\d{2}|\d{2}\))(-|.|\s)?\d{1,4}(-|.|\s)?\d{1,4}$)*$/;
            result = !!rgexp.test(value);
            ngModel.$setValidity('phone-invalid', result);
       	  }else{
       	    ngModel.$setValidity('phone', result);
       	  }
        };
        
        if (scope.modelValue) {
          checkValidity(scope.modelValue);
        }
        
        ngModel.$parsers.push(function(value) {
          checkValidity(value);
          return value;
        });
      }
    };
  }
  phoneValidator.$inject = [];
  win.MainApp.Directives
    .directive('phoneValidator', phoneValidator);
}(window));
