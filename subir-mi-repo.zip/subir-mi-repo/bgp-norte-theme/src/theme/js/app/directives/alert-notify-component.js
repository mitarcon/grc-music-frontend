(function (win) {
  "use strict";

  var showMessage = function(status, message, translate, id) {};
  var showMessageNoTimeout = function(status, message, translate, id, noTimeout) {};
  var closeAll = function() {};
  var closeById = function(id) {};

  var AlertNotifyService = function() {
    return {
      showInfo: function(message, id) {
        showMessage("info", message, false, id);
      },
      showInfoT: function(key, id) {
        showMessage("info", key, true, id);
      },
      showSuccess: function(message, id) {
        showMessage("success", message, false, id);
      },
      showSuccessT: function(key, id) {
        showMessage("success", key, true, id);
      },
      showWarning: function(message, id) {
        showMessage("warning", message, false);
      },
      showWarningT: function(key, id) {
        showMessage("warning", key, true, id);
      },
      showError: function(message, id) {
        showMessage("error", message, false, id);
      },
      showErrorT: function(key, id) {
        showMessage("error", key, true, id);
      },
      showErrorNoTimeout: function(message, id) {
        showMessageNoTimeout("error", message, false, id, true);
      },
      closeAll: closeAll,
      close: closeById
    };
  };

  window.MainApp.Services.service("alertNotifyService", AlertNotifyService);

  var AlertNotifyController = function(translateService, $rootScope, $timeout) {
    var self = this;

    var statusClasses = {
      info: 'alert-info',
      success: 'alert-success',
      warning: 'alert-warning',
      error: 'alert-danger'
    };

    var iconClasses = {
      info: 'fa-info-circle',
      success: 'fa-check-circle',
      warning: 'fa-exclamation-circle',
      error: 'fa-times-circle'
    };

    self.messages = [];

    self.$onInit = function() {

      showMessage = function (status, text, translate, id) {
        showMessageNoTimeout(status, text, translate, id, false);
      };

      showMessageNoTimeout = function (status, text, translate, id, noTimeout) {
        if (translate)
          text = translateService.getValue(text);

        if (id !== undefined)
          closeById(id);

        var message = {
          id: id,
          message: text,
          statusClass: statusClasses[status],
          iconClass: iconClasses[status],
          noTimeout: noTimeout
        };

        self.messages.push(message);
        if (!noTimeout) {
          $timeout(function() { self.close(message); }, 5000);
        }
      };

      closeAll = function() {
        self.messages = [];
      };

      closeById = function(id) {
        var message = _.find(self.messages, function(m){ return m.id == id; });
        self.close(message);
      };

      $rootScope.$on('$stateChangeStart', function() {
        closeAll();
      });
    };

    self.close = function(message) {
      var index = self.messages.indexOf(message);
      if (index > -1)
        self.messages.splice(index, 1);
    };
  };

  AlertNotifyController.$inject = ["translateService", "$rootScope", "$timeout"];

  win.MainApp.Directives.component('alertNotify', {
    templateUrl: window.baseThemeURL + 'common/alert-notify-component.html',
    controller: AlertNotifyController,
    scope: {
      messages: '<'
    }
  });
}(window));
