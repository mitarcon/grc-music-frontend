/* globals angular, appName */

(function (win) {
    "use strict";

    function atLeastOneSpecialCharValidator() {
        return {
            require : 'ngModel',
            link : function(scope, element, attrs, ngModel) {
                $(element).on('blur', function () {
                    if(attrs.atLeastOneSpecialCharValidator != "optional"){
                        scope.$apply(function () {
                            ngModel.$setValidity('atLeastOneSpecialChar', true);
                        });
                    }
                });
                $(element).on('focus', function () {
                    var rgexp = /[\.,\"\-_\/:\*\@\#\$\?!\(\)\[\]<\>;\%]+/;
                    var result = !!rgexp.test(ngModel.$modelValue);
                    if(attrs.atLeastOneSpecialCharValidator != "optional"){
                        scope.$apply(function () {
                            ngModel.$setValidity('atLeastOneSpecialChar', result);
                        });
                    }
                });
                ngModel.$parsers.push(function(value) {
                    var rgexp = /[\.,\"\-_\/:\*\@\#\$\?!\(\)\[\]<\>;\%]+/;
                    var result = !!rgexp.test(value);

                    if(attrs.atLeastOneSpecialCharValidator != "optional"){
                        ngModel.$setValidity('atLeastOneSpecialChar', result);
                    } else {
                        element.attr( 'atLeastOneSpecialChar', result);
                    }

                    return value;
                });
            }
        };
    }

    angular
        .module(appName + ".directives")
        .directive('atLeastOneSpecialCharValidator', atLeastOneSpecialCharValidator);

    atLeastOneSpecialCharValidator.$inject = ['$timeout'];
}(window));
