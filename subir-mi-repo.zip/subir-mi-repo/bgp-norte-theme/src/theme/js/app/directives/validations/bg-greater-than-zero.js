(function (win){
  'use strict';
  function bgGreaterThanZero(filter, isEmpty){
    return {
      require: 'ngModel',
      scope: {},
      link: function(scope, elm, attrs, ngModel) {

        var validate = function(viewValue) {

        if(!isEmpty(viewValue)){

          if (viewValue <= 0) {
            ngModel.$setValidity('greaterThanZero', false);
          }else{
            ngModel.$setValidity('greaterThanZero', true);
          }

        }

        return viewValue;

        };

        ngModel.$parsers.unshift(validate);
        ngModel.$formatters.unshift(validate);

      }
    };
  }
  bgGreaterThanZero.$inject=['$filter',
                             'isEmptyFilter'];
  win.MainApp.Directives
    .directive('bgGreaterThanZero',bgGreaterThanZero);
}(window));
