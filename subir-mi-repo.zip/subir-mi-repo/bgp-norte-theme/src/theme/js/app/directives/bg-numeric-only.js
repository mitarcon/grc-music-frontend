(function(win){
  "use strict";
  function numericOnly(){
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function(scope, element, attrs, modelCtrl) {
            modelCtrl.$parsers.push(function (inputValue) {
                var transformedInput = inputValue ?
                    inputValue.replace(/[^\d.-]/g,'') : null;
                if (transformedInput!=inputValue) {
                    modelCtrl.$setViewValue(transformedInput);
                    modelCtrl.$commitViewValue();
                    modelCtrl.$render();
                }
                return transformedInput;
            });
        }
    };
  }
  numericOnly.$inject = [];
  win.MainApp.Directives
    .directive('numericOnly',numericOnly);
}(window));
