(function (win){
  'use strict';
  function bgFieldMatch(){
    return {
      require: "ngModel",
      scope: {
        compareTo: "=bgFieldMatch"
      },
      link: function(scope, elm, attrs, ngModel) {

        ngModel.$parsers.unshift(function(value){
          validate(value, scope.compareTo);
          return value;
        });

        ngModel.$formatters.unshift(function(value){
          validate(value, scope.compareTo);
          return value;
        });

        scope.$watch('compareTo', function(newVal, oldVal) {
          if(newVal != oldVal)
            validate(ngModel.$viewValue, newVal);
        });

        function validate (myValue, compare) {
          myValue = myValue === '' ? undefined : myValue;
          compare = compare === '' ? undefined : compare;
          if (attrs.bgFieldMatchCompare == "true"){
            ngModel.$setValidity(ngModel.$name,
              myValue === compare);
          }
        }

      }
    };
  }
  bgFieldMatch.$inject = [];
  win.MainApp.Directives
    .directive('bgFieldMatch',bgFieldMatch);
}(window));
