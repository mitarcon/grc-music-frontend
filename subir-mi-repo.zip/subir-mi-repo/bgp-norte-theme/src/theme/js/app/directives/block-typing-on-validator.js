/* globals angular, appName */
(function (win) {
    "use strict";

    function blockTypingOn () {
        return {
            link: function (scope, elm, attrs) {

                elm.bind('keypress', function (e) {
                    // stop typing if length is equal or greater then limit
                    if (elm[0].value.length >= attrs.blockTypingOn) {
                        e.preventDefault();
                        return false;
                    }
                });
            }
        };
    }

    blockTypingOn.$inject = [];

    // add directive custom-server-message-validator
    angular
        .module(appName + ".directives")
        .directive('blockTypingOn', blockTypingOn);
}(window));
