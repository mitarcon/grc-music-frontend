(function(win) {
  "use strict";

  var DatePickerController = function($filter, scope) {

    var vm = this;

    vm.datepickerDisabled = vm.datepickerDisabled ? vm.datepickerDisabled : false;

    vm.model = vm.model ? vm.model : new Date();
    vm.index = vm.index ? vm.index : '';
    vm.newDate = new Date();

    vm.formattedMinDate = $filter('date')(new Date(vm.minDate), 'dd-MMM-yyyy');
    vm.formattedMaxDate = $filter('date')(new Date(vm.maxDate), 'dd-MMM-yyyy');

    //Datepicker configuration

    function setDatePickerOptions (){
      vm.datePickerOptions = {
        showWeeks: false,
        startingDay: 1,
        minDate: vm.minDate ? new Date(vm.minDate) : null,
        maxDate: vm.maxDate ? new Date(vm.maxDate) : null,
        dateDisabled: executeDisabledDates,
        yearColumns: 4,
        monthColumns: 4,
        yearRows: 3
      };
    }
    setDatePickerOptions();

    scope.$watch('[BGPDatePickerCtrl.minDate, BGPDatePickerCtrl.maxDate]', function() {
      setDatePickerOptions();
    });

    function executeDisabledDates(date) {

      var disabledDate = false;
      var disabledDay = vm.validateSundays ? 0 : 99999;

      if (vm.disabledDates) {

        angular.forEach(vm.disabledDates, function(value) {

          var d = new Date(value);

          if (d.toDateString() === date.date.toDateString()) {
            disabledDate = true;
          }

        });
      }

      return ((date.mode === 'day' && (date.date.getDay() === disabledDay)) || disabledDate);
    }

    if (vm.onDateChange && angular.isFunction(vm.onDateChange)) {

      scope.$watch('BGPDatePickerCtrl.model', function() {
        vm.onDateChange();
      });

    }

  };

  DatePickerController.$inject = ["$filter", "$scope"];

  function bgpDatePicker() {
    return {
      restrict: 'E',
      require: '^form',
      scope: {
        labelKey: '=',
        model: '=ngModel',
        isDisabled: '=?ngDisabled',
        validateSundays: '=?',
        index: '@?',
        disabledDates: '=?',
        minDate: '@?',
        maxDate: '@?',
        onDateChange: '&'
      },
      controllerAs: 'BGPDatePickerCtrl',
      bindToController: true,
      templateUrl: window.baseThemeURL + 'partials/bgp-date-picker.html',
      controller: DatePickerController,
      link: function(scope, element, attrs, ctrl) {
        scope.form = ctrl;
      }
    };
  }

  bgpDatePicker.$inject = [];

  angular.module(appName + ".directives")
    .directive('bgpDatePicker', bgpDatePicker);

}(window));
