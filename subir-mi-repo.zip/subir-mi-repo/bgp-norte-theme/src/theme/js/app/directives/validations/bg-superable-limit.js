(function (win) {
  'use strict';

  function bgSuperableVal() {

    return {
      restrict: 'A',
      require: 'ngModel',
      link: link
    };

    function link (scope, elm, attrs, ctrl) {
      //For model -> DOM validation
      ctrl.$formatters.unshift(function (viewValue) {
        var valid = validateIsSuperable(viewValue, attrs.bgSuperableValSumamo,
          attrs.bgSuperableValSuggestlim);
        ctrl.$setValidity('bgSuperableVal', valid);
        return viewValue;
      });

      //For DOM -> model validation
      ctrl.$parsers.unshift(function (viewValue) {
        var valid = validateIsSuperable(viewValue, attrs.bgSuperableValSumamo,
          attrs.bgSuperableValSuggestlim);
        ctrl.$setValidity('bgSuperableVal', valid);
        return viewValue;
      });
    }

    function validateIsSuperable (viewval, superableAmount,
      suggestedLimit) {

      if (typeof viewval === 'string') {
        viewval = viewval.replace(',', '');
        viewval = parseFloat(viewval);
      }

      if (superableAmount === "true") {
        return true;
      } else if (viewval > suggestedLimit) {
        return false;
      }
    }
  }

  bgSuperableVal.$inject = [];

  win.MainApp.Directives
    .directive('bgSuperableVal', bgSuperableVal);

}(window));
