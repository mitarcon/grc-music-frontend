/* globals angular, appName */

(function(win) {
  "use strict";

  function showPassword(isEmpty) {
    return {
        restrict: 'E',
        scope: {
          model: '=',
          label: '@',
          maxlength: '@?',
          pattern: '@?',
          inputsize: '@?',
          fieldmatch: '=?',
          fieldName: '@?',
          disabled: '='
        },
        templateUrl: window.baseThemeURL + 'partials/bg-show-password.html',
        link: function(scope) {
          scope.showPassword = false;
          scope.inputSize = isEmpty(scope.inputSize) ? '4' : scope.inputSize;

          scope.getInputSize = function(){
            var fullSize = "col-xs-" + scope.inputSize;
            return fullSize;
          };

          scope.showingPass = function(){
            scope.showPassword = !scope.showPassword;
          };

          scope.showHiddenText = function(){
            return scope.showPassword === false ? 'hiddenText':'normalText';
          };
        }
    };
  }

  showPassword.$inject = ['isEmptyFilter'];
  win.MainApp.Directives
    .directive('showPassword', showPassword);
}(window));
