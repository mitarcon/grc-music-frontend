(function(win) {
  'use strict';

  function bgClientDetail(
    isEmpty,
    commonFunctions,
    scoringPhaseStatus,
    log,
    bgValue,
    filter,
    popUpService,
    routeInvoker,
    $log
  ) {

    return {
      restrict: 'E',
      scope: {
        'executeBusinessRule': '&',
        'participant': '=',
        'isPrincipal': '=',
        'updateQuoteSession': '&',
        'ruleOperation': '=',
        'quoteId': '=',
        'stageId': '=',
        'statusId': '=',
        'isDisabledQuote': '&',
        'roleChanged': '&',
        'deleteParticipant': '&',
        'getApcDataAdditionalParticipant': '&',
        'isDisableTab': '=',
        'app': '=',
        'product': '=',
        'updateCustomerApcFlagFn': '=',
        'validateClient': '=',
        'objHolder': '=',
        'deletedEmployments': '=',
        'additionalRoleChange': '&',
        'hideElement': '='
      },
      template: '<div ng-include="template"></div>',
      link: link
    };

    function link(scope) {
      scope.template = window.baseThemeURL +
        'partials/bg-client-detail.html';
      scope.alertMissingFields = alertMissingFields;
      scope.changeAdditionalRole = changeAdditionalRole;
      scope.changeRelationship = changeRelationship;
      scope.creditHistoryIcon = creditHistoryIcon;
      scope.getAPCDocumentNumber = getAPCDocumentNumber;
      scope.getAPCIdentificationType = getAPCIdentificationType;
      scope.getLastEmailContact = getLastEmailContact;
      scope.getLastPhoneContact = getLastPhoneContact;
      scope.goToCustomer = goToCustomer;
      scope.defineLinkStyle = defineLinkStyle;
      scope.openAdditionalApc = openAdditionalApc;
      scope.additionalRoleChange = scope.additionalRoleChange();

      scope.deleteParticipant = scope.deleteParticipant();

      function alertMissingFields(entityId) {
        if (scope.validateClient && scope.validateClient.clients &&
          scope.validateClient.clients.indexOf(entityId) >= 0) {
          return true;
        } else {
          return false;
        }
      }

      function changeAdditionalRole() {
        var roleChangeWrapper = {
          participant: scope.participant,
          productType: {
            id: scope.product
          }
        };

        if (angular.isFunction(scope.roleChanged)) {
          scope.roleChanged()();
        }

        scope.additionalRoleChange(roleChangeWrapper).then(function(
            response) {
            //actualizar las obligaciones del participante
            //si es rol dueno-deudor se agrega la obligacion manual de alquiler
            //de vivienda sino la tiene, si se cambia a cualquier otro rol,
            //se le quita esa obligacion
            scope.participant.apcData.activeObligations =
              response.data.apcData.activeObligations;
            scope.executeBusinessRule()(null, null, true);
          })
          .catch(function(exception) {
            $log.error("Error en carQuoteService.additionalRoleChange ", exception);
          })
          .finally(function() {

          });
      }

      function changeRelationship() {
        scope.executeBusinessRule()(null, null, true);
      }

      function creditHistoryIcon(record) {
        if (record === bgValue('creditHistory').good) {
          return {
            icon: 'check-circle',
            color: 'verde'
          };
        } else if (record === bgValue('creditHistory').regular) {
          return {
            icon: 'exclamation-circle',
            color: 'amarillo'
          };
        } else if (record === bgValue('creditHistory').higher) {
          return {
            icon: 'exclamation-circle',
            color: 'rojo'
          };
        }
      }

      function getAPCDocumentNumber(documentNumber, documentType) {
        return commonFunctions
          .getAPCDocumentNumber(documentNumber, documentType);
      }

      function getAPCIdentificationType(documentNumber, documentType) {
        return commonFunctions.getAPCIdentificationType(documentNumber,
          documentType);
      }

      function getLastEmailContact(participant) {
        var emails;
        if (!isEmpty(participant.contactData)) {
          emails = participant.contactData.filter(function(obj) {
            return obj.type.id === 'M';
          });
          if (!angular.isUndefined(emails) && emails.length > 0) {
            emails = filter('orderBy')(emails, '-modificationDate')[0].name;
          } else {
            emails = '';
          }
        }
        return emails;
      }

      function getLastPhoneContact(participant) {
        var phones;
        if (!isEmpty(participant.contactData)) {
          phones = participant.contactData.filter(function(obj) {
            return obj.type.id === 'C';
          });
          if (!angular.isUndefined(phones) && phones.length > 0) {
            phones = filter('orderBy')(phones,
              '-modificationDate')[0].name;
          } else {
            phones = "";
          }
          return phones;
        }
      }

      function goToCustomer(participant, disabled, withProduct) {
        scope.updateQuoteSession()
          .then(function() {
              var isDataSheetPrinted;
              var isDataSheetPrintedRequired;

              angular.forEach(participant.documents,
                function(document) {
                  if (document.code === bgValue('bgDocumentCode').dataSheet) {
                    isDataSheetPrinted = document.printed;
                    isDataSheetPrintedRequired = document.printingRequired;
                  }
                });

              commonFunctions.goToCustomer(scope, participant,
                scope.isPrincipal, disabled, scope.ruleOperation,
                scope.quoteId, scope.stageId, scope.statusId,
                isDataSheetPrinted, isDataSheetPrintedRequired, withProduct);
            },
            function(data) {
              //commonFunctions.callMessageError(data);
            });
      }

      function defineLinkStyle() {
        var style1 = "";
        var style2 = "";
        if (scope.isDisableTab) {
          style1 = 'unClickLink';
        }
        if (scope.alertMissingFields(scope.participant.entityId) &&
          (scope.objHolder.outdatedMessages && scope.objHolder.outdatedMessages[scope.participant
            .entityId])) {
          style2 = 'customer-edit';
        } else {
          style2 = 'link-color';
        }

        return style1 + ' ' + ' ' + style2;
      }
      scope.setApcDataAdditionalParticipant = function(participant) {
        scope.participant.apcData = participant.apcData;
      };

      function openAdditionalApc() {
        var attrs = {
          bgPopupMethod: scope.setApcDataAdditionalParticipant,
          bgPopupCancelMethod: scope.setApcDataAdditionalParticipant,
          bgPopupTpl: 'partials/bgp-popup/bg-popup-apc-additional.html',
          bgPopupFromService: true,
          bgPopupData: {
            participant: scope.participant,
            ruleFn: scope.executeBusinessRule(),
            apcFilter: {
              product: {
                id: scope.product
              },
              quoteCode: scope.quoteId,
              customerId: scope.participant.entityId,
              identificationType: getAPCIdentificationType(
                scope.participant.documentNumber,
                scope.participant.documentType),
              identification: getAPCDocumentNumber(scope.participant.documentNumber,
                scope.participant.documentType),
              forceUpdate: false,
              addHouseRentalObligation: false
            },
            getPrintApcLetterWrapper: scope.getPrintApcLetterWrapper,
            getApcDataAdditionalParticipant: scope.getApcDataAdditionalParticipant,
            setApcDataAdditionalParticipant: scope.setApcDataAdditionalParticipant,
            disabledField: scope.isDisabledQuote(),
            isDisabledQuote: scope.isDisabledQuote(),
            isDisableTab: scope.isDisableTab,
            app: scope.app,
            showLoading: scope.showLoading,
            updateCustomerApcFlagFn: scope.updateCustomerApcFlagFn
          },
          bgPopupClass: "bg-modal-lg"
        };
        popUpService.open(attrs);
      }
    }
  }
  bgClientDetail.$inject = [
    'isEmptyFilter',
    'commonFunctions',
    'scoringPhaseStatus',
    '$log',
    'bgValueFilter',
    '$filter',
    'bgPopUpService',
    'routeInvoker',
    '$log'
  ];

  win.MainApp.Directives.directive('bgClientDetail', bgClientDetail);

}(window));