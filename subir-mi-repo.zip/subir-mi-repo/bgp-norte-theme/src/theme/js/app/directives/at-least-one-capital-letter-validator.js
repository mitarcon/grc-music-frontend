/* globals angular, appName */

(function (win) {
    "use strict";

    function atLeastOneCapitalLetterValidator() {
        return {
            require : 'ngModel',
            link : function(scope, element, attrs, ngModel) {
                $(element).on('blur', function () {
                    scope.$apply(function () {
                        if(attrs.atLeastOneCapitalLetterValidator != "optional"){
                            ngModel.$setValidity('atLeastOneCapitalLetter', true);
                        }
                    });
                });
                $(element).focus(function () {

                    var rgexp = /([A-Z])+/;
                    var result = !!rgexp.test(ngModel.$modelValue);
                    if(attrs.atLeastOneCapitalLetterValidator != "optional"){
                        scope.$apply(function () {
                            ngModel.$setValidity('atLeastOneCapitalLetter', result);
                        });
                    }
                });
                ngModel.$parsers.push(function(value) {
                    var rgexp = /([A-Z])+/;
                    var result = !!rgexp.test(value);
                    if(attrs.atLeastOneCapitalLetterValidator != "optional"){
                        ngModel.$setValidity('atLeastOneCapitalLetter', result);
                    } else {
                        element.attr( 'atLeastOneCapitalLetter', result);
                    }
                    return value;
                });
            }
        };
    }

    angular
        .module(appName + ".directives")
        .directive('atLeastOneCapitalLetterValidator', atLeastOneCapitalLetterValidator);

    atLeastOneCapitalLetterValidator.$inject = ['$timeout'];
}(window));
