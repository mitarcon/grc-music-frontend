(function(win) {
  "use strict";

  function securityQuestion(transferCommonService, $state) {
    return {
      restrict: 'E',
      replace: true,
      scope: {
        control: '=',
        title: '@',
        onSubmitQuestion: '&'
      },
      templateUrl: window.baseThemeURL + 'partials/security-question.html',
      link: function(scope, element, attrs) {
        scope.internalControl = scope.control || {};

        $('#securityQuestionModal').on('shown.bs.modal', function () {
          $('#answer').focus();
          scope.securityQuestion.answer="";
        });

        var showModal=function(){
          $('#securityQuestionModal').modal('show');
        };

        scope.internalControl.showQuestion = function(){
          if(!scope.securityQuestion){
            scope.showLoading = true;

            scope.title = scope.title || 'login-step-security-questions';
            var xhr = transferCommonService.getSecurityQuestion();
            xhr.then(function(response) {
              if (response.data.params.state){
                $state.go(response.data.params.state);
                return;
              }
              scope.securityQuestion = response.data.params.securityQuestion;
            });

            xhr.finally(function() {
              scope.showLoading=false;
              showModal();
            });

            xhr.catch(function() {
            });
          }else{
            showModal();
          }
        };

        scope.onSubmit = function(){
          $('#securityQuestionModal').modal('hide');
          scope.onSubmitQuestion()(scope.securityQuestion);
        };
      }
    };
  }

  securityQuestion.$inject = ["transferCommonService","$state"];

  win.MainApp.Directives
    .directive('securityQuestion', securityQuestion);
}(window));
