	(function(win) {
	'use strict';

	function bgContacts  (log,
			 	isEmpty, bgValue,
				contactUtils,
				translateService,
			  clientNameRule,
				forceCloseForm,
				catalogService
//			testService, alertNotifyService
			 ){

		log.debug("[bg-contacts] Initializing...");

		/*
 ==============
 VALUES
 ==============
		 */
		//VM


		return {
			restrict: 'E',
			scope: {
		        client: '=ngModel',
						apps: '@'
		      },
		    require: 'ngModel',
			templateUrl: window.baseThemeURL + 'partials/bg-contacts-data.html',

			link: function(scope) {
				scope.personalData = {
						showDetail: true,
						contactAddTemplate: true
				};
				scope.client.addingObj ={
					type:{},
					contactDataVal: undefined
				};


				/*
       ==============
       METHODS
       ==============
				 */

				var selectDefaults = function(data) {
					scope.client.contactData = contactUtils.complete(data, scope.apps);
					scope.client.addingObj.type = catalogService.item(
						bgValue('contactType').mail, 'contactType', scope.apps);

				};

				selectDefaults(scope.client.contactData);

				scope.deleteContact = function(index) {
					if (!isEmpty(index)){
					scope.client.contactData.splice(index, 1);
					}
				};

				scope.resetContactData = function() {
					scope.client.addingObj.contactDataVal = undefined;
				};

				// TODO: @sparker
				// Se necesita la integracion con reglas para finalizar
				// el funcionamiento de este metodo
				//El value bgValue('genderTypes').male, solo hace referencia a
				//la letra M que es un tipo de contacto, se utilizo el mismo para no
				//utilizar otro value.

				scope.changeValidation = function(code) {
					if (!isEmpty(code)) {
						return code.trim() === bgValue('genderTypes').male ?
						clientNameRule.email : clientNameRule.phone;
					}
						return clientNameRule.email;
				};


				// method to erase
				scope.selectToDelete = function(description, value) {
					if (!isEmpty(description) && !isEmpty(value)){
						var data = catalogService.item(description.trim(),
							'contactType', scope.apps);
							scope.actionMessage = translateService.getValue(
							'title.want.delete', [data.name, value]
						);
					}
				};

				scope.showTemplate = function() {
					scope.personalData.contactAddTemplate = !scope.personalData.contactAddTemplate;
					scope.client.addingObj.contactDataVal = undefined;
					scope.client.addingObj.type.id = bgValue('genderTypes').male;
				};

				scope.addContact = function () {
				  if (!isEmpty(scope.client.addingObj.type) &&
				    !isEmpty(scope.client.addingObj.contactDataVal)) {

					  scope.client.contactData.push({
				      type: {
								id: scope.client.addingObj.type.id,
								name: scope.client.addingObj.type.name
				      },
				      name: scope.client.addingObj.contactDataVal,
				      isFromView: true,
				      isDeletable: true
				    });
						scope.client.addingObj.contactDataVal = '';
						scope.client.addingObj.type.id = bgValue('genderTypes').male;
				    scope.personalData.contactAddTemplate = true;
				  }
				};

				scope.isForceClose = function(){
				return forceCloseForm.get();
				};

				scope.validateContacts = function (contact) {
				  if (!isEmpty(contact)) {
				    if (!contact.isFromView) {
				      return true;
				    }
				    for (var index in scope.client.contactData) {
				      if (!isEmpty(scope.client.contactData[index].name)) {
				        return false;
				      }
				    }
				    return true;
				  }
				};
				//llaves de cierre del return
			}
		};
	}


	bgContacts.$inject = [
	                          "$log",
														'isEmptyFilter',
														"bgValueFilter",
														"contactUtils",
//	                          'tplRootUrl',
	                          'translateService',
	                          'clientNameRule',
	                          'forceCloseFormService',
	                          'catalogService'
//	                          "testService",
//	                          "alertNotifyService",
	                          ];

	win.MainApp.Directives
	.directive("bgContacts",
			bgContacts);

}(window));
