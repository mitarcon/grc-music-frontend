(function (win) {
  'use strict';

  function bgRangeLimit(common) {

    var showReasons = function (valid, ctrl) {
      if (ctrl.$$parentForm.$aaFormExtensions && valid && ctrl.$touched) {
        ctrl.$$parentForm.$aaFormExtensions[ctrl.$name]
          .showErrorReasons = ['bgRangeLimit'];
      }
    };

    var isValid = function isValid(value, max, min, exclusive) {
      if (common.isEmpty(value) || value === '.') {
        return true;
      }
      if (typeof value === 'string') {
        value = value.split(",").join("");
        value = parseFloat(value);
      }
      var result = true;
      if (exclusive === 'true') {
        if (!common.isEmpty(max) && !isNaN(max)) {
          result = result && parseFloat(value) < parseFloat(max);
        }
        if (!common.isEmpty(min) && !isNaN(min)) {
          result = result && parseFloat(value) > parseFloat(min);
        }
        return result;
      }
      if (!common.isEmpty(max) && !isNaN(max)) {
        result = result && parseFloat(value) <= parseFloat(max);
      }
      if (!common.isEmpty(min) && !isNaN(min)) {
        result = result && parseFloat(value) >= parseFloat(min);
      }

      return result;
    };

    return {
      restrict: 'A',
      require: 'ngModel',
      link: function (scope, elm, attrs, ctrl) {
        var isExceptionCase = scope.$eval(attrs.bgRangeException);
        //For DOM -> model validation
        ctrl.$parsers.unshift(function (viewValue) {
          if (isExceptionCase && isExceptionCase()) {
            ctrl.$setValidity('bgRangeLimit', true);
            return viewValue;
          }
          var valid = isValid(viewValue,
            attrs.bgRangeLimitMax, attrs.bgRangeLimitMin,
            attrs.bgRangeLimitExclusive);
          ctrl.$setValidity('bgRangeLimit', valid);
          showReasons(valid, ctrl);
          return viewValue;
        });

        //For model -> DOM validation
        ctrl.$formatters.unshift(function (viewValue) {
          if (isExceptionCase && isExceptionCase()) {
            ctrl.$setValidity('bgRangeLimit', true);
            return viewValue;
          }
          var valid = isValid(viewValue,
            attrs.bgRangeLimitMax, attrs.bgRangeLimitMin,
            attrs.bgRangeLimitExclusive);
          ctrl.$setValidity('bgRangeLimit', valid);
          showReasons(valid, ctrl);
          return viewValue;
        });
      }
    };
  }
  bgRangeLimit.$inject = [
    'commonFunctions'
  ];

  win.MainApp.Directives
    .directive('bgRangeLimit', bgRangeLimit);

}(window));
