(function(win) {
  "use strict";

  function disableCopypaste() {
    return {
      restrict: 'A',
      link: function(scope, element) {
        element.on('cut copy paste', function (event) {
          event.preventDefault();
        });        
      }
    };
  }
  disableCopypaste.$inject = [];
  win.MainApp.Directives
    .directive('disableCopypaste', disableCopypaste);
}(window));