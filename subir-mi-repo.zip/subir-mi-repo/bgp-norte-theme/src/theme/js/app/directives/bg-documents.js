(function (win) {
  "use strict";
  function bgDocuments(
    translateService,
    filter,
    isEmpty,
    dateFilter,
    popUpService,
    bgValue,
    documentCode,
    manageFile,
    storage,
    routeInvoker,
    alertNotifyService,
    jasperServices,
    reportsService,
    documentSizes,
    commonFunctions
  ){

    /*
     * additionalParticipants: Arreglo de participantes adicionales
     * masterForm: Formulario global para Validaciones
     * idQuote: id de la cotización
     * principalParticipant: participante principal
     * quote: Cotizacion, usada para cuando se llama a imprimir
     * user: Usuario que esta editando la Cotizacion
     * quoteDocument: documentos de la cotizacion
    */
    var directive = {
      restrict: 'E',
      templateUrl: window.baseThemeURL + 'partials/bg-documents.html',
      replace : true,
      scope : {
        additionalParticipants : '=',
        masterForm : '=',
        idQuote : '=',
        principalParticipant : '=',
        quote : '=',
        user : '=',
        quoteDocument: '=?',
        updateSessionObject: '=',
        uploadDocumentFn: '&',
        updatePrintedFn: '&',
        updateUploadedFn: '&',
        isDisableTabFn : '=',
        getAllDocumentFn: '&',
        downloadFileFn: '&',
        app: '@',
        findDataFlag: '@', //Bandera usada para saber si se busca data en sesion java
        stageQuote: '='
      },
      link : link
    };

    return directive;


    function link(scope){
      scope.btnDelete = btnDelete;
      scope.btnOpenDocumentManage = btnOpenDocumentManage;
      scope.btnSave = btnSave;
      scope.clickAddRowDocument = clickAddRowDocument;
      scope.countDocumentsForPrint = countDocumentsForPrint;
      scope.countDocumentsForUpload = countDocumentsForUpload;
      scope.countDocumentsUploaded = countDocumentsUploaded;
      scope.documentsConfig = {};
      scope.documentsConfig.mainParticipant = {};
      scope.documentsConfig.additionalParticipants = [];
      scope.getInfoEditDocument = getInfoEditDocument;
      scope.newDocument = {};
      scope.receivedIcon = receivedIcon;
      scope.showCommentDocument = showCommentDocument;
      scope.toggleFormDocument = toggleFormDocument;
      scope.validateButtonPrint = validateButtonPrint;
      scope.downloadFile = downloadFile;

      scope.uploadDocumentFn = scope.uploadDocumentFn();
      scope.updatePrintedFn = scope.updatePrintedFn();
      scope.updateUploadedFn = scope.updateUploadedFn();
      scope.getAllDocumentFn = scope.getAllDocumentFn();
      scope.downloadFileFn = scope.downloadFileFn();

      // Para trabajar de forma generica documentos de la cotizacion y
      // participante le agrego el entity
      if (!isEmpty(scope.quoteDocument)) {
        scope.quoteDocument.entityId = 0;
      }


      // Revisar porque puedo tener un arreglo de objetos donde uno represente el
      // formulario y el otro represente los dropdown de ocular documentos

      scope.showNewDocumentForm = [];

      scope.printDocuments = commonFunctions.getPrintDocuments(scope.app);

      init();

      function btnDelete (objWithDocuments, index){
        objWithDocuments.documents[index].received = false;
        var isDeleted = false;

        if (!isEmpty(objWithDocuments.documents[index].config) &&
        objWithDocuments.documents[index].config.inputComment) {
          objWithDocuments.documents.splice(index, 1);
          isDeleted = true;
        }

        if (!isDeleted) {
          var dlFile = manageFile.createDLFileWrapper(
            translateService.getValue(
              'constant.base.folder.process.type.tramite'),
            objWithDocuments.documents[index],
            storage.getProductConfig().ruleOperation, scope.idQuote,
            undefined, undefined, undefined, undefined, undefined);
          scope.updateUploadedFn(dlFile);
        }

        scope.updateSessionObject();
        scope.masterForm.$setDirty();
      }

      function btnOpenDocumentManage (objWithDocuments, isDocumentQuote, index){
        var document = objWithDocuments.documents[index];
        var entityId = isDocumentQuote ? undefined : objWithDocuments.entityId;
        var dlFile = manageFile.createDLFileWrapper(
          translateService.getValue('constant.base.folder.process.type.tramite'),
          document, storage.getProductConfig().ruleOperation, scope.idQuote,
          undefined, undefined, undefined, entityId,
          translateService.getValue('constant.base.subFolder.quote'), undefined);
        scope.getAllDocumentFn(dlFile)
        .then(function(response){
          var attrs = {
            bgPopupTitle: translateService.getValue('global.document.management'),
            bgPopupClass: "bg-modal-md",
            bgPopupTpl: 'partials/bgp-popup/bg-popup-document-management.html',
            bgPopupFromService: true,
            bgPopupMethod: uploadFile,
            bgPopupData: {
              files: response.data,
              newFile: {},
              isManagement: !scope.isDisableTabFn().upload,
              isShow: scope.isDisableTabFn().upload,
              document: document,
              downloadFile: downloadFile,
              entityId: entityId,
              wrapperBtnSave: {
                objWithDocuments: objWithDocuments,
                index: index
              }
            }
          };
          popUpService.open(attrs);
        })
        .catch(function(error){
          alertNotifyService.showErrorT('common-unexpected-error');
        });
      }
      function btnSave(objWithDocuments, index){
        objWithDocuments.documents[index].creationUser = {};
        objWithDocuments.documents[index].receivedDate = new Date();
        objWithDocuments.documents[index].creationUser.id = scope.user.id;
        objWithDocuments.documents[index].creationUser.name = scope.user.name;
        objWithDocuments.documents[index].received = true;
        scope.masterForm.$setDirty();
        var dlFile = manageFile.createDLFileWrapper(
          translateService.getValue(
            'constant.base.folder.process.type.tramite'),
          objWithDocuments.documents[index],
          storage.getProductConfig().ruleOperation, scope.idQuote,
          undefined, undefined, undefined, undefined, undefined);
        scope.updateUploadedFn(dlFile);
        scope.updateSessionObject();
      }
      function clickAddRowDocument(objWithDocuments){
        scope.newDocument.creationUser = {};
        scope.newDocument.name = filter('uppercase')(scope.newDocument.name);
        //si no existe el arreglo le seteo vacio para poder agregar el nuevo
        if (isEmpty(objWithDocuments.documents)) {
          objWithDocuments.documents = [];
        }
        scope.newDocument.config = {
          inputComment: true,
          showComment: false
        };
        scope.newDocument.order = 5000;
        scope.newDocument.status = "V";
        scope.newDocument.code = 'OTROS';
        scope.newDocument.type = documentCode.typeClm;
        scope.newDocument.required = false;
        scope.newDocument.printingRetoggleFormDocumentquired = false;
        scope.newDocument.uploadingRequired = false;
        scope.newDocument.printingWithDataRequired = false;
        scope.newDocument.printed = false;
        scope.newDocument.received = true;
        scope.newDocument.availableAction = true;
        scope.newDocument.creationDate = new Date();
        scope.newDocument.receivedDate = new Date();
        scope.newDocument.visible = true;
        scope.newDocument.creationUser.id = scope.user.id;
        scope.newDocument.creationUser.name = scope.user.name;
        objWithDocuments.documents.push(scope.newDocument);
        scope.toggleFormDocument(objWithDocuments.entityId);
        scope.masterForm.$setDirty();
        scope.updateSessionObject();
        scope.newDocument = {};
      }
      function countDocumentsForPrint(documents){
        var total = 0;
        angular.forEach(documents, function(value) {
          if (value.type === 'BG' && value.printingRequired &&
          !value.printed) {
            total++;
          }
        });
        return total;
      }
      function countDocumentsForUpload(documents) {
        var total = 0;
        angular.forEach(documents, function(value) {
          if (value.type === 'CLT' && value.uploadingRequired) {
            total++;
          }
        });
        return total;
      }
      function countDocumentsUploaded (documents){
        var total = 0;
        angular.forEach(documents, function(value) {
          if (value.type === 'CLT' && value.uploadingRequired &&
          !value.received) {
            total++;
          }
        });
        return total;
      }
      function documentCustom (documents){
        angular.forEach(documents, function(items) {
          if (isEmpty(items.received)) {
            items.received = false;
            items.printed = false;
          }
          if (isEmpty(items.creationUser)) {
            items.creationUser = {};
          }
          if (angular.isUndefined(items.config)) {
            items.config = {
              inputComment: false,
              showComment: false
            };
          }
        });
      }
      function getInfoEditDocument(document){
        var date = new Date(document.receivedDate);
        if (!document.received) {
          return translateService.getValue('global.pending');
        }
        return translateService.getValue('quote.file.upload.by',
          [document.creationUser.name.toUpperCase(),
          dateFilter(date,translateService.getValue('save.date.format.doc2'))
            .replace('.', '')]);
      }
      function init (){
        scope.showNewDocumentForm[scope.principalParticipant.entityId] = false;
        documentCustom(scope.principalParticipant.documents);

        angular.forEach(scope.additionalParticipants, function(value) {
          scope.showNewDocumentForm[value.entityId] = false;
          documentCustom(value.documents);
        });
      }
      function receivedIcon (classIcon){
        if (classIcon) {
          return 'fa-check-circle-custom';
        } else {
          return 'fa-times-circle-custom';
        }
      }
      function showCommentDocument (documentClient){
        if(isEmpty(documentClient.config)){
          return;
        }

       documentClient.config.showComment =
         !documentClient.config.showComment;
      }
      function toggleFormDocument (entityId){
       scope.newDocument = {};
       scope.showNewDocumentForm[entityId] =
         !scope.showNewDocumentForm[entityId];
      }
      function uploadFile(wrapper){
        manageFile.createDLFileWrapper64Promise(
          translateService.getValue('constant.base.folder.process.type.tramite'),
          wrapper.documentDTO, storage.getProductConfig().ruleOperation,
          scope.idQuote, wrapper.newFile.name, undefined, wrapper.newFile.file,
          wrapper.entityId, translateService.getValue('constant.base.subFolder.quote'),
          wrapper.newFile.type)
        .then(function(data){
          scope.uploadDocumentFn(data)
          .then(function(response){
            alertNotifyService.showSuccessT('quote.file.upload.notify');
            btnSave(wrapper.wrapperBtnSave.objWithDocuments, wrapper.wrapperBtnSave.index);
          })
          .catch(function(error){
            alertNotifyService.showErrorT('common-unexpected-error');
          });
        })
        .catch(function(error){
          alertNotifyService.showErrorT('common-unexpected-error');
        });

      }

      function selectDocumentCode(code) {
        switch (code) {
          case documentCode.cardApc:
          case documentCode.dataSheet:
          case documentCode.healthDeclaration:
          case documentCode.perfwla:
            return true;
          default:
            return false;
        }
      }
      function selectPdfCode(code){
        switch(code){
          case documentCode.regularTransferCard:
          case documentCode.exemptTaxTransferCard:
            return false;
          default:
            return true;
        }
      }

      function validateButtonPrint(objWithDocuments, index) {

        var attrs = {};

        var document = objWithDocuments.documents[index];

        // se valida que los camos esten llenos
        if (!canPrint(document)) {

         attrs = {
           bgPopupTitle: translateService.getValue(
             'quote.pending.save.data.print'), 
           bgPopupMessage: translateService.getValue(
             'report.save.quote.after.print'),
           bgPopupOkText: translateService.getValue('global.accept'),
           bgPopupTittleTwoLine: true
         };

         popUpService.open(attrs);

         return;
        }

        //Se llama la modal para confirmar impresion
        attrs = {
          bgPopupMethod: validatePrintDocument,
          bgPopupCancelText: translateService.getValue('car.quote.no.cancel'),
          bgPopupTpl: 'partials/bgp-popup/bg-popup-print-docs.html',
          bgPopupFromService: true,
          bgPopupData: {
            msg: translateService
            .getValue('global.print.document.msg',
            [documentSizes[document.code]]),
            paramObj:{
              documentIndex: index,
              objWithDocuments: objWithDocuments
            }
          }
        };

        popUpService.open(attrs);
      }

      function validatePrintDocument (paramObj) {

        var document = paramObj.objWithDocuments.documents[paramObj.documentIndex];
        var attrs = {};

        paramObj.wrapper = {
          procedureId: scope.idQuote,
          procedureState: scope.stageQuote.id,
          findDataFlag: scope.findDataFlag,
          productType: scope.app,
          // siempre enviar la informacion del principal y pisar solo cuando sea un documento del adicional
          entityId: scope.principalParticipant.entityId,
          printVersion: undefined
        };

        paramObj.getReportPromisesVar = reportsService
          .getReportPromises(document.code, scope.app);

        if (document.printingWithDataRequired) {
          //Se requieren datos para imprimir

          if (selectDocumentCode(document.code)) {

            //Documento de participante
            paramObj.wrapper.productPerson = paramObj.objWithDocuments;
            paramObj.wrapper.entityId = paramObj.objWithDocuments.entityId;

          } else {

            //Documento de cotizacion
            paramObj.wrapper.quote = scope.quote;
          }


          // Se valida que el documento tenga los servicios de impresion
          var pdfDocument = false;

          for (var key in documentCode) {
            if (documentCode[key] === document.code) {
              pdfDocument = true;
              break;
            }
          }

          if (!pdfDocument) {
            //No posee servicios de impresion

            alertNotifyService.showErrorT('error.documents.not.printed');
            return;
          }

          // llamar al validador
          paramObj.getReportPromisesVar.valid(paramObj.wrapper)
          .then(function(result) {
            if (isEmpty(result.data.sections)) {
              //Puedo imrpimir el documento

              printDocument(paramObj);
            } else {
              //Faltan datos para imprimir

              attrs = {
                bgPopupTitle: translateService
                  .getValue('quote.pending.data.print', [document.name]),
                bgPopupTpl: 'partials/bgp-popup/bg-popup-pendientes.html',
                bgPopupTittleTwoLine: true,
                bgPopupData: {
                  sections: result.data.sections,
                  documents: true
                }
              };

              popUpService.open(attrs);
            }
          });

        } else {
          // no se requieren datos para imprimir

          printDocument(paramObj);
        }

      }

      function printDocument (paramObj) {

        var document = paramObj.objWithDocuments.documents[paramObj.documentIndex];
        document.printed = true;

        var dlFile = manageFile.createDLFileWrapper(
          translateService.getValue(
            'constant.base.folder.process.type.tramite'),
          document, storage.getProductConfig().ruleOperation, scope.idQuote,
          undefined, undefined, undefined, paramObj.wrapper.entityId, undefined);

        var xrh = scope.updatePrintedFn(dlFile);
        xrh.then(function(response) {
            var documentClient = response.data;

            // // Actualizo el documento con la información traida
            // paramObj.participant.documents[index] = document;
            // scope.updateSessionObject();

            //Obtengo el numero de veces impresas del documento
            paramObj.wrapper.printVersion = documentClient.printVersion;

            paramObj.getReportPromisesVar
              .reportPromise(paramObj.wrapper).then(
              function (report) {

                updateInfoDocumentAfterPrint(paramObj.objWithDocuments,
                    true, paramObj.wrapper.printVersion, documentClient.code);

                // llamo a la funcion de imprimir documento
                jasperServices.openReport(report);

              }, function (data) {
                alertNotifyService.showErrorT('common-unexpected-error');
              });

        });

      }

      function updateInfoDocumentAfterPrint (objWithDocuments, printed, printVersion, documentCode) {

        angular.forEach(objWithDocuments.documents,
          function (document) {

            if (document.code === documentCode) {

              document.printVersion = printVersion;
              document.printed = printed;
              scope.updateSessionObject();
            }

        });
      }

      // Valida si el documento se puede imprimir revisando printDocuments
      // return true -> puede imprimir
      //        false -> no puede imprimir
      function canPrint(document){
        // Validar si existe en la lista de documentos especiales
        var auxPrintDocument = {};
        if (!isEmpty(scope.printDocuments[document.code])) {
          auxPrintDocument = scope.printDocuments[document.code];
        } else {
          //Si no es uno de los especificos seteo el valor de los default
          auxPrintDocument = scope.printDocuments[documentCode.defaultVal];
        }
        //Validaciones de formulario sucio
        if (scope.masterForm.$dirty && !auxPrintDocument.printWithDirtyForm) {
            return false;
        }
        //Validacion de solicitud nueva
        if (scope.idQuote === 0 && !auxPrintDocument.printWithNewQuote) {
          return false;
        }
        //Si no esta sucia la solicutud y no es nueva, puedo imprimir
        return true;
      }

      function downloadFile(dlFile, versionId){
        var query = angular.copy(dlFile);
        query.versionId = versionId;
        // query.updateDate = undefined;
        // query.createDate = undefined;
        var xrh = scope.downloadFileFn(query);
        xrh.then(function(response){
          if( response.data.extension=== 'pdf'){
            window.open(response.data.url, response.data.dlFileName, 'fullscreen=yes');
          } else {
            window.open(response.data.url);
          }
        }).catch(function(exception){
          alertNotifyService.showErrorT('common-unexpected-error');
        })
        .finally(function(){});
      }
    }
}

  bgDocuments.$inject =[
    'translateService',
    '$filter',
    'isEmptyFilter',
    'dateFilter',
    'bgPopUpService',
    'bgValueFilter',
    'bgDocumentCode',
    'manageFileService',
    'storageService',
    'routeInvoker',
    'alertNotifyService',
    'jasperServices',
    'reportsService',
    'bgDocumentSizes',
    'commonFunctions'
  ];

  win.MainApp.Directives
  .directive("bgDocuments", bgDocuments);
}(window));
