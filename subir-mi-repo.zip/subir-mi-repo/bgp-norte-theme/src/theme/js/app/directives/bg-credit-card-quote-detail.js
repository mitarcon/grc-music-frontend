(function(win) {
'use strict';

function bgCreditCardQuoteDetail(
  $log,
  buildAccountList,
  bgValue,
  isEmpty,
  filter
){

$log.debug("[bg-credit-card-quote-detail] Initializing...");

  return {
    restrict: 'E',
    scope: {
      principalParticipant: '=',
      additionalParticipants: '=',
      limitSelected: '=',
      executeBusinessRuleFn: '&',
      app: '=?',
      paymentMethod: '=',
      customerAccounts: '=',
      procedureId: '=',
      canShowPledge: '=',
      creditCardQuote: '='
    },

    templateUrl: window.baseThemeURL +
      'partials/bg-credit-card-quote-detail.html',
    link: function (scope, element, attrs){
      /*
      ===============
      VALUES
      ===============
      */

      var cardPlastic = scope.principalParticipant.cardPlastic;
      scope.hasPlastic =isEmpty(cardPlastic) ? false : !cardPlastic;
      scope.ownershipDescription = undefined;
      scope.lenghtNameTDC = parseInt(bgValue('lenghtNameTDC'));

      init();
      /*
      ===============
      METHODS
      ===============
      */
      scope.validateNameTDC=validateNameTDC;
      scope.showPlasticRequired=showPlasticRequired;
      scope.executeHasPlastic=executeHasPlastic;
      scope.chkBenefitBehavior=chkBenefitBehavior;
      scope.deleteAdditionalClient=deleteAdditionalClient;
      scope.setDefaultSharedLimit=setDefaultSharedLimit;
      scope.buildAccount=buildAccount;
      scope.getOwnerShip=getOwnerShip;
      scope.showOwnerShip=showOwnerShip;
      scope.clearAccounts=clearAccounts;
      scope.changeOriginInfoType = changeOriginInfoType;
      scope.changeDeliveryInfoType = changeDeliveryInfoType;
      scope.changeDeliveryTypeBg = changeDeliveryTypeBg;




      function validateNameTDC(participant, typeName) {

        if (typeName === 'firstname') {

          participant.creditCard.cardholderName =
            validateCreditCardName(participant.creditCard.cardholderName);

        } else if (typeName === 'lastname') {

          participant.creditCard.cardholderLastName =
            validateCreditCardName(participant.creditCard.cardholderLastName);

        }
        
      }

      function validateCreditCardName(value) {
        if (!isEmpty(value)){
          value = value.trim();
          value = replaceApostrophe(value);
          value = replaceEnie(value);
          value = value.trim();
          value = value.toUpperCase();
          return value;
        }
      }

      function replaceApostrophe (value) {
        return value.replace(/'/g, ' ');
      }

      function replaceEnie(value) {
        return value.replace(/['ñ'||'Ñ']/g, 'N');
      }

      function showPlasticRequired(){
        if(scope.additionalParticipants.length > 0){
          return true;
        }
        scope.principalParticipant.cardPlastic = true;
        scope.hasPlastic = false;
        return false;
      }

      function executeHasPlastic(){
        scope.principalParticipant.cardPlastic = !scope.hasPlastic;
      }

      function chkBenefitBehavior() {
        if (!isEmpty(scope.principalParticipant.creditCard) && (
            scope.principalParticipant.creditCard.benefit.id ===
            bgValue('codeBenefit').mileagePlus ||
            scope.principalParticipant.creditCard.benefit.id ===
            bgValue('codeBenefit').connectMilles)) {
            return true;
        }
        return false;
      }

      // Delete an additional client from list
      function deleteAdditionalClient(index) {
        scope.additionalParticipants.splice(index, 1);
        scope.executeBusinessRuleFn();
      }

      // Set the default Shared Limit for additional participant
      function setDefaultSharedLimit(creditCard){
        if(!isEmpty(creditCard)) {
          creditCard.limit = creditCard.sharedLimit ?
          scope.limitSelected : undefined;
        }
      }

       function clearAccounts(){
         scope.principalParticipant.creditCard.paymentInfo.account={};
         scope.principalParticipant.creditCard.paymentInfo.paymentType = {};
         scope.ownershipDescription=undefined;
       }

       function buildAccount(account, accountName) {
         return buildAccountList(account, accountName);
       }

       function showOwnerShip() {
         return (!isEmpty(scope.ownershipDescription)) &&
         (scope.ownershipDescription !== '');
       }

       function getOwnerShip(){
         var data=scope.principalParticipant.creditCard.paymentInfo.account.id;
         scope.ownershipDescription=getAccountByNumber(data);
       }

      function getAccountByNumber (accountNumber) {
        if (isEmpty(accountNumber)){
          return;
        }
        var accounts = filter(scope.customerAccounts, function(item) {
          if (!isEmpty(item.account)) {
            return item.account.trim() === accountNumber.trim();
          }
        });

        if (!isEmpty(accounts)) {
          var ownerShip=accounts[0].ownershipDescription;
          return ownerShip;
        }
      }

       function init(){

         if (isEmpty(scope.principalParticipant.creditCard.deliveryInfo)) {
           scope.principalParticipant.creditCard.deliveryInfo = {
             branchOffice:{},
             deliveryAddress:{}
           };
         }

         if (isEmpty(scope.principalParticipant.creditCard.paymentInfo.paymentType)) {
           scope.principalParticipant.creditCard.paymentInfo.paymentType = {};
         }

         if (isEmpty(scope.principalParticipant.creditCard.
         paymentInfo.receiveAccountStatement)) {
           scope.principalParticipant.creditCard.
           paymentInfo.receiveAccountStatement = {
             branchOffice:{}
           };
         }
       }

       function changeOriginInfoType () {

          if (!isEmpty(scope.principalParticipant.creditCard) &&
           !isEmpty(scope.principalParticipant.creditCard.originInfo) &&
           !isEmpty(scope.principalParticipant.creditCard.originInfo.type) ) {

             switch (scope.principalParticipant.creditCard.originInfo.type.id) {

               case bgValue('codCatalogTDCDetails').originDeliveryType.sucursal:

                 scope.principalParticipant.creditCard.originInfo.otherChannel = undefined;
                 break;

               case bgValue('codCatalogTDCDetails').originDeliveryType.otrosCanales:

                 scope.principalParticipant.creditCard.originInfo.branchOffice = undefined;
                 break;

               default:
                 // TODO: Modal de alerta
                 return null;
             }
          }

        }

       function changeDeliveryInfoType () {

         if (!isEmpty(scope.principalParticipant.creditCard) &&
          !isEmpty(scope.principalParticipant.creditCard.deliveryInfo) &&
          !isEmpty(scope.principalParticipant.creditCard.deliveryInfo.deliveryType) ) {

            switch (scope.principalParticipant.creditCard.deliveryInfo.deliveryType.id) {

              case bgValue('codCatalogTDCDetails').deliveryType.mensajeria:

                scope.principalParticipant.creditCard.deliveryInfo.deliveryTypeBg = undefined;
                scope.principalParticipant.creditCard.deliveryInfo.branchOffice = undefined;
                scope.principalParticipant.creditCard.deliveryInfo.otherChannel = undefined;
                break;

              case bgValue('codCatalogTDCDetails').deliveryType.bg:

                scope.principalParticipant.creditCard.deliveryInfo.deliveryAddress = undefined;
                scope.principalParticipant.creditCard.deliveryInfo.secondDeliveryAddress = undefined;
                break;

              default:
                // TODO: Modal de alerta
                return null;
            }
         }

       }

       function changeDeliveryTypeBg () {

         if (!isEmpty(scope.principalParticipant.creditCard) &&
          !isEmpty(scope.principalParticipant.creditCard.deliveryInfo) &&
          !isEmpty(scope.principalParticipant.creditCard.deliveryInfo.deliveryTypeBg) ) {

            switch (scope.principalParticipant.creditCard.deliveryInfo.deliveryTypeBg.id) {

              case bgValue('codCatalogTDCDetails').deliveryTypeBg.sucursal:

                scope.principalParticipant.creditCard.deliveryInfo.otherChannel = undefined;
                break;

              case bgValue('codCatalogTDCDetails').deliveryTypeBg.otrosCanales:

                scope.principalParticipant.creditCard.deliveryInfo.branchOffice = undefined;
                break;

              default:
                // TODO: Modal de alerta
                return null;
            }
         }

       }

    }
  };

}

bgCreditCardQuoteDetail.$inject = [
  '$log','buildAccountListFilter',
  'bgValueFilter','isEmptyFilter', 'filterFilter',
];

win.MainApp.Directives
  .directive("bgCreditCardQuoteDetail",bgCreditCardQuoteDetail);

}(window));
