(function(win) {
  "use strict";

  function bgPattern(patterns, isEmpty) {

    var isValid = function isValid(value, key) {
      if (isEmpty(value) || isEmpty(value.trim())) {
        return true;
      } else {
        var REGEXP = patterns[key];
        if (angular.isDefined(REGEXP)) {
          return REGEXP.test(String(value));
        }
        return true;
      }
    };

    return {
      require: 'ngModel',
      restrict: 'A',
      link: function(scope, elem, attrs, ctrl) {

        //For DOM -> model validation
        ctrl.$parsers.unshift(function(viewValue) {
          ctrl.$setValidity(attrs.bgPattern,
            isValid(viewValue, attrs.bgPattern));
          return viewValue;
        });

        //For model -> DOM validation
        ctrl.$formatters.unshift(function(viewValue) {
          ctrl.$setValidity(attrs.bgPattern,
            isValid(viewValue, attrs.bgPattern));
          return viewValue;
        });

      }
    };
  }

  bgPattern.$inject = ['bgPatternsList', 'isEmptyFilter'];

  win.MainApp.Directives.directive('bgPattern', bgPattern);

}(window));
