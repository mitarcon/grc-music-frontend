(function(win) {
  'use strict';

  function bgClientDetailTask(
    isEmpty,
    commonFunctions,
    scoringPhaseStatus,
    log,
    bgValue,
    filter,
    popUpService
  ) {

    return {
      restrict: 'E',
      scope: {
        'executeBusinessRule': '&',
        'participant': '=',
        'isPrincipal': '=',
        'updateSession': '&',
        'ruleOperation': '=',
        'quoteId': '=',
        'stageId': '=',
        'statusId': '=',
        'isDisabledQuote': '&',
        'roleChange': '&',
        'deleteParticipant': '&',
        'isDisableTab':'=',
        'app':'=',
        'product':'='
      },
      template: '<div ng-include="template"></div>',
      link: link
    };

    function link(scope) {
      scope.template = window.baseThemeURL +
        'partials/bg-client-detail-task.html';
      scope.alertMissingFields = alertMissingFields;
      scope.changeAdditionalRole = changeAdditionalRole;
      scope.changeRelationship = changeRelationship;      
      scope.creditHistoryIcon = creditHistoryIcon;
      scope.getAPCDocumentNumber = getAPCDocumentNumber;
      scope.getAPCIdentificationType = getAPCIdentificationType;
      scope.getLastEmailContact = getLastEmailContact;
      scope.getLastPhoneContact = getLastPhoneContact;
      scope.goToCustomer = goToCustomer;
      scope.openAdditionalApc = openAdditionalApc;

      scope.isDisabledQuote = scope.isDisabledQuote();
      scope.updateSession = scope.updateSession();

      scope.deleteParticipant = scope.deleteParticipant();
      function alertMissingFields(){

      }

      function changeAdditionalRole(participant){
        var roleChangeWrapper = {
          participant : participant
        };
        //TODO: Debo ejecutar las acciones del rolChange en el controlador que
        // llama a la directiva
        scope.roleChange(roleChangeWrapper);
      }
      
      function changeRelationship() {
        scope.executeBusinessRule()(null, null, true);
      }

      function creditHistoryIcon (record) {
        if (record === bgValue('creditHistory').good) {
          return {
            icon: 'check-circle',
            color: 'verde'
          };
        } else if (record === bgValue('creditHistory').regular) {
          return {
            icon: 'exclamation-circle',
            color: 'amarillo'
          };
        } else if (record === bgValue('creditHistory').higher) {
          return {
            icon: 'exclamation-circle',
            color: 'rojo'
          };
        }
      }
      function getAPCDocumentNumber(documentNumber, documentType){
        return commonFunctions
         .getAPCDocumentNumber(documentNumber, documentType);
      }
      function getAPCIdentificationType(documentNumber, documentType){
        return commonFunctions.getAPCIdentificationType(documentNumber,
            documentType);
      }
      function getLastEmailContact(participant){
        var emails;
        if (!isEmpty(participant.contactData)) {
          emails = participant.contactData.filter(function(obj) {
            return obj.type.id === 'M';
          });
          if (!angular.isUndefined(emails) && emails.length > 0) {
            emails = filter('orderBy')(emails, '-modificationDate')[0].name;
          }else{
            emails = '';
          }
        }
        return emails;
      }
      function getLastPhoneContact (participant) {
        var phones;
        if (!isEmpty(participant.contactData)) {
          phones = participant.contactData.filter(function(obj) {
            return obj.type.id === 'C';
          });
          if (!angular.isUndefined(phones) && phones.length > 0) {
            phones = filter('orderBy')(phones,
              '-modificationDate')[0].name;
          } else {
            phones = "";
          }
          return phones;
        }
      }
      function goToCustomer (participant, disabled) {
        var withProduct = false;
        scope.updateSession()
        .then(function() {
          var isDataSheetPrinted;
          var isDataSheetPrintedRequired;

          angular.forEach(participant.documents,
          function(document) {
            if (document.code === bgValue('bgDocumentCode').dataSheet) {
              isDataSheetPrinted = document.printed;
              isDataSheetPrintedRequired = document.printingRequired;
            }
          });
          commonFunctions.goToCustomer(scope, participant,
            scope.isPrincipal, disabled, scope.product,
            scope.quoteId, scope.stageId, scope.statusId,
            isDataSheetPrinted, isDataSheetPrintedRequired, withProduct);
        },
        function (data){
          //commonFunctions.callMessageError(data);
        });
      }
      function openAdditionalApc() {
        var attrs = {
          bgPopupMethod: scope.setApcDataAdditionalParticipant,
          bgPopupCancelMethod: scope.setApcDataAdditionalParticipant,
          bgPopupTpl: 'partials/bgp-popup/bg-popup-apc-additional.html',
          bgPopupFromService: true,
          bgPopupData: {
            participant: scope.participant,
            ruleFn: scope.executeBusinessRule,
            apcFilter: {
              product: {
                id: scope.product
              },
              quoteCode: scope.quoteId,
              customerId: scope.participant.entityId,
              identificationType: getAPCIdentificationType(
                scope.participant.documentNumber,
                scope.participant.documentType),
              identification: getAPCDocumentNumber(scope.participant.documentNumber,
                scope.participant.documentType),
              forceUpdate: false,
              addHouseRentalObligation: false
            },
            getPrintApcLetterWrapper: scope.getPrintApcLetterWrapper,
            getApcDataAdditionalParticipant: scope.getApcDataAdditionalParticipant,
            setApcDataAdditionalParticipant: scope.setApcDataAdditionalParticipant,
            disabledField: scope.isDisabledQuote(),
            app: scope.app,
            showLoading: scope.showLoading
          },
          bgPopupClass: "bg-modal-lg"
        };
        popUpService.open(attrs);
      }
    }
  }
  bgClientDetailTask.$inject = [
    'isEmptyFilter',
    'commonFunctions',
    'scoringPhaseStatus',
    '$log',
    'bgValueFilter',
    '$filter',
    'bgPopUpService'
  ];

  win.MainApp.Directives
    .directive('bgClientDetailTask', bgClientDetailTask);

}(window));
