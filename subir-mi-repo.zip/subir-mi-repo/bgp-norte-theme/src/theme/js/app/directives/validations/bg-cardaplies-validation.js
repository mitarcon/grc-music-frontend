(function (win){
  'use strict';

    function bgCardApplies() {

      var validateApplies = function(applies){
        if (applies === "true"){
          return true;
        } else {
          return false;
        }
      };

      return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, elm, attrs, ctrl) {
          ctrl.$parsers.unshift(function (viewValue) {
            var valid = validateApplies(attrs.bgCardAppliesVal);
            ctrl.$setValidity('bgCardApplies', valid);
            return viewValue;
          });

          //For model -> DOM validation
          ctrl.$formatters.unshift(function (viewValue) {
            var valid = validateApplies(attrs.bgCardAppliesVal);
            ctrl.$setValidity('bgCardApplies', valid);
            return viewValue;
          });
        }
      };
    }
  bgCardApplies.$inject =[];
  win.MainApp.Directives
    .directive('bgCardApplies', bgCardApplies);
}(window));
