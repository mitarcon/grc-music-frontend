/* globals angular, appName */

(function (win) {
    "use strict";

    function atLeastOneNumberValidator() {
        return {
            require : 'ngModel',
            link : function(scope, element, attrs, ngModel) {

                ngModel.$parsers.push(function(value) {
                    var rgexp = /([0-9])+/i;
                    var result = !!rgexp.test(value);

                    ngModel.$setValidity('atLeastOneNumber', result);

                    return value;
                });
            }
        };
    }

    angular
        .module(appName + ".directives")
        .directive('atLeastOneNumberValidator', atLeastOneNumberValidator);

    atLeastOneNumberValidator.$inject = ['$timeout'];
}(window));
