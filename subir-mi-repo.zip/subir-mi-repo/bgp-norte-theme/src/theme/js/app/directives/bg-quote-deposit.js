(function(win) {
  'use strict';

  function bgQuoteDeposit(isEmpty, commonFunctions, log, paramService) {
    log.debug('[bgQuoteDeposit] Initializing....');

    return {
      restrict: 'E',
      replace : true,
      scope : {
        blurAmount:'&',
        blurPercentage:'&',
        depositAmount:'=',
        depositPercentage:'=',
        focusPercentDeposit:'&',
        focusAmountDeposit:'&',
        disabled: "=",
        message : '=',
        hasErrorDecimalPercentage:'&',
        hasErrorLengthPercentage:'&'
      },
      templateUrl: window.baseThemeURL + 'partials/bg-quote-deposit.html',

      link: function(scope) {


      }
    };
  }
  /*CONFIGURATION*/
    bgQuoteDeposit.$inject = ['isEmptyFilter',
                                 'commonFunctions',
                                 '$log',
                                 'bgParamsService',
    ];

  win.MainApp.Directives.directive('bgQuoteDeposit', bgQuoteDeposit);
}(window));
