(function (win) {
  "use strict";

  function bgInputCharacterCounter(log, compile) {
    log.debug("[bgInputCharacterCounter] Initializing....");

    return {
      restrict: "A",
      replace: true,
      require: 'ngModel',
      scope: {
        model: '=?ngModel',
        bgInputCharacterCounterMinorEqual: '@'
      },
      link: function (scope, elem, attrs, ngModel) {

        var textRed = "text-color-brand-red";
        var textOrange = "text-color-brand-orange";
        var textGray = "text-color-gray-variation-3";

        scope.getClass = function () {

          if (!attrs.maxlength || !scope.model || !scope.bgInputCharacterCounterMinorEqual) return textGray;

          if (scope.model.length == attrs.maxlength) {
            return textRed;
          } else if ((attrs.maxlength - scope.model.length) <= scope.bgInputCharacterCounterMinorEqual) {
            return textOrange;
          } else {
            return textGray;
          }

        };

        if (attrs.maxlength) {

          scope.maxlength = attrs.maxlength;

          var elementCompile = compile('<span class="pls input-character-counter" ng-class="getClass()" >{{maxlength - model.length}}</span>')(scope);

          elem.after(elementCompile);
        }

      }
    };
  }

  bgInputCharacterCounter.$inject = [
    "$log",
    "$compile"
  ];

  win.MainApp.Directives.directive("bgInputCharacterCounter", bgInputCharacterCounter);
})(window);
