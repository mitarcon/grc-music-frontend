/* globals angular, appName */

(function (win) {
    "use strict";

    function atLeastOneLetterValidator() {
        return {
            require : 'ngModel',
            link : function(scope, element, attrs, ngModel) {

                ngModel.$parsers.push(function(value) {
                    var rgexp = /([A-Za-z])+/i;
                    var result = !!rgexp.test(value);

                    ngModel.$setValidity('atLeastOneLetter', result);

                    return value;
                });
            }
        };
    }

    angular
        .module(appName + ".directives")
        .directive('atLeastOneLetterValidator', atLeastOneLetterValidator);

    atLeastOneLetterValidator.$inject = ['$timeout'];
}(window));
