(function(win) {
  'use strict';

  function bgApcTab(log, apcFlagOptions, isEmpty,
    storage, jasperServices, reportsService, bgDocumentCode, bgValue,
    buildClientNameService
    //lang
  ) {

    log.debug("[bg-Apc-Tab] Initializing...");
    /*
    ==============
    VALUES
    ==============
    */

    return {
      scope: {
        data: '=',
        printApcLetterWrapper: '&',
        app:'='
      },
      restrict: 'E',
      template: '<div ng-include="template"></div>',

      link: function(scope) {
        scope.template = window.baseThemeURL + 'partials/bg-apc-tab.html';
        scope.ipcWrapper = storage.getIpcWrapper(scope);

        scope.radioAPC = {};
        scope.signApc = false;
        var printApcPromises = reportsService.getReportPromises(bgDocumentCode.cardApc,
        scope.app);

        /*
              ==============
              METHODS
              ==============
          		*/
        scope.goToPrint = function() {
          scope.postPrint = true;
          scope.final = false;
          scope.getCreditReferencesReport();
          scope.signApc = true;
        };

        if (scope.data.entityId === 0 || !scope.data.apcData.apcFlag) {
          scope.final = false;
        } else {
          scope.final = true;
        }

        if (scope.data.apcData.apcFlag) {
          scope.radioAPC.signAPCval = apcFlagOptions.mark;
        } else if (scope.data.apcData.apcTemporaryFlag) {
          scope.radioAPC.signAPCval = apcFlagOptions.tempMark;
        } else {
          scope.radioAPC.signAPCval = undefined;
        }

        scope.signAPC = function(signApcFinal) {

          if (!isEmpty(signApcFinal) && signApcFinal === apcFlagOptions.mark) {
            scope.data.apcData.apcFlag = true;
            storage.updateApcDataProperty(scope, true,
              'apcFlag');
            scope.data.apcData.apcTemporaryFlag = false;
            storage.updateApcDataProperty(scope, false,
              'apcTemporaryFlag');
            scope.final = true;
          }

          if (scope.radioAPC.signAPCval === apcFlagOptions.mark) {

            scope.data.apcData.apcFlag = true;
            storage.updateApcDataProperty(scope, true,
              'apcFlag');
            scope.data.apcData.apcTemporaryFlag = false;
            storage.updateApcDataProperty(scope, false,
              'apcTemporaryFlag');

          } else if (scope.radioAPC.signAPCval === apcFlagOptions.tempMark) {

            scope.data.apcData.apcTemporaryFlag = true;
            storage.updateApcDataProperty(scope, true,
              'apcTemporaryFlag');
            scope.data.apcData.apcFlag = false;
            storage.updateApcDataProperty(scope, false,
              'apcFlag');

          }
        };

        scope.signAPC();
        var wrapper = {
          productType: bgValue('apps').wizard,
          productPerson: scope.data
        };
         scope.getCreditReferencesReport = function() {
           
            wrapper.productPerson.completeName =
              buildClientNameService.getName(wrapper.productPerson);

           printApcPromises.reportPromise(wrapper)
             .then(function(report) {
               jasperServices.openReport(report);
             });
         };

        log.debug("[bg-Apc-Tab] closing...");
      }
    };
  }

  /*
  ===============
  CONFIGIRATION
  ===============
  */
  bgApcTab.$inject = ['$log',
    'apcFlagOptions',
    'isEmptyFilter',
    // 'commonFunctions'
    'storageService',
    'jasperServices',
    'reportsService',
    'bgDocumentCode',
    'bgValueFilter',
    'buildClientNameService'
    //'lang'

  ];
  win.MainApp.Directives
    .directive("bgApcTab",
      bgApcTab);

}(window));
