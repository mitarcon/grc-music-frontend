(function(win){
  'use strict';

  function bgQuoteHeader(filter, isEmpty, trans, popUpService, recalculateMsg,
    findDifferencesService, bgRedirectService, commonFunctions, alertNotifyService,
    storageService){

    return {
      restrict: 'E',
      scope: {
        previousVersion:"=",
        mainParticipant: '=',
        additionalParticipants: '=',
        stage: '=',
        status: '=',
        channel: '=',
        totalSalary: '=',
        creditHistory: '=',
        compliesWithEmployment: '=',
        quoteId: '=',
        user: '=',
        updateSessionFn: '&',
        isDisabledQuoteFn: '&',
        services: '=',
        setQuoteScopeFn: '=',
        tabsWithErrors: '=',
        quoteMasterForm: '=',
        printQuote: '=',
        getQuoteFn: '&',
        cancelQuoteFn: '&',
        sendToAssessFn: '&',
        product: '@',
        executeBusinessRuleFn: '&',
        isSaveButtonDisabledFn: '&',
        differenceFlag: '=',
        dirtyFormFlag: '=',
        initFn: '&',
        validationList: '=',
        differenceObjHolder: '=',
        app:'@',
        availableOptions: '=',
        task: '=',
        quoteFinished: '=',
        sharedService: '='
      },
      templateUrl: window.baseThemeURL +
        'partials/bg-quote-header/bg-quote-header.html',
      link: link
    };

    function link(scope, element, attrs){
    //console.log("taskAssignedTo:",taskAssignedTo);
      /*
      ===============
      VALUES
      ===============
      */

      scope.pendingFields = true;
      scope.quoteIsSaved = false;
      scope.validationList.clients = [];

      init();

      /*
       ===============
       METHODS
       ===============
       */
      scope.cancelQuote = cancelQuote;
      scope.getExceptionsLength = getExceptionsLength;
      scope.openModalExeption = openModalExeption;
      scope.openModalOptions = openModalOptions;
      scope.openModalNext = openModalNext;
      scope.openModalMissingfield = openModalMissingfield;
      scope.reviewData = reviewData;
      scope.saveQuote = saveQuote;
      scope.setMessages = setMessages;
      scope.formatQuoteId = formatQuoteId;
      scope.validateModal = validateModal;
      scope.reviewDataDisabled = reviewDataDisabled;

      function cancelQuote() {
        var attrs = {
          bgPopupTitle: trans.getValue('quote.header.cancel'),
          bgPopupMessage: trans.getValue('quote.cancel.quote.message'),
          bgPopupOkText: trans.getValue('car.quote.cancel.reject'),
          bgPopupCancelText: trans.getValue('car.quote.no.cancel'),
          bgPopupFromService: true,
          bgPopupMethod: changeToCancel
        };
        popUpService.open(attrs);
      }

      function changeToCancel () {
        scope.pendingFields = true;
        if (scope.quoteId !== 0) {
          scope.cancelQuoteFn({
            params: {
              quoteCode: scope.quoteId
            }
          });
          scope.status.id = trans
            .getValue('constant.update.status.param.cancel');
        } else {
          scope.status = {};
          scope.status.id = trans
            .getValue('constant.update.status.param.cancel');

        }
      }

      function changeToSendToAssess() {
        scope.sendToAssessFn(
        {
          params : {
            quoteCode: scope.quoteId
          },
          callback: printMemo
        });
        scope.stage.id = filter('bgValue')('scoringPhaseStatus').evaluationPhase;
      }

      function init(){
        if(scope.quoteFinished === false && scope.quoteId !== 0 &&
          scope.stage.id === filter('bgValue')('scoringPhaseStatus').scoringPhase
        ){

          scope.services.validateQuote(scope.getQuoteFn())
            .then(function(response) {

              scope.sections = response.data.sections;
              scope.pendingFields = false;
              scope.quoteIsSaved = true;
              setMessages();
            }, function(data) {
              /*
               * TODO: necesario hacer las llamadas para mostrar mensajes
               */
              //commonFunctions.callMessageError(data);
            });

        }
        // else {
        //   scope.pendingFields = false;
        // }
      }

      function getExceptionsLength() {
       var count = 0;
       if (!isEmpty(scope.additionalParticipants)) {
         angular.forEach(scope.additionalParticipants,
           function(participant) {
             if (!isEmpty(participant.exceptions)) {
               count += participant.exceptions.length;
             }
           });
       }

       if (!isEmpty(scope.mainParticipant.exceptions)) {
         count += scope.mainParticipant.exceptions.length;
       }
       return count;
      }

      function openModalExeption(){
        var attrs = {
          bgPopupData: {
            previousVersion: scope.previousVersion,
            mainParticipant: angular.copy(scope.mainParticipant),
            additionalParticipants: angular.copy(scope.additionalParticipants),
            selectedClient: scope.mainParticipant.entityId,
            isDisabled: scope.isDisabledQuoteFn(),
            app: scope.app
          },
          bgPopupClass: "bg-modal-sm",
          bgPopupTpl: 'partials/bgp-popup/bg-popup-exceptions.html',
          bgPopupMethod: updateParticipantsExeptions,
          bgPopupFromService: true
        };
        popUpService.open(attrs);
      }

      function reasonGroupFn(item){
        if(item.reason.secondLevelName !== " "){
          return item.reason.name;
        }
      }

      function openModalOptions(availableOptions, stage){

        var attrs = {
          bgPopupData: {
            availableOptions: availableOptions,
            reasonGroupFn: reasonGroupFn,
            app: scope.app,
            operation: filter('bgValue')('routingTaskOptionsTypes').optionButtonVal,
            stage: stage
          },
          bgPopupClass: "bg-modal-md",
          bgPopupTpl: 'partials/bgp-popup/bg-popup-options.html',
          bgPopupMethod: selectTaskOptions,
          bgPopupFromService: true
        };
        popUpService.open(attrs);
      }

      function openModalNext(user){

        scope.taskUser = user;
        var attrs = {
          bgPopupData: {
            services: scope.services,
            user: scope.taskUser,
            quoteId: scope.quoteId,
            availableOptions: scope.availableOptions,
            sharedService: scope.sharedService,
            product: scope.product
          },
          bgPopupClass: "bg-modal-md extended-popup",
          bgPopupTpl: 'partials/bgp-popup/bg-popup-next.html',
          bgPopupFromService: true        };
          popUpService.open(attrs);
      }

      function printMemo(){
        var attrs = {
          bgPopupTitle: trans.getValue('quote.sended.quote'),
          bgPopupMessage: trans.getValue('quote.sended.quote.message'),
          bgPopupOkText: trans.getValue('quote.print.memo'),
          bgPopupCancelText: trans.getValue('global.close'),
          bgPopupFromService: true,
          bgPopupMethod: printMemoDocument
        };
        popUpService.open(attrs);
      }

      function printMemoDocument() {
        var quote = scope.getQuoteFn();
        var getReportPromisesVar = reportsService
          .getReportPromises(bgDocumentCode.preca);
        getReportPromisesVar.valid(quote)
          .then(function(result) {

           if (isEmpty(result.data.sections)) {
            getReportPromisesVar.reportPromise(quote)
              .then(function(report) {
                 jasperServices.openReport(report);
               }, function(data) {
                //  TODO: Llamada a errores
               });
           } else {
             var attrs = {
               bgPopupTitle: trans.getValue('car.documents.empty.fields'),
               bgPopupTpl: 'partials/bgp-popup/bg-popup-pendientes.html',
               bgPopupData: {
                 sections: result.data.sections
               }
             };
             popUpService.open(attrs);
           }
         });
       }

      function resetExceptions(exceptions){
        if(!isEmpty(exceptions)){
          exceptions = exceptions.filter(function(obj) {
            return obj.isNew === false || obj.isNew === undefined;
          });
        }
        return exceptions;
      }

      function reviewData (participant, isPrincipalParticipant, disabled, withProduct){
       scope.updateSessionFn()
         .then(function() {
           var isDataSheetPrinted;
           var isDataSheetPrintedRequired;

           angular.forEach(participant.documents, function(document) {
             if (document.code ===
              filter('bgValue')('bgDocumentCode').dataSheet) {
               isDataSheetPrinted = document.printed;
               isDataSheetPrintedRequired = document.printingRequired;
             }
           });

           commonFunctions.goToCustomer(scope, participant,
             isPrincipalParticipant, disabled, scope.product,
             scope.quoteId, scope.stage.id, scope.status.id,
             isDataSheetPrinted, isDataSheetPrintedRequired, withProduct);

         }, function(data){
           /*
           * TODO: Funcion para llamar a los errores
           */
         });
      }

      function saveQuote() {

        scope.services.saveQuote(scope.getQuoteFn())
          .then(function(response) {
            scope.sections = response.data.sections;
            scope.pendingFields = false;
            scope.quoteIsSaved = true;
            scope.differenceFlag = false;
            // colocar nuevamente
            scope.dirtyFormFlag.flagDirty = false;
            scope.setQuoteScopeFn(response.data.resultType, true);

            scope.quoteMasterForm.$setPristine(true);

            scope.printQuote.disabled = false;

            // si es una cotización nueva debo setear el id de la cotizacion en el storage
            var product = storageService.getIpcWrapperTask(scope).product;
            if(isEmpty(product.id) ||  product.id === 0){

              storageService.updateProductId(scope, response.data.resultType.id);
            }


            scope.services.findDifferences(response.data.resultType.id)
              .then(function (response) {
                scope.differenceObjHolder.outdatedMessages = [];
                findDifferencesService.setOutdatedMessages(
                  scope.differenceObjHolder, response.data);
            }, function(data) {
              alertNotifyService.showError(
                      trans.getValue('constant.error.unexpected'));
            });

            if(scope.stage.id !==
            filter('bgValue')('scoringPhaseStatus').evaluationPhase){
              scope.services.validateQuote(scope.getQuoteFn())
                 .then(function(response) {
                   scope.sections = response.data.sections;
                   setMessages();
                 }, function(data) {
                   alertNotifyService.showError(
                           trans.getValue('constant.error.unexpected'));
                 });

            }
            scope.services.findTaskByQuoteIdFromSession(response.data.resultType.id)
              .then(function(response) {
                scope.sharedService.task = response.data.task;
                scope.availableOptions = response.data.availableOptions;
              }, function(data) {
                alertNotifyService.showError(
                     trans.getValue('constant.error.unexpected'));
            });
            saveQuoteModal(response.data.sections);

          }).catch(function(data) {
            alertNotifyService.showError(
                    trans.getValue('constant.error.unexpected'));
          });
      }

      scope.enableNextMove = function() {
        if(!scope.quoteIsSaved || scope.status.id ===
          trans.getValue('constant.update.status.param.cancel') ||
          scope.quoteFinished ||
          !isEmpty(scope.differenceObjHolder.stopServiceList) ||
          (angular.isDefined(scope.quoteMasterForm) &&
            (scope.quoteMasterForm.$dirty || !scope.quoteMasterForm.$valid)) ||
          (angular.isDefined(scope.dirtyFormFlag) &&
            scope.dirtyFormFlag.flagDirty) || scope.pendingFields ||
          !haveOption(filter('bgValue')('routingTaskOptionsTypes').nextButtonVal) ||
          scope.quoteId === 0 ||
          scope.stage.id !== filter('bgValue')('scoringPhaseStatus').scoringPhase
        ){
          return false;
        }else{
          return true;
        }
      };


      scope.enableOptions = function() {
        if(scope.quoteId === 0 || scope.quoteFinished ||
          !haveOption(filter('bgValue')('routingTaskOptionsTypes').optionButtonVal) ||
          scope.stage.id !== filter('bgValue')('scoringPhaseStatus').scoringPhase ||
          (angular.isDefined(scope.quoteMasterForm) &&
              (scope.quoteMasterForm.$dirty || scope.quoteMasterForm.$invalid))
        ){
          return false;
        }else{
          return true;
        }
      };

      function setMessages(){

        scope.tabsWithErrors.quote = false;
        scope.tabsWithErrors.clients = false;
        scope.tabsWithErrors.detail = false;
        scope.tabsWithErrors.documents = false;
        scope.validationList.clients = [];

        angular.forEach(scope.sections, function(value) {

          switch (value.name) {
            case trans.getValue('quote.section.COTIZACION'):
              if (!isEmpty(value.participantResults)) {
                scope.tabsWithErrors.quote = true;
                scope.pendingFields = true;
              }
              break;
            case trans.getValue('quote.section.PERSONALES'):
              if (!isEmpty(value.participantResults)) {
                scope.tabsWithErrors.clients = true;
                scope.pendingFields = true;
                setValidationForClient(value.participantResults);
              }
              break;
            case trans.getValue('quote.section.PERSONALES_DIRECCION'):
              if (!isEmpty(value.participantResults)) {
                scope.tabsWithErrors.clients = true;
                scope.pendingFields = true;
                setValidationForClient(value.participantResults);
              }
              break;
            case trans.getValue('quote.section.COTIZACION_DETALLE'):
              if (!isEmpty(value.participantResults)) {
                scope.tabsWithErrors.detail = true;
                scope.pendingFields = true;
              }
              break;
            case trans.getValue('quote.section.LABORALES_ACTUAL'):
              if (!isEmpty(value.participantResults)) {
                scope.tabsWithErrors.clients = true;
                scope.pendingFields = true;
                setValidationForClient(value.participantResults);
              }
              break;
            case trans.getValue('quote.section.LABORALES_CESANTE'):
              if (!isEmpty(value.participantResults)) {
                scope.tabsWithErrors.clients = true;
                scope.pendingFields = true;
                setValidationForClient(value.participantResults);
              }
              break;
            case trans.getValue('quote.section.REFERENCIAS'):
              if (!isEmpty(value.participantResults)) {
                scope.tabsWithErrors.clients = true;
                scope.pendingFields = true;
                setValidationForClient(value.participantResults);
              }
              break;
            case trans.getValue('global.DIRECCION_EMPRESA'):
              if (!isEmpty(value.participantResults)) {
                scope.tabsWithErrors.clients = true;
                scope.pendingFields = true;
                setValidationForClient(value.participantResults);
              }
              break;
            case trans.getValue('quote.section.DOCUMENTOS'):
              if (!isEmpty(value.participantResults)) {
                scope.tabsWithErrors.documents = true;
                scope.pendingFields = true;
              }
              break;
            default:
              if (!isEmpty(value.participantResults)) {
                scope.pendingFields = true;
              }
          }

        });

      }

      function setValidationForClient (participantResults) {
        angular.forEach(participantResults, function(item) {
          if (item.entityId > 0) {
            if (scope.validationList.clients.indexOf(item.entityId) < 0) {
              scope.validationList.clients.push(parseInt(item.entityId));
            }
          }
        });
      }

      function openModalMissingfield() {

        scope.quoteMasterForm.$aaFormExtensions.$onSubmitAttempt();

        var attrs = {
          bgPopupFromService: true,
          bgPopupTitle: trans.getValue('quote.save.title'),
          bgPopupMessage: trans.getValue('client.missing.documents')
        };
        popUpService.open(attrs);
      }

      function selectTaskOptions(attrs){
        var reasons = [];

        if (angular.isDefined(attrs.selected) &&
          attrs.selected instanceof Array) {
          angular.forEach(attrs.selected, function(obj) {
              if (!isEmpty(obj.reason)) {
                  reasons.push({
                    'id': obj.reason.id,
                    'name': obj.reason.name,
                    'desciption': obj.reason.secondLevelName
                  });
              }
          });
        }

        var nextStageWrapper = {
          'task': scope.sharedService.task,
          'observation': attrs.observation,
          'action': {
            'id': attrs.optionValue,
            'reasons': reasons
           }
        };

        scope.services.moveToNextStage(nextStageWrapper)
        .then(function(response) {
          if ( typeof response.data.task !== 'undefined') {
            scope.sharedService.carQuote.stage = response.data.task.stage;
            scope.sharedService.carQuote.status = response.data.task.status;
            scope.sharedService.carQuote.user = response.data.assignedUser;
            scope.sharedService.task = response.data.task;
          } else {
            if (response.data.toTaskFinished) {
              bgRedirectService.toTaskFinished(
                trans.getValue('global.quote'));
      			} else {
      			  alertNotifyService.showErrorT('constant.error.unexpected');
      			}

          }
        }).catch(function(response) {
          if (response.data && response.data.name) {
            alertNotifyService.showError(response.data.name);
          } else {
            alertNotifyService.showError(
                trans.getValue('constant.error.unexpected'));
          }

        });

      }

      function updateParticipantsExeptions ( attrs ){

        // scope.additionalParticipants.exceptions = attrs.additionals.exceptions;

        // Principal
        scope.mainParticipant.exceptions = attrs.principal.exceptions;
        scope.mainParticipant.exceptionsSupport =
          attrs.principal.exceptionsSupport;
        angular.forEach(scope.mainParticipant.exceptions,
        function(value) {
          if (value.type === 'M' && value.isNew === true) {
            value.isNew = false;
          }
        });

        // Adicionales
        angular.forEach(attrs.additionals,
        function(participant, key) {
          angular.forEach(participant.exceptions,
          function(value) {
            if (value.type === 'M' && value.isNew === true) {
              value.isNew = false;
            }
          });

          // Asignar campos editados
          scope.additionalParticipants[key].exceptionsSupport =
            participant.exceptionsSupport;
          scope.additionalParticipants[key].exceptions =
            participant.exceptions;
        });
        scope.dirtyFormFlag.flagDirty = true;
        scope.quoteMasterForm.$setDirty();
        scope.executeBusinessRuleFn();
      }

      function saveQuoteModal(sections) {

        var attrs = {};

        attrs = {
          bgPopupTitle: trans.getValue('global.save.procedures'),
          bgPopupTpl: 'partials/bgp-popup/bg-popup-pendientes.html',
          bgPopupData: {
            sections: sections
          },
          bgPopupClass:'extended-popup'
        };

        popUpService.open(attrs);
      }

      function validateModal() {

        var attrs = {};

        if (scope.sections !== undefined && scope.sections.length !== 0) {

          attrs = {
            bgPopupTitle: trans.getValue('quote.header.pending.assessment'),
            bgPopupTpl: 'partials/bgp-popup/bg-popup-pendientes.html',
            bgPopupData: {
              sections: scope.sections,
              pendingFields: scope.pendingFields
            }
          };

        } else {

          attrs = {
            bgPopupTitle: trans.getValue('quote.header.ready.assessment'),
            bgPopupMessage: trans.getValue(
              'quote.header.ready.assessment.message'),
            bgPopupOkText: trans.getValue('global.accept')
          };

        }
        popUpService.open(attrs);
      }

      function formatQuoteId(quoteId) {
        if (isEmpty(quoteId)) {
          return '';
        }

        quoteId = String(quoteId);

        if (quoteId !== '0') {
          quoteId = commonFunctions.formatQuoteCode(quoteId);
        } else {
          quoteId = '';
        }

        return quoteId;
      }

      function haveOption(type){
        if(isEmpty(scope.availableOptions)){
          return false;
        }
        return  scope.availableOptions
        .filter(function(option){
          return option.type === type;
        }).length > 0;
      }

      function reviewDataDisabled(){
        return scope.isDisabledQuoteFn();
      }

    }

  }

  /*
  ==============
  CONFIGURATION
  ==============
  */

  bgQuoteHeader.$inject =[
    '$filter',
    'isEmptyFilter',
    'translateService',
    'bgPopUpService',
    'recalculateMsgService',
    'findDifferencesService',
    'bgRedirectService',
    'commonFunctions',
    'alertNotifyService',
    'storageService'
  ];

  win.MainApp.Directives
    .directive('bgQuoteHeader', bgQuoteHeader);
}(window));
