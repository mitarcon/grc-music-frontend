(function(win) {
  "use strict";

  function bgRequiredCondition() {
    return {
      restrict: 'A',
      require: 'ngModel',
      scope: {
        validateCondition: '&'
      },
      link: function(scope, element, attrs, ngModel) {

        function validate (viewValue) {

          ngModel.$setValidity('bgRequiredCondition', scope.validateCondition());

           return viewValue;
        }

        ngModel.$parsers.unshift(validate);
        ngModel.$formatters.unshift(validate);

      }
    };
  }
  bgRequiredCondition.$inject = [];
  win.MainApp.Directives
    .directive('bgRequiredCondition', bgRequiredCondition);
}(window));




