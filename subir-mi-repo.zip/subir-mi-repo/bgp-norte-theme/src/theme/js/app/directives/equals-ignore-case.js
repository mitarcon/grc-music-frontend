/* globals angular, appName */
(function (win) {
    "use strict";

    var valid = function(model, comparator){
      var valid = true;
      if (model !=="" || comparator !=="") {
        valid = (model.toLowerCase()) === (comparator.toLowerCase());
      }
      return valid;
    }
    
    var validChangeToCompare = function(oldValue, newValue){
      return oldValue.toLowerCase()!==newValue.toLowerCase();
    }
    
    var validShowMessage = function(scope, attrs, toCompare, elem, ctrl){
      var oldValue = scope.$eval(attrs.ngInit);
      var v = valid(elem.val(),$(toCompare).val());
      var changed = validChangeToCompare(oldValue, $(toCompare).val());
      if($(elem).val() === "" && !changed) {
        v = true;
      }
      ctrl.$setValidity('equals', v);
    }
    
    function equalsIgnoreCase() {
        return {
            require : 'ngModel',
            optional : 'ngInit',
            link: function (scope, elem, attrs, ctrl) {
                var toCompare = '#' + attrs.equalsIgnoreCase;           
                $(toCompare).on('change', function(){
                  scope.$apply(function () {
                    validShowMessage(scope, attrs, toCompare, elem, ctrl)
                    ctrl.$setTouched();
                  });
                });
                $(elem).on('keyup', function(){
                  scope.$apply(function () {
                    validShowMessage(scope, attrs, toCompare, elem, ctrl)
                  }); 
                });
            }
        };
    }

    equalsIgnoreCase.$inject = [];

    // add directive custom-server-message-validator
     angular
    .module(appName + ".directives")
        .directive('equalsIgnoreCase', equalsIgnoreCase);
}(window));
