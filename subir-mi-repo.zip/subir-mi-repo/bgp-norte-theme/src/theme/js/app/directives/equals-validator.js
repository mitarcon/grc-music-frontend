/* globals angular, appName */
(function (win) {
    "use strict";

    function equalsValidator() {
        return {
            require : 'ngModel',
            link: function (scope, elem, attrs, ctrl) {
                var toCompare = '#' + attrs.equalsValidator;
                $(elem).add($(toCompare)).on('keyup', function () {
                  scope.$apply(function () {
                    var v = elem.val()===$(toCompare).val();
                    ctrl.$setValidity('equals', v);
                  });
                });
            }
        };
    }

    equalsValidator.$inject = [];

    // add directive custom-server-message-validator
     angular
    .module(appName + ".directives")
        .directive('equalsValidator', equalsValidator);
}(window));
