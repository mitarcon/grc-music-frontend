(function(win) {
  "use strict";

  function emptyCheckboxButton($log, $window, bgValue, isEmpty) {

    return {
      require: 'ngModel',
      restrict: 'A',
      link: function(scope, elem, attr, ngModel) {

        var validate = function(viewValue) {

          if(attr.ngRequired && scope.$eval(attr.ngRequired)) {

            if(!viewValue) {
              ngModel.$setValidity('emptyCheckboxButton', false);
            }else {
              ngModel.$setValidity('emptyCheckboxButton', true);
            }

          }

          return viewValue;

        };

        ngModel.$parsers.unshift(validate);
        ngModel.$formatters.unshift(validate);
      }
    };
  }

  emptyCheckboxButton.$inject = [
    "$log",
    "$window",
    "bgValueFilter",
    "isEmptyFilter"
  ];

  win.MainApp.Directives.directive('emptyCheckboxButton', emptyCheckboxButton);

}(window));
