(function (win){
  'use strict';
  function bgPromoterValidations(){
    return {
      require: 'ngModel',
      scope: {},
      link: function(scope, elm, attrs, ngModel) {

        var validate = function(viewValue) {

        if(!isEmpty(viewValue)){
          var projectsRelated = filter('filter')
            (catalogFilter('projectPromoterRelations'),
            {promoterId: viewValue.id}, true)[0];

            if (isEmpty(projectsRelated)) {
              ngModel.$setValidity('noProjects', false);
            }else{
              ngModel.$setValidity('noProjects', true);
            }
        }

        return viewValue;

        };

        ngModel.$parsers.unshift(validate);
        ngModel.$formatters.unshift(validate);

      }
    };
  }
  bgPromoterValidations.$inject = ['$filter',
                                   'catalogFilter',
                                   'isEmptyFilter'];
  win.MainApp.Directives
    .directive('bgPromoterValidations',bgPromoterValidations);
}(window));
