(function(win) {
  'use strict';

  function bgApcMonthlyFee(filter, bgValue, isEmpty) {

    var directive = {
      restrict: 'E',
      transclude: true,
      scope: {
        executeBusinessRule: '&',
        obligation: '=',
        clientTab: '='
      },
      template: '<div ng-include="template"></div>',
      link: link
    };
    return directive;

    function link(scope){

      /*
      ===============
      VALUES
      ===============
      */
      scope.template = filter('BgpTplRootUrl')
        ('partials/bg-apc-monthly-fee.html');
      var lastValue = scope.obligation.apcAmount;
      var lastPercent = scope.obligation.percentage;

      /*
      ===============
      METHODS
      ===============
      */
      scope.blurPercent = blurPercent;
      scope.blurValue = blurValue;
      scope.changePercent = changePercent;
      scope.changeValue = changeValue;
      scope.isDisabledMonthlyFee = isDisabledMonthlyFee;

      function blurPercent() {
        if (isNaN(scope.obligation.percentage)) {
          scope.obligation.apcAmount = undefined;
          return;
        }
        if (lastPercent === scope.obligation.percentage ||
          scope.obligation.percentage < 0) {
          return;
        }
        lastPercent = scope.obligation.percentage;
        scope.executeBusinessRule();
      }
      function blurValue() {
        if (isNaN(scope.obligation.apcAmount)) {
          scope.obligation.percentage = undefined;
          return;
        } else if (scope.obligation.type ===
          bgValue('obligationTypes').manual) {
          scope.obligation.spApcAmount = scope.obligation.apcAmount;
        }
        if (lastValue === scope.obligation.apcAmount ||
          scope.obligation.apcAmount < 0) {
          return;
        }
        lastValue = scope.obligation.apcAmount;
        scope.executeBusinessRule();
      }
      function changePercent() {
        if (isEmpty(scope.obligation.percentage) ||
          isNaN(scope.obligation.percentage)) {
          return;
        }
        scope.obligation.apcAmount =
          (parseFloat(scope.obligation.percentage) *
             parseFloat(scope.obligation.spApcAmount) / 100.00);
      }
      function changeValue() {
        if (isEmpty(scope.obligation.apcAmount) ||
          isNaN(scope.obligation.apcAmount)) {
          return;
        }
        scope.obligation.percentage =
          ((parseFloat(scope.obligation.apcAmount) * 100.00) /
            parseFloat(scope.obligation.spApcAmount));
      }
      function isDisabledMonthlyFee() {
        return scope.obligation.type === bgValue('obligationTypes').automatic &&
          scope.obligation.apcAmount < 0;
      }
    }
  }

  bgApcMonthlyFee.$inject = [
    '$filter',
    'bgValueFilter',
    'isEmptyFilter'
  ];
  win.MainApp.Directives
    .directive('bgApcMonthlyFee', bgApcMonthlyFee);
}(window));
