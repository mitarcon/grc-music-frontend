(function(win) {
  'use strict';

  function bgCarSelection(carQuoteService,
    isEmpty, commonFunctions, scoringPhaseStatus, bgTrim, log) {

    log.debug('[bgCarSelection] Initializing....');

    /*VALUES*/

    return {
      restrict: 'E',
      scope: {
        executeBusinessRule: '&',
        'carQuote': '='
      },
      template: '<div ng-include="template"></div>',

      link: function(scope) {
        scope.template = window.baseThemeURL +
          'partials/bg-car-selection.html';

        /*METHODS*/

        var brandsReady;
        var modelsReady;
        var agenciesReady;

        var isDataReady = function() {
          return !isEmpty(scope.carQuote.car.priceWithTax) &&
            scope.carQuote.car.priceWithTax > 0 &&
            !isEmpty(scope.carQuote.car.carModel.name) &&
            !isEmpty(scope.carQuote.car.carBrand.name) &&
            !isEmpty(scope.carQuote.car.carAgency.name) &&
            brandsReady && modelsReady && agenciesReady;
        };

        var checkCurrentSelection = function(array, currentValue) {
          var exist = false;
          var evaluatedValue = bgTrim(currentValue);
          for (var i in array) {
            var arrayVal = bgTrim(array[i].name);

            if (array.hasOwnProperty(i) && arrayVal === evaluatedValue) {
              exist = true;
              break;
            }
          }
          return exist;
        };

        var loadAgencies = function(filters, executeRule) {
          carQuoteService.getCarAgencies(filters).then(
            function(response) {
              scope.agencies = response.data;
              var carAgency = scope.carQuote.car.carAgency;
              if (!checkCurrentSelection(scope.agencies, carAgency.name)) {
                carAgency.name = '';
              } else {
                scope.setConcessionaire();
                scope.setCreditorId();
              }

              agenciesReady = true;

              if (executeRule) {
                scope.executeLocalBusinessRule();
              }

            }
            // TODO: averiguar que hacer con este metodo
            // ya no existe en commonFunctions
            // function(data) {
            //   commonFunctions.callMessageError(data);
            // }
          );
        };

        var loadBrands = function(filters, executeRule) {
          carQuoteService.getCarBrands(filters).then(
            function(response) {
              scope.brands = response.data;
              var carBrand = scope.carQuote.car.carBrand;
              if (!checkCurrentSelection(scope.brands, carBrand.name)) {
                carBrand.name = '';
              } else {
                scope.setOrigin();
              }

              brandsReady = true;

              if (executeRule) {
                scope.executeLocalBusinessRule();
              }

            }
            // TODO: averiguar que hacer con este metodo
            // ya no existe en commonFunctions
            // function(data) {
            //   commonFunctions.callMessageError(data);
            // }
          );
        };

        var loadModels = function(filters, executeRule) {
          carQuoteService.getCarModels(filters).then(
            function(response) {
              scope.models = response.data;
              var carModel = scope.carQuote.car.carModel;
              if (!checkCurrentSelection(scope.models, carModel.name)) {
                carModel.name = '';
              }

              modelsReady = true;

              if (executeRule) {
                scope.executeLocalBusinessRule();
              }

            }
            // TODO: averiguar que hacer con este metodo
            // ya no existe en commonFunctions
            // function(data) {
            //   commonFunctions.callMessageError(data);
            // }
          );
        };

        scope.setConcessionaire = function() {
          var agencyName = bgTrim(scope.carQuote.car.carAgency.name);


          scope.carQuote.car.carAgency.concessionaire = scope.agencies.filter(
            function(obj) {
              var objName = bgTrim(obj.name);

              return objName === agencyName;
            })[0].concessionaire;
        };

        scope.setCreditorId = function() {
          var creditorName = bgTrim(scope.carQuote.car.carAgency.name);

          scope.carQuote.car.carAgency.creditorId = scope.agencies.filter(
            function(obj) {
              var objName = bgTrim(obj.name);
              return objName === creditorName;
            })[0].creditorId;
        };

        scope.setOrigin = function() {
          var originName = bgTrim(scope.carQuote.car.carBrand.name);

          scope.carQuote.car.carBrand.origin = scope.brands.filter(
            function(obj) {
              var objName = bgTrim(obj.name);
              return objName === originName;
            })[0].origin;
        };

        scope.executeLocalBusinessRule = function() {
          if (isDataReady()) {
            scope.executeBusinessRule();
          }
        };


        /*Setup*/

        scope.reloadFilters = function(executeRule, blurModel) {
          brandsReady = false;
          modelsReady = false;
          agenciesReady = false;

          if (blurModel && isEmpty(scope.carQuote.car.carBrand.name)) {
            scope.carQuote.car.carModel.name = '';
            scope.carQuote.car.carAgency.name = '';
            delete scope.carQuote.car.carBrand.origin;
            scope.executeBusinessRule();
          }

          if (scope.carQuote.stage.id &&
            scope.carQuote.stage.id !== scoringPhaseStatus.evaluationPhase) {
            loadBrands({
              carModel: scope.carQuote.car.carModel,
              carAgency: scope.carQuote.car.carAgency
            }, executeRule);

            loadModels({
              carBrand: scope.carQuote.car.carBrand,
              carAgency: scope.carQuote.car.carAgency
            }, executeRule);

            loadAgencies({
              carBrand: scope.carQuote.car.carBrand,
              carModel: scope.carQuote.car.carModel
            }, executeRule);

          }

        };
        scope.reloadFilters(false);

      }
    };
  }
  /*CONFIGURATION*/
  bgCarSelection.$inject = ['carQuoteService',
    'isEmptyFilter',
    'commonFunctions',
    'scoringPhaseStatus',
    'bgTrimFilter',
    '$log',
  ];

  win.MainApp.Directives.directive('bgCarSelection', bgCarSelection);

}(window));
