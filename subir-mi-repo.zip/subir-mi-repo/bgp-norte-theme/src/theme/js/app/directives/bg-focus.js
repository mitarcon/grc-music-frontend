/* globals angular, appName */

(function(win) {
  "use strict";

  function bgFocusMe() {
    return {
      link: function(scope, element, attrs) {
        scope.$watch(attrs.bgFocusMe, function(value) {
          if (value === true) {
            element[0].focus();
            scope[attrs.bgFocusMe] = false;
          }
        });
      }
    };
  }

  angular
    .module(appName + ".directives")
    .directive('bgFocusMe', bgFocusMe);
}(window));
