/* globals angular, appName */

(function (win) {
    "use strict";

    function focusMe($timeout) {
        return {
            link: function ( scope, element, attrs ) {
                $timeout( function () { element[0].focus(); } );
            }
        };
    }


    angular
        .module(appName + ".directives")
        .directive('focusMe', focusMe);

    focusMe.$inject = ['$timeout'];
}(window));
