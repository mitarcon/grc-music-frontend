(function (win) {
  "use strict";

  var autoNumeric = function() {
    return {
      require: '?ngModel',
      restrict: 'A',
      scope: {
        autoNumeric: '<'
      },
      link: function (scope, elm, attrs, controller) {

        elm.autoNumeric('init', scope.autoNumeric);

        var updateElement = function (newVal) {
          if ($.isNumeric(newVal)) {
            elm.autoNumeric('set', newVal);
          } else if(isEmptyString(newVal)) {
            elm.autoNumeric('set', '');
          }
        };

        var isEmptyString = function(value) {
          return typeof value == 'string' && !value.trim() || typeof value == 'undefined' || value === null;
        };

        if (controller) {
          controller.$render = function () {
            updateElement(controller.$viewValue);
          };

          scope.$watch(attrs.ngModel, function () {
            controller.$render();
          });

          elm.on('change', function (e) {
            scope.$apply(function () {
              controller.$setViewValue(elm.autoNumeric('get'));
            });
          });

        } else {
          attrs.$observe('value', function (val) {
            updateElement(val);
          });
        }
      }
    };
  };

  win.MainApp.Directives.directive('autoNumeric', autoNumeric);

}(window));
