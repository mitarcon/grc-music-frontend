(function(win) {
  "use strict";

  function bgpDismissibleAlert() {

    return {
      restrict: 'E',
      scope: {
        alertTitle: '@',
        message: '@',
        iconType: "@",
        alertType: "@"
      },
      templateUrl: '/o/bgp-norte-theme/angular/partials/bg-dismissible-alert.html',
      link: function(scope, elem, attr, ngModel) {

        scope.show = true;

        scope.close = function() {
          scope.show = false;
        };

      }
    };
  }

  bgpDismissibleAlert.$inject = [];

  win.MainApp.Directives.directive('bgpDismissibleAlert', bgpDismissibleAlert);

}(window));
