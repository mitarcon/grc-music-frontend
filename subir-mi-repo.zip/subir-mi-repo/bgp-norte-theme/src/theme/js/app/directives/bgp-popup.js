(function(win){
  'use strict';

/**
 * Pop-up directive
 * ----------------
 * Add to your element the following attributes:
 * - bg-popup
 * - bg-popup-title
 * - bg-popup-message
 * - bg-popup-ok-text (optional)
 * - bg-popup-cancel-text (optional)
 * - bg-popup-method (optional)
 * - bg-popup-tpl (optional)
 * - bg-popup-class(optional) [bg-modal-lg|bg-modal-sm]
 * - bg-popup-data (optional)
 */

    function bgPopup(popUpService) {
      return {
        restrict: 'A',
        scope: {
          bgPopupTitle: '@',
          bgPopupMessage: '@',
          bgPopupOkText: '@',
          bgPopupCancelText: '@',
          bgPopupTpl: '@',
          bgPopupClass: '@',
          bgPopupMethod: '&',
          bgPopupCancelMethod: '&',
          bgPopupData: '=',
          bgPopupLockScreen: '@',
          bgPopupBlocked: '=',
          product: '@',
          bgPopupFromService: '@'
        },
        link: function (scope, element) {
          element.bind('click', function () {
            popUpService.open(scope);
          });
        }
      };
    }
    bgPopup.$inject = ['bgPopUpService'];
    win.MainApp.Directives
      .directive('bgPopup',bgPopup);

}(window));
