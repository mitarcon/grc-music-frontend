/* globals angular, appName, _ */
(function (win) {
    "use strict";

    function customServerMessageValidator() {
        return {
            require : 'ngModel',
            link : function(scope, element, attrs, ngModel) {

                var customMessages = attrs.customServerMessageValidator;

                if (customMessages.length === 0) { return false; }

                customMessages = customMessages.split(',');

                _.map(customMessages, function (message) {
                    ngModel.$parsers.push(function(value) {
                        ngModel.$setValidity(message, true);
                        return value;
                    });
                });
            }
        };
    }

    customServerMessageValidator.$inject = [];

    // add directive custom-server-message-validator
     angular
    .module(appName + ".directives")
        .directive('customServerMessageValidator', customServerMessageValidator);
}(window));
