/* globals angular, appName */
(function(win) {
  "use strict";

  function bgInteger() {
    return {
      require: 'ngModel',
      link: function(scope, ele, attr, ctrl) {
        ctrl.$parsers.unshift(function(viewValue) {
          return parseInt(viewValue, 10);
        });
      }
    };
  }

  angular
    .module(appName + ".directives")
    .directive('bgInteger', bgInteger);
}(window));
