(function() {
  "use strict";

  function bgpRedirectButton($log) {

    return {

      scope: {
        text: '@',
        primary: '=',
        url: '@'
      },

      restrict: 'E',
      templateUrl: window.baseThemeURL +
        'partials/go-to-accounts-button.html',
      link: function($scope) {

        $scope.getButtonText = function() {
          return $scope.text;
        };

        $scope.redirect = function() {
          window.location = $scope.url;
        };

      }

    };

  }

  bgpRedirectButton.$inject = ['$log'];

  angular
    .module(appName + ".directives")
    .directive('bgpRedirectButton', bgpRedirectButton);

}());
