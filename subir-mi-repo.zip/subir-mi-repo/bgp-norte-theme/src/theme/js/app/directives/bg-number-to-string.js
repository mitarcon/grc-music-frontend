/* globals angular, appName */

(function(win) {
  "use strict";

  function numberToString() {
    return {
      require: 'ngModel',
      link: function(scope, element, attrs, ngModel) {
        ngModel.$parsers.push(function(val) {
          return val ? parseInt(val, 10) : null;
        });
        ngModel.$formatters.push(function(val) {
          return val ? '' + val : null;
        });
      }
    };
  }

  angular
    .module(appName + ".directives")
    .directive('numberToString', numberToString);
}(window));
