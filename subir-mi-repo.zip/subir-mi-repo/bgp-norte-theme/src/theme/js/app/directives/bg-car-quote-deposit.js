(function(win) {
  'use strict';

  function bgCarQuoteDeposit(isEmpty, commonFunctions, log, paramService) {
    log.debug('[bgCarQuoteDeposit] Initializing....');

    return {
      restrict: 'E',
      replace : true,
      scope : {
        blurAmount:'&',
        blurPercentage:'&',
        depositAmount:'=',
        depositPercentage:'=',
        focusPercentDeposit:'&',
        focusAmountDeposit:'&',
        disabled: "=",
        message : '='
      },
      templateUrl: window.baseThemeURL + 'partials/bg-car-quote-deposit.html',

      link: function(scope) {

          var decimal;
          var creditBaseP;
          scope.lengthPercentage = 2;
          scope.fractionPercentage = 0;

        function init() {
          decimal = {
            number: commonFunctions.getSizeDecimalNumber(),
            percentage: commonFunctions.getSizeDecimalPercentage()
          };
          creditBaseP = paramService.getAuLowestDeposit();
        }
        init();
      }
    };
  }
  /*CONFIGURATION*/
    bgCarQuoteDeposit.$inject = ['isEmptyFilter',
                                 'commonFunctions',
                                 '$log',
                                 'bgParamsService',
    ];

  win.MainApp.Directives.directive('bgCarQuoteDeposit', bgCarQuoteDeposit);
}(window));
