(function(win) {
  'use strict';

  function bgpUserContactDataPopover(log) {

    log.debug("[bgpUserContactDataPopover] Initializing...");

    /*
    ===============
    VALUES
    ===============
    */

    return {
      scope: {
        user: '=',
        colorClass: '@'
      },
      restrict: 'E',
      templateUrl: window.baseThemeURL + 'partials/bgp-user-contact-data-popover.html',
      link: function(scope) {

      }

    };

    /*
    ==============
    CONFIGURATION
    ==============
    */
  }
  bgpUserContactDataPopover.$inject = [
    "$log"
  ];

  win.MainApp.Directives
    .directive('bgpUserContactDataPopover', bgpUserContactDataPopover);
}(window));
