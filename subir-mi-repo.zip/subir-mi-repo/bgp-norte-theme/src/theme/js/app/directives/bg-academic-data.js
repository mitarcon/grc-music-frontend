(function(win) {
'use strict';

var  bgAcademicData = function (catalogService,
  $log, alertNotifyServicel, bgValue){


  $log.debug("[bg-academic-data] Initializing...");

    return {
      restrict: 'E',
      scope: {
        client: '=ngModel',
        app: '='
      },
      require: 'ngModel',
      templateUrl: window.baseThemeURL + 'partials/bg-academical-data.html',
      link:function (scope, element, attrs) {
        scope.entity = attrs.entity;

        var setEducation = function(personalData){
          var code = personalData.educationLevel ?
            personalData.educationLevel.id : '';
            personalData.educationLevel = catalogService.item(code,
             bgValue('academicDataType').education,scope.app);
        };

        var setProfession = function(personalData){
          var code = personalData.profession ?
            personalData.profession.id : '';
          personalData.profession = catalogService.item(code,
             bgValue('academicDataType').profession,scope.app);
        };

        scope.init = function () {
          var personalData = scope.client;
          setProfession(personalData);
          setEducation(personalData);
        };
      }
    };
};

  bgAcademicData.$inject = [
    "catalogService",
    "$log",
    "alertNotifyService",
    "bgValueFilter"
 ];

  win.MainApp.Directives
    .directive("bgAcademicData",
        bgAcademicData);

}(window));
