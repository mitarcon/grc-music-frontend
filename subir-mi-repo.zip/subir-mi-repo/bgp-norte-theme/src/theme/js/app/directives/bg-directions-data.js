(function(win) {
  'use strict';

  /**
   * Directions directive
   * ----------------
   * You must define a variable named scope.addresses in your controller in order
   * to be used by this directive. Defined as follow:
   *
   * scope.addresses - a list of directions with the following attributes:
   *  principal: boolean
   *  type: string
   *  street: string
   *  complement: string
   *  neighborhood: string
   *  area: string
   *  district: string
   *  province: string
   *
   * Don't forget to create a variable scope.addresses in you controller
   * It must be sent a type, to properly show or hide some addresses of the list
   */
  var bgDirections = function($log, ctpl, addTypeOpts, panamaCode,
    buildLocalAddress, arrToString, forceCloseForm, common, routeInvoker,
    bgValue, isEmpty
    //  tplRootUrl, ctpl, ajaxServices, addTypeOpts, arrToString,
    //buildLocalAddress, common, panamaCode, forceCloseForm
  ) {

    $log.debug("bg-directions initializing ....");
    return {
      require: '^form',
      restrict: 'E',
      scope: {
        addresses: '=',
        type: '@',
        pendingAddForms: '=',
        app: '='
      },
      templateUrl: ctpl('directionsTemplate'),
      link: function(scope) {

        scope.enableAdd = true;
        scope.countries = [];
        scope.indexOpened = -1;
        scope.addressTypeOptions = addTypeOpts;
        scope.showAddForm = !scope.addresses.length;
        scope.addressList = angular.copy(scope.addresses);
        scope.address = {};
        var lastCountryId = -1;

        /*
         * Search for Neighborhoods in remote service
         */
        scope.searchNeighborhoods = function(input, callback) {
          // filter params to perform the search
          var province = scope.address.province;
          var filter = {
            addressDTO: {
              neighborhood: {
                name: input
              },
              province: {
                name: province ? province.name : '',
                id: province ? province.id : ''
              }
            }
          };

          // just populate the local list when the user
          // typed three words at least
          if (input.length >= 3 && angular.isDefined(province) &&
            (parseInt(province.id) !== -1)) {

            routeInvoker.invoke(bgValue('apps').neighborhood,
              'getNeighborhood', filter).then(
              function(response) {
                callback(response.data);
              },
              function(data) {
                common.callMessageError(data);
              });

          } else {
            callback([]);
          }

        };

        /*
         * Event when the user selects the neighborhood
         */

        scope.selectNeighborhoods = function(selected) {
          //label is reserved for macgyver. It must be set so the input keep
          //the value selected, otherwise it gets cleared
          selected.label = selected.neighborhood.name;
          scope.address.neighborhood.name = selected.neighborhood.name;
          scope.address.neighborhood.id = selected.neighborhood.id;

          scope.address.township.name = selected.zone.name;
          scope.address.township.id = selected.zone.id;

          scope.address.district.name = selected.district.name;
          scope.address.district.id = selected.district.id;
        };

        /**
         * Evaluates address type to set respective pending form
         */
        var updatePendingAddFroms = function(flag) {
          if (scope.type === 'PERSONAL') {
            scope.pendingAddForms.personalAddresses = flag;
          } else {
            scope.pendingAddForms.laborAddresses = flag;
          }
        };

        /*
         * Controls the open/close behavior of the acordion
         */
        scope.toggleOpen = function(index, address) {

          if (scope.showAddForm) {
            return null;
          }
          scope.indexOpened = scope.indexOpened === index ? -1 : index;
          if (scope.indexOpened === -1) {
            scope.enableAdd = true;
            scope.reset();
          } else {
            scope.enableAdd = false;
            scope.address = address;
          }
          //update outter object
          updatePendingAddFroms(scope.indexOpened !== -1);

        };

        /**
         * Controls that must have just one principal address on the list
         */
        scope.togglePrincipal = function(index) {
          angular.forEach(scope.addressList, function(address, i) {
            if (index !== i) {
              address.principal = false;
              scope.addresses[i].principal = false;
            } else {
              scope.addresses[i].principal = !scope.addresses[i].principal;
            }
          });
        };

        /**
         * Mark an address as principal
         */
        scope.checkPrincipal = function(address) {
          var innerIndex = scope.addressList.indexOf(address);

          if (innerIndex !== -1) {
            if (scope.addressList.length === 1 && !address.principal) {
              address.principal = true;
              scope.addresses[innerIndex].principal = true;
            }
          }
        };

        /**
         * Show or hide addong form
         */
        scope.toggleAddForm = function() {
          scope.showAddForm = !scope.showAddForm;
          if (scope.showAddForm) {
            scope.enableAdd = false;
          } else {
            scope.enableAdd = true;
          }

          //update outter object
          updatePendingAddFroms(scope.showAddForm);

          if (scope.showAddForm) {
            scope.reset();
          } else {
            scope.indexOpened = -1;
            scope.address = {};
          }

        };

        /**
         * Adds a new Address to the list
         */
        scope.add = function() {
          scope.address = common.objectUppercase(scope.address);
          scope.address.isAdding = true;
          scope.addresses.push(angular.copy(scope.address));
          scope.addressList.push(angular.copy(scope.address));
          scope.showAddForm = false;
          scope.enableAdd = true;

          //update outter object
          updatePendingAddFroms(scope.showAddForm);
          scope.reset();
        };

        /**
         * Cancel a creation or update form
         */
        scope.cancel = function(address) {

          scope.enableAdd = true;
          scope.indexOpened = -1;
          var innerIndex = scope.addressList.indexOf(address);

          if (innerIndex !== -1) {
            scope.addressList[innerIndex] =
              angular.copy(scope.addresses[innerIndex]);
          }
          //update outter object
          updatePendingAddFroms(false);
        };

        /**
         * Update an address from list
         */
        scope.update = function(address) {
          address = common.objectUppercase(address);
          scope.enableAdd = true;
          scope.indexOpened = -1;
          var innerIndex = scope.addressList.indexOf(address);

          if (innerIndex !== -1) {
            scope.addresses[innerIndex] =
              angular.copy(scope.addressList[innerIndex]);
          }
          //update outter object
          updatePendingAddFroms(false);

        };

        /**
         * Delete an address from list
         */
        scope.delete = function(address) {
          var innerIndex = scope.addressList.indexOf(address);
          if (innerIndex !== -1) {
            scope.addresses.splice(innerIndex, 1);
            scope.addressList.splice(innerIndex, 1);
            scope.showAddForm = false;
          }
        };

        /**
         * Return a string with a combined set of values
         * to show and address description
         */
        scope.addressInLine = function(address) {

          if (address.addressType.id === 'L' ||
            address.addressType.id === 'M') {

            return arrToString([(address.country) ?
              address.country.name : undefined,
            address.foreignAddress
            ], ', ');

          } else {
            var province = (address.province) ?
              address.province.name : '';
            var district = (address.district) ?
              address.district.name : '';
            var area = (address.township) ?
              address.township.name : '';
            var neighborhood = (address.neighborhood) ?
              address.neighborhood.name : '';
            var street = (address.street) ?
              address.street : '';
            var houseNumber = (address.building) ?
              address.building : '';

            return buildLocalAddress.getAddress(province,
              district, area, neighborhood, street, houseNumber);
          }

        };

        /**
         * sets a default country according with the type of address.
         */
        scope.setCountry = function() {

          scope.address.foreignAddress = undefined;
          scope.address.building = undefined;
          scope.address.district.name = "";
          scope.address.neighborhood = undefined;
          scope.address.province = undefined;
          scope.address.township.name = '';
          scope.address.street = '';
          scope.address.country = {
            id: panamaCode,
            name: ''
          };

          if (scope.address.addressType.id === 'M' ||
            scope.address.addressType.id === 'L') {

            if ((lastCountryId === panamaCode)) {
              scope.address.country.id = '-1';
              scope.address.foreignAddress = '';
            } else {
              scope.address.country.id = lastCountryId;
            }

            if (lastCountryId == '-1' && scope.address.foreignAddress != '') {
              scope.address.foreignAddress = '';
            }

          } else {
            lastCountryId = scope.address.country.id;
            scope.address.country = {
              id: panamaCode,
              name: ''
            };
          }

        };

        scope.isForceClose = function() {
          return forceCloseForm.get();
        };

        /**
         * Determine wether an address should be shown or not,
         * according with the type of address.
         * @param  address
         * @return boolean
         */
        scope.shouldShowAddress = function(address) {
          if (scope.type === 'PERSONAL' && (address.addressType.id ===
              'D' ||
              address.addressType.id === 'L')) {
            return true;
          } else if (scope.type === 'LABOR' && (address.addressType.id ===
              'M' ||
              address.addressType.id === 'E')) {
            return true;
          }
          return false;
        };

        /**
         * Reset the new address to save
         */
        scope.reset = function() {
          scope.address = {
            addressType: {
              id: 'D',
              name: 'LOCAL'
            },
            neighborhood: {
              id: 0,
              name: ''
            },
            township: {
              id: 0,
              name: ''
            },
            district: {
              id: 0,
              name: ''
            },
            province: {
              id: -1,
              name: ''
            },
            country: {
              id: panamaCode,
              name: ''
            }
          };
          scope.address.addressType.id =
            scope.type === 'LABOR' ? 'E' : 'D';
        };
        scope.reset();
      }
    };
  };
  bgDirections.$inject = [
    '$log',
    'ctplFilter',
    'addressTypeOptions',
    'panamaCode',
    'buildLocalAddressService',
    'arrToStringFilter',
    'forceCloseFormService',
    'commonFunctions',
    'routeInvoker',
    'bgValueFilter',
    'isEmptyFilter'
  ];
  win.MainApp.Directives
    .directive('bgDirections', bgDirections);

}(window));