(function(win) {
  "use strict";

  function bgpNorteRecord(translate, log, isEmpty, bgValue, filter) {
    log.debug('[bgpNorteRecord] Initializing....');

    return {
      restrict: 'E',
      replace: true,
      scope: {
        record: '=',
        stage:'=',
        user:'=',
        idValue:'=',
        idName: "@"
      },
      templateUrl: window.baseThemeURL + 'partials/bgp-norte-record.html',

      link: function(scope) {

        scope.addNote = addNote;
        scope.deleteNote = deleteNote;
        scope.formattedDate = formattedDate;
        scope.formattedTime = formattedTime;

        scope.procedureRecordsId = function() {
          return "!" + bgValue('recordTypes').notes.id;
        };

        function addNote() {
          if (isEmpty(scope.observation) || scope.idValue === 0) {
            return;
          }
          var newRecord;

          newRecord = {
            stage: scope.stage,
            description: translate.getValue('global.follow.up.notes.cap'),
            user: scope.user,
            observation: scope.observation,
            type: {
              id: bgValue('recordTypes').notes.id,
              name: bgValue('recordTypes').notes.name
            },
            isNew: true,
            isDeletable: true
          };

          newRecord[scope.idName] = scope.idValue;

          scope.record.unshift(newRecord);
          scope.observation = '';
        }

        function deleteNote(index) {
          scope.record.splice(index, 1);
        }
        /*
      Gives a format specific to the date; for example : 8-Ago-2017
    */
        function formattedDate(date) {
          if (!isEmpty(date)) {
            var newDate = filter('date')(date, 'd-MMM-y');
            return newDate.replace(".", "");
          }
        }

        function formattedTime(time) {
          if (!isEmpty(time)) {
            var parts = time.split(':');
            if (parts.length === 3) {
              var date = new Date(0, 0, 0, parts[0], parts[1], parts[2]);
              return filter('date')(date, 'shortTime');
            }
          }

        }
      }
    };
  }

  bgpNorteRecord.$inject = [
    'translateService',
    '$log',
    'isEmptyFilter',
    'bgValueFilter',
    '$filter'
  ];

  win.MainApp.Directives.directive("bgpNorteRecord", bgpNorteRecord);
}(window));
