(function (win) {
  'use strict';

  function bgValidEvalType() {

    return {
      restrict: 'A',
      require: 'ngModel',
      link: function (scope, elm, attrs, ctrl) {
        ctrl.$parsers.unshift(function (viewValue) {
          ctrl.$setValidity('bgValidEvalType', viewValue.applies);
          return viewValue;
        });

        //For model -> DOM validation
        ctrl.$formatters.unshift(function (viewValue) {
          ctrl.$setValidity('bgValidEvalType', viewValue.applies);
          return viewValue;
        });
      }
    };
  }

  bgValidEvalType.$inject = [];

  win.MainApp.Directives
    .directive('bgValidEvalType', bgValidEvalType);

}(window));
