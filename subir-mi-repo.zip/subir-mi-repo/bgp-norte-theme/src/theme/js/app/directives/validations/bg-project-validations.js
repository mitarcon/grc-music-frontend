(function (win){
  'use strict';
  function bgProjectValidations(filter, catalogFilter, isEmpty){
    return {
      require: 'ngModel',
      scope: {},
      link: function(scope, elm, attrs, ngModel) {

        var validate = function(viewValue) {

          if (!isEmpty(viewValue)) {

            var project = filter('filter')
              (catalogFilter('projects'),{id:viewValue}, true)[0];

            var promotersRelated = filter('filter')
              (catalogFilter('projectPromoterRelations'),
              {projectId:viewValue}, true)[0];

            if(!project.financed){
              ngModel.$setValidity('financedProject', false);
            }else{
              ngModel.$setValidity('financedProject', true);
            }

            if (isEmpty(promotersRelated)) {
              ngModel.$setValidity('noPromoters', false);
            }else{
              ngModel.$setValidity('noPromoters', true);
            }

          }else{
            ngModel.$setValidity('financedProject', true);
            ngModel.$setValidity('noPromoters', true);
          }

          return viewValue;

        };

        ngModel.$parsers.unshift(validate);
        ngModel.$formatters.unshift(validate);

      }
    };
  }
  bgProjectValidations.$inject = ['$filter',
                                  'catalogFilter',
                                  'isEmptyFilter'];
  win.MainApp.Directives.directive('bgProjectValidations', bgProjectValidations);
}(window));
