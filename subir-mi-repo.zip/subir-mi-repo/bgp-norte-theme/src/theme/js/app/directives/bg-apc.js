(function(win) {
  "use strict";

  function bgApc(filter, bgValue, isEmpty, trans, catalogFilter, routeInvoker,
    reportsService, jasperServices) {
    return {
      restrict: 'E',
      scope: {
        apcModel: '=',
        apcFilter: '=?',
        clientTab: '=',
        executeBusinessRuleFn: '&',
        updateCustomerApcFlagFn: '=',
        findApcFn: '=',
        quoteStatus: '=',
        quoteStage: '=',
        printApcLetterWrapper: '&',
        quoteId: '=',
        evaluationTypePromo: '=',
        getApcDataAdditionalParticipant: '&',
        setApcDataAdditionalParticipant: '&',
        actualDate: '=',
        app:'=',
        isDisableTab: '=',
        isDisabledQuote: '=',
        participant: '='
      },
      template: '<div ng-include="template"></div>',
      link: link
    };

    function link(scope){
      /*
      ===============
      VALUES
      ===============
      */

      scope.template = filter('BgpTplRootUrl')('partials/bg-apc.html');
      var counter = 0;
      var defaultPercent = 100.0;
      scope.obligationUse = {};

      init();

      /*
      ===============
      METHODS
      ===============
      */
      scope.rangeLimitMsg = rangeLimitMsg;
      scope.changeConcept = changeConcept;
      scope.changePointColor = changePointColor;
      scope.clickAddRow = clickAddRow;
      scope.clickCustomerSignedLetter = clickCustomerSignedLetter;
      scope.clickHideForm = clickHideForm;
      scope.clickLinkContinue = clickLinkContinue;
      scope.clickPrintLetter = clickPrintLetter;
      scope.clickRemoveRow = clickRemoveRow;
      scope.clickRetrying = clickRetrying;
      scope.clickSeeDetail = clickSeeDetail;
      scope.clickShowActive = clickShowActive;
      scope.clickShowAll = clickShowAll;
      scope.clickShowForm = clickShowForm;
      scope.clickSeeSummary = clickSeeSummary;
      scope.clickToggleRow = clickToggleRow;
      scope.clickUpdateRow = clickUpdateRow;
      scope.executeUpdate = executeUpdate;
      scope.formatDate = formatDate;
      scope.getApcAppliesTo = getApcAppliesTo;
      scope.getObligationUse = getObligationUse;
      scope.hideUpdateApc = hideUpdateApc;
      scope.historyClass = historyClass;
      scope.showUpdateObligations = showUpdateObligations;
      scope.tableInitRow = tableInitRow;

      // basado en este comentario se realiza esta implementacion
      // https://stackoverflow.com/questions/29857998/proper-way-to-pass-functions-to-directive-for-execution-in-link
      scope.executeBusinessRuleFn = scope.executeBusinessRuleFn();

      function rangeLimitMsg(min, max){
        var msg = trans.getValue('car.quote.price.message',
        [filter('currency')(min.toString(),'$',2),
        filter('currency')(max.toString(),'$',2)]);
        return msg;
      }

      function changeConcept(index) {
        if (scope.tableRowsEdit[index].data.hasMonthlyFee) {
          scope.tableRowsEdit[index].data.hasMonthlyFee = false;
        }
      }
      function changePointColor(color) {
        if (color === "GRIS") {
          color = 'indicator-gray';
        } else if (color === "VERD") {
          color = 'indicator-green';
        } else if (color === "AMAR") {
          color = 'indicator-yellow';
        } else if (color === "ROJO") {
          color = 'indicator-red';
        }
        return color;
      }
      function clickAddRow() {
        setDefaultRowEditValue('active');
        var activeObligationsLastCounter;
        if (isEmpty(scope.apcModel.activeObligations)) {
          scope.apcModel.activeObligations = [];
        }
        var activeManualObligations =
          scope.apcModel.activeObligations.filter(function(obj) {
            return obj.type === 'MA';
        });
        if (isEmpty(activeManualObligations)) {
          counter++;
        } else {
          activeObligationsLastCounter = filter('orderBy')(
            activeManualObligations, '-sequence');
          counter = activeObligationsLastCounter[0].sequence + 1;
        }
        var amount = null;
        if(scope.newObligation.tableNewConcept !==
          bgValue('product').mortgage) {
          amount = 0;
        }else {
          amount = scope.newObligation.tableNewRowBalance;
        }
        var entityName = null;
        if(!isEmpty(scope.newObligation.tableNewRowInstitution)) {
          entityName =
            scope.newObligation.tableNewRowInstitution.toUpperCase();
        }
        var newObligation = {
          referenceId: counter,
          isFinancialEntity: '',
          startDate: undefined,
          endDate: undefined,
          canceledDate: undefined,
          history: '',
          sequence: counter,
          relationship:{
            id:scope.newObligation.tableNewConcept,
            name:getObligationTypes(scope
            .newObligation.tableNewConcept)
          },
          entityName: entityName,
          daysOverdue: 0,
          type: 'MA',
          payments: 0,
          percentage: defaultPercent,
          paymentMethod:{
            id:scope.newObligation.tableNewRowPaymentMethod,
            name:getPaymentMethods(scope.newObligation.tableNewRowPaymentMethod)
          },
          amount: amount,
          lastPaymentAmount: 0,
          balance: scope.newObligation.tableNewRowBalance,
          initialMonthly: scope.newObligation.tableNewRowMonthly,
          apcAmount: scope.newObligation.tableNewRowMonthly,
          spApcAmount: scope.newObligation.tableNewRowMonthly,
          userObservation: scope.newObligation.tableNewRowComment,
          observation: '',
          status: 'A',
          automatic: scope.newObligation.tableNewRowAutomatic,
        };
        scope.apcModel.activeObligations.push(newObligation);
        scope.tableNewRowOptionFormVisible = false;
        scope.newObligation.tableNewConcept = '';
        scope.newObligation.tableNewRowInstitution = '';
        scope.newObligation.tableNewRowPaymentMethod = '';
        scope.newObligation.tableNewRowBalance = 0;
        scope.newObligation.tableNewRowMonthly = 0;
        scope.newObligation.tableNewRowComment = '';
        scope.newObligation.tableNewRowAutomatic = false;
        scope.executeBusinessRuleFn();
      }
      function clickRemoveRow(index) {
        scope.apcModel.activeObligations.splice(index, 1);
        scope.tableRowsEdit.splice(index, 1);
        scope.$parent.apcCtrl.global.quoteMasterForm.$setDirty();
        scope.executeBusinessRuleFn();
      }
      function clickCustomerSignedLetter() {

        scope.updateCustomerApcFlagFn(scope.apcFilter).then(
        function() {

          scope.apcModel.apcFlag = true;
          scope.messageVisible = false;
          scope.buttonsVisible = false;
          scope.buttonPrintLetterVisible = false;
          scope.executeUpdate(false);

        },
        function(data) {
          //TODO: LLAMAR A ERROR
          // common.callMessageError(data);
        });
      }
      function clickHideForm() {
        scope.tableNewRowOptionFormVisible = false;
      }
      function clickLinkContinue() {
        scope.tableVisible = true;
        scope.menuVisible = true;
        scope.menuUpdateVisible = true;
        scope.alertVisible = false;
        scope.alertLinkContinueVisible = false;
      }
      function clickPrintLetter() {
        scope.buttonCustomerSignedLetterVisible = true;
        printLetter();
      }
      function clickRetrying() {
        // TODO: llevar a value los status
        updateAPC(
          scope.apcModel.apcHeader.connectionStatus==='PS_OK,APC_NO',{
          validate: function() {
            validateModel();
          }
        });
      }
      function clickSeeDetail() {
        scope.menuSeeDetailVisible = false;
        scope.menuSeeSummaryVisible = true;
        scope.tableVisible = true;
        scope.tableSummaryVisible = false;
      }
      function clickShowActive() {
        scope.tableRowFilterActive = true;
        var max = scope.apcModel.paidObligations.length;
        for (var index = 0; index < max; index++) {
          scope.tablePaidRowsOption[index].visible = false;
        }
      }
      function clickShowAll() {
        scope.tableRowFilterActive = false;
        var max = scope.apcModel.activeObligations.length;
        for (var index = 0; index < max; index++) {
          scope.tableRowsOption[index].visible = true;
        }
        var maxPaid = scope.apcModel.paidObligations.length;
        for (index = 0; index < maxPaid; index++) {
          scope.tablePaidRowsOption[index].visible = true;
        }
      }
      function clickShowForm() {
        scope.tableNewRowOptionFormVisible = true;
        scope.newObligation.tableNewRowBalance = 0;
        scope.newObligation.tableNewRowMonthly = 0;
      }
      function clickSeeSummary() {
        scope.menuSeeSummaryVisible = false;
        scope.menuSeeDetailVisible = true;
        scope.tableVisible = false;
        scope.tableSummaryVisible = true;
      }
      function clickToggleRow(index, type) {
        if (type === 'active') {
        scope.tableRowsEdit[index].visible =
          !scope.tableRowsEdit[index].visible;

          if (scope.tableRowsEdit[index].visible) {
            scope.tableRowsEdit[index].data =
              angular.copy(scope.apcModel.activeObligations[index]);
          }
        }else{
          scope.tablePaidRowsEdit[index].visible =
            !scope.tablePaidRowsEdit[index].visible;
        }
      }
      function clickUpdateRow(index) {
        if(!isEmpty(scope.tableRowsEdit[index].data.entityName)) {
          scope.tableRowsEdit[index].data.entityName =
            scope.tableRowsEdit[index].data.entityName.toUpperCase();
        }
        if (scope.tableRowsEdit[index].data.relationship.name.trim() ===
          getObligationTypes(
            scope.tableRowsEdit[index].data.relationship.id).trim()) {
          scope.tableRowsEdit[index].data.hasMonthlyFee = true;
          scope.tableRowsEdit[index].data.initialMonthly =
            angular.copy(scope.tableRowsEdit[index].data.monthly);
        }
        scope.apcModel.activeObligations[index]=
          angular.copy(scope.tableRowsEdit[index].data);

        scope.apcModel.activeObligations[index].apcAmount=
          angular.copy(scope.tableRowsEdit[index].data.spApcAmount);

        scope.apcModel.activeObligations[index].relationship.name =
          getObligationTypes(scope.tableRowsEdit[index]
          .data.relationship.id);
        if(!isEmpty(scope.apcModel.activeObligations[index].entityName)) {
          scope.apcModel.activeObligations[index].entityName =
            scope.apcModel.activeObligations[index].entityName.toUpperCase();
        }
        scope.tableRowsEdit[index].visible = false;
        scope.executeBusinessRuleFn();
      }
      function executeUpdate(force) {
        updateAPC(force,{
          validate: function() {
            validateModel();
          }
        });
      }
      function formatDate(str, format) {
        var fmt = trans.getValue('apc.js.format1');
        if (format !== undefined) {
          fmt = trans.getValue(format);
        }
        var val = moment(str, trans.getValue('apc.java.format')).toDate();
        // Control formato de APC - Obligaciones format2/format3
        // format2: dd 'de' MMMM  / format3: dd 'de' MMMM 'de' yyyy
        if (!isEmpty(scope.actualDate) && format === 'apc.js.format3'){
          var actualYear = moment(scope.actualDate,
                trans.getValue('apc.java.format')).toDate().getFullYear();
          var dinamicYear = val.getFullYear();
          if (actualYear === dinamicYear){
            fmt = trans.getValue('apc.js.format2');
          }
        }
        return filter('date')(val, fmt);
      }
      function getApcAppliesTo(val) {
        if (isEmpty(val)) {
          return;
        }
        var apcAppliesTo = catalogFilter('apcAppliesTo' , scope.app);
        for (var index in apcAppliesTo) {
          if (apcAppliesTo[index].id === val) {
            return apcAppliesTo[index].name;
          }
        }
      }
      function getObligationTypes(val) {
        if (isEmpty(val)) {
          return;
        }
        var ObligationTypes = catalogFilter('apcManualObligationTypes', scope.app);
        for (var index in ObligationTypes) {
          if (ObligationTypes[index].id === val) {
            return ObligationTypes[index].name;
          }
        }
      }
      function getObligationUse(val, field, toDisable) {
        if (isEmpty(val)) {
          return;
        }
        if (!isEmpty(scope.obligationUse) &&
          (!isEmpty (scope.obligationUse.name) ||
          !isEmpty (scope.obligationUse.id)) &&
          (scope.obligationUse.name === val ||
            scope.obligationUse.id === val)) {
          if (toDisable) {
            return !getObligationUseProperty(
              val, field, scope.obligationUse);
          }
          return getObligationUseProperty(val, field, scope.obligationUse);
        }
        var exist = false;
        var obligationsUses = catalogFilter('obligationUses',scope.app);
        for (var index in obligationsUses) {
          /*
          * Se valida que exista el tipo de obligacion en el catalogo
          * de los usos de obligaciones
          **/
          if (!isEmpty (obligationsUses[index].name) ||
            !isEmpty (obligationsUses[index].id)){
              if (obligationsUses[index].name === val ||
                obligationsUses[index].id === val) {
                  exist = true;
                scope.obligationUse = obligationsUses[index];
                return getObligationUseProperty(
                  val, field, obligationsUses[index]);
              }
          }
        }
        if (toDisable) {
          return !exist;
        }
        return true;
      }
      function getObligationUseProperty(val, field, oblUse) {
        switch (field) {
          case 'applyTo':
            return oblUse.apply;
          default:
            return oblUse[field];
        }
      }
      function getPaymentMethods(val) {
        if (isEmpty(val)) {
          return;
        }
        var paymentMethods = catalogFilter('apcPaymentMethods', scope.app);
        for (var index in paymentMethods) {
          if (paymentMethods[index].id === val) {
            return paymentMethods[index].name;
          }
        }
      }
      function hideUpdateApc() {
        if (isEmpty(scope.apcModel.apcHeader)) {
          return;
        }
        return scope.apcModel.apcHeader.apcStatus ===
          bgValue('debtorLostApcFlagCode') || scope.quoteStatus ===
          trans.getValue('constant.update.status.param.cancel') ||
          scope.quoteStage === trans.getValue('constant.quote.stage.evaluation');
      }
      function historyClass(value) {
        var val = parseInt(value);
        var clazz = 'history-cell-color-';
        if (val === 0) {
          clazz += 'gray';
        } else if (val === 1 || val === 2) {
          clazz += 'green';
        } else if (val === 3 || val === 4) {
          clazz += 'yellow';
        } else if (val >= 5 && val <= 9) {
          clazz += 'red';
        }
        return clazz;
      }
      function init() {

        // debtorLostApcFlagCode = bgValue('debtorLostApcFlagCode');
        var counter = parseInt(trans.getValue('car.manual.obligations.init.counter'));

        /*
         * TODO: Se necesita migrar los servicios de Documentos
         */
        var printApcPromises = reportsService
          .getReportPromises(bgValue('bgDocumentCode').cardApc);

        // menu
        scope.menuVisible = loadApcMark(false);
        scope.menuUpdateVisible = false;
        scope.menuSeeSummaryVisible = loadApcMark(false);
        scope.menuSeeDetailVisible = false;

        // alert
        scope.alertVisible = false;
        scope.alertKey = '';
        scope.alertClassName = '';
        scope.alertIconClassName = '';
        scope.alertLinkContinueVisible = false;

        // message
        scope.messageVisible = false;
        scope.messageKey = '';

        // buttons
        scope.buttonsVisible = false;
        scope.buttonRetryingVisible = false;
        scope.buttonCustomerSignedLetterVisible = false;
        scope.buttonPrintLetterVisible = false;

        // table summary
        scope.tableSummaryVisible = false;

        // table
        scope.tableVisible = loadApcMark(false);
        scope.tableRowFilterActive = false;
        scope.tableRowsEdit = [];
        scope.tablePaidRowsEdit = [];
        scope.tableRowsOption = [];
        scope.tablePaidRowsOption = [];
        scope.tableNewRowOptionVisible = true;
        scope.tableNewRowOptionFormVisible = false;
        scope.tableNewConcept = '';
        scope.tableNewRowInstitution = '';
        scope.tableNewRowPaymentMethod = '';
        scope.tableNewRowBalance = 0;
        scope.tableNewRowMonthly = 0;
        scope.tableNewRowComment = '';
        scope.tableNewRowAutomatic = false;

        scope.newObligation = {};
        // Seteo de condiciones para desplegar el html de la directiva
        validateModel();
      }
      function loadApcMark(val){
        return scope.quoteStage ===
         bgValue('scoringPhaseStatus').evaluationPhase ? !val : val;
      }
      function printLetter() {
        var wrapper = {
          productType: scope.app,
          productPerson: scope.participant
        };
        var printApcPromises = reportsService
          .getReportPromises(bgValue('bgDocumentCode').cardApc, scope.app);
        printApcPromises.reportPromise(wrapper)
          .then(function(report) {
            jasperServices.openReport(report);
        });
      }
      function setDefaultRowEditValue(type, index, data) {
        if (type === 'active') {
          scope.tableRowsEdit[index] = {
            visible: false,
            data: isEmpty(data) ? {} : data
          };
        } else {
          scope.tablePaidRowsEdit[index] = {
            visible: false,
            data: isEmpty(data) ? {} : data
          };
        }
      }
      function showAlert(key, className, iconClassName){
        scope.alertVisible = loadApcMark(true);
        scope.alertKey = key;
        scope.alertClassName = className;
        scope.alertIconClassName = iconClassName;

        if (scope.alertClassName === undefined) {
          scope.alertClassName = 'alert-info';
        }
        if (scope.alertIconClassName === undefined) {
          scope.alertIconClassName = 'fa-exclamation-circle';
        }
      }
      function showAlertDeceased() {
        showAlert('apc.obligations.deceased', 'alert-warning');
        scope.alertLinkContinueVisible = true;
      }
      function showAlertWithoutConnection() {
        var messageKey = 'apc.obligations.withoutConnection';
        if (scope.retryingCounter > 0) {
          messageKey = 'apc.obligations.tryLater';
        }
        showAlert(messageKey, 'alert-danger', 'fa-times-circle');
        scope.buttonsVisible = true;
        scope.buttonRetryingVisible = true;
        scope.buttonCustomerSignedLetterVisible = false;
      }
      //Esta funcion valida si la cotizacion se guardo con promocode
      function showUpdateObligations(){
        return scope.evaluationTypePromo ==='PROMO' &&
         scope.quoteId > 0;
      }
      function showData() {
        scope.tableVisible = true;
        scope.tableSummaryVisible = false;
        scope.menuVisible = true;
        scope.menuUpdateVisible = true;
        scope.menuSeeSummaryVisible = true;
        scope.menuSeeDetailVisible = false;
        scope.alertVisible = false;
        scope.buttonsVisible = false;
        scope.buttonRetryingVisible = false;
        scope.messageVisible = false;
        scope.alertKey = '';
        scope.alertClassName = '';
        scope.alertIconClassName = '';
        scope.alertLinkContinueVisible = false;
        scope.messageKey = '';
      }
      function tableInitRow(type, index, data) {
        if (type === 'active') {
          scope.tableRowsOption[index] = {
            visible: true,
            infoVisible: false
          };
          setDefaultRowEditValue(type, index, data);
        } else {
          scope.tablePaidRowsOption[index] = {
            visible: true,
            infoVisible: false
          };
          setDefaultRowEditValue(type, index, data);
        }
      }
      function updateAPC(force, success, error) {
        scope.showLoading = true;
        if (force === undefined) {
          force = false;
        }
        if (isEmpty(scope.apcModel.activeObligations)) {
          scope.apcModel.activeObligations = [];
        }
        angular.forEach(scope.apcModel.activeObligations, function(data) {
          if(data.relationship &&
          data.relationship.id === bgValue('codeHouseRental') &&
          data.type === bgValue('obligationTypes').manual){
            scope.apcFilter.addHouseRentalObligation = false;
          }
        });
        //hold the manual obligations
        var manualObligations =
          scope.apcModel.activeObligations
          .filter(function(obj) {
            return obj.type === bgValue('obligationTypes').manual;
        });
        scope.apcFilter.forceUpdate = force;
        routeInvoker.invoke(scope.app,'findAPC', scope.apcFilter).then(
        function(response) {
          scope.retryingCounter = 0;
          if (response.data.activeObligations) {
            scope.apcModel.activeObligations = response.data.
              activeObligations;
          }
          if (response.data.paidObligations) {
            scope.apcModel.paidObligations = response.data.
              paidObligations;
          }
          scope.apcModel.apcHeader = response.data.apcHeader;
          scope.apcModel.apcFlag = response.data.apcFlag;
          if ( !isEmpty(manualObligations) && manualObligations.length > 0) {
            angular.forEach(manualObligations, function(data){
              var find = false;
              angular.forEach(scope.apcModel.activeObligations, function(newObligations) {
                if(data.sequence === newObligations.sequence){
                  find = true;
                }

              });
              if(!find){
                scope.apcModel.activeObligations.push(data);
              }
            });

          }
          if (scope.clientTab) {
            scope.executeBusinessRuleFn(updateApcDataRule, success);
          } else {
            scope.executeBusinessRuleFn(success.validate);
          }
        }, function() {
          scope.retryingCounter++;
          scope.apcModel.status = false;
          if (angular.isFunction(error)) {
            error();
          }
        }).finally(function(){
          scope.showLoading = false;
        });
      }
      function updateApcDataRule(success) {
        scope.apcModel =
          scope.getApcDataAdditionalParticipant()()(scope.participant.entityId);
        success.validate();
      }
      function validateModel(){
        //Si la persona no ha permitido consultar su información de APC
        if (!scope.apcModel.apcFlag && !scope.apcModel.apcTemporaryFlag) {
          showAlert('apc.obligations.lackAuthorization',
            'alert-warning', 'fa-exclamation-circle');
          scope.messageVisible = loadApcMark(true);
          scope.messageKey = 'apc.obligations.withoutAuthorization';
          scope.buttonsVisible = loadApcMark(true);
          scope.buttonRetryingVisible = false;
          scope.buttonPrintLetterVisible = true;
          return;
        }

        var connStatus = scope.apcModel.apcHeader.connectionStatus;
        if (!isEmpty(connStatus) && connStatus.indexOf("APC_NO") > -1 ||
         scope.apcModel.apcHeader.apcStatus === undefined) {
          showData();
          showAlertWithoutConnection();
          return;
        }
        //Se llevo la condicion al if superior porque tienen el mismo comportamiento
        // if (scope.apcModel.apcHeader.apcStatus === undefined) {
        //   showData();
        //   showAlertWithoutConnection();
        //   return;
        // }
        switch (scope.apcModel.apcHeader.apcStatus) {
          case 0:
            showData();
            showAlert('apc.obligations.withoutReference','alert-warning');
            break;
          case 1:
            showData();
            showAlert('apc.obligations.withoutReference','alert-warning');
            break;
          case 2:
            showAlertDeceased();
            break;
          case 3:
            showAlertDeceased();
            break;
          case bgValue('debtorLostApcFlagCode'):
          /*custom state when the customer lost apcFlag*/
            showData();
            break;
          default:
            showData();
            break;
        }
        if(!scope.apcModel.apcFlag && scope.apcModel.apcTemporaryFlag){
          scope.buttonsVisible = true;
          scope.buttonPrintLetterVisible = true;
          showAlert('apc.obligations.lackAuthorizationTemp',
            'alert-warning', 'fa-exclamation-circle');
        }
      }
    }
  }


  bgApc.$inject = [
    '$filter',
    'bgValueFilter',
    'isEmptyFilter',
    'translateService',
    'catalogFilter',
    'routeInvoker',
    'reportsService',
    'jasperServices'
  ];
  win.MainApp.Directives
    .directive('bgApc', bgApc);
}(window));
