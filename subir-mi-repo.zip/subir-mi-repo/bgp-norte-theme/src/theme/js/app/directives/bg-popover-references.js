(function(win) {
  'use strict';

  function bgPopoverReferences(isEmpty,
    riesgoCredito) {

    return {
      restrict: 'E',
      transclude: true,
      scope: {
        participant: '=',
        manager: '='
      },
      templateUrl: window.baseThemeURL +
        'partials/bg-popover-references.html',

      link: function(scope) {

        if (!isEmpty(scope.participant.warnings)) {
          angular.forEach(scope.participant.warnings,
            function(value) {
              if (value.type.id === riesgoCredito) {
                scope.creditRisk = true;
              } else {
                scope.referenceGreater = true;
              }
            });
        }

      }

    };
  }

  bgPopoverReferences.$inject = ['isEmptyFilter',
                                 'riesgoCredito',
  ];

  win.MainApp.Directives.directive('bgPopoverReferences', bgPopoverReferences);

}(window));
