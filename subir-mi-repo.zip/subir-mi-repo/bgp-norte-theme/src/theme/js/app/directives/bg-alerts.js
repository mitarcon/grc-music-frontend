(function (win) {
    "use strict";

    function bgAlerts() {
        return {
            restrict: 'E',
            scope: {
                alerts: '='
            },
            templateUrl: window.baseThemeURL + 'partials/bg-alerts.html'
        };
    }

    bgAlerts.$inject = [];

    win.MainApp.Directives
        .directive('bgAlerts', bgAlerts);
}(window));
