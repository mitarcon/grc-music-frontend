/* globals angular, appName, $ */

(function () {
    "use strict";

    function externalLinkQuestion($rootScope) {
        return {
            link: function ( scope, element, attrs ) {
                angular.element(element).bind("click", function (e) {
                    e.preventDefault();

                    $("#externalLinkModal").modal('show');

                    $rootScope.externalLinkHref = attrs.href;
                });
            }
        };
    }

    angular
        .module(appName + ".directives")
        .directive('externalLinkQuestion', externalLinkQuestion);

    externalLinkQuestion.$inject = ['$rootScope'];

}());
