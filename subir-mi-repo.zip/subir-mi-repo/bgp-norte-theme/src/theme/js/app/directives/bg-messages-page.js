(function(win) {
  'use strict';
  /**
   *
   * @param {String} alertType 'warning, danger, success, info '
   * @param {String} iconType 'fa-exclamation-circle, fa-times-circle, fa-check-circle, fa-info-circle'
   * @param {String} alertMessage
   * @param {String} secondaryMessage
   * @param {String} thirdMessage
   * @param {Boolean} showRedirectButton
   * @param {String} redirectButtonText
   * @param {String} redirectUrl
   * @param {String} templateBodyUrl 'string template url to include in body'
   *
   */

  function bgMessagesPage(log) {

    log.debug("[BG-messages] Initializing...");

    return {
      scope: {
        alertType: '@',
        iconType: '@',
        alertMessage: '@',
        secondaryMessage: '@',
        thirdMessage: '@',
        showRedirectButton: '=?',
        redirectButtonText: '@',
        redirectUrl: '@',
        templateBodyUrl: '@',
        messages: '='
      },
      restrict: 'E',
      templateUrl: window.baseThemeURL +
        'partials/bg-messages-page.html'
    };
  }

  /*
  ===============
  CONFIGIRATION
  ===============
  */
  bgMessagesPage.$inject = ['$log'

  ];
  win.MainApp.Directives
    .directive("bgMessagesPage",
    bgMessagesPage);

}(window));
