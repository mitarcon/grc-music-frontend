(function(win) {
  'use strict';

  function bgClient(isEmpty, log, bgValue, filter, commonFunctions, cedFilter,
    modalService, bgParamsService, redirect, storage, bgProductConfig) {

    return {
      scope: {
        'participant': '=',
        'executeBusinessRule': '&',
        'catalogs': '=',
        'location': '@',
        'disableLinks': '='
      },
      restrict: 'E',
      templateUrl: window.baseThemeURL + 'partials/bg-client.html',
      link: function(scope) {

        scope.getLastEmailContact = function(contactData){
          var emails = "-";

          if (!isEmpty(contactData)) {

            emails = contactData.filter(function(obj) {
              return obj.type.id === bgValue('contactType').mail ||
                obj.type.id === bgValue('contactTypeWorkEmail').id;
            });

            if (!angular.isUndefined(emails) && emails.length > 0) {

              emails = filter('orderBy')(emails, '-modificationDate')[0].name;

            } else {

              emails = "-";

            }

          }

          return emails;
        };

        scope.getMaxDepositAmount = function() {
          return bgParamsService.getAccountMaxDepositAmount();
        };

        scope.getLastPhoneContact = function(contactData) {

          var phones = "-";

          if (!isEmpty(contactData)) {

            phones = contactData.filter(function(obj) {
              return obj.type.id === 'C';
            });

            if (!angular.isUndefined(phones) && phones.length > 0) {

              phones = filter('orderBy')(phones,
                '-modificationDate')[0].name;

            } else {
              phones = "-";
            }
          }

          return phones;
        };

        scope.getNameById = function(id, collection) {
          return filter('filter')(collection, {id: id}, true)[0].name;
        };

        scope.creditHistoryIcon = function(record) {
          if (record === bgValue('creditHistory').good) {
            return {
              icon: 'check-circle',
              color: 'verde'
            };
          } else if (record === bgValue('creditHistory').regular) {
            return {
              icon: 'exclamation-circle',
              color: 'amarillo'
            };
          } else if (record === bgValue('creditHistory').higher) {
            return {
              icon: 'exclamation-circle',
              color: 'rojo'
            };
          }
        };

        function getAPCDocumentNumber(documentNumber, documentType) {
          return commonFunctions.getAPCDocumentNumber(documentNumber, documentType);
        }

        function getAPCIdentificationType(documentNumber, documentType) {
          return commonFunctions.getAPCIdentificationType(documentNumber,
            documentType);
        }

        scope.setApcData = function(entityId, apcData) {
          scope.participant.apcData = apcData;
        };

        scope.toCustomerManagement = function(participant) {

          scope.showLoading = true;

          var person = {
            entityId: participant.entityId,
            apcData: {
              apcTemporaryFlag: false
            }
          };

          storage.updatePerson(scope, person);
          storage.updateIpcWrapper(scope, false, 'newClientFlag');
          storage.updateIpcWrapper(scope, false, 'wizardFlag');
          storage.updateIpcWrapper(scope, false, 'withProduct');
          storage.updateIpcWrapper(scope, scope.location, 'location');
          storage.setProductConfig(bgProductConfig.get(bgValue('apps').liabilityAdvice));

          redirect.toCustomerManagement();

        };

        scope.getApcData = function() {
          return scope.participant.apcData;
        };

        scope.viewApc = function() {
          var attrs = {
            bgModalMethod: scope.setApcData,
            bgModalTpl: 'bgp-norte-theme/angular/partials/bgp-popup/bg-popup-apc-additional.html',
            bgModalData: {
              participant: scope.participant,
              ruleFn: scope.executeBusinessRule,
              apcFilter: {
                product: {
                  id: scope.product
                },
                customerId: scope.participant.entityId,
                identificationType: getAPCIdentificationType(
                  scope.participant.documentNumber,
                  scope.participant.documentType),
                identification: getAPCDocumentNumber(scope.participant.documentNumber,
                  scope.participant.documentType),
                forceUpdate: false,
                addHouseRentalObligation: false
              },
              getApcDataAdditionalParticipant: scope.getApcData,
              setApcDataAdditionalParticipant: scope.setApcData,
              showLoading: scope.showLoading,
              app: scope.location
            },
            bgSize: "lg"
          };
          modalService.open(attrs);
        };
      }
    };

  }

  bgClient.$inject = [
    'isEmptyFilter',
    '$log',
    'bgValueFilter',
    '$filter',
    'commonFunctions',
    'cedFilter',
    'modalService',
    'bgParamsService',
    'bgRedirectService',
    'storageService',
    'bgProductConfig'
  ];

  win.MainApp.Directives.directive('bgClient', bgClient);

}(window));
