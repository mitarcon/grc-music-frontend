(function (win) {
  'use strict';

  function bgYearValid() {

    var validateApplies = function (isYearError) {
      return (isYearError === "true");
    };

    return {
      restrict: 'A',
      require: 'ngModel',
      link: function (scope, elm, attrs, ctrl) {
        ctrl.$parsers.unshift(function (viewValue) {
          var valid = validateApplies(attrs.bgYearValidVal);
          ctrl.$setValidity('bgYearValid', valid);
          return viewValue;
        });

        //For model -> DOM validation
        ctrl.$formatters.unshift(function (viewValue) {
          var valid = validateApplies(attrs.bgYearValidVal);
          ctrl.$setValidity('bgYearValid', valid);
          return viewValue;
        });
      }
    };
  }


  bgYearValid.$inject = [];

  win.MainApp.Directives
    .directive('bgYearValid', bgYearValid);

}(window));
