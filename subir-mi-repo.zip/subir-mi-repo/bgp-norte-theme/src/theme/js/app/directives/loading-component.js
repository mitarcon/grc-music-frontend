(function (win) {
    "use strict";

    function loadingComponent(
      serviceInvoker
    ) {
        return {
            restrict: 'E',
            scope: {
                display: '='
            },
            templateUrl: window.baseThemeURL + 'partials/loading_component.html',
            link: link
        };
        function link(scope){
          scope.loading = serviceInvoker;
        }
    }

    loadingComponent.$inject = [
      'serviceInvoker'
    ];

    win.MainApp.Directives
        .directive('loadingComponent', loadingComponent);
}(window));
