(function (win) {
    "use strict";

    function customSelectComponent() {
        return {
            restrict: 'EA',
                scope: {
                options: '=',
                selectedOption: '=',
                nameField: '@',
                summaryField: '@',
                blankOption: '@'
            },
            templateUrl: window.baseThemeURL + 'common/custom_select_component.html'
        };
    }

    customSelectComponent.$inject = [];

    win.MainApp.Directives
        .directive('customSelect', customSelectComponent);
}(window));
