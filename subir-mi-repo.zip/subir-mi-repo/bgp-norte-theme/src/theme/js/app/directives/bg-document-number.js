(function(win) {
  "use strict";

  function documentNumber($log, $window, bgValue, isEmpty) {

    return {
      require: 'ngModel',
      restrict: 'A',
      link: function(scope, elem, attr, ngModel) {

        var validate = function(viewValue) {

        if(!isEmpty(viewValue)){
          ngModel.$setValidity('identification',
            bgValue('bgPatternsList').identification.test(viewValue));
        }

          return viewValue;

        };

        ngModel.$parsers.unshift(validate);
        ngModel.$formatters.unshift(validate);
      }
    };
  }

  documentNumber.$inject = [
    "$log",
    "$window",
    "bgValueFilter",
    "isEmptyFilter"
  ];

  win.MainApp.Directives.directive('documentNumber', documentNumber);

}(window));
