(function(win){
  'use strict';

  function bgpFileUpload(
    BgpTplRootUrl
  ){
    var directive = {
      restrict: 'E',
      scope: {
        newFile: '=ngModel',
      },
      require : 'ngModel',
      templateUrl: BgpTplRootUrl('partials/bgp-file-upload.html'),
      link: link
    };
    return directive;
    function link(scope){
      scope.addNewFile = addNewFile;

      function addNewFile (){
        var posicion = scope.newFile.file[0].name.lastIndexOf('.');
        scope.newFile.name = scope.newFile.file[0].name.substring(0, posicion);
        scope.newFile.type = scope.newFile.file[0].name.substring(posicion+1);
      }
    }
  }

  /*
  ==============
  CONFIGURATION
  ==============
  */

  bgpFileUpload.$inject =[
    'BgpTplRootUrlFilter'
  ];

  win.MainApp.Directives
    .directive('bgpFileUpload', bgpFileUpload);

}(window));
