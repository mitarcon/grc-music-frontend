(function(win){
  'use strict';

  function bgClientIdentification(log, parse, filter,
                                bgPatternsList, clientNameRule,
                                isEmpty, config, utils, bgValue){
    log.debug('[bgClientIdentification] Initializing...');

    /*
    ==============
    VALUES
    ==============
    */

    return{
      require: 'ngModel',
      restrict: 'E',
      scope: {
        identification: '=?ngModel',
        isValidField: '=?isValid',
        autoFocus: '@',
        bgDisabled: '@'
      },
      template: '<div ng-include="template"></div>',

      link: function (scope, elm, attrs, ctrl){

        scope.template = window.baseThemeURL +
                         'partials/bg-client-identification.html';
        scope.config = config;
        scope.isValidField = true;
        var identification = {};

        var modelType = 'object';
        var invalid = " ng-invalid";
        var mandatoryString =
          'form-control text-uppercase ng-invalid-required';

        var nonMandatoryString = 'form-control text-uppercase';

        /*
        ============
        SETUP
        ============
        */

        var init = function () {
          generatePlaceholders();
          toggleAll();
          scope.$watch('identification', function (newVal) {
            if (isEmpty(newVal)) {
              angular.forEach(scope.config, function (item) {
                item.input = '';
                item.complete = '';
              });
            }
          });
          var watcher = scope.$watch('identification', function () {
            if (!isEmpty(scope.identification)) {
              if (typeof scope.identification === 'string') {
                modelType = 'string';
                identification = utils.textToModel(scope.identification);
              }
              else {
                identification = angular.copy(scope.identification);
              }
              angular.forEach(scope.config, function (item) {
                item.input = identification[item.name];
                scope.generate(item);
              });
              watcher();
            }
          });
        };
        init();

        /*
        =========
        METHODS
        =========
        */

        function generatePlaceholders() {
          angular.forEach(scope.config, function (item) {
            item.placeholder = addPad(item.placeholder, item.defaultHolder,
              item.max, item.pad);
          });
        }

        function addPad(elem, chr, size, direction) {
          var value = angular.isDefined(elem) ? elem.toString() : '';
          if (value.length > 0 && value.length < size) {
            var max = (size - value.length)/chr.length;
            for (var i = 0; i < max; i++) {
              value = direction === bgValue('orientationType').left ?
              (chr + value) : value + chr;
            }
          }
          return value;
        }

        var configItem = function (name) {
          return filter('filter')(scope.config, function (item) {
            return name === item.name;
          })[0];
        };

        var undefinedField = function (name) {
          var item = configItem(name);
          if (angular.isDefined(item.input)) {
            toggleOne(item, item.input.length>0);
          }
          else {
            item.input = '';
            toggleOne(item, false);
          }
        };

        scope.generate = function (item) {
          item.input =
            addPad(item.input, item.defaultHolder, item.max, item.pad);

          if (item.name === bgValue('documentSection').alpha ||
              item.name === bgValue('documentSection').prov) {
            undefinedField(item.name);
            var anotherItem =
              configItem(item.name === 'province'?'alpha':'province');

            undefinedField(anotherItem.name);
            if(item.input.length > 0 || anotherItem.input.length > 0) {
              toggleOne(item, false);
              toggleOne(anotherItem, false);
            }else{
              toggleOne(anotherItem, true);
              toggleOne(item, true);
            }
            buildClientId();
            return;
          }
          angular.forEach(scope.config, function (item) {
            toggleOne(item, item.required);
          });
          toggleOne(item, item.input.length === 0);
          buildClientId();
        };

        function toggleAll() {
          angular.forEach(scope.config, function (item) {
            toggleOne(item, item.input === '');
          });
        }

        function toggleOne(item, specific) {
          item.required = angular.isDefined(specific) ? specific : false;
          item.classes = item.required ? mandatoryString : nonMandatoryString;
        }

        function isNumber(item) {
          return angular.isNumber(item);
        }


        var evalValue = function (key, value) {
          var REGEXP = bgPatternsList[key];
          return REGEXP.test(value);
        };

        function addRemoveStyle(condition, itemName) {
          var item = configItem(itemName);
          if (!isNaN(condition)) {
            if (!condition) {
              item.classes = item.classes + invalid;
            } else {
              item.classes = item.classes.replace(invalid, '');
            }
          }
        }

        var isValid = function () {
          scope.isValidField = true;
          angular.forEach(scope.config, function (item) {
            var validItem = evalValue(item.pattern, item.complete);
            addRemoveStyle(validItem, item.name);
            if (!validItem) {
              scope.isValidField = false;
              ctrl.$$parentForm.$aaFormExtensions[ctrl.$name]
                .showErrorReasons = ['bgClientIdentification'];
            }
          });

          return scope.isValidField;
        };



        function completeField(val, item) {
          item.complete = addPad(val, item.defaultHolder, item.max, item.pad);
        }

        function buildClientId() {
          var alpha = configItem('alpha');
          var province = configItem('province');
          var folio = configItem('folio');
          var seat = configItem('seat');
          if (angular.isUndefined(seat.input) ||
            angular.isUndefined(folio.input) ||
            angular.isUndefined(province.input) ||
            angular.isUndefined(alpha.input)) {
            return;
          }
          if ((province.input.length > 0 || alpha.input.length > 0) &&
            folio.input.length > 0 && seat.input.length > 0) {

            if (province.input.length === 0 && alpha.input.length !== 0) {
              completeField('0', province);
            } else {
              completeField(province.input, province);
            }

            if (province.input.length !== 0 && alpha.input.length === 0) {
              completeField(' ', alpha);
            } else {
              completeField(alpha.input, alpha);
            }

            completeField(folio.input, folio);
            completeField(seat.input, seat);
            identification = {
              province: province.complete,
              alpha: filter('uppercase')(alpha.complete),
              folio: folio.complete,
              seat: seat.complete
            };

            ctrl.$setValidity('bgClientIdentification', isValid());

            if (typeof scope.identification === 'object') {
              scope.identification = angular.copy(identification);
            }
            else {
              scope.identification = utils.modelToText(identification);
            }
          }
        }

        scope.focus = function (name) {
          var item = configItem(name);
          if ((!isNumber(item.input) && name !== 'alpha' ) ||
            (isNumber(item.input) && name === 'alpha' ) ||
            angular.isUndefined(item.input) ||
            item.input.length === 0) {
            return;
          }
          item.input = (name === 'alpha') ?
            item.input.replace(' ', '') : parseInt(item.input).toString();
        };

      }
    };


  }

  /*
  ==============
  CONFIGURATION
  ==============
  */
  bgClientIdentification.$inject = ['$log', '$parse','$filter',
                                      'bgPatternsList',
                                      'clientNameRule',
                                      'isEmptyFilter',
                                      'identificationConfig',
                                      'identificationUtils',
                                      'bgValueFilter'];

  win.MainApp.Directives
    .directive('bgClientIdentification', bgClientIdentification);

}(window));
