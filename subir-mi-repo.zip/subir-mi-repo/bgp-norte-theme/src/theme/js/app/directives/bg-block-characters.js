(function(win) {
  "use strict";

  function bgBlockCharacters() {
    return {
      require: 'ngModel',
      restrict: 'A',
      scope: {
        regex: '='
      },
      link: function(scope, elem, attrs, modelCtrl) {

        modelCtrl.$parsers.push(function(inputValue) {
            if (inputValue == null)
            {
              return '';
            }
            inputValue = inputValue.toString();
            var cleanInputValue = inputValue.replace(scope.regex, '');
            if (cleanInputValue != inputValue) {
              modelCtrl.$setViewValue(cleanInputValue);
              modelCtrl.$render();
            }
            return cleanInputValue;
          });
      }
    };
  }

  bgBlockCharacters.$inject = [];

  win.MainApp.Directives
    .directive('bgBlockCharacters', bgBlockCharacters);
}(window));
