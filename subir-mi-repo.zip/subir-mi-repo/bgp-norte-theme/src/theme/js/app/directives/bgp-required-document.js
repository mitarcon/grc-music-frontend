(function(win) {
  "use strict";

  function bgpRequiredDocument($log, $window, bgValue, isEmpty) {

    return {
      require: 'ngModel',
      restrict: 'A',
      scope: {
        bgpRequiredDocument: '=',
      },
      link: function(scope, elem, attr, ngModel) {

        var validate = function(viewValue) {

        if (!viewValue && scope.bgpRequiredDocument == true) {
          ngModel.$setValidity('bgpRequiredDocument', false);
        } else {
          ngModel.$setValidity('bgpRequiredDocument', true);
        }

        return viewValue;

        };

        scope.$watch('bgpRequiredDocument', function() {
          validate(ngModel.$viewValue);
        });

        ngModel.$parsers.unshift(validate);
        ngModel.$formatters.unshift(validate);
      }
    };
  }

  bgpRequiredDocument.$inject = [
    "$log",
    "$window",
    "bgValueFilter",
    "isEmptyFilter"
  ];

  win.MainApp.Directives.directive('bgpRequiredDocument', bgpRequiredDocument);

}(window));
