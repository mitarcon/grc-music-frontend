(function(win) {
  'use strict';

  function bgRangeLimitTwoWay(formConfig, common, translate) {

    return {
      require: 'ngModel',
      scope: {
        min: '=?bgRangeLimitMin',
        max: '=?bgRangeLimitMax',
        exclusive: '=?bgRangeLimitExclusive',
        exception: "=?bgRangeException"
      },
      link: function(scope, element, attrs, ngModel) {
        ngModel.$parsers.unshift(function(viewValue) {
          validate(viewValue);
          return viewValue;
        });
        ngModel.$formatters.unshift(function(viewValue) {
          validate(viewValue);
          return viewValue;
        });
        scope.$watch('max', validate);
        scope.$watch('min', validate);

        function validate(viewValue) {
          maxInclude(viewValue);
          minInclude(viewValue);
          max(viewValue);
          min(viewValue);
        }

        function maxInclude(value) {
          value = common.isEmpty(value) ? ngModel.$modelValue : value;

          if (!common.isEmpty(scope.exclusive) && scope.exclusive === true) {
            //La validacion que se debe realizar es por max
            ngModel.$setValidity('maxInclude', true);
            return true;
          }

          if (angular.isFunction(scope.exception) && scope.exception()) {
            ngModel.$setValidity('maxInclude', true);
            return true;
          }

          var result = true;
          if (!common.isEmpty(scope.max) && !isNaN(scope.max) &&
            !common.isEmpty(value) && !isNaN(value)) {
            result = parseFloat(value) <= parseFloat(scope.max);
          }

          if (!result) {
            // si result es false hay error y debo actualizar el texto
            formConfig.changeValidateMessage("maxInclude",
              translate.getValue('validation.max.include', [attrs.aaLabel, scope.max]));
          }
          ngModel.$setValidity('maxInclude', result);

        }

        function max(value) {

          value = common.isEmpty(value) ? ngModel.$viewValue : value;

          if (common.isEmpty(scope.exclusive) || scope.exclusive === false) {
            //La validacion que se debe realizar es por maxInclude
            ngModel.$setValidity('max', true);
            return true;
          }

          if (angular.isFunction(scope.exception) && scope.exception()) {
            ngModel.$setValidity('max', true);
            return true;
          }

          var result = true;
          if (!common.isEmpty(scope.max) && !isNaN(scope.max) &&
            !common.isEmpty(value) && !isNaN(value)) {
            result = parseFloat(value) < parseFloat(scope.max);
          }

          if (!result) {
            // si result es false hay error y debo actualizar el texto
            formConfig.changeValidateMessage("max",
              translate.getValue('validation.max', [attrs.aaLabel, scope.max]));
          }
          ngModel.$setValidity('max', result);
          return result;

        }

        function minInclude(value) {

          value = common.isEmpty(value) ? ngModel.$modelValue : value;
          if (!common.isEmpty(scope.exclusive) && scope.exclusive === true) {
            //La validacion que se debe realizar es por min
            ngModel.$setValidity('minInclude', true);
            return true;
          }

          if (angular.isFunction(scope.exception) && scope.exception()) {
            ngModel.$setValidity('minInclude', true);
            return true;
          }

          var result = true;
          if (!common.isEmpty(scope.min) && !isNaN(scope.min) &&
            !common.isEmpty(value) && !isNaN(value)) {
            result = parseFloat(value) >= parseFloat(scope.min);
          }

          if (!result) {
            // si result es false hay error y debo actualizar el texto
            formConfig.changeValidateMessage("minInclude",
              translate.getValue('validation.min.include', [attrs.aaLabel, scope.min]));
          }
          ngModel.$setValidity('minInclude', result);

        }

        function min(value) {

          value = common.isEmpty(value) ? ngModel.$viewValue : value;

          if (common.isEmpty(scope.exclusive) || scope.exclusive === false) {
            //La validacion que se debe realizar es por minInclude
            ngModel.$setValidity('min', true);
            return true;
          }

          if (angular.isFunction(scope.exception) && scope.exception()) {
            ngModel.$setValidity('min', true);
            return true;
          }

          var result = true;
          if (!common.isEmpty(scope.min) && !isNaN(scope.min) &&
            !common.isEmpty(value) && !isNaN(value)) {
            result = parseFloat(value) > parseFloat(scope.min);
          }

          if (!result) {
            // si result es false hay error y debo actualizar el texto
            formConfig.changeValidateMessage("min",
              translate.getValue('validation.min', [attrs.aaLabel, scope.min]));
          }
          ngModel.$setValidity('min', result);
          return result;

        }
      }
    };
  }

  bgRangeLimitTwoWay.$inject = [
    'formConfig', 'commonFunctions', 'translateService',
  ];

  win.MainApp.Directives
    .directive('bgRangeLimitTwoWay', bgRangeLimitTwoWay);

}(window));
