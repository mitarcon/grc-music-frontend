(function(win) {
  "use strict";

  function bgBlockEnter() {
    return {
      require : 'ngModel',
      restrict : 'A',
      link : function(scope, elem, attrs, modelCtrl) {

        elem.bind('keydown', function(event) {

          if ('13' == event.which) {

            event.preventDefault();

            window.stop();

            document.execCommand("Stop");

            return false;

          }

        });

      }
    };

  }

  bgBlockEnter.$inject = [];

  win.MainApp.Directives.directive('bgBlockEnter', bgBlockEnter);
  
}(window));