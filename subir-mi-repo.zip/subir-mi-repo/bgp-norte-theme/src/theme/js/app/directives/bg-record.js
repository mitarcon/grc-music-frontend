(function(win) {
  "use strict";

  function bgRecord(trans, log, isEmpty, bgValue, filter) {
    log.debug('[bgRecord] Initializing....');

    return {
      restrict: 'E',
      replace: true,
      scope: {
        record: '=',
        stage:'=',
        user:'=',
        quoteId:'='
      },
      templateUrl: window.baseThemeURL + 'partials/bg-record.html',

      link: function(scope) {
        scope.addNote = addNote;
        scope.deleteNote = deleteNote;
        scope.formattedDate = formattedDate;
        scope.formattedTime = formattedTime;
        scope.procedureRecordsId = procedureRecordsId;

        function addNote() {
          if (isEmpty(scope.observation) || scope.quoteId === 0) {
            return;
          }
          var newRecord;
          newRecord = {
            quoteID: scope.quoteId,
            stage: scope.stage,
            description: trans.getValue('global.follow.up.notes.cap'),
            user: scope.user,
            observation: scope.observation,
            type: {
              id: bgValue('recordTypes').notes.id,
              name: bgValue('recordTypes').notes.name
            },
            isNew: true,
            isDeletable: true
          };
          scope.record.unshift(newRecord);
          scope.observation = '';
        }

        function procedureRecordsId() {
          return "!" + bgValue('recordTypes').notes.id;
        }

        function deleteNote(index) {
          scope.record.splice(index, 1);
        }
        /*
      Gives a format specific to the date; for example : 8-Ago-2017
    */
        function formattedDate(date) {
          if (!isEmpty(date)) {
            var newDate = filter('date')(date, 'd-MMM-y');
            return newDate.replace(".", "");
          }
        }
        function formattedTime(time) {
          if (!isEmpty(time)) {
            var parts = time.split(':');
            if (parts.length === 3) {
              var date = new Date(0, 0, 0, parts[0], parts[1], parts[2]);
              return filter('date')(date, 'shortTime');
            }
          }

        }
      }
    };
  }

  bgRecord.$inject = [
    'translateService',
    '$log',
    'isEmptyFilter',
    'bgValueFilter',
    '$filter',
  ];


  win.MainApp.Directives.directive("bgRecord", bgRecord);
}(window));
