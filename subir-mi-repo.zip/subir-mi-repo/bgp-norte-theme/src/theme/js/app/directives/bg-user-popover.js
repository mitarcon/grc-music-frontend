/* globals angular, appName */

(function(win) {
  "use strict";

  function userPopover(isEmpty, bgValue, routeInvoker, userArray) {
    return {
        restrict: 'E',
        scope: {
          model: '=',
          linkDialog: '@',
          popoverTitle: '@'
        },
        templateUrl: window.baseThemeURL +
        'partials/bg-popover/popover-assign-to-directive.html',
        link: function(scope) {

          scope.executeEvent = function () {
            if (userArray[scope.model.id] == undefined) {

              routeInvoker.invoke(bgValue('apps').quoteEvaluation,
                  'findUserData', scope.model)
                .then(function (response) {
                  userArray[scope.model.id] = response.data;
                  // scope.userArray.push(scope.userArray[scope.model.id]);
                  scope.user = userArray[scope.model.id];
                })
                .catch(function (error) {
                  alertNotifyService.showErrorT(
                    'constant.error.unexpected');
                });

            } else {
              scope.user = userArray[scope.model.id];
            }
          };
        }
    };
  }

  userPopover.$inject = ['isEmptyFilter','bgValueFilter','routeInvoker',
    'userArray'];
  win.MainApp.Directives
    .directive('userPopover', userPopover);

    function userArray() {
      var array = [];
      return array;
    }
    win.MainApp.Services
      .factory('userArray', userArray);

}(window));
