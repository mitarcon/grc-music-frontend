(function(win) {
'use strict';

var  bgCarQuoteDetail = function ($log, buildAccountList, translateService,
      bgValue, filter, isEmpty, $filter){


  $log.debug("[bg-car-quote-detail] Initializing...");

    return {
      restrict: 'E',
      scope: {
        data: '=ngModel',
        app: '=?',
        creditCard: '=?',
        disableField: '=?',
        yearsCatalog: '='
      },
      require: 'ngModel',
      templateUrl: window.baseThemeURL + 'partials/bg-car-quote-detail.html',
      link:function (scope, element, attrs) {
        scope.entity = attrs.entity;
        scope.car = scope.data.car ? scope.data.car : {};
        scope.car.year =
          scope.car.year ? scope.car.year : "";
        scope.data.technicalProduct = (isEmpty(
          scope.data.technicalProduct) || isEmpty(
          scope.data.technicalProduct.account)) ? undefined :
          scope.data.technicalProduct;
         scope.data.signatureUser.channel.name =
          isEmpty(scope.data.signatureUser.channel.name) ?
          scope.data.channel.name : scope.data.signatureUser.channel.name;
          
        scope.calendar = {
          valuationDate: false,
          sinceVigency: false,
          untilVigency: false,
          lifeSinceVigency: false,
          lifeUntilVigency: false,
          lifeSinceEndorsement: false,
          lifeUntilEndorsement: false
        };

        scope.openCalendar = function (name) {
            angular.forEach(scope.calendar,
            function(value, key) {
              scope.calendar[key] = key === name;
            });
        };

        scope.dateOptions = {
          showWeeks: false,
          startingDay: 1,
          yearColumns:4,
          yearRows:3
        };

        if (!isEmpty(scope.car.antiqueness.id) &&
          isEmpty(scope.data.valuationType)) {

          if (scope.car.antiqueness.id === bgValue('antiqueness').used &&
            (scope.data.valuationType.id = scope.car.carAgency.name ===
              bgValue('carAgenciesWithoutDealer').naturalPerson ||
              scope.car.carAgency.name ===
              bgValue('carAgenciesWithoutDealer').legalPerson)) {

            scope.data.valuationType.id = bgValue('valuationType').assessment;

          } else {
            scope.data.valuationType.id = bgValue('valuationType').invoice;
          }
        }

        scope.policyOtherId =
          translateService.getValue('ccd.otherinsuranceCarrier.id');

        scope.buildAccount = function(account, accountName) {
          return buildAccountList(account, accountName);
        };

        scope.clearAccounts = function() {
          scope.data.technicalProduct.account = undefined;
          scope.data.technicalProduct.name = undefined;
        };

        scope.clearAssessmentAmount = function() {
          if (scope.data.valuationType.id ===
            bgValue('valuationType').invoice) {
            scope.car.assessmentAmount = null;
            scope.carDetailForm.carAssessmentAmount.
            $setValidity('validateCarAssessment', true);
            scope.car.assessmentCompany.name = null;
            scope.car.assessmentDate = null;
            scope.carDetailForm.valuationDate.
            $setValidity('assignmentDateGreaterThan30', true);
            scope.carDetailForm.valuationDate.
            $setValidity('dateGreaterThanToday', true);
          }
        };

        scope.isEndoseLifePolicy = function(){
          if (!isEmpty(scope.data.expenses)) {
            return filter(scope.data.expenses, function (item) {
                return item.description ===
                bgValue('carExpensesCodes').POL_VIDA && item.endorsement;
              }).length > 0;
          }
        };

        scope.isThereASeller = function() {
          return (scope.car.carAgency.name ===
            bgValue('carAgenciesWithoutDealer').naturalPerson) ||
            (scope.car.carAgency.name ===
              bgValue('carAgenciesWithoutDealer').legalPerson);
        };

        scope.cleanOtherDescrip = function() {
          scope.data.carPolicy.coverage = undefined;
        };

        scope.cleanLifePolicyDescrip = function() {
          scope.data.lifePolicy.coverage = undefined;
        };

        scope.rangeLimitMsg = function(min, max){
          var msg = translateService.getValue('car.quote.price.message',
          [$filter('currency')(min.toString(),'$',2),
          $filter('currency')(max.toString(),'$',2)]);
          return msg;
        };

        scope.validateCarAssessment = function() {
          if (!isEmpty(scope.car.assessmentAmount)) {
            var invalid = scope.car.assessmentAmount >= scope.car.priceWithTax;
            scope.carDetailForm.carAssessmentAmount.
            $setValidity('validateCarAssessment', invalid);
            if (scope.carDetailForm.carAssessmentAmount.$error.bgRangeLimit) {
              scope.carDetailForm.carAssessmentAmount.
              $setValidity('validateCarAssessment', true);
            }
          }else {
            scope.carDetailForm.carAssessmentAmount.
            $setValidity('validateCarAssessment', true);
          }
        };

        scope.validAssessmentDate = function() {
          var today = new Date();
          var parseTodayDate = Date.parse(today);
          var parseAssessmentDate = Date.parse(scope.car.assessmentDate);
          var ONE_DAY = 1000 * 60 * 60 * 24;
          var difference_ms = Math.abs(parseTodayDate - parseAssessmentDate);
          var greaterThanToday = parseAssessmentDate > parseTodayDate;

          if (greaterThanToday) {
            scope.carDetailForm.valuationDate.
            $setValidity('dateGreaterThanToday', false);
          }else {
            scope.carDetailForm.valuationDate.
            $setValidity('dateGreaterThanToday', true);
          }
          if(Math.round(difference_ms/ONE_DAY) > 30 && !(greaterThanToday)){
            scope.carDetailForm.valuationDate.
            $setValidity('assignmentDateGreaterThan30', false);
          }else{
            scope.carDetailForm.valuationDate.
            $setValidity('assignmentDateGreaterThan30', true);
          }
        };

        scope.validatePolicyAmount = function() {
          if (!isEmpty(scope.data.carPolicy.policyAmount)) {
            var invalid = scope.data.carPolicy.policyAmount >=
            scope.car.priceWithTax;
            scope.carDetailForm.carPolicyAmount.
            $setValidity('validateCarPolicyAmount', invalid);
            if (scope.carDetailForm.carPolicyAmount.$error.bgRangeLimit) {
              scope.carDetailForm.carPolicyAmount.
              $setValidity('validateCarPolicyAmount', true);
            }
          }else {
            scope.carDetailForm.carPolicyAmount.
            $setValidity('validateCarPolicyAmount', true);
          }
        };

        scope.validateEndorsementAmount = function() {
          var invalid = scope.data.carPolicy.endorsementAmount >=
          scope.car.priceWithTax;
          scope.carDetailForm.carPolicyEndorsementAmount.
          $setValidity('validateEndorsementAmount', invalid);
        };

        scope.validateLifePolicyEndorsementAmount = function() {
          if(!isEmpty(scope.data.lifePolicy.endorsementAmount)){
            var invalid = scope.data.lifePolicy.endorsementAmount >=
            scope.data.totalToFinance;
            scope.carDetailForm.lifePolicyEndorsementAmount.
            $setValidity('validateLifePolicyEndorsement', invalid);
            if (scope.carDetailForm.lifePolicyEndorsementAmount.
                $error.bgRangeLimit) {
              scope.carDetailForm.lifePolicyEndorsementAmount.
              $setValidity('validateLifePolicyEndorsement', true);
            }
          }
          if(isEmpty(scope.data.lifePolicy.endorsementAmount))
            scope.carDetailForm.lifePolicyEndorsementAmount.
            $setValidity('validateLifePolicyEndorsement', true);
        };

        scope.validateLifePolicyAmount = function() {
          if (!isEmpty(scope.data.lifePolicy.policyAmount)) {
            var invalid = scope.data.lifePolicy.policyAmount >=
              scope.data.totalToFinance;
            scope.carDetailForm.lifePolicyAmount.
            $setValidity('validateLifePolicyAmount', invalid);
            if (scope.carDetailForm.lifePolicyAmount.$error.bgRangeLimit) {
              scope.carDetailForm.lifePolicyAmount.
              $setValidity('validateLifePolicyAmount', true);
            }

          } else {
            scope.carDetailForm.lifePolicyAmount.
            $setValidity('validateLifePolicyAmount', true);
          }
        };

        scope.autocompleteSinceEndorsement = function(){
          scope.data.carPolicy.endorsementDateFrom =
            scope.data.carPolicy.effectiveDateFrom;
        };

        scope.autocompleteUntilEndorsement = function(){
          scope.data.carPolicy.endorsementDateTo =
            scope.data.carPolicy.effectiveDateTo;
        };

        scope.autocompleteEdousementAmount = function(){
          scope.data.carPolicy.endorsementAmount =
            scope.data.carPolicy.policyAmount;
        };

        if(!isEmpty(scope.data.carPolicy)){
          scope.autocompleteSinceEndorsement();
          scope.autocompleteUntilEndorsement();
          scope.autocompleteEdousementAmount();
        }

      }
    };
};

  bgCarQuoteDetail.$inject = [
    '$log','buildAccountListFilter', 'translateService',
    'bgValueFilter','filterFilter','isEmptyFilter','$filter',
 ];

  win.MainApp.Directives
    .directive("bgCarQuoteDetail",bgCarQuoteDetail);

}(window));
