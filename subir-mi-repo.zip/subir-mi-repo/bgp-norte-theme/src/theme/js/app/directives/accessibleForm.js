(function (win) {
    "use strict";

    function accessibleForm() {
        return {
            restrict: 'A',
            link: function (scope, elem) {

                elem.on('submit', function () {
                    var firstInvalid = elem[0].querySelector('.ng-invalid');

                    if (firstInvalid) {
                        firstInvalid.focus();
                    }
                });
            }
        };
    }

    accessibleForm.$inject = [];

    win.MainApp.Directives
        .directive('accessibleForm', accessibleForm);
}(window));
