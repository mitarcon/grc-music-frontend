/* globals Liferay, appName */

(function() {
  "use strict";

  function userSettingsNav($log, layoutService, groupService) {

    return {

      restrict: 'E',
      templateUrl: window.baseThemeURL + 'partials/user-settings-nav.html',
      link: function($scope) {

        $scope.layouts = [];
        $scope.groupUrl = "";

        $scope.isCurrentLayout = function(layoutId) {
          return Liferay.ThemeDisplay.getLayoutId() === layoutId;
        };

        var getGroupDisplayUrl = function() {

          var xhr = groupService.getGroupDisplayUrl({
            groupId: Liferay.ThemeDisplay.getScopeGroupId(),
            privateLayout: true,
            secureConnection: false
          });

          xhr.then(function(response) {
            $scope.groupUrl = response;
          });

          xhr.catch(function() {
            $log.error("Error");
          });

        };

        var getLayouts = function() {

          var xhr = layoutService.getLayouts({
            groupId: Liferay.ThemeDisplay.getScopeGroupId(),
            privateLayout: true,
            parentLayoutId: Liferay.ThemeDisplay.getParentLayoutId()
          });

          xhr.then(function(response) {
            $scope.layouts = response;
            getGroupDisplayUrl();
          });

          xhr.catch(function() {
            $log.error("Error");
          });

        };

        getLayouts();
      }

    };

  }

  userSettingsNav.$inject = ['$log', 'layoutService', 'groupService'];

  angular
    .module(appName + ".directives")
    .directive('userSettingsNav', userSettingsNav);

}());
