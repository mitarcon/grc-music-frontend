  /* globals angular, appName */

  (function(win) {
    "use strict";

    function bgSelectOnClick($window) {
      return {
        link: function(scope, element, attrs) {
          element.bind('click', function() {
            if (!$window.getSelection().toString()) {
              this.setSelectionRange(0, this.value.length);
            }
          });
        }
      };
    }

    bgSelectOnClick.$inject = ['$window'];

    angular
      .module(appName + ".directives")
      .directive('bgSelectOnClick', bgSelectOnClick);
  }(window));
