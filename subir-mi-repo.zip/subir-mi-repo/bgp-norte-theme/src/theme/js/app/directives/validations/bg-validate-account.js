(function (win) {
  'use strict';

  //TODO -@Sparker
  //TODO carAjaxServices
  // Validar si esta injeccion aun
  // se utilizara o si cambiara de nombre
  function bgValidateAccount(formConfig, commonFunctions, routeInvoker,
    alertNotifyService, $log) {

    return {
      require: 'ngModel',
      scope: {
        accountName: '=',
        holdersAmount: '='
      },
      link: function (scope, elm, attrs, ngModel) {

        var validate = function (viewValue) {

          if (viewValue) {

            routeInvoker.invoke(
              attrs.bgValidateAccountInvokename,
               'validateClientAccount',{
                  account: viewValue
                })
              .then(function (response) {
                if (response.data.validAccount) {

                  scope.accountName = response.data.name;
                  scope.holdersAmount = response.data.holdersAmount;
                } else {
                  formConfig.validateAccountMessage(response.data
                    .ownershipDescription);
                }
                ngModel.$setValidity('thirdAccountMessage',
                  response.data.validAccount);

              })
              .catch(function(exception){
                $log.error("Error en validacion de cuentas ", exception);
                alertNotifyService.showErrorT('global.defaultError');
              });
          }else {
            scope.accountName = undefined;
            ngModel.$setValidity('thirdAccountMessage', true);
            ngModel.$setPristine();
          }
          return viewValue;

        };

        ngModel.$parsers.unshift(validate);
        ngModel.$formatters.unshift(validate);

      }
    };
  }

  //TODO -@Sparker
  //TODO carAjaxServices
  // Validar si esta injeccion aun
  // se utilizara o si cambiara de nombre

  bgValidateAccount.$inject = [
    'formConfig', 'commonFunctions','routeInvoker',
    'alertNotifyService','$log'
  ];

  win.MainApp.Directives
    .directive('bgValidateAccount', bgValidateAccount);

}(window));
