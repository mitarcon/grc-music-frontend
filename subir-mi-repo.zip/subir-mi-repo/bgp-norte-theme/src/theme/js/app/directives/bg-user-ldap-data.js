(function(win) {
  "use strict";

  function bgUserLdapData(routeInvoker, bgValue) {
    return {
      restrict : 'E',

      scope:{
        user : "=",
        popoverPlacement: "@"
      },

      templateUrl : window.baseThemeURL + 'partials/bg-user-ldap.data.html',

      link : function(scope, elem, attrs) {

        scope.setUserInfo = setUserInfo;
        scope.userToShowTooltip = {};

        function setUserInfo(screenName) {

          scope.showLoading = true;

          var commons = bgValue('apps').commons;

          var xhr = routeInvoker.invoke(commons, 'findLDAPUserData', screenName);

          xhr.then(function(response) {

            if (response.data) {

              scope.user.jobTitle = response.data.jobTitle;
              scope.user.location = response.data.location;
              scope.user.extensionNumber = response.data.extensionNumber;
              scope.user.cellPhoneNumber = response.data.cellPhoneNumber;

            } else {
              scope.userToShowTooltip.location = "No se pudo obtener la información asociada al usuario";
            }

          });

          xhr.catch(function(exception) {
            scope.userToShowTooltip.location = "No se pudo obtener la información asociada al usuario";
          });

          xhr.finally(function() {
            scope.showLoading = false;
          });

        }


      }

    };
  }

  bgUserLdapData.$inject = [ 'routeInvoker', 'bgValueFilter' ];

  win.MainApp.Directives.directive('bgUserLdapData', bgUserLdapData);

}(window));
