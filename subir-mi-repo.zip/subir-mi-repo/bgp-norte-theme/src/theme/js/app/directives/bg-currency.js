(function (win) {
  "use strict";

  var MIN_VALUE = 0.01;
  
  var autoNumericOptions = {
    digitGroupSeparator: ',',
    decimalCharacter: '.',
    decimalPlacesOverride: 2,
    minimumValue: 0,
    maximumValue: 9999999999999.99
  };

  win.MainApp.Directives.directive("bgMin", function() {
    return {
      restrict: 'A',
      require : 'ngModel',
      link: function link(scope, elem, attrs, ngModel) {
        ngModel.$parsers.push(function(value) {
          ngModel.$setValidity('min', !$.isNumeric(value) || value >= attrs.bgMin);
          return value;
        });
      }
    };
  });

  win.MainApp.Directives.directive("bgCurrency", function($compile) {
    return {
      restrict: 'A',
      priority: 1001,
      terminal: true,
      link: function link(scope, elem, attrs, ngModel) {
        elem.attr('auto-numeric', JSON.stringify(autoNumericOptions));
        elem.attr('bg-min', MIN_VALUE);
        elem.attr('placeholder', '0.00');
        elem.attr('autocomplete', 'off');

        elem.removeAttr('bg-currency');

        $compile(elem)(scope);
      }
    };
  });

}(window));