(function(win){
  'use strict';

  function bgCarProcedureHeader(
    commonFunctions,
    isEmpty,
    popUpService,
    bgValue,
    translate,
    $log,
    alertNotifyService,
    bgRedirectService,
    filter
  ){

    return {
      restrict: 'E',
      scope: {
        headWrapper: '=',
        saveFn: '&',
        isSaveButtonDisabledFn: '&',
        masterForm: '=',
        availableOptions: '=',
        app:'@',
        goBack: '&',
        goNext: '&',
        disabledButton: '=',
        validateOperationResult: '=',
        isValidTask: '=',
        findUsersToAssignFn: '&',
        assigntTaskToFn: '&',
        initInterfaceService: '&',
        checkStatusInterfaceService: '&',
        retryInterfaceService: '&',
        initHeader: '&',
        isMine: '&'
      },
      templateUrl: window.baseThemeURL +
        'partials/procedure/car/bg-car-procedure-header.html',
      link: link
    };

    function link(scope, element, attrs) {
      scope.formatQuoteId = formatQuoteId;
      scope.saveFn = scope.saveFn();
      scope.goBack = scope.goBack();
      scope.goNext = scope.goNext();
      scope.openModalOptions = openModalOptions;
      scope.openModalNextOptions = openModalNextOptions;
      scope.assigmentOther = assigmentOther;
      scope.validateModal = validateModal;
      scope.enableNextMove = enableNextMove;
      scope.enableOptions = enableOptions;
      scope.openModalMissingfield = openModalMissingfield;
      scope.changeTaskNameToView = changeTaskNameToView;

      if(angular.isDefined (scope.isSaveButtonDisabledFn)){
        scope.isSaveButtonDisabledFn = scope.isSaveButtonDisabledFn();
      }
      function formatQuoteId(quoteId) {
        if (isEmpty(quoteId)) {
          return '';
        }
        quoteId = String(quoteId);
        if (quoteId !== '0') {
          quoteId = commonFunctions.formatQuoteCode(quoteId);
        } else {
          quoteId = '';
        }
        return quoteId;
      }

      function openModalOptions(availableOptions, operation, stage){

        var xhr = scope.isMine(scope.headWrapper.task);

        xhr.then(function(response) {

          if (response.data && response.data === true) {

            if(isEmpty(availableOptions)){
              alertNotifyService.showErrorT('common-unexpected-error');
              return;
            }

            var attrs = {
              bgPopupData: {
                availableOptions: availableOptions,
                reasonGroupFn: reasonGroupFn,
                app: scope.app,
                operation: operation,
                stage: stage
              },
              bgPopupClass: "bg-modal-md",
              bgPopupTpl: 'partials/bgp-popup/bg-popup-options.html',
              bgPopupMethod: selectTaskOptions,
              bgPopupFromService: true,
            };

            popUpService.open(attrs);

          }

        });

        xhr.catch(function(exception) {

          if (exception && exception.data && exception.data.name) {
              alertNotifyService.showError(exception.data.name);
          } else {
              alertNotifyService.showErrorT('constant.error.unexpected');
          }

        });

      }
      function openModalValidate(){
        // isValid
      }
      function reasonGroupFn(item){
        if(item.reason.secondLevelName !== " "){
          return item.reason.name;
        }
      }
      function selectTaskOptions(attrs){
        var reasons = [];

        if (angular.isDefined(attrs.selected) &&
          attrs.selected instanceof Array) {
          angular.forEach(attrs.selected, function(obj) {
              if (!isEmpty(obj.reason)) {
                  reasons.push({
                    'id': obj.reason.id,
                    'name': obj.reason.name,
                    'desciption': obj.reason.secondLevelName
                  });
              }
          });
        }

        var nextStageWrapper = {
          'task': scope.headWrapper.task,
          'observation': attrs.observation,
          'action': {
            'id': attrs.optionValue,
            'reasons': reasons
          },
          'user': scope.headWrapper.userAssigned,
        };
        if(attrs.operation === bgValue('routingTaskOptionsTypes').optionButtonVal){
          nextStageWrapper.forward = false;
          scope.goBack(nextStageWrapper);
        } else if (attrs.operation === bgValue('routingTaskOptionsTypes').nextButtonVal) {
          nextStageWrapper.forward = true;
          scope.goNext(nextStageWrapper);
        }
      }
      function selectTaskOptionsFinal(){
        var option = {};
        if (!isEmpty(scope.availableOptions) &&
          scope.availableOptions instanceof Array &&
          scope.availableOptions.length >0) {
          var type = bgValue('routingTaskOptionsTypes').nextButtonVal;
          option = filter('filter')(scope.availableOptions, function(item) {
            return item.type === type;
          })[0];

        }

        var attrs = {
          operation: bgValue('routingTaskOptionsTypes').nextButtonVal,
          optionValue: (!isEmpty(option)) ? option.id : ''
        };
        selectTaskOptions(attrs);
      }
      function assigmentOther(){

        var xhr = scope.isMine(scope.headWrapper.task);

        xhr.then(function(response) {

          if (response.data && response.data === true) {

            scope.findUsersToAssignFn()(scope.headWrapper.task)
            .then(function(response){
              attrs = {
                bgPopupTitle: translate.getValue('task.header.assigment.other'),
                bgPopupTpl: 'partials/bgp-popup/bg-popup-assigment-other.html',
                bgPopupMethod: assigntTask,
                bgPopupFromService: true,
                bgPopupData: {
                  arrayUser: filter('orderBy')(response.data, "fullName"),
                  selectUser: undefined,
                  taskDescription: scope.headWrapper.task.description
                }
              };
              popUpService.open(attrs);
            })
            .catch(function(exception){
              $log.error("Error en bgCarProcedureHeader findUsersToAssignFn", exception);
              alertNotifyService.showErrorT('common-unexpected-error');
            });

          }

        });

        xhr.catch(function(exception) {

          if (exception && exception.data && exception.data.name) {
              alertNotifyService.showError(exception.data.name);
          } else {
              alertNotifyService.showErrorT('constant.error.unexpected');
          }

        });

      }
      function validateModal() {

        var attrs = {};

        if (scope.validateOperationResult !== undefined &&
          scope.validateOperationResult.length !== 0) {

          attrs = {
            bgPopupTitle: translate.getValue('quote.header.pending.assessment'),
            bgPopupTpl: 'partials/bgp-popup/bg-popup-pendientes.html',
            bgPopupData: {
              sections: scope.validateOperationResult.sections,
              pendingFields: scope.isValidTask
            }
          };

        } else {

          attrs = {
            bgPopupTitle: trans.getValue('quote.header.ready.assessment'),
            bgPopupMessage: trans.getValue(
              'quote.header.ready.assessment.message'),
            bgPopupOkText: trans.getValue('global.accept')
          };

        }
        popUpService.open(attrs);
      }
      function assigntTask(user){

        var xhr = scope.isMine(scope.headWrapper.task);

        xhr.then(function(response) {

          if (response.data && response.data === true) {

            var data = {
                task: scope.headWrapper.task,
                user: user
              };
              scope.assigntTaskToFn()(data)
              .then(function(response){
                bgRedirectService.toTaskFromNextTask(
                  scope.headWrapper.task,
                  false, scope.headWrapper.task.stage.name);
              })
              .catch(function(exception){

                var error = translate.getValue('constant.error.unexpected');

                if (exception.data && exception.data.name) {
                  error = exception.data.name;
                }

                alertNotifyService.showError(error);

              });

          }

        });

        xhr.catch(function(exception) {

          if (exception && exception.data && exception.data.name) {
              alertNotifyService.showError(exception.data.name);
          } else {
              alertNotifyService.showErrorT('constant.error.unexpected');
          }

        });

      }
      function enableNextMove() {
        if((angular.isDefined(scope.masterForm) &&
            (scope.masterForm.$dirty || scope.masterForm.$invalid)) ||
          !haveOption(bgValue('routingTaskOptionsTypes').nextButtonVal) ||
          !scope.isValidTask
        ){
          return false;
        }else{
          return true;
        }
      }

      function enableOptions() {
        if((angular.isDefined(scope.masterForm) &&
            (scope.masterForm.$dirty || scope.masterForm.$invalid)) ||
          !haveOption(bgValue('routingTaskOptionsTypes').optionButtonVal)){
          return false;
        }else{
          return true;
        }
      }

      function haveOption(type){
        if(isEmpty(scope.availableOptions)){
          return false;
        }
        return scope.availableOptions
        .filter(function(option){
          return option.type === type;
        }).length > 0;
      }

      function openModalMissingfield() {

        scope.masterForm.$aaFormExtensions.$onSubmitAttempt();

        var attrs = {
          bgPopupFromService: true,
          bgPopupTitle: translate.getValue('global.save.procedures'),
          bgPopupMessage: translate.getValue('client.missing.documents')
        };
        popUpService.open(attrs);
      }

      function changeTaskNameToView (taskname){
        return commonFunctions.changeTaskNameToView(taskname);
      }

      function openModalNextOptions(availableOptions, operation, stage) {

        var xhr = scope.isMine(scope.headWrapper.task);

        xhr.then(function(response) {

          if (response.data && response.data === true) {

            if(isEmpty(availableOptions)){
              alertNotifyService.showErrorT('common-unexpected-error');
              return;
            }

            if (stage === bgValue('taskStagesPhases').liquidation){
                //Si es liquidación levanto el popup final
                var data = {
                  quoteId: scope.headWrapper.task.procedureId,
                  statusFromTail: false
                };
                scope.checkStatusInterfaceService()(data)
                .then(function(response){

                  if( isEmpty(response.data.steps) ){

                    // La cotizacion no se ha liquidado anteriormente
                    var attrs = {
                      bgPopupTitle: translate.getValue('global.important.message'),
                      bgPopupMessage: translate.getValue('quote.modal.interphase.modal', ['liquidación']),
                      bgPopupOkText: translate.getValue('global.continue'),
                      bgPopupCancelText: translate.getValue('global.cancel'),
                      bgPopupLockScreen: false,
                      bgPopupFromService: true,
                      bgPopupMethod: initInterface
                    };

                    popUpService.open(attrs);
                  } else {

                    // La cotizacion ya se ha ejecutado y tiene estatus
                    openInterfaceModal(response.data);
                  }


                })
                .catch(function(exception){
                  $log.error("Error en bgCarProcedureHeader checkStatusInterfaceService", exception);
                  alertNotifyService.showErrorT('common-unexpected-error');
                });

            }else{
              //Cualquiera de las otras etapas debe levantarse el popup de mover tarea
              openModalOptions(availableOptions, operation, stage);
            }

          }

        });

        xhr.catch(function(exception) {

          if (exception && exception.data && exception.data.name) {
              alertNotifyService.showError(exception.data.name);
          } else {
              alertNotifyService.showErrorT('constant.error.unexpected');
          }

        });


      }

      function initInterface () {

        var data = {
          quoteId: scope.headWrapper.task.procedureId
        };

        scope.initInterfaceService()(data)
        .then(function(response){
          openInterfaceModal(response.data);
        })
        .catch(function(exception){
          $log.error("Error en bgCarProcedureHeader initInterfaceService", exception);
          alertNotifyService.showErrorT('common-unexpected-error');
        });

      }

      function openInterfaceModal (data) {

        var attrs = {
            bgPopupData: {
              app: scope.app,
              init: data,
              checkStatusInterfaceService: scope.checkStatusInterfaceService(),
              retryInterfaceService: scope.retryInterfaceService(),
              task: scope.headWrapper.task
            },
            bgPopupTitle: translate.getValue('liquidation.popup.title'),
            bgPopupClass: "bg-modal-md",
            bgPopupTpl: 'partials/bgp-popup/bg-popup-car-procedure-finished.html',
            bgPopupMethod: selectTaskOptionsFinal,
            bgPopupCancelMethod: scope.initHeader(),
            bgPopupFromService: true,
            bgPopupLockScreen: true
          };

          popUpService.open(attrs);

      }
    }

  }

  bgCarProcedureHeader.$inject=[
    'commonFunctions',
    'isEmptyFilter',
    'bgPopUpService',
    'bgValueFilter',
    'translateService',
    '$log',
    'alertNotifyService',
    'bgRedirectService',
    '$filter'
  ];

  win.MainApp.Directives
    .directive('bgCarProcedureHeader', bgCarProcedureHeader);
}(window));
