/* globals angular, appName */
(function(win) {
  "use strict";

  function crossSelling(isEmpty, crossSellingSrv) {
    return {
      restrict: 'E',
      scope: {
        carQuote: '=ngModel',
        cardModal: '=',
        disableField: '=?',
        app: '=?'
      },
      require: 'ngModel',
      templateUrl: window.baseThemeURL + 'partials/bg-cross-selling.html',
      link: function(scope) {

        scope.resetCrossSelling = function() {
          if (scope.carQuote.crossSelling.accepted) {
            scope.cardModal = crossSellingSrv.setCrossSellingState(
              scope.carQuote.crossSelling);
          } else {
            scope.carQuote.crossSelling.creditCard = undefined;
          }
        };

        scope.validateOwner = function() {
          scope.carQuote.crossSelling.creditCard.cardholderName =
            validateCreditCardName(scope.carQuote.crossSelling.creditCard
              .cardholderName);
        };

        scope.chkBenefitBehavior = function() {
          if (!isEmpty(scope.carQuote.crossSelling.creditCard) &&
            !isEmpty(scope.carQuote.crossSelling.creditCard.benefit) && (
              scope.carQuote.crossSelling.creditCard.benefit.id ===
              'MILEAGE' ||
              scope.carQuote.crossSelling.creditCard.benefit.id ===
              'CONNECT')) {
            return true;
          }
          return false;
        };

        scope.isChkDelivery = function() {

          if (scope.carQuote.crossSelling.creditCard.deliveryInfo.deliveryType
            .id === 'EM') {

            scope.carQuote.crossSelling.creditCard.
            deliveryInfo.branchOffice = {};

          } else if (scope.carQuote.crossSelling.creditCard.deliveryInfo
            .deliveryType.id === 'RS') {

            scope.carQuote.crossSelling.creditCard.
            deliveryInfo.deliveryAddress = {};

          }
        };

        scope.updateCardSelection = function(card) {

          scope.carQuote.crossSelling.creditCard.logo = card.logo;
          scope.carQuote.crossSelling.creditCard.description = card.description;
          scope.carQuote.crossSelling.creditCard.benefit = card.benefit;
          scope.carQuote.crossSelling.creditCard.category = card.category;
          scope.carQuote.crossSelling.creditCard.rate = card.rate;
          scope.carQuote.crossSelling.creditCard.maxLimit = card.maxLimit;
          scope.carQuote.crossSelling.creditCard.minLimit = card.minLimit;
          scope.carQuote.crossSelling.creditCard.applies = card.applies;
          scope.carQuote.crossSelling.creditCard.promotion = card.promotion;
          scope.cardSelected = card.description + ' ' + card.category.name;
          scope.rateSelect = card.rate;
        };

        if (!isEmpty(scope.carQuote.crossSelling) &&
          !isEmpty(scope.carQuote.crossSelling.creditCard) &&
          !isEmpty(scope.carQuote.crossSelling.creditCard.logo)) {
          scope.updateCardSelection(
            scope.carQuote.crossSelling.creditCard);
        }

        var replaceApostrophe = function(value) {
          return value.replace(/'/g, ' ');
        };

        var replaceEnie = function(value) {
          return value.replace(/['ñ'||'Ñ']/g, 'N');
        };

        var validateCreditCardName = function(value) {
          value = value.trim();
          value = replaceApostrophe(value);
          value = replaceEnie(value);
          value = value.trim();
          value = value.toUpperCase();
          return value;
        };

        scope.blurAmountRequested = function() {
          scope.cardModal = crossSellingSrv.setCrossSellingState(
            scope.carQuote.crossSelling);
        };

        scope.blurAmountRequested();
      }
    };
  }

  crossSelling.$inject = ['isEmptyFilter', 'creditCardCrossSellingService'];
  win.MainApp.Directives
    .directive('crossSelling', crossSelling);
}(window));
