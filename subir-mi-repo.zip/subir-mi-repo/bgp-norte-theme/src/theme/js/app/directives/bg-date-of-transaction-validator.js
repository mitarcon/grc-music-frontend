(function(win) {
  "use strict";

  function bgDateOfTransactionValidator(dateUtilsService) {
    return {
      require: 'ngModel',
      link: function(scope, element, attrs, ngModel) {

        var validate = function(date) {
          ngModel.$setValidity('validateMax4Years', date && dateUtilsService.checkForNext4Years(date));
          ngModel.$setValidity('validateSundayDay', !date || date.getDay() !== 0);

          return date;
        };

        ngModel.$parsers.push(validate);
        ngModel.$formatters.push(validate);
      }
    };
  }
  bgDateOfTransactionValidator.$inject = ["dateUtilsService"];
  win.MainApp.Directives
    .directive('bgDateOfTransactionValidator', bgDateOfTransactionValidator);
}(window));
