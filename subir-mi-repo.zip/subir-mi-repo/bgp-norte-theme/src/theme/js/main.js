/* globals AUI, Liferay */

"use strict";

/**
 * Conservando estado de navegación entre páginas
 */
AUI().ready(function(A) {

  /** Side bar menu show hide**/
  var menu;

  if (A.Cookie.get("bgp-menu") == "true") {

    menu = true;

  } else {

    menu = false;

  }

});

AUI().use(
  'aui-node',
  function(A) {
    A.one('body').delegate('click', function(e) {
      var target = e.target;

      target.ancestor('.alert-notify').toggle();
    }, '.alert-notify .close');

    var Lang = A.Lang;

    var CONFIG = A.config;

    var DOC = CONFIG.doc;

    Liferay.SessionDisplay.prototype._uiSetActivated = function() {
      var instance = this;

      // DOC.title = instance.reset('pageTitle').get('pageTitle'); IGNORED
      // BECAUSE BG WANTS TO KEEP THE ORIGINAL TITLE

      instance._host.unregisterInterval(instance._intervalId);

      var banner = instance._getBanner();

      if (banner) {
        banner.hide();
      }
    };

    Liferay.SessionDisplay.prototype._uiSetExpired = function() {
      var instance = this;

      var banner = instance._getBanner();

      banner.setAttrs(
        {
          message: instance._expiredText,
          title: Liferay.Language.get('danger'),
          type: 'danger'
        }
      );

    // DOC.title = instance.get('pageTitle'); IGNORED BECAUSE BG WANTS
    // TO KEEP THE ORIGINAL TITLE
    };

    Liferay.SessionDisplay.prototype._uiSetRemainingTime = function(remainingTime, counterTextNode) {
      var instance = this;

      var banner = instance._getBanner();
      var warningText = Liferay.Language.get('warning-your-session-will-expire');
      var extendItText = Liferay.Language.get('extend-it');
      warningText = Lang.sub(
        warningText,
        [
          '<span class="countdown-timer">{0}</span>',
          instance._host.get('sessionLength') / 60000,
          '<a class="warning-alert-link" href="#">' + extendItText + '</a>'
        ]
      );

      banner.set(
        'message',
        Lang.sub(
          warningText,
          [
            instance._formatTime(remainingTime)
          ]
        )
      );

    // DOC.title = banner.get('contentBox').text(); IGNORED BECAUSE BG
    // WANTS TO KEEP THE ORIGINAL TITLE
    };

    Liferay.SessionDisplay.prototype._getBanner = function() {
      var instance = this;

      var banner = instance._banner;

      if (!banner) {
        banner = new Liferay.Notification(
          {
            closeable: true,
            delay: {
              hide: 0,
              show: 0
            },
            duration: 500,
            message: instance._warningText,
            on: {
              click: function(event) {
                if (event.domEvent.target.test('.warning-alert-link')) {
                  event.domEvent.preventDefault();
                  instance._host.extend();
                }
              }
            },
            title: Liferay.Language.get('warning'),
            type: 'warning'
          }
        ).render('body');

        instance._banner = banner;
      }

      return banner;
    };
  }
);
