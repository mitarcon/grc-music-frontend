(function(win) {
  "use strict";


  var InboxTabsLayoutController = function(log, $interval, storage, serviceInvoker, translateService, bgValue) {
    /*
     ==============
     SETUP
     ==============
    */

    // VM
    var vm = this;

    vm.setup = function() {

      storage.cleanStorage();
      notificationsHandler();
      vm.activeTab = 1;
      vm.handlerTab();
    };

    vm.getNotifications = function() {

      var xhr = serviceInvoker.invoke("GET", '/o/api/notification/getRecentNotificationsCountByUser', null, false);

      xhr.then(function(response) {

        vm.notificationsCount = response.data;

      });

      xhr.catch(function(exception) {

        var error = exceptionHandlerService.handleError(
          exception, vm.serviceTitleKey);

        if (error) {
          alertNotifyService.showErrorT(translateService.getValue('constant.error.unexpected'));
        }

        vm.tasks = "Error";

      });

    }

    var notificationsHandler = function() {

      vm.interval = $interval(function() {

        if (vm.initNotifications == false) {

          vm.getNotifications();

        }

      }, bgValue("timeToGetNewNotifications"));
    }

    vm.handlerTab = function() {

      vm.getNotifications();

      switch (vm.activeTab) {
      case 1:
        vm.initMyTasks = true;
        vm.initGroupTasks = false;
        vm.initQuote = false;
        vm.initNotifications = false;
        break;

      case 2:
        vm.initMyTasks = false;
        vm.initGroupTasks = true;
        vm.initQuote = false;
        vm.initNotifications = false;
        break;

      case 3:
        vm.initMyTasks = false;
        vm.initGroupTasks = false;
        vm.initQuote = true;
        vm.initNotifications = false;
        break;

      case 4:
        vm.initMyTasks = false;
        vm.initGroupTasks = false;
        vm.initQuote = false;
        vm.initNotifications = true;
        break;

      default:
        vm.initMyTasks = true;
        vm.initGroupTasks = false;
        vm.initQuote = false;
        vm.initNotifications = false;
      }

    };

    vm.setup();

  };

  /*
  ================
  CONFIGURATION
  ================
  */

  InboxTabsLayoutController.$inject = [ '$log',
    '$interval',
    'storageService',
    'serviceInvoker',
    'translateService',
    'bgValueFilter'];
  win.MainApp.Controllers
    .controller('InboxTabsLayoutController', InboxTabsLayoutController);

}(window));