(function(win) {
  "use strict";


  var ClientLayoutController = function(log) {

    log.debug("[Liferay/Angular/ClientLayoutController] Initializing...");

    /*
     * ============== VALUES ==============
     */

    // VM
    var vm = this;

    /*
     ==============
     SETUP
     ==============
    */

    vm.setup = function() {
      vm.activeTab = 0;
    };

    vm.setup();

  };

  /*
  ================
  CONFIGURATION
  ================
  */

  ClientLayoutController.$inject = ['$log'];

  win.MainApp.Controllers
    .controller('ClientLayoutController', ClientLayoutController);

}(window));
