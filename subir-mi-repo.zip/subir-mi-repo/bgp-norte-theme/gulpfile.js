'use strict';

var gulp = require('gulp');
var props = require('gulp-props');
var sass = require('gulp-sass');
var bourbon = require('node-bourbon');
var sourcemaps = require('gulp-sourcemaps');
var uglify = require('gulp-uglify');
var rename = require('gulp-rename');
var concat = require('gulp-concat');
var propsReader = require('properties-reader');
var replace = require('gulp-replace');
var karma = require('karma');
var gutil = require('gulp-util');
var uniqid = require('uniqid');
var bgpUniqId = uniqid();

var buildThemeDir = 'build/buildTheme';

var mainApp = [
  'src/theme/js/app/app.js',
  'src/theme/js/app/configs/**/*.js'
];

var services = [
  'src/theme/js/app/services/**/*.js'
];

var controllers = [
  'src/theme/js/app/controllers/**/*.js'
];

var filters = [
  'src/theme/js/app/filters/**/*.js'
];

var directives = [
  'src/theme/js/app/directives/**/*.js'
];

var values = [
  'src/theme/js/app/values/**/*.js'
];

var layoutControllers = [
  'src/theme/layouttpl/js/**.js'
];

var allFiles = mainApp
  .concat(services)
  .concat(controllers)
  .concat(layoutControllers)
  .concat(filters)
  .concat(directives)
  .concat(values);

var deps = [
  'node_modules/angular/angular.js', //SI
  'node_modules/jquery/dist/jquery.js', //SI
  'node_modules/angular-filter/dist/angular-filter.js', // Bunch of useful filters for AngularJS
  'node_modules/angular-agility/dist/angular-agility.js',
  'node_modules/ngstorage/ngStorage.js',
  'node_modules/ng-table/bundles/ng-table.js', //http://ng-table.com
  'node_modules/angular-sanitize/angular-sanitize.js',
  'node_modules/ngSmoothScroll/lib/angular-smooth-scroll.js',
  'node_modules/angular-i18n/angular-locale_es-pa.js',
  'node_modules/@uirouter/angularjs/release/angular-ui-router.js',
  'node_modules/angular-messages/angular-messages.js',
  'node_modules/angular-ui-bootstrap/dist/ui-bootstrap.js',
  'node_modules/angular-ui-bootstrap/dist/ui-bootstrap-tpls.js',
  'node_modules/moment/min/moment-with-locales.min.js',
  'node_modules/moment-precise-range-plugin/moment-precise-range.js',
  'node_modules/moment/locale/es.js',
  'node_modules/@lordfriend/nya-bootstrap-select/dist/js/nya-bs-select.js',
  'node_modules/angular-smart-table/dist/smart-table.js',
  'node_modules/angular-macgyver/dist/macgyver.js',
  'node_modules/angular-animate/angular-animate.js',
  'node_modules/ng-currency/dist/ng-currency.js',
  'node_modules/angular-macgyver/dist/macgyver.js',
  'node_modules/ui-select/dist/select.js',
  'node_modules/ng-file-upload/dist/ng-file-upload.min.js',
  'node_modules/angularjs-slider/dist/rzslider.min.js',
  'node_modules/ng-pattern-restrict/src/ng-pattern-restrict.min.js',
  'node_modules/angular-bootstrap-multiselect/dist/angular-bootstrap-multiselect.min.js',
  'node_modules/string-mask/src/string-mask.js'
];

var commonUglify = function(name, files, ugly) {

  var version = getVersion();
  var process = gulp.src(files)
    .pipe(concat(name + '.' + version + '.js'))
    .pipe(gulp.dest(buildThemeDir + '/js/'));

  if (ugly) {
    process = process.pipe(uglify());
  }

  return process
    .pipe(rename(name + '.' + version + '.min.js'))
    .pipe(gulp.dest(buildThemeDir + '/js/'));
};

var getVersion = function () {

  var properties = propsReader('gradle.properties');
  return properties.get('version') + '_' + bgpUniqId;
};

gulp.task('check-js-version', function () {
  return gulp.src(['src/theme/templates/boilerplate.ftl'])
    .pipe(replace('<#assign version = "" />', '<#assign version = "'+getVersion()+'" />'))
    .pipe(gulp.dest('build/buildTheme/templates/'));
});

gulp.task('build-es-language-files', function() {
  return gulp.src('src/theme/WEB-INF/src/content/Language.properties')
  .pipe(props({
    namespace: 'BGP_i18n'
  }))
  .pipe(rename('Language' + getVersion() + '.js'))
  .pipe(gulp.dest(buildThemeDir + '/js/language/'))
  .pipe(rename('Language_es' + getVersion() + '.js'))
  .pipe(gulp.dest(buildThemeDir + '/js/language/'));
});

gulp.task('copy-fontawesome', function() {
  return gulp.src('node_modules/font-awesome/fonts/**.*')
    .pipe(gulp.dest(buildThemeDir + '/fonts'));
});

gulp.task('copy-js-dependencies', function() {
  return commonUglify('bg_deps', deps, true);
});

gulp.task('copy-js', function() {
  return commonUglify('bg', allFiles, true);
});

gulp.task('copy-dependencies', [
  'copy-fontawesome',
  'copy-js-dependencies',
  'copy-js',
  'check-js-version'
]);

gulp.task('build-bgp-style', ['copy-dependencies'], function() {
  var sassOptions = {
    outputStyle: 'compressed',
    includePaths: [
      'src/bgp-style/css',
      'node_modules/bootstrap-sass/assets/stylesheets',
      'node_modules/font-awesome/scss',
      'node_modules/@lordfriend/nya-bootstrap-select/dist/css',
      'node_modules/angular-macgyver/dist',
      'node_modules/angularjs-slider/dist',
      bourbon.includePaths
    ]
  };

  return gulp.src('src/bgp-style/css/style.scss')
    .pipe(sourcemaps.init())
    .pipe(
      sass(sassOptions)
        .on('error', sass.logError)
        .on('error', function() {
          process.exit(1);
        })
  )
    .pipe(rename('style-' +   getVersion() + '.css'))
    .pipe(sourcemaps.write('.'))
    .pipe(gulp.dest(buildThemeDir + '/css'));
});

//Test task
gulp.task('test-src', function (done) {
  gutil.log('*** Ejecutando Pruebas unitarias de Js de *** ->', __dirname);
  new karma.Server({
    configFile: __dirname + '\\karma-src.conf.js',
    singleRun: true,
    autoWatch: false
  }, done).start();
});

gulp.task('build', ['build-es-language-files', 'build-bgp-style']);
//task clean buildTheme
gulp.task('test', ['test-src']);
