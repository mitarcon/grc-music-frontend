# Theme Notes

NOTE: First you need to install gulp as global tool npm install -g gulp


For deploy this module in your local server you need to create one file called `liferay-theme.json`, and configure your paths like thís:

```
{
  "LiferayTheme": {
    "appServerPath": "/%YOUR-PATH%/%LIFERAY-HOME%/tomcat-8.0.32",
    "deployPath": "/%YOUR-PATH%/%LIFERAY-HOME%/deploy",
    "url": "http://localhost:8080",
    "appServerPathPlugin": "/%YOUR-PATH%/%LIFERAY-HOME%/tomcat-8.0.32/webapps/bgp-norte-theme",
    "deployed": false,
    "pluginName": "anglo-gramalote-theme"
  }
}
```

`/%YOUR-PATH%/%LIFERAY-HOME%` example `/DXP/bundle/tomcat-8.0.32`

Now, you can execute `gulp deploy`

Or use  the gradle clean build deploy task

Create in user gradle.properties the key var app.server.parent.dir = C:\\DXP\\bundle

pointing to your server home