'use strict';

module.exports = function (config) {
  config.set({

    // base path that will be used to resolve all patterns (eg. files, exclude)
    basePath: '',

    // frameworks to use
    // available frameworks: https://npmjs.org/browse/keyword/karma-adapter
    frameworks: ['jasmine'],

    // list of files / patterns to load in the browser
    files: [
      'src/theme/angular/**/*.html',
      'test/test-initconfig.js',
      'build/buildTheme/js/bg.js',
      'build/buildTheme/js/bg_deps.js',
      'build/buildTheme/js/language/Language_es.js',
      'test/spec/**/*.js'
    ],


    // list of files to exclude
    exclude: [],


    // preprocess matching files before serving them to the browser
    // preprocessors: https://npmjs.org/browse/keyword/karma-preprocessor
    preprocessors: {
      'app/src/**/!(ajax)*.js': ['coverage'],
      'app/tpl/**/*.html': ['ng-html2js']
    },

    /*
     test results reporter to use
     possible values: 'dots', 'progress'
     available reporters: https://npmjs.org/browse/keyword/karma-reporter
     */
    reporters: ['progress', 'coverage'],

    // web server port
    port: 9876,

    // enable / disable colors in the output (reporters and logs)
    colors: true,

    /*
     level of logging
     possible values: config.LOG_DISABLE || config.LOG_ERROR ||
     config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
     */
    logLevel: config.LOG_DISABLE,

    /*
     enable / disable watching file and executing tests whenever any file
     changes
     */
    autoWatch: false,

    /*
     start these browsers
     available launchers: https://npmjs.org/browse/keyword/karma-launcher
     */
    browsers: ['PhantomJS'], //['Safari', 'Chrome', 'PhantomJS'],

    /*Continuous Integration mode
     if true, Karma captures browsers, runs the tests and exits
     */
    singleRun: true,

    // Configure the reporter
    coverageReporter: {
      type: 'lcovonly',
      dir: 'coverage/'
    }
  });
};
