#!/bin/bash

# Script para crear una rama apartir de otra y subirla al repo
#autor : langulo

set -e
#

source ./variables.sh
RAMA_ORIGEN=master
RAMA_TEMP=test-merge-4
RAMA_=release_20_03_2018
#$GTI_GROUP$repo/merge_requests/new?merge_request%5Bsource_branch%5D=test-04-03-2018&merge_request%5Btarget_branch%5D=dev



#release_28_02_2018
cd ..
for repo in ${gitRepo[*]}
do
  #Hace pull del repo si existe y lo clona si no existe
  echo "::::Procesando el Repositorio: "$repo
  if [ -d $repo/ ];
  then
    echo "-->EL REPO YA EXISTE"
	  pwd
	  cd $repo
	  pwd
	  echo '======================================================================'
	  echo '================ Inicia Pull de '$repo
	  echo '======================================================================'
      git checkout $RAMA_ORIGEN
	    git checkout -b $RAMA_TEMP
      git pull origin $RAMA_RELEASE --no-edit
      git push -u origin $RAMA_TEMP
	  echo '======================================================================'
	  echo '================ Termina push de '$repo
	  echo '======================================================================'
	  cd ..

  else
    echo "-->EL REPO NO EXISTE"
    pwd

    echo '$======================================================================'
    echo '================ Inicia clone de '$repo
    echo '======================================================================'
    git clone $GTI_GROUP$repo
    cd $repo
      git checkout $RAMA_ORIGEN
	    git checkout -b $RAMA_TEMP
      git pull origin $RAMA_RELEASE --no-edit
      git push -u origin $RAMA_TEMP

    echo '======================================================================'
    echo '================ Termina clone de '$repo
    echo '======================================================================'
    cd ..
  fi
done
echo '***************** Termina sincronizar de los repositorios *****************'
exit 0;
