#!/bin/bash
set -e

echo "                                                               "
echo " ____    _____             _____    _____ __      __ ______    "
echo "|  _ \  / ____|           / ____|  |_   _|\ \    / /|  ____|   "
echo "| |_) || |  __   ______  | (___      | |   \ \  / / | |__      "
echo "|  _ < | | |_ | |______|  \___ \     | |    \ \/ /  |  __|     "
echo "| |_) || |__| |           ____) |_  _| |_  _ \  / _ | |____  _ "
echo "|____/  \_____|          |_____/(_)|_____|(_) \/ (_)|______|(_)"
echo "                                                               "
echo "                                                               "

#
echo "Generando reporte de dependencias"

#LOS PROYECTOS PADRES AGREGAR LA TAREA SIGUIENTE PARA LOS SUBPROYECTOS	
#subprojects {

#  task allDeps(type: DependencyReportTask) {}
  
#  repositories {
#    mavenLocal()
#    maven { url nexusBGeneral }
#    maven { url nexusBGeneralAlt }
#    maven {
#      url nexusBGeneralgradle
#    }
#  }
  
GTI_GROUP="http://gitlab.bgeneral.com/dxp/"
gitRepo=(\
  "bgp-norte-language"\
  #"bgp-norte-login-theme"\
  #"bgp-norte-theme"\
  #"bgp-norte-car-quote-layout"\
  "bgp-norte-ws-client"\
  "bgp-norte-common"\
  "bgp-norte-quote-alerts"\
  "bgp-norte-address"\
  "bgp-norte-sb-car-catalog"\
  "bgp-norte-sb-neighborhood-catalog"\
  "bgp-norte-product"\
  "bgp-norte-campaign"\
  "bgp-norte-catalog"\
  "bgp-norte-user"\
  "bgp-norte-sb-procedure-workflow"\
  "bgp-norte-contact"\
  "bgp-norte-company"\
  "bgp-norte-parameter"\
  "bgp-norte-reference"\
  "bgp-norte-expenses"\
  "bgp-norte-other-income"\
  "bgp-norte-document"\
  "bgp-norte-exception"\
  "bgp-norte-apc"\
  "bgp-norte-warning"\
  "bgp-norte-quote-additional-info"\
  "bgp-norte-credit-card"\
  "bgp-norte-employment"\
  "bgp-norte-customer"\
  "bgp-norte-quote-record"\
  "bgp-norte-interphase"\
  "bgp-norte-notification"\
  "bgp-norte-task"\
  "bgp-norte-quote"\
  "bgp-norte-notification"\
  "bgp-norte-car-quote"\
  "bgp-norte-credit-card-quote"\
  "bgp-norte-quote-summary"\
  "bgp-norte-general-rules"\
  "bgp-norte-quote-evaluation"\
  "bgp-norte-liability-opening"\
  "bgp-norte-account-opening"\
  "bgp-norte-liability-opening-advice"\
  "bgp-norte-quote-communication"\
  "bgp-norte-car-quote-review"\
  "bgp-norte-car-quote-liquidation"\
  "bgp-norte-catalog-web"\
  "bgp-norte-car-quote-web"\
  "bgp-norte-credit-card-quote-web"\
  "bgp-norte-search-client-web"\
  "bgp-norte-client-details-web"\
  "bgp-norte-common-service-web"\
  "bgp-norte-quote-web"\
  "bgp-norte-user-office-web"\
  "bgp-norte-sb-car-catalog-web"\
  "bgp-norte-sb-neighborhood-web"\
  "bgp-norte-task-web"\
  "bgp-norte-wizard-web"\
  "bgp-norte-maintenance-web"\
  "bgp-norte-sb-procedure-workflow-web"\
  "bgp-norte-notification-web"\
  "bgp-norte-quote-summary-web"\
  "bgp-norte-quote-record-web"\
  "bgp-norte-quote-head-web"\
  "bgp-norte-quote-evaluation-web"\
  "bgp-norte-account-opening-web"\
  "bgp-norte-quote-document-web"\
  "bgp-norte-quote-client-web"\
  "bgp-norte-quote-communication-web"\
  "bgp-norte-car-quote-details-web"\
  "bgp-norte-car-quote-review-web"\
  "bgp-norte-car-quote-liquidation-web"\
  "bgp-norte-liability-opening-layout"\
  "bgp-norte-liability-opening-advice-web"\
  "bgp-norte-account-opening-approval-web"\
  "bgp-norte-customer-management-web"\
  "bgp-norte-customer-management-layout"\
  #"bgp-norte-reports"\
)

cd ..
for repo in ${gitRepo[*]}
do
  #Hace pull del repo si existe y lo clona si no existe
  echo "::::Procesando el Repositorio: "$repo
  if [ -d $repo/ ];
  then
    echo "-->EL REPO YA EXISTE"
	  pwd
	  cd $repo
	  pwd
	  echo '======================================================================'
	  echo '================ Inicia Pull de '$repo
	  echo '======================================================================'
	  git fetch
	  git checkout dev
	  git pull
	  echo '======================================================================'
	  echo '================ Termina Pull de '$repo
	  echo '======================================================================'
	  cd ..
	
  else
    echo "-->EL REPO NO EXISTE"
    pwd
	cd $repo
    echo '$======================================================================'
    echo '================ Inicia clone de '$repo
    echo '======================================================================'
    git clone $GTI_GROUP$repo
    echo '======================================================================'
    echo '================ Termina clone de '$repo
    echo '======================================================================'
	cd ..
  fi
  
  cd $repo
  
   if [[ $repo = *"-web"* || $repo = "bgp-norte-language" || $repo = *"-layout"* ]]; then
	comammdTask='dependencies --configuration compileOnly'
	echo "================ Proyecto WEB $repo ================"
	gradle $comammdTask > /c/DXP/norte_dxp_ws/bgp-norte-scripts/reportes_dependencias/$repo.txt
	
  else
	echo "================ Proyecto de API $repo ================"
    comammdTask='allDeps --configuration compileOnly'
	gradle $comammdTask > /c/DXP/norte_dxp_ws/bgp-norte-scripts/reportes_dependencias/$repo.txt
  fi

  cd ..
  
done
echo "================ Termina sincronizar de los repositorios ================"
exit 0;