#!/bin/bash
set -e
#

source variables.sh

RAMA=release_20_03_2018
#release_28_02_2018
cd ..
for repo in ${gitRepo[*]}
do
  #Hace pull del repo si existe y lo clona si no existe
  echo "::::Procesando el Repositorio: "$repo
  if [ -d $repo/ ];
  then
    echo "-->EL REPO YA EXISTE"
	  pwd
	  cd $repo
	  pwd
	  echo '======================================================================'
	  echo '================ Inicia Pull de '$repo
	  echo '======================================================================'
	  git checkout -b $RAMA
      git push -u origin $RAMA
	  echo '======================================================================'
	  echo '================ Termina push de '$repo
	  echo '======================================================================'
	  cd ..
	
  else
    echo "-->EL REPO NO EXISTE"
    pwd

    echo '$======================================================================'
    echo '================ Inicia clone de '$repo
    echo '======================================================================'
    git clone $GTI_GROUP$repo
    cd $repo
    git checkout -b $RAMA
    git push -u origin $RAMA
    echo '======================================================================'
    echo '================ Termina clone de '$repo
    echo '======================================================================'
    cd ..
  fi
done
echo '***************** Termina sincronizar de los repositorios *****************'
exit 0;
