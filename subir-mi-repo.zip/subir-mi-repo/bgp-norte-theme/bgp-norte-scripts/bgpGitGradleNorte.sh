#!/bin/bash
set -e

echo "  ____          _   _  _____ ____     _____ ______ _   _ ______ _____            _        "      
echo " |  _ \   /\   | \ | |/ ____/ __ \   / ____|  ____| \ | |  ____|  __ \     /\   | |       "
echo " | |_) | /  \  |  \| | |   | |  | | | |  __| |__  |  \| | |__  | |__) |   /  \  | |       "
echo " |  _ < / /\ \ |     | |   | |  | | | | |_ |  __| |     |  __| |  _  /   / /\ \ | |       "
echo " | |_) / ____ \| |\  | |___| |__| | | |__| | |____| |\  | |____| | \ \  / ____ \| |____   "
echo " |____/_/    \_\_| \_|\_____\____/   \_____|______|_| \_|______|_|  \_\/_/    \_\______|  "
echo "                                                                                          "

#
echo "..::- Ejecutando DeployNorte para branchs $1  -::.."
isDev=false;
if [ "$1" = "dev" ];
then
  echo "--> Se solicita actualizar y desplegar branch DEV..."
  isDev=true;
else
  if [ "$1" != "actual" ];
  then
    echo "ERROR: Parametro inválido. Los parametros permitidos son: dev y actual"
    exit 1;
  fi
fi

echo "--> Tarea solicitada = $2"
comammdTask=$2;
if [[ "$2" == "" ]];
then
    comammdTask='clean install deploy'
else
    if [[ "$2" != "clean" && "$2" != "build" && "$2" != "install" && "$2" != "deploy" ]];
    then
        echo "Commando gradle inválido"
    exit 1;
    fi
fi

source variables.sh

cd ..
for repo in ${gitRepo[*]}
do
  #Hace pull del repo si existe y lo clona si no existe
  echo "::::Procesando el Repositorio: "$repo
  if [ -d $repo/ ];
  then
    echo "-->EL REPO YA EXISTE"
    if [ "$isDev" = true ];
    then
	  pwd
	  cd $repo
	  pwd
	  echo '======================================================================'
	  echo '================ Inicia Pull de '$repo
	  echo '======================================================================'
	  git fetch
	  git checkout dev
	  git pull --no-edit
	  echo '======================================================================'
	  echo '================ Termina Pull de '$repo
	  echo '======================================================================'
	  cd ..
	else
	  pwd
	  cd $repo
	  pwd
	  echo '======================================================================'
	  echo '================ Inicia Pull de '$repo
	  echo '======================================================================'
	  git fetch
	  git pull --no-edit origin dev
	  echo '======================================================================'
	  echo '================ Termina Pull de '$repo
	  echo '======================================================================'
	  cd ..
	fi
  else
    echo "-->EL REPO NO EXISTE"
    pwd
    echo '$======================================================================'
    echo '================ Inicia clone de '$repo
    echo '======================================================================'
    git clone $GTI_GROUP$repo
    echo '======================================================================'
    echo '================ Termina clone de '$repo
    echo '======================================================================'
  fi

 if [[  "$repo" = "bgp-norte-common-lib" || "$repo" = "bgp-norte-reports" ]];
  then
    echo "-->ES EL REPO DE COMMON-LIB y REPORTS...(continua)"
    continue
  else
    #Ejecuta tareas gradle
    if [ "$repo" = "bgp-norte-ws-client" ];
    then
      echo "-->ES EL REPO DE CLIENTES WS"
      cd bgp-norte-ws-client/bgp-norte-ws-client-common/
      echo '======================================================================'
      echo '================ Inicia '$comammdTask' de bgp-norte-ws-client/bgp-norte-ws-client-common/'
      echo '======================================================================'
      gradle $comammdTask
      echo '======================================================================'
      echo '================ Termina '$comammdTask' de bgp-norte-ws-client/bgp-norte-ws-client-common/'
      echo '======================================================================'
      cd ..
      echo '======================================================================'
      echo '================ inicia '$comammdTask' de bgp-norte-ws-client'
      echo '======================================================================'
      gradle $comammdTask
      echo '======================================================================'
      echo '================ Termina '$comammdTask' de bgp-norte-ws-client'
      echo '======================================================================'
      cd ..
    else
      cd $repo
      if [[ "$repo" = "bgp-norte-sb-car-catalog" || "$repo" = "bgp-norte-sb-neighborhood-catalog" || "$repo" = "bgp-norte-sb-procedure-workflow" ]];
      then
        echo "-->ES UN SERVICE BUILDER"
        echo '======================================================================'
        echo '================ Inicia buildService de '$repo
        echo '======================================================================'
        gradle buildService
        echo '======================================================================'
        echo '================ Termina buildService de '$repo
        echo '======================================================================'
        echo '======================================================================'
        echo '================ Inicia clean build '$comammdTask' de '$repo
        echo '======================================================================'
        cd $repo"-api"
        gradle $comammdTask
        cd ..
        cd $repo"-service"
        echo "############ Actualiza Referencias #######################"
        gradle clean build --refresh-dependencies $comammdTask
        cd ..
        echo '======================================================================'
        echo '================ Termina clean build '$comammdTask' de '$repo
        echo '======================================================================'
      else
      	if [[ "$repo" = "bgp-norte-car-quote-layout" ]];
        then
        	npm install
        	gradle $comammdTask
        else
	        echo "-->ES PROYECTO API O WEB"
	        echo '======================================================================'
	        echo '================ Inicia '$comammdTask' de '$repo
	        echo '======================================================================'
	        gradle $comammdTask
	        echo '======================================================================'
	        echo '================ Termina '$comammdTask' de '$repo
	        echo '======================================================================'
	    fi
      fi
      cd ..
    fi
  fi

done
echo '***************** Termina sincronizar de los repositorios *****************'
exit 0;
