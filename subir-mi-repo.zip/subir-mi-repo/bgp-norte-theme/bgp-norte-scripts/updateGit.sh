#!/bin/bash
set -e

echo "  ██████╗ ██████╗ ███╗   ██╗███████╗██╗   ██╗██╗  ████████╗███████╗ ██████╗              ████████╗██╗"
echo " ██╔════╝██╔═══██╗████╗  ██║██╔════╝██║   ██║██║  ╚══██╔══╝██╔════╝██╔════╝              ╚══██╔══╝██║"
echo " ██║     ██║   ██║██╔██╗ ██║███████╗██║   ██║██║     ██║   █████╗  ██║         █████╗       ██║   ██║"
echo " ██║     ██║   ██║██║╚██╗██║╚════██║██║   ██║██║     ██║   ██╔══╝  ██║         ╚════╝       ██║   ██║"
echo " ╚██████╗╚██████╔╝██║ ╚████║███████║╚██████╔╝███████╗██║   ███████╗╚██████╗                 ██║   ██║"
echo "  ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝╚══════╝ ╚═════╝ ╚══════╝╚═╝   ╚══════╝ ╚═════╝                 ╚═╝   ╚═╝"
#

GTI_GROUP="http://adelrosario@gitlab.bgeneral.com/dxp/"

gitRepo=(\
  "bgp-norte-ws-client"\
  "bgp-norte-common"\
  "bgp-norte-quote-alerts"\
  "bgp-norte-address"\
  "bgp-norte-sb-car-catalog"\
  "bgp-norte-sb-neighborhood-catalog"\
  "bgp-norte-product"\
  "bgp-norte-catalog"\
  "bgp-norte-user"\
  "bgp-norte-sb-procedure-workflow"\
  "bgp-norte-credit-card"\
  "bgp-norte-contact"\
  "bgp-norte-company"\
  "bgp-norte-parameter"\
  "bgp-norte-reference"\
  "bgp-norte-expenses"\
  "bgp-norte-other-income"\
  "bgp-norte-document"\
  "bgp-norte-exception"\
  "bgp-norte-apc"\
  "bgp-norte-warning"\
  "bgp-norte-quote-additional-info"\
  "bgp-norte-employment"\
  "bgp-norte-customer"\
  "bgp-norte-quote-record"\
  "bgp-norte-task"\
  "bgp-norte-quote"\
  "bgp-norte-car-quote"\
  "bgp-norte-quote-summary"\
  "bgp-norte-general-rules"\
  "bgp-norte-notification"\
  "bgp-norte-quote-evaluation"\
  "bgp-norte-liability-opening"\
  "bgp-norte-account-opening"\
  "bgp-norte-liability-opening-advice"\
  "bgp-norte-quote-communication"\
  "bgp-norte-car-quote-review"\
  "bgp-norte-car-quote-liquidation"\
  "bgp-norte-catalog-web"\
  "bgp-norte-car-quote-web"\
  "bgp-norte-search-client-web"\
  "bgp-norte-client-details-web"\
  "bgp-norte-common-service-web"\
  "bgp-norte-quote-web"\
  "bgp-norte-user-office-web"\
  "bgp-norte-sb-car-catalog-web"\
  "bgp-norte-sb-neighborhood-web"\
  "bgp-norte-task-web"\
  "bgp-norte-wizard-web"\
  "bgp-norte-maintenance-web"\
  "bgp-norte-document-web"\
  "bgp-norte-sb-procedure-workflow-web"\
  "bgp-norte-notification-web"\
  "bgp-norte-quote-summary-web"\
  "bgp-norte-quote-record-web"\
  "bgp-norte-quote-head-web"\
  "bgp-norte-quote-evaluation-web"\
  "bgp-norte-account-opening-web"\
  "bgp-norte-quote-document-web"\
  "bgp-norte-quote-client-web"\
  "bgp-norte-quote-communication-web"\
  "bgp-norte-car-quote-details-web"\
  "bgp-norte-car-quote-review-web"\
  "bgp-norte-car-quote-liquidation-web"\
  "angular-boilerplate-include-js"\
  "bgp-norte-liability-opening-layout"\
  "bgp-norte-liability-opening-advice-web"\
  "bgp-norte-login-theme"\
  "bgp-norte-theme"\
  "documentacion"\
)

for repo in ${gitRepo[*]}
do
  cd ../$repo
  echo "Actualizando "$repo"..."
  git remote set-url origin $GTI_GROUP$repo
  
done
exit 0;
