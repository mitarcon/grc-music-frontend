#!/bin/bash
    
#tr -d "\r" < mover.sh > mover2.sh

#Bandeja
mv com.bgp.norte.quote.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Bandeja/
mv com.bgp.norte.task.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Bandeja/

#Autos
mv com.bgp.norte.car.quote.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Autos/
mv com.bgp.norte.car.quote.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Autos/
mv com.bgp.norte.car.quote.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Autos/
mv com.bgp.car.quote.details.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Autos/
mv com.bgp.norte.car.quote.review.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Autos/
mv com.bgp.norte.car.quote.review.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Autos/
mv com.bgp.norte.car.quote.review.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Autos/
mv bgp-norte-car-communication-tabs-layouttpl.war /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Autos/
mv bgp-norte-car-evaluation-tabs-layouttpl.war /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Autos/
mv bgp-norte-car-formalization-tabs-layouttpl.war /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Autos/
mv bgp-norte-car-liquidation-tabs-layouttpl.war /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Autos/
mv bgp-norte-car-previous_liquidation-tabs-layouttpl.war /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Autos/
mv com.bgp.norte.car.quote.liquidation.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Autos/
mv com.bgp.norte.car.quote.liquidation.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Autos/
mv com.bgp.norte.car.quote.liquidation.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Autos/

#Cliente
mv com.bgp.norte.address.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/
mv com.bgp.norte.address.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/
mv com.bgp.norte.apc.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/
mv com.bgp.norte.apc.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/
mv com.bgp.norte.company.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/
mv com.bgp.norte.company.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/
mv com.bgp.norte.contact.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/
mv com.bgp.norte.contact.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/

mv com.bgp.norte.customer.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/
mv com.bgp.norte.document.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/
mv com.bgp.norte.document.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/
mv com.bgp.norte.employment.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/


mv com.bgp.norte.maintenance.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/
mv com.bgp.norte.other.income.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/
mv com.bgp.norte.other.income.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/

mv com.bgp.norte.reference.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/
mv com.bgp.norte.reference.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/


#21-12-2017

#Pasivos
mv com.bgp.norte.liability.opening.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Pasivos/
mv com.bgp.norte.account.opening.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Pasivos/
mv com.bgp.norte.account.opening.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Pasivos/
mv com.bgp.norte.liability.opening.layout.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Pasivos/
mv com.bgp.norte.liability.opening.advice.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Pasivos/
mv com.bgp.norte.liability.opening.advice.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Pasivos/
mv com.bgp.norte.liability.opening.advice.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Pasivos/
mv com.bgp.norte.account.opening.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Pasivos/
mv com.bgp.norte.liability.opening.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Pasivos/
mv com.bgp.norte.ws.client.generic.create.bel.affiliation.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Pasivos/
mv com.bgp.norte.account.opening.approval.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Pasivos/
mv com.bgp.norte.customer.management.layout.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Pasivos/
mv com.bgp.norte.customer.management.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Pasivos/


#Tarjetas

mv com.bgp.norte.credit.card.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Tarjetas/
mv com.bgp.norte.credit.card.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Tarjetas/

mv com.bgp.norte.credit.card.quote.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Tarjetas/
mv com.bgp.norte.credit.card.quote.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Tarjetas/
mv com.bgp.norte.credit.card.quote.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Tarjetas/
mv com.bgp.norte.campaign.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Tarjetas/
mv com.bgp.norte.campaign.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Tarjetas/

#Terceros
mv biz.aQute.remote.agent.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv commons-beanutils-1.9.2.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv commons-lang3-3.0.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv cxf-core-3.0.3.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv cxf-rt-bindings-soap-3.0.3.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv cxf-rt-bindings-xml-3.0.3.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv cxf-rt-databinding-jaxb-3.0.3.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv cxf-rt-frontend-jaxws-3.0.3.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv cxf-rt-frontend-simple-3.0.3.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv cxf-rt-transports-http-3.0.3.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv cxf-rt-wsdl-3.0.3.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv gson-2.6.2.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv guava-23.0.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv jackson-annotations-2.7.2.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv jackson-core-2.7.2.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv jackson-databind-2.7.2.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv jackson-datatype-jsr310-2.7.2.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv jackson-jaxrs-base-2.7.2.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv jackson-jaxrs-json-provider-2.7.2.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv org.apache.aries.blueprint-1.1.0.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv org.apache.aries.blueprint.annotation.api-1.0.0.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv org.apache.aries.jmx.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv org.apache.aries.jmx.core.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv org.apache.aries.proxy-1.0.1.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv org.apache.aries.util.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv xmlschema-core-2.2.1.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv commons-io-2.5.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv cxf-rt-rs-client-3.1.6.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv javax.annotation-api-1.3.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv lombok-1.16.8.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/


#Comunes

mv bgp-norte-login-theme.war /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv bgp-norte-theme.war /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.check.quantity.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.find.customer.cards.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.find.officer.branch.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.liability.opening.parameters.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.related.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.search.bel.affiliation.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/


#mv com.bgp.norte.ws.client.generic.search.bel.affiliation.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/com.bgp.norte.ws.client.generic.search.bel.affiliation.jar

mv com.bgp.norte.ws.client.rest.rules.opening.account.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.rest.rules.liability.parameters.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.task.si.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.quote.record.reason.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.liability.opening.participant.data.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.liability.opening.limitation.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.manage.liability.opening.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.quote.evaluation.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.evaluation.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.summary.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.record.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.head.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.evaluation.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.find.quote.reasons.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.find.quote.specific.reasons.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.manage.car.procedure.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.change.quote.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.find.user.faculties.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.manage.quote.manipulation.rule.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/ 
mv com.bgp.norte.ws.client.navigation.flow.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.notification.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.notification.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.notification.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.rules.document.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.summary.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.summary.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.document.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.catalog.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.catalog.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.catalog.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.client.details.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/
mv com.bgp.norte.client.search.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.common.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.common.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.common.service.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.find.official.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.find.quote.differences.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.find.quote.participants.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.find.quotes.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.find.summary.car.quote.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.find.user.access.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.find.user.information.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.ldap.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.manage.car.quote.expenses.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.manage.cross.selling.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.manage.quote.additional.info.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.quote.exception.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.quote.exception.support.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.update.quote.status.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.update.revision.date.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.validate.car.quotes.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.validate.car.quotes.stage.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.quote.manage.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.quote.reference.si.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.quote.si.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.reference.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.reference.siv.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.rules.car.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.rules.general.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.sen.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.si.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.task.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.utility.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.permissions.flow.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.find.aprobation.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.find.branch.offices.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.find.car.quote.alerts.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.generate.account.number.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.manage.checkbook.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.manage.customer.accounts.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.manage.quote.address.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/


mv com.bgp.norte.ws.client.generic.manage.requirement.customer.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.rest.rules.liability.catalog.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.quote.alerts.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.alerts.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.client.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.communication.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.communication.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.communication.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.document.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.general.rules.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.general.rules.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.interphase.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.interphase.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.channels.offices.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.create.account.number.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.find.checkbooks.type.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.find.sale.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.generic.manage.liability.opening.document.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.procedure.interphase.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/


mv com.bgp.norte.language.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.find.liability.opening.reasons.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.find.user.cards.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.manage.crs.info.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.manage.customer.pep.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.management.document.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.manage.other.incomes.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.manage.postal.mail.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.manage.regulatory.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.manage.sale.tracking.notes.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.sale.record.reason.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.search.economic.activity.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.search.sale.history.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.update.sale.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.validate.account.number.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/


mv com.bgp.norte.exception.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.exception.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.expenses.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.expenses.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.parameter.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.parameter.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.product.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.product.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.additional.info.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.additional.info.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.record.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.record.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.quote.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.sb.car.catalog.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.sb.car.catalog.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.sb.car.catalog.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.sb.neighborhood.catalog.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.sb.neighborhood.catalog.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.sb.neighborhood.catalog.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.sb.procedure.workflow.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.sb.procedure.workflow.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.sb.procedure.workflow.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.task.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.task.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.user.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.user.office.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.user.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.warning.api.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.warning.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.wizard.web.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Cliente/
mv com.bgp.norte.ws.client.apc.references.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.car.catalog.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.car.parameters.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.catalog.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.common.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.authorize.apc.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.car.quotes.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/


mv com.bgp.norte.ws.client.generic.delete.quote.participant.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.document.quote.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.find.amortization.data.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.find.casacash.info.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.find.credit.reference.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.find.customer.product.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.find.filtered.catalog.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.find.obligation.use.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.credit.card.catalog.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.ws.client.credit.card.parameters.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.campaign.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.credit.card.quotes.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.find.summary.credit.card.quote.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.manage.credit.card.procedure.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.manage.credit.card.quote.expenses.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.manage.credit.card.quote.offer.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.manage.quote.plastic.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.validate.credit.card.quotes.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.rules.credit.card.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.generic.find.cobis.date.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.credit.notification.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.ws.client.send.notification.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/

mv com.bgp.norte.customer.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/
mv com.bgp.norte.employment.service.jar /var/cversiones/pasepruebas/jars/20-03-2018-PASE/Comunes/